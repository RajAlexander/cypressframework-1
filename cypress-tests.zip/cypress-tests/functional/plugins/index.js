// ***********************************************************
// This example plugins/index.js can be used to load plugins
//
// You can change the location of this file or turn off loading
// the plugins file with the 'pluginsFile' configuration option.
//
// You can read more here:
// https://on.cypress.io/plugins-guide
// ***********************************************************

let shouldSkip = false;
const path = require('path');
const fs = require('fs');
const downloadDirectory = path.join(__dirname, '..', 'downloads');
const { install, ensureBrowserFlags } = require('@neuralegion/cypress-har-generator');

module.exports = (on, config) => {
  install(on, config);
  const turbineUrl = config.env.turbineUrl || null;
  const baseUrl = config.env.CYPRESS_baseUrl || null;

  if (baseUrl) {
    config.baseUrl = baseUrl;
  }
  if (turbineUrl) {
    config.turbineUrl = config.env.turbineUrl;
  }

  // Allow cypress.env.json to override any cypress config
  if (config.env.CYPRESS) {
    Object.assign(config, config.env.CYPRESS);
  }

  if (config.baseUrl.endsWith('/')) {
    config.baseUrl = config.baseUrl.replace(/\/$/, '');
  }

  require('cypress-terminal-report/src/installLogsPrinter')(on);
  // register cypress-grep plugin code
  require('cypress-grep/src/plugin')(config);

  on('task', {
    shouldSkip(value) {
      if (value != null) shouldSkip = value;
      return shouldSkip;
    },
    log(message) {
      console.log(message);
      return null;
    },
    clearDownloads() {
      console.log('clearing folder %s', downloadDirectory);
      try {
        if (fs.existsSync(downloadDirectory)) {
          fs.rmdirSync(downloadDirectory, { recursive: true });
          console.log(`${downloadDirectory} is deleted!`);
        }
      } catch (err) {
        console.error(`Error while deleting ${downloadDirectory}.`);
        console.error(err);
      }

      return null;
    }
  });

  if (config.env.ENABLE_COVERAGE_PLUGIN) {
    require('@cypress/code-coverage/task')(on, config);
  }

  on('before:browser:launch', (browser = {}, launchOptions) => {
    ensureBrowserFlags(browser, launchOptions);
    return launchOptions;
  });

  return config;
};

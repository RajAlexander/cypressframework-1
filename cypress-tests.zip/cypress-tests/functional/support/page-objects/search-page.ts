import { verifyPopup3 } from './main-app-objects/common-pieces/popupMessages';

export function validateTableViewNoData(section = true) {
  if (section === false) {
    cy.get('.empty-row').should('exist').should('contain', 'No data to display');
  } else {
    cy.get('.page-count').should('exist').should('contain', '0 total');
  }
}

export function addColumnTableSearchPage(tableColumn) {
  cy.get('.search-page__header').within(() => {
    cy.get('.search-page__header-toolbar')
      .should('exist')
      .find('ngx-button.search-page__header-save-btn')
      .as('saveBtn');
    cy.get('@saveBtn')
      .should('contain', 'Save')
      .within(() => {
        cy.get('button').should('have.attr', 'disabled');
      });
  });
  cy.get('.search-list-columns')
    .find('ngx-dropdown')
    .click()
    .within(() => {
      cy.get('.btn-save').should('be.disabled');
      cy.get('.ngx-input').should('exist').ngxFindNativeInput().should('have.attr', 'placeholder', 'Filter columns...');
      cy.get('ngx-input').ngxFill(tableColumn);
      cy.get('.ngx-checkbox--content').contains(tableColumn).click();
      cy.get('.btn-save').contains('Apply').click();
    });
  cy.get('.datatable-header-cell-wrapper').contains(tableColumn);
}
export function validateReportHeader(reportName = 'Default Report') {
  cy.get('.search-page__header-report-name').should('exist').should('contain', reportName);
}

export function deleteReport(message = 'Report deleted') {
  cy.intercept('DELETE', '/api/reports/**').as('delReport');
  cy.get('ngx-dropdown.dropdown__menu').should('exist').find('button').click();
  cy.get('ul.dropdown__menu-list').find('li').contains('Delete Report').click();
  cy.get('.ngx-dialog-footer').find('button').should('have.length', 2).as('btns');
  cy.get('@btns').first().should('contain', 'Ok').click();
  cy.wait('@delReport').then(intercept => {
    expect(intercept.response.statusCode).to.equal(204);
  });
  verifyPopup3({ subtext: message });
  cy.wait(500); // waiting for table on serachPage
}

export function saveReportAs(reportName, message = 'Report created') {
  cy.intercept('POST', '/api/reports').as('postReport');
  cy.intercept('POST', '/api/search').as('searchReport');
  cy.get('ngx-dropdown.dropdown__menu').should('exist').find('button').click();
  cy.get('ul.dropdown__menu-list').find('li').contains('Save Report As').click();

  cy.get('.ngx-large-format-dialog-content').within(() => {
    cy.get('ngx-input').should('exist').ngxFindLabel().should('contain.text', 'Name');
    cy.get('ngx-input').ngxFill(reportName);
    cy.get('.btn-primary').contains('Save New Report').click();
  });

  cy.wait('@postReport').then(intercept => {
    expect(intercept.response.statusCode).to.equal(
      200,
      intercept.response.hasOwnProperty('error') ? intercept.response.error.text : 'PASS'
    );
  });

  cy.wait('@searchReport').its('response.statusCode').should('eq', 200);

  verifyPopup3({ subtext: message });
  cy.wait(500); // waiting for table on serachPage
}

export function saveTableChanges(message = 'Report updated') {
  cy.intercept('PUT', '/api/reports/**').as('putReport');
  cy.get('.search-page__header-save-btn').contains('Save').click();
  cy.wait('@putReport').then(intercept => {
    expect(intercept.response.statusCode).to.equal(
      200,
      intercept.response.hasOwnProperty('error') ? intercept.response.error.text : 'PASS'
    );
  });
  verifyPopup3({ subtext: message });
}

export function detailsAndSchedules(reportName, defaultReport = true) {
  cy.get('ngx-dropdown.dropdown__menu').should('exist').find('button').click();
  cy.get('ul.dropdown__menu-list').find('li').contains('Details and Schedules').click();
  cy.get('.ngx-drawer-content').within(() => {
    if (defaultReport === false) {
      cy.get('ngx-input').should('exist').ngxFindLabel().should('contain.text', 'Name');
      cy.get('ngx-input').ngxFill(reportName);
      cy.get('.ngx-tab').contains('Permissions').click();
      cy.get('.ngx-toggle-label').click();
      cy.get('.btn-primary').contains('Apply').click();
    } else {
      cy.get('ngx-input').should('not.exist');
      cy.get('.ngx-tab').contains('Permissions').click();
      cy.get('.ngx-toggle-label').should('not.exist');
      cy.get('.btn-primary').contains('Apply').should('be.disabled');
    }
  });
}

// tslint:disable: tsr-detect-non-literal-regexp

const mainEle = 'welcome__container';

export function clickContinue() {
  cy.get('@nextButton').click();
}

export function finish() {
  cy.get('@finishButton').click();
}

export function previous() {
  cy.get('@previousButton').click();
}
export function verifyPage(pageNum: number, username = '') {
  const productName = Cypress.env('productName');
  const details = [
    {
      title: `Welcome to ${productName}, ${username}!`,
      subText: "Let's build new applications to solve security problems.",
      button: 'Start Building',
      rightButton: 'Next'
    },
    {
      title: 'Complete Your Profile',
      subText: `Finish adding the details to complete your ${productName} profile.`,
      button: 'Edit Profile',
      rightButton: 'Next',
      leftButton: 'Previous'
    },
    {
      title: 'Learn More',
      subText: `Jump into the help documentation to learn more about ${productName}.`,
      button: 'View Documentation',
      finishButton: ' Got it! Close help ',
      leftButton: 'Previous'
    }
  ];
  cy.dataCy(mainEle).within(() => {
    cy.dataCy('title__text').should('be.visible').and('contain.text', details[pageNum].title);
    cy.dataCy('sub__text').should('be.visible').and('contain.text', details[pageNum].subText);
    cy.dataCy('action__btn').should('be.visible').and('contain.text', details[pageNum].button);
    if (details[pageNum].hasOwnProperty('rightButton')) {
      cy.dataCy('next__btn')
        .contains(new RegExp(`^\\s*${details[pageNum].rightButton}\\s*$`))
        .should('be.visible')
        .as('nextButton');
    }
    if (details[pageNum].hasOwnProperty('leftButton')) {
      cy.dataCy('previous__btn')
        .contains(new RegExp(`^\\s*${details[pageNum].leftButton}\\s*$`))
        .should('be.visible')
        .as('previousButton');
    }
    if (details[pageNum].hasOwnProperty('finishButton')) {
      cy.dataCy('close__btn')
        .contains(new RegExp(`^\\s*${details[pageNum].finishButton}\\s*$`))
        .should('be.visible')
        .as('finishButton');
    }
  });
}

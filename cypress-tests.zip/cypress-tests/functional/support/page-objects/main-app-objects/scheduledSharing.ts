// tslint:disable: tsr-detect-non-literal-regexp

import { verifyModalConfirmDialogNew, verifyPopup3 } from './common-pieces/popupMessages';
import { setUserGroupValue } from './common-pieces/interactions';
import * as pdfFormatting from './pdfFormatting';
import 'cypress-iframe';

const downloadsFolder = 'functional/downloads';
const path = require('path');
const mainEle = 'schedule-report-dialog';

type DOWNLOAD_OPTIONS = {
  ReportControls?: string[];
  Name?: string;
  Notes?: string;
};

type PREVIEWINFO = {
  Name: string;
  Notes: string;
  reportName: string;
  reportURL?: string;
  url?: string;
};

function downloadFile(downloadOptions: Record<string, any>) {
  setOptions(downloadOptions);

  // click Download Button
  cy.get('ngx-button')
    .contains(/^\s*Download\s*$/)
    .click();
  cy.wait('@getPdfReport').then(xhr => {
    expect(xhr.response.statusCode).to.equal(200);
    const name = String(xhr.response.headers['content-disposition'])
      .split('; ')[2]
      .split('=')[1]
      .replace("UTF-8''", '');
    const downloadedFilename = path.join(downloadsFolder, decodeURIComponent(name));
    cy.readFile(downloadedFilename, 'binary', { timeout: 60000 }).should(buffer => {
      expect(buffer.length).to.be.gt(100);
    });
  });
  if (
    downloadOptions.hasOwnProperty('ReportControls') &&
    downloadOptions.ReportControls.includes('Include Report Table as CSV File Attachment in Download')
  ) {
    cy.wait('@getCsvReport').then(xhr => {
      const downloadedFilename = path.join(
        downloadsFolder,
        String(xhr.response.headers['content-disposition']).split('; ')[1].split('=')[1].replace(/"/g, '')
      );

      cy.readFile(downloadedFilename, 'binary', { timeout: 60000 }).should(buffer => {
        expect(buffer.length).to.be.gt(10);
      });
    });
  }
}

export function downloadReport(downloadOptions: DOWNLOAD_OPTIONS = {}) {
  cy.intercept('POST', '/api/sharing/scheduled/download/pdf').as('getPdfReport');
  cy.intercept('POST', '/api/sharing/scheduled/report/export/csv').as('getCsvReport');

  cy.get(mainEle).within(() => {
    downloadFile(downloadOptions);
  });
}

export function downloadDashboard(downloadOptions: DOWNLOAD_OPTIONS = {}) {
  cy.intercept('POST', '/api/sharing/scheduled/dashboard/export/pdf').as('getPdfReport');
  cy.intercept('POST', '/api/sharing/scheduled/dashboard/export/csv').as('getCsvReport');

  cy.get(mainEle).within(() => {
    downloadFile(downloadOptions);
  });
}

export function closeDialog(saveChanges: boolean | string = false) {
  cy.get(mainEle)
    .find('div.dialog-close button')
    .contains(new RegExp(`^\\s*${saveChanges === false ? 'Close' : 'Cancel'}\\s*$`))
    .click();
  if (saveChanges !== false) {
    verifyModalConfirmDialogNew('You have unsaved changes.', 'Are you sure you want to leave?', String(saveChanges));
  }
  cy.get(mainEle).should('not.exist');
}

export function closeDialogNoSave() {
  cy.get(mainEle).find('div.dialog-close').click();
}

export function clickSave(isDashboard = false) {
  cy.intercept('POST', `/api/scheduled${isDashboard ? '/dashboard' : ''}`).as('postSchedule');

  cy.get(mainEle)
    .find('ngx-button')
    .contains(/^\s*Save Schedule\s*$/)
    .click();
  cy.wait('@postSchedule').its('response.statusCode').should('eq', 200);
  if (isDashboard) {
    verifyPopup3({
      subtext: 'Dashboard Schedule Enabled, Saved and Added to Dashboard Settings and Schedules'
    });
  } else {
    verifyPopup3({
      subtext: 'Report Schedule Enabled, Saved and Added to Report Details and Schedules'
    });
  }
}

export function clickSendNow(isDashboard = false) {
  cy.intercept('POST', '/api/sharing/scheduled/*').as('postSendSchedule');

  cy.get(mainEle)
    .find('ngx-button')
    .contains(/^\s*Send Now\s*$/)
    .click();
  cy.wait('@postSendSchedule').its('response.statusCode').should('eq', 204);
  if (isDashboard) {
    verifyPopup3({
      subtext: 'Your dashboard report is processing and the email will be sent momentarily'
    });
  } else {
    verifyPopup3({
      subtest: 'Your report is processing and the email will be sent momentarily'
    });
  }
}

export function setReportSharing(newSettings: Record<string, any>) {
  // verify all the expected settings from default or saved scheduler.
  cy.get(mainEle).within(() => {
    setOptions(newSettings);
  });
}

export function verifySettings(expectedSettings: Record<string, any>) {
  // verify all the expected settings from default or saved scheduler.
  cy.get(mainEle).within(() => {
    cy.get('.dialog-header p').should('have.text', expectedSettings.report);

    if (expectedSettings.hasOwnProperty('disabled')) {
      cy.getByName('schedule-enable').ngxGetValue().should('eq', !expectedSettings.disabled);
    }
    cy.getByLabel('Name').ngxGetValue().should('eq', expectedSettings.Name.substring(0, 64));
    cy.getByLabel('Notes').ngxGetValue().should('eq', expectedSettings.Notes);
    if (expectedSettings.hasOwnProperty('Recipients')) {
      cy.getByLabel('Recipients').within(() => {
        if (expectedSettings.Recipients.length > 0) {
          cy.get('ul.ngx-select-input-list')
            .find('li.ngx-select-input-option')
            .should('have.length', expectedSettings.Recipients.length)
            .each(inputname => {
              cy.wrap(inputname).its('0.textContent').should('be.oneOf', expectedSettings.Recipients);
            });
        } else {
          cy.get('.ngx-select-input-box ul').should('not.exist');
        }
      });
    }
    if (expectedSettings.hasOwnProperty('ReportControls')) {
      cy.get('.report-controls')
        .find('ngx-checkbox')
        .each(checkbox => {
          cy.wrap(checkbox)
            .its('0.innerText')
            .then(textLabel => {
              if (expectedSettings.ReportControls.includes(textLabel.trim())) {
                cy.wrap(checkbox).find('input').should('be.checked');
              } else {
                cy.wrap(checkbox).find('input').should('not.be.checked');
              }
            });
        });
    }
    if (expectedSettings.hasOwnProperty('Schedule')) {
      cy.get('.schedule-time-content').within(() => {
        cy.get('ngx-radiobutton')
          .contains(new RegExp(`^\\s*${expectedSettings.Schedule.type}\\s*$`))
          .find('input')
          .should('be.checked');
        if (expectedSettings.Schedule.type == 'Recurring') {
          cy.get('ngx-button.btn-primary')
            .its('0.innerText')
            .should('match', new RegExp(`^\\s*${expectedSettings.Schedule.frequency}\\s*$`));
          cy.get('ngx-date-time input').should('have.value', expectedSettings.Schedule.time);
          if (expectedSettings.Schedule.frequency == 'Weekly') {
            cy.get('ngx-select-input li span').should('have.text', expectedSettings.Schedule.dayOfWeek);
          }
          if (expectedSettings.Schedule.frequency == 'Monthly') {
            cy.get('ngx-input input').should('have.value', expectedSettings.Schedule.dayOfMonth);
          }
        } else {
          cy.get('div.ngx-calendar-container').within(() => {
            let dateTime = '';
            cy.get('.day-container button.active')
              .invoke('attr', 'title')
              .then(title => {
                dateTime += title;
              });
            cy.get('#undefined-hour')
              .its('0.value')
              .then(value => {
                dateTime += ` ${value}`;
              });
            cy.get('#undefined-minute')
              .its('0.value')
              .then(value => {
                dateTime += `:${value}`;
              });
            cy.get('button.ampm.selected')
              .its('0.textContent')
              .then(value => {
                dateTime += ` ${value}`;
                expect(new Date(dateTime).toString()).to.equal(expectedSettings.Schedule.dateTime);
              });
          });
        }
      });
    }
    if (expectedSettings.hasOwnProperty('save')) {
      cy.get('ngx-button')
        .contains(/^\s*Save Schedule\s*$/)
        .should('be.visible')
        .and(expectedSettings.save ? 'be.enabled' : 'be.disabled');
    }
    if (expectedSettings.hasOwnProperty('send')) {
      cy.get('ngx-button')
        .contains(/^\s*Send Now\s*$/)
        .should('be.visible')
        .and(expectedSettings.send ? 'be.enabled' : 'be.disabled');
    }
    if (expectedSettings.hasOwnProperty('download')) {
      cy.get('ngx-button')
        .contains(/^\s*Download\s*$/)
        .should('be.visible')
        .and(expectedSettings.download ? 'be.enabled' : 'be.disabled');
    }
  });
}

export function verifyReportPreview(previewInfo: PREVIEWINFO) {
  cy.get('.print-preview-container').within(() => {
    cy.frameLoaded();
    cy.iframe().within(() => {
      cy.get('.header').within(() => {
        cy.get('p').contains(previewInfo.Name);
        cy.get('p').contains(previewInfo.Notes);
      });
      cy.get('.section').within(() => {
        cy.get('span').contains(previewInfo.reportName);
        cy.get('chart').should('be.visible');
      });
      if (previewInfo.hasOwnProperty('url')) {
        cy.get('.footer a').contains(previewInfo.url);
      }
    });
  });
}

export function verifyDashboardPreviewCards(previewCards: string[]) {
  cy.get('.print-preview-container').within(() => {
    cy.get('div.dashboard').within(() => {
      cy.get('gridster-item').then(reports => {
        expect(reports).to.have.lengthOf(previewCards.length);
        cy.wrap(reports).each(report => {
          cy.wrap(report)
            .find('.card-title')
            .its('0.innerText')
            .then(cardName => {
              expect(cardName.trim()).to.be.oneOf(previewCards);
            });
        });
      });
    });
  });
}

export function verifyPageOrientation(orientation: string) {
  cy.get(mainEle).within(() => {
    pdfFormatting.verifyPageOrientation(orientation);
  });
}

export function verifyHeaderCode(headerCode: string) {
  cy.get(mainEle).within(() => {
    pdfFormatting.checkHTMLCode('Header', headerCode);
  });
}

export function verifyFooterCode(footerCode: string) {
  cy.get(mainEle).within(() => {
    pdfFormatting.checkHTMLCode('Footer', footerCode);
  });
}

export function setFooterCode(htmlCode: string) {
  const alias = 'buildReport' + Math.random();
  cy.intercept('POST', '/scheduled-reports/report').as(alias);
  cy.get(mainEle).within(() => {
    pdfFormatting.setHTMLCode('Footer', htmlCode);
  });
  cy.wait(`@${alias}`).its('response.statusCode').should('eq', 200);
}

export function setHeaderCode(htmlCode: string) {
  const alias = 'buildReport' + Math.random();
  cy.intercept('POST', '/scheduled-reports/report').as(alias);
  cy.get(mainEle).within(() => {
    pdfFormatting.setHTMLCode('Header', htmlCode);
  });
  cy.wait(`@${alias}`).its('response.statusCode').should('eq', 200);
}

export function revertHeaderCodeToSettings() {
  const alias = 'buildReport' + Math.random();
  cy.intercept('POST', '/scheduled-reports/report').as(alias);
  cy.get(mainEle).within(() => {
    pdfFormatting.revertToSettings();
  });
  cy.wait(`@${alias}`).its('response.statusCode').should('eq', 200);
}

export function setPageOrientation(orientation: string) {
  const alias = 'buildReport' + Math.random();
  cy.intercept('POST', '/scheduled-reports/report').as(alias);
  cy.get(mainEle).within(() => {
    pdfFormatting.setPageOrientation(orientation);
  });
  cy.wait(`@${alias}`).its('response.statusCode').should('eq', 200);
}

export function setOptions(theOptions: Record<string, any>, isDashboard = true) {
  cy.intercept('GET', '/api/user/search?**').as('getUsers');
  cy.intercept('GET', '/api/groups/lookup?**').as('getGroups');
  cy.intercept('POST', '/scheduled-reports/report').as('buildReport');

  Object.keys(theOptions).forEach(key => {
    switch (key) {
      case 'disabled':
        cy.getByName('schedule-enable')[theOptions.disabled ? 'uncheck' : 'check']();
        break;
      case 'Name':
      case 'Notes':
        cy.getByLabel(key).ngxFill(theOptions[key]);
        if (isDashboard) {
          // noop
        } else {
          cy.wait('@buildReport').its('response.statusCode').should('eq', 200);
          cy.wait(500);
        }
        break;
      case 'Recipients':
        if (theOptions.Recipients.hasOwnProperty('emails')) {
          theOptions.Recipients.emails.forEach((email: string) => {
            cy.getByLabel('Recipients').click('right');
            cy.get('.ngx-select-filter-input').type(email);
            cy.wait(['@getUsers', '@getGroups']);
            cy.get('.ngx-select-empty-placeholder-add').click();
          });
        }
        if (theOptions.Recipients.hasOwnProperty('userGroups')) {
          theOptions.Recipients.userGroups.forEach($selectValue => {
            setUserGroupValue($selectValue, 'multi', ['@getUsers', '@getGroups'], `[label="Recipients"]`);
          });
        }
        break;
      case 'ReportControls':
        cy.get('.report-controls')
          .find('ngx-checkbox')
          .each(checkbox => {
            cy.wrap(checkbox)
              .its('0.innerText')
              .then(textLabel => {
                cy.wrap(checkbox)[theOptions.ReportControls.includes(textLabel.trim()) ? 'check' : 'uncheck']();
              });
          });
        break;
      case 'Schedule':
        cy.get('.schedule-time-content')
          .scrollIntoView()
          .within(() => {
            cy.get('ngx-radiobutton')
              .contains(new RegExp(`^\\s*${theOptions.Schedule.type}\\s*$`))
              .closest('ngx-radiobutton')
              .check();
            if (theOptions.Schedule.type === 'Recurring') {
              cy.get('ngx-button')
                .contains(new RegExp(`^\\s*${theOptions.Schedule.frequency}\\s*$`))
                .click();
              cy.get('ngx-date-time input').ngxFill(theOptions.Schedule.time);
              if (theOptions.Schedule.frequency === 'Weekly') {
                // cy.get('ngx-select-input').should('have.value', newSettings.Schedule.dayOfWeek);
              }
              if (theOptions.Schedule.frequency === 'Monthly') {
                // cy.get('ngx-input input').should('have.value', newSettings.Schedule.dayOfMonth);
              }
            } else {
              // This is for one time sending.
              // dateTime
              const targetDate = new Date(theOptions.Schedule.dateTime);
              cy.get('ngx-calendar').within(() => {
                cy.get('button.title')
                  .its('0.textContent')
                  .then(monthYear => {
                    const currentMonth = new Date(monthYear);
                    const monthsToSkip =
                      (targetDate.getFullYear() - currentMonth.getFullYear()) * 12 -
                      (currentMonth.getMonth() - targetDate.getMonth());
                    const directionEle = monthsToSkip > 0 ? 'button.next-month' : 'button.prev-month';
                    for (let step = 0; step < Math.abs(monthsToSkip); step++) {
                      cy.get('.title-row').find(directionEle).click();
                    }
                  });
                cy.get('button.title')
                  .its('0.textContent')
                  .then(monthYear => {
                    monthYear = monthYear.trim().replace(' ', ` ${targetDate.getDate()}, `);
                    cy.get('.day-container')
                      .find(`button.day[title="${monthYear}"]`)
                      .contains(new RegExp(`^\\s*${targetDate.getDate()}\\s*$`))
                      .click();
                  });
              });
              const theHour = targetDate.getHours();
              if (theHour < 12) {
                cy.get('button')
                  .contains(/^\s*AM\s*$/)
                  .click();
                cy.get('#undefined-hour').ngxFill(theHour === 0 ? '12' : String(theHour));
              } else {
                cy.get('button')
                  .contains(/^\s*PM\s*$/)
                  .click();
                cy.get('#undefined-hour').ngxFill(String(theHour === 12 ? theHour : theHour - 12));
              }
              cy.get('#undefined-minute').ngxFill(String(targetDate.getMinutes()));
            }
          });
        break;
      case 'ReportCards':
        cy.get('.dashboard-elements')
          .scrollIntoView()
          .within(() => {
            Object.keys(theOptions.ReportCards).forEach(report => {
              // cy.log(Object.keys(theOptions.ReportCards));
              cy.get('li')
                .contains(new RegExp(`^\\s*${report}\\s*$`))
                .closest('ngx-checkbox')
                [theOptions.ReportCards[report] ? 'check' : 'uncheck']();
            });
          });
        break;
    }
  });
}

// tslint:disable: tsr-detect-non-literal-regexp

import { verifyDoubleCheck, verifyPopup3 } from './common-pieces/popupMessages';
import { escapeForRegex } from './common-pieces/common-calls';

const dashboardsListing = '[data-cy=dashboards-listing__section]';

export function deleteDashboard(dashboardName: string) {
  cy.intercept('DELETE', '/api/dashboard/**').as('delDashboard');

  cy.get(dashboardsListing)
    .should('be.visible')
    .within(() => {
      cy.get('datatable-body-cell')
        .contains(new RegExp(`^\\s*${escapeForRegex(dashboardName)}\\s*$`))
        .closest('datatable-body-row')
        .find('i.ngx-trash')
        .click();
    });

  verifyDoubleCheck(
    'Are you sure?',
    `You are about to delete this dashboard: '${dashboardName}'. Do you want to continue?`
  );
  cy.wait('@delDashboard').its('response.statusCode').should('eq', 204);
  verifyPopup3({ subtext: 'Dashboard deleted' });
}

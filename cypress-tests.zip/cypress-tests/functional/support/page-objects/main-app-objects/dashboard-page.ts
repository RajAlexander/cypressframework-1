// tslint:disable: tsr-detect-non-literal-regexp

import * as editDashboardDialog from './editDashboardDialog';
import * as scheduledSharingEditor from './scheduledSharing';
import { verifyElements as verifyRecordListing } from './app-list-all';
import { verifyPopup3 } from './common-pieces/popupMessages';

export { editDashboardDialog, scheduledSharingEditor };

const dashboardListingElement = '[data-cy=dashboard-cards__layout]';
const dashboardControls = '[data-cy=dashboard__controls]';
const dashboardMenu = '[data-cy=workspace__menu]';

export function verifyElements() {
  cy.get(dashboardListingElement, { timeout: 50000 });
}

export function clickMenuItem(itemName: string) {
  cy.get(dashboardControls).within(() => {
    cy.get('i.ngx-icon.ngx.ngx-dots-vert-round.ng-star-inserted').click();
    cy.get('ngx-dropdown-menu.align-right.ngx-dropdown-menu')
      .contains(new RegExp(`\\s*${itemName}\\s*$`))
      .click();
  });
}

export function editDashboard() {
  cy.intercept('GET', '/api/scheduled/dashboard/**').as('getSchedDashboard');

  cy.get(dashboardControls).within(() => {
    cy.get(dashboardMenu).click();
    cy.get('li')
      .contains(/^\s*Settings and Schedules\s*$/)
      .click();
  });

  cy.wait('@getSchedDashboard').its('response.statusCode').should('eq', 200);
}

export function verifyWorkspace(workspaceName: string) {
  cy.url().should('match', /\/workspace\/[a-zA-Z0-9_]{15,24}\/$/);
  cy.get('[data-cy=workspace__title]')
    .contains(new RegExp(`^\\s*${workspaceName}\\s*$`))
    .should('be.visible');
}

export function verifyDashboard(dashboardName: string) {
  cy.url().should(
    'match',
    // tslint:disable-next-line: tsr-detect-unsafe-regexp
    /\/workspace\/[a-zA-Z0-9_]{15,24}\/[a-zA-Z0-9_]{15,24}(\/[a-zA-Z0-9_]{15,24}\/[a-zA-Z0-9_]{15,24})?$/
  );
  cy.get('[data-cy=dashboard__title]')
    .contains(new RegExp(`^\\s*${dashboardName}\\s*$`))
    .should('be.visible');
}

export function createDashboardOnEmpty() {
  cy.get('[data-cy=create_dashboard__btn]')
    .contains(/^\s*Create Dashboard\s*$/)
    .click();
}

export function addCard() {
  cy.get(dashboardControls).find('[data-cy=new-card_btn]').click();
}

export function save() {
  cy.intercept('PUT', '/api/dashboard/**').as('putDashboard');
  cy.get(dashboardControls).find('li state-save-button').click();
  cy.wait('@putDashboard').its('response.statusCode').should('eq', 200);
  // This text is in the Body, not the title...
  verifyPopup3({ subtext: 'Dashboard updated' });
}

export function selectCardChartItem(cardName: string, chartValue: string) {
  cy.intercept('POST', '/api/search/').as('recordsSearch');

  cy.get(dashboardListingElement)
    .find(`div.card-title`)
    .contains(new RegExp(`^\\s*${cardName}\\s*$`))
    .closest('dashboard-item')
    .find(`path.bar[aria-label~=${chartValue}]`)
    .click();
  cy.wait('@recordsSearch').its('response.statusCode').should('eq', 200);
  verifyRecordListing();
}

export function verifyCard(cardName: string, index = null) {
  let elementIndex = '';
  switch (String(index).toLocaleLowerCase()) {
    case 'last':
      elementIndex = ':last-of-type';
      break;
    case 'first':
      elementIndex = ':first-of-type';
      break;
    case 'null':
      break;
    default:
      elementIndex = `:nth-of-type(${index})`;
  }
  cy.get('gridster.dashboard-grid').within(() => {
    cy.get(`gridster-item${elementIndex}`)
      .find('div.card-title')
      .contains(new RegExp(`^\\s*${cardName}\\s*$`));
  });
}

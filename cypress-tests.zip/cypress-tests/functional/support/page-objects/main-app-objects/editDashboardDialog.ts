// tslint:disable: tsr-detect-non-literal-regexp

import { escapeForRegex } from './common-pieces/common-calls';
import { verifyDoubleCheck, verifyPopup3 } from './common-pieces/popupMessages';

const mainElement = '.update-dashboard';

function openSchedulesTab(action: any) {
  cy.get(mainElement)
    .find('dashboard-form')
    .within(() => {
      cy.get('ngx-tabs')
        .find('button')
        .contains(/^\s*Schedules\s*$/)
        .click();
      action();
    });
}

export function editScheduledDialogReport(reportName: string) {
  cy.intercept('GET', '/api/reports/*').as('getSchedule');
  cy.intercept('GET', '/api/settings/schedule').as('getSettings');
  cy.intercept('GET', '/api/app/*').as('getApp');
  cy.intercept('POST', '/api/search/').as('getSearch');

  openSchedulesTab(() => {
    cy.get('div.card')
      .contains(new RegExp(`^\\s*${escapeForRegex(reportName)}\\s*$`))
      .closest('div.card--actions')
      .find('i.ngx-edit')
      .click();
    cy.wait(['@getSchedule', '@getSettings', '@getApp', '@getSearch']).then(intercepts => {
      intercepts.forEach(apiCall => expect(apiCall.response.statusCode).to.equal(200));
    });
  });
}

export function close() {
  cy.get(mainElement).find('button.close').click();
  cy.get(mainElement).should('not.exist', { timeout: 1000 });
}

export function deleteScheduledDashboardReport(reportName: string, continueAction = true) {
  openSchedulesTab(() => {
    cy.get('div.card')
      .contains(new RegExp(`^\\s*${escapeForRegex(reportName)}\\s*$`))
      .closest('div.card--actions')
      .find('i.ngx-trash')
      .click();
  });
  verifyDoubleCheck('Delete Schedule?', 'Are you sure you want to delete this schedule?', continueAction, 'Delete');
  verifyPopup3({ subtext: 'Dashboard Schedule Deleted' });
}

export function verifySchedulesListed(reportList: string[]) {
  openSchedulesTab(() => {
    if (reportList.length > 0) {
      cy.get('div.card').then(schedules => {
        cy.wrap(schedules)
          .should('have.length', reportList.length)
          .withinEach($el => {
            cy.get('label.ellipse').then($el => {
              expect($el.text().trim()).to.be.oneOf(reportList);
            });
          });
      });
    }
  });
}

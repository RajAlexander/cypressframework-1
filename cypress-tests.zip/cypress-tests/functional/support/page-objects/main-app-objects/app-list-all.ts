// tslint:disable: tsr-detect-non-literal-regexp

import { verifyPopup } from './common-pieces/popupMessages';
import { escapeForRegex, interactWithDropdownChooser } from './common-pieces/common-calls';
import { typeInField } from './common-pieces/interactions';
import * as editReportDialog from './editReportDialog';
import * as scheduledSharingEditor from './scheduledSharing';

export { editReportDialog, scheduledSharingEditor };

const toolbarElement = '[data-cy=app-records__toolbar]';
const RecordsListingElement = '[data-cy=app-records__listing]';
const chartBuilder = '[data-cy=chart-builder__section]';

export function verifyElements(reportName = null) {
  cy.get(RecordsListingElement).find('div.progress-linear.ng-hide', {
    timeout: 50000
  });
  if (reportName !== null) {
    cy.get(toolbarElement)
      .contains('span', new RegExp(`^\\s*${reportName}\\s*$`))
      .should('exist');
  }
}

function getRecord(recordID: string) {
  cy.get(RecordsListingElement)
    .contains('.dt-cell-content', new RegExp(`^\\s*${escapeForRegex(recordID)}\\s*$`))
    .scrollIntoView()
    .as('recordTarget');
}

export function openRecord(recordID: string) {
  cy.intercept('GET', '/api/app/**/record/**').as('getRecord');
  cy.intercept('GET', '/api/workflow/**').as('processWorkflow');

  cy.wait(2000);
  getRecord(recordID);
  cy.get('@recordTarget').click();
  cy.wait(['@getRecord', '@processWorkflow']);
}

export function openFirstRecord() {
  cy.intercept('GET', '/api/app/**/record/**').as('getRecord');
  cy.intercept('GET', '/api/workflow/**').as('processWorkflow');

  cy.get(`${RecordsListingElement} .dt-row-center .dt-cell-content`).first().should('be.visible').click();
  cy.wait(['@getRecord', '@processWorkflow']);
}

export function openRecordWorkflowResults(recordID: string, workflowStatus = 'status-success') {
  getRecord(recordID);
  cy.get('@recordTarget')
    .closest('.dt-row')
    .find(`span .workflow-status .${workflowStatus}`)
    .should('be.visible')
    .click();
}

export function openCreatedRecordWorkflowResults(
  appName,
  conditionName,
  actionName,
  rootNodeStatus = 'run',
  runStatus = 'run',
  actionStatus = 'run-success'
) {
  cy.get('.nodes')
    .find('.node-group')
    .within(() => {
      cy.get('.root')
        .should('have.class', `${rootNodeStatus}`)
        .find('.node-type')
        .contains(/^\s*start\s*$/)
        .siblings('.node-label')
        .contains(new RegExp(`^\\s*${escapeForRegex(appName.slice(0, 25))}...\\s*$`));
      cy.get('.stage')
        .should('have.class', `${runStatus}`)
        .find('.node-label')
        .contains(new RegExp(`^\\s*${conditionName}\\s*$`))
        .siblings('.node-type')
        .contains(/^\s*condition\s*$/);
      cy.get('.action')
        .should('have.class', `${actionStatus}`)
        .find('.node-label')
        .contains(new RegExp(`^\\s*${actionName}\\s*$`))
        .siblings('.node-type')
        .contains(/^\s*action\s*$/);
    });
}

export function closeRecordWindow() {
  // Have to use the force here
  cy.get('.stacks-backdrop').click('topLeft', { force: true });
}

export function showRecordList(appName: string) {
  cy.get('.sub-nav-item')
    .find('.subnav-label')
    .contains(new RegExp(`^\\s*${escapeForRegex(appName)}\\s*$`))
    .click();
}

export function toggleShowRecordFields(fieldNames: string[]) {
  cy.intercept('POST', '/api/search').as('recordSearch');

  cy.get(RecordsListingElement)
    .find('div.column-dropdown')
    .click()
    .within(() => {
      fieldNames.forEach($fieldName => {
        cy.get('span')
          .contains(new RegExp(`^\\s*${escapeForRegex($fieldName)}\\s*$`))
          .scrollIntoView()
          .click();
      });
      cy.get('button')
        .contains(/^\s*Apply\s*$/)
        .should('be.visible')
        .click();
    });
  cy.wait('@recordSearch');
  verifyElements();
}

export function getRecordCount() {
  return cy
    .get(RecordsListingElement)
    .find('div.page-count')
    .should('be.visible')
    .its('0.innerText')
    .then($pageCount => {
      return parseInt($pageCount.split(' ')[0], 10);
    });
}

export function openCharts() {
  cy.get(toolbarElement)
    .find('span')
    .contains(/^\s*Charts\s*$/)
    .click();
  cy.get(chartBuilder).should('be.visible');
}

export function closeCharts() {
  cy.get(toolbarElement)
    .find('span')
    .contains(/^\s*Charts\s*$/)
    .click();
  cy.get(chartBuilder).should('not.exist');
}

export function buildChart(measure: string, dimensions: string | string[], chartType = '') {
  cy.get(chartBuilder).within(() => {
    cy.get('div.measure-list span')
      .contains(new RegExp(`^\\s*${escapeForRegex(measure)}\\s*$`))
      .parents('a.handle')
      .siblings('a.add-button')
      .scrollIntoView()
      .click();
    cy.get('div.dimension-list').as('dimensionsItems');
    if (Array.isArray(dimensions)) {
      dimensions.forEach($dimension => {
        cy.get('@dimensionsItems')
          .find('span')
          .contains(new RegExp(`^\\s*${escapeForRegex($dimension)}\\s*$`))
          .parents('a.handle')
          .siblings('a.add-button')
          .scrollIntoView()
          .click();
      });
    } else {
      cy.get('@dimensionsItems')
        .find('span')
        .contains(new RegExp(`^\\s*${escapeForRegex(dimensions)}\\s*$`))
        .parents('a.handle')
        .siblings('a.add-button')
        .scrollIntoView()
        .click();
    }
    cy.get('div.viz-container').scrollIntoView();
  });
}

export function saveReportAs(
  reportName: string,
  createNewReport = true,
  reportPermissions = null,
  autoCreateDashboardCard = null
) {
  cy.intercept('POST', '/api/reports').as('postReports');

  cy.get(toolbarElement).within(() => {
    cy.get('a.dropdown-toggle').click();
    cy.get('ul.dropdown-menu span')
      .contains(/^\s*Save Report As\s*$/)
      .click();
  });

  cy.get('div.SaveReportController')
    .should('be.visible')
    .within(() => {
      cy.get('div.page-toolbar').as('saveReportToolbar');
      cy.get('@saveReportToolbar').find('h4').should('have.text', 'Save Report As');
      cy.get('ul.nav-tabs li.active').should('have.attr', 'heading', 'General');
      cy.get('div.form-group').contains('Save As').as('reportSelector');
      cy.get('@reportSelector').siblings('div.ui-select-container').as('saveAsSelector');
      if (createNewReport) {
        interactWithDropdownChooser('@saveAsSelector', 'New Report');
        cy.get('div.form-group')
          .contains('Name')
          .then($reportNameInput => {
            cy.wrap($reportNameInput)
              .siblings('input#new-name')
              // THIS IS OLD ANGULAR 1
              .then($inputEle => {
                typeInField($inputEle, reportName);
              });
          });
        if (autoCreateDashboardCard !== null) {
          cy.get('toggle#createCard').click();
          cy.get('div')
            .contains(/^\s*Dashboard\s*$/)
            .closest('div.form-group')
            .find('.ui-select-container')
            .click()
            .within(() => {
              cy.get('li')
                .contains(new RegExp(`^\\s*${autoCreateDashboardCard}\\s*$`))
                .click();
            });
        }
      } else {
        interactWithDropdownChooser('@saveAsSelector', 'Existing Report');
        cy.get('@reportSelector').find("div[name='report']").as('reportChooser');
        interactWithDropdownChooser('@reportChooser', reportName);
      }
      if (reportPermissions != null) {
        cy.get('ul.nav-tabs li[heading=Permissions]').click();
        reportPermissions.forEach(role => {
          // Could use fill if we had the option to NOT blur
          cy.get('input[placeholder="Add roles..."]').click().type(role.name);
          cy.get('li')
            .contains(new RegExp(`^\\s*${escapeForRegex(role.name)}\\s*$`))
            .scrollIntoView()
            .click();
          cy.get('button').contains('Add').click();
          cy.get('table.permissions-table').within(() => {
            cy.get('td')
              .contains(role.name)
              .closest('tr')
              .within(() => {
                Object.keys(role.permissions).forEach(permission => {
                  //  Force the check/uncheck because it is hidden, and that is expected.
                  if (role.permissions[permission]) {
                    cy.get(`input[data-cy=${permission}]`).check({
                      force: true
                    });
                  } else {
                    cy.get(`input[data-cy=${permission}] `).uncheck({
                      force: true
                    });
                  }
                });
              });
          });
        });
      }
      cy.get('@saveReportToolbar').find('span.ngx-check').click();
    });

  cy.wait('@postReports').its('response.statusCode').should('eq', 200);
  verifyPopup(createNewReport ? 'Report created' : 'Report updated');
}

export function saveReport() {
  cy.intercept('PUT', '/api/reports/**').as('reportSave');

  cy.get(toolbarElement).within(() => {
    cy.get('a.dropdown-toggle').click();
    cy.get('ul.dropdown-menu span')
      .contains(/^\s*Save Report\s*$/)
      .click();
  });
  cy.wait('@reportSave').its('response.statusCode').should('eq', 200);

  verifyPopup('Report and its scheduled reports have been updated');
}

export function verifyFilters(filterlist: string[]) {
  cy.get(toolbarElement).within(() => {
    filterlist.forEach($filterText => {
      cy.get('span')
        .contains(new RegExp(`^\\s*${escapeForRegex($filterText)}\\s*$`))
        .should('exist');
    });
  });
}

export function clickMenuItem(itemName: string | number | RegExp) {
  cy.intercept('POST', '/scheduled-reports/report').as('buildReport');
  cy.get(toolbarElement).within(() => {
    cy.get('a.dropdown-toggle').click();
    cy.get('ul.dropdown-menu share-report-dropdown-option button').contains(itemName).click();
    cy.wait('@buildReport').its('response.statusCode').should('eq', 200);
  });
}

export function editReport() {
  cy.intercept('GET', '/api/reports/app/**').as('getReport');
  cy.intercept('GET', '/api/scheduled/report/**').as('getSchedReport');
  cy.intercept('GET', '/api/roles/light').as('getRolesLight');

  cy.get(toolbarElement).within(() => {
    cy.get('a.dropdown-toggle.ngx-icon.ngx-dots-vert').click();
    cy.get('ul.dropdown-menu span')
      .contains(/^\s*Details and Schedules\s*$/)
      .click();
  });

  cy.wait(['@getReport', '@getSchedReport', '@getRolesLight']);
}

export function clickRefresh() {
  cy.intercept('POST', '/api/search/').as('getRecords');
  cy.get('.refresh-button-container').click();
  cy.wait('@getRecords');
  verifyElements();
}

export function validateSortingSearchPage(columnName, columnValue) {
  cy.get('.datatable-header-cell-label').contains(columnName).click();
  cy.get('.datatable-row-wrapper').eq(0).should('contain', columnValue);
}

export function setAddRemoveColumsValue(columnName) {
  cy.get('button.dropdown-toggle').click();
  cy.get('div.dropdown-menu').within(() => {
    cy.get('span').contains(columnName).click();
    cy.get('button').contains('Apply').click();
  });
}

export function recordFilter(filterValue, operatorValue, days, time) {
  // Set Previous day Filter selection
  cy.get('div.filter-bar').click();
  cy.get('.filter-menu').within(() => {
    cy.get('span').contains(filterValue).click();
    cy.get('a[aria-label="Select box select"]').first().click();
    if (operatorValue == 'Previous') {
      cy.get('li.ui-select-choices-group')
        .first()
        .contains(operatorValue)
        .then(option => {
          option[0].click();
          cy.get('a[aria-label="Select box select"]').first().contains(operatorValue);
        });
      cy.get('input[ng-model="filter.value"]').type(days);
      cy.get('a[aria-label="Select box select"]').last().click();
      cy.get('li.ui-select-choices-group')
        .last()
        .contains(time)
        .then(option => {
          option[0].click();
          cy.get('a[aria-label="Select box select"]').last().contains(time);
          cy.get('button').contains('Apply').click();
        });
    }
  });
}

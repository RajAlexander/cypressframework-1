// tslint:disable: tsr-detect-non-literal-regexp

import { verifyPopup, verifyPopup3 } from './common-pieces/popupMessages';
import { typeInField } from './common-pieces/interactions';

const recordEditor = 'app-record';

export function save(
  message = 'Record created',
  expectRefUpdate = false,
  recordClosed = false,
  isWidget = false,
  isCalculated = false
) {
  cy.intercept('PUT', '/api/app/**/record').as('putRecord');
  cy.intercept('GET', '/api/app/**/record/**').as('getRecord');
  cy.intercept('GET', '/api/workflow/**').as('getWorkflow');
  cy.intercept('POST', '/api/app/**/record').as('postRecord');
  cy.intercept('POST', '/api/app/**/record/**/calc').as('postCalc');
  cy.intercept('GET', '/api/history/**').as('getHistory');

  cy.get(recordEditor)
    .find('.record-state__toolbar')
    .contains('ngx-button', /^\s*Save\s*$/)
    .click();

  if (message === 'Record created') {
    cy.wait('@postRecord').its('response.statusCode', { timeout: 500 }).should('eq', 200);
    if (recordClosed === false) {
      cy.wait('@getRecord');
    }
  } else if (message === 'The record has validation error(s)!') {
    // There are no API calls going out, so nothing to wait on.
  } else {
    cy.wait('@putRecord').its('response.statusCode', { timeout: 500 }).should('eq', 200);
  }

  verifyPopup3({ subtext: message });
  if (isCalculated === true) {
    cy.wait('@postCalc').its('response.statusCode', { timeout: 500 }).should('eq', 200);
    cy.wait('@getHistory').its('response.statusCode', { timeout: 500 }).should('eq', 200);
  }

  if (expectRefUpdate === true) {
    waitForRefUpdate();
  }

  if (isWidget === false) {
    if (message === 'Record saved') {
      cy.get('ui-view').find('a.btn').its('0.innerText').should('not.equal', 'New Record');
    }
  }
}

export function setFieldValue(fieldValuesJSON: Record<string, any>, isGridType?: boolean) {
  cy.intercept('POST', '/api/app/**/record/**/calc').as('postCalculated');
  cy.intercept('POST', '/api/app/**/record/**/unique/**').as('postUnique');
  cy.intercept('POST', '/api/app/**/record/**/references').as('postReferences');

  for (const key of Object.keys(fieldValuesJSON)) {
    cy.get(recordEditor).within(() => {
      if (key.includes('Rich Text')) {
        cy.getByLabel(key)
          .closest('.text-field__rte-container')
          .scrollIntoView()
          .within(() => {
            cy.getRTE().focus().type(fieldValuesJSON[key]['value']).blur();
          });
      } else if (key.includes('Selection')) {
        cy.getByLabel(key).within(() => {
          cy.get('div.ngx-select-input-box__controls button').click();
          cy.get('li.ngx-select-dropdown-option').contains(fieldValuesJSON[key]['value']).click();
        });
      } else if (key.includes('Comments')) {
        cy.getByLabel(key)
          .closest('div.comments-field__rte')
          .scrollIntoView()
          .within(() => {
            cy.getRTE().focus().type(fieldValuesJSON[key]['value']);
            cy.get('.btn-primary').click();
          });
      } else if (key.includes('Reference') && isGridType) {
        cy.getByLabel(key).within(() => {
          cy.intercept('POST', '/api/search/keyword**').as('searchRecords');
        });
        cy.get('button[tooltiptitle="Lookup"]').click();
        cy.root()
          .closest('body')
          .find('.ngx-dialog-content')
          .find('.search-banner')
          .find('input.ngx-input-box')
          .then($fieldInput => {
            typeInField($fieldInput, fieldValuesJSON[key]['value'].trim(), true, true);
            cy.wait('@searchRecords').its('response.statusCode').should('eq', 200);
            cy.root()
              .closest('body')
              .find('.search-container')
              .find('div.search-results span.record-label')
              .contains(new RegExp(`^\\s*${fieldValuesJSON[key]['value']}\\s*$`))
              .siblings('div.record-selector')
              .click();
            cy.root()
              .closest('body')
              .find('div.search-sidebar')
              .find('div.search-sidebar--selection-list--actions')
              .find('ngx-button')
              .contains(/^\s*Add Record\s*/)
              .click();
            cy.get('div.search-sidebar--selection-list--actions').should('not.exist');
          });
      } else if (key.includes('Reference') && !isGridType) {
        cy.getByLabel(key)
          .closest('.reference-field__select')
          .find('div.reference-field__select__controls button[tooltiptitle="Lookup"]')
          .click();
        cy.root()
          .closest('body')
          .find('.ngx-dialog-content')
          .find('.search-banner')
          .find('input.ngx-input-box')
          .then($fieldInput => {
            typeInField($fieldInput, fieldValuesJSON[key]['value'].trim(), true, true);
            cy.root()
              .closest('body')
              .find('.search-container')
              .find('div.search-results span.record-label')
              .contains(new RegExp(`^\\s*${fieldValuesJSON[key]['value']}\\s*$`))
              .siblings('div.record-selector')
              .click();
            cy.root()
              .closest('body')
              .find('div.search-sidebar')
              .find('div.search-sidebar--selection-list--actions')
              .find('ngx-button')
              .contains(/^\s*Add Record\s*/)
              .click();
            cy.wait('@postReferences').its('response.statusCode').should('eq', 200);
            cy.get('div.search-sidebar--selection-list--actions').should('not.exist');
            // Have to wait a bit for the UI to reflect the recently added reference
            cy.wait(500);
          });
      } else {
        cy.getByLabel(key).ngxFill(fieldValuesJSON[key]['value']);
      }
      if (fieldValuesJSON[key].hasOwnProperty('workflowTrigger')) {
        verifyPopup('Record updated');
      }
      if (fieldValuesJSON[key].isCalculated) {
        cy.wait('@postCalculated', { timeout: 50000 }).its('response.statusCode', { timeout: 500 }).should('eq', 200);
      }
      if (fieldValuesJSON[key].isUnique) {
        cy.wait('@postUnique', { timeout: 50000 }).its('response.statusCode', { timeout: 500 }).should('eq', 200);
      }
    });
  }
}

export function verifyFieldValues(fieldValuesJSON, verifyAllFields = true, isDateTime = false, isComment = false) {
  expect(fieldValuesJSON).to.not.deep.equal({});
  cy.get(recordEditor)
    .find('div.record-field')
    .should('be.visible')
    .as('fieldsList')
    .then($fieldsList => {
      if (verifyAllFields === true) {
        expect($fieldsList.length).to.equal(Object.keys(fieldValuesJSON).length);
      }
    });
  for (const fieldName of Object.keys(fieldValuesJSON)) {
    if (!Array.isArray(fieldValuesJSON[fieldName])) {
      if (!isDateTime && !isComment) {
        cy.log(fieldName);
        cy.get('@fieldsList')
          .getByLabel(fieldName)
          .ngxGetValue()
          .should('match', new RegExp(`^\\s*${fieldValuesJSON[fieldName]}\\s*$`));
      } else if (isDateTime && !isComment) {
        cy.log(fieldName);
        cy.get('@fieldsList');
        cy.get('time.ngx-time__container[datetime]').then($value => {
          const expectedDate = new Date(fieldValuesJSON[fieldName]);
          const calculatedDate = new Date($value.text().trim());
          expect(expectedDate.toUTCString()).to.equal(calculatedDate.toUTCString());
        });
      } else {
        cy.log(fieldName);
        cy.get('@fieldsList');
        cy.get('div.record-field.comments-field');

        cy.get('.record-field__field-label')
          .contains(fieldName)
          .parent()
          .within(() => {
            cy.get('span.comment--body--rich').then($value => {
              expect($value.text().trim()).to.equal(fieldValuesJSON[fieldName].trim());
            });
          });
      }
    } else {
      cy.get('@fieldsList')
        .getByLabel('Multi-select Reference')
        .find('.reference-field__tag__value')
        .then($fieldValues => {
          expect($fieldValues).to.have.lengthOf(fieldValuesJSON[fieldName].length);
          cy.wrap($fieldValues).each($el => {
            cy.log('Why am I here?');
            cy.log($el.text());
            expect($el.text().trim()).to.be.oneOf(fieldValuesJSON[fieldName]);
          });
        });
    }
  }
}

export function verifyReadOnlyFieldValues(fieldValuesJSON) {
  expect(fieldValuesJSON).to.not.deep.equal({});
  for (const fieldName of Object.keys(fieldValuesJSON)) {
    cy.contains('label', fieldName).parent().should('contain.text', fieldValuesJSON[fieldName]);
  }
}

export function verifyValueVerification(fieldErrorData) {
  cy.get(recordEditor).within(() => {
    Object.keys(fieldErrorData).forEach($fieldName => {
      cy.get('span')
        .contains(new RegExp(`^\\s*${$fieldName}\\s*$`))
        .closest('ngx-input')
        .within(() => {
          cy.get('div.ngx-input-hint').should('be.visible').should('contain.text', fieldErrorData[$fieldName]);
        });
    });
  });
}

export function verifySaveButton(isPresent = true) {
  cy.contains('span', /^\s*Save\s*$/).should(`${isPresent ? '' : 'not.'}be.enabled`);
}

export function verifyFieldIsCalculated(fieldNames) {
  if (!Array.isArray(fieldNames)) {
    fieldNames = [fieldNames];
  }
  cy.get(recordEditor).within(() => {
    fieldNames.forEach($fieldName => {
      cy.get('div.record-state__layout')
        .find('div.record-layout__layout-item, .record-field__field-label')
        .contains(new RegExp(`^\\s*${$fieldName}\\s*$`));
      cy.get('ngx-icon[tooltiptitle="Calculated Field"]');
    });
  });
}

export function waitForRefUpdate() {
  cy.intercept('POST', '/api/app/**/record/**/references').as('postRefs');
  cy.wait('@postRefs', { timeout: 50000 }).its('response.statusCode', { timeout: 500 }).should('eq', 200);
}

export function getRecordTrackingID(isNew = false) {
  return cy
    .get(isNew ? 'app-record' : 'ui-view[name=record]')
    .should('be.visible')
    .dataCy('record_page__title')
    .its('0.innerText');
}

export function verifyRecordPageElements(newRecord = true, appName: string, acronym: string) {
  if (newRecord) {
    cy.url().should('match', new RegExp(`${Cypress.config('baseUrl')}\/record2\/[a-zA-Z0-9_]*/`));
    cy.get('[data-cy=workspace__title]').should('have.text', ` ${appName} Workspace `);
    cy.get('app-record')
      .find('ngx-toolbar-title, ngx-toolbar-title-col, record-state__toolbar__title')
      .should('have.text', `New Record`);
    verifySaveButton(false);
  } else {
    cy.wait(500);
    cy.url().should('match', new RegExp(`${Cypress.config('baseUrl')}\/record2\/[a-zA-Z0-9_]*\/[a-zA-Z0-9_]*`));
    cy.dataCy('workspace__title').should('have.text', ` ${appName} Workspace `);
    cy.dataCy('record_page__title')
      .its('0.innerText')
      .should('match', new RegExp(`^\\s*${acronym}\-[0-9]+\\s*$`));
    verifySaveButton(false);
  }
}

export function verifyReferenceFieldOptions(
  fieldName: string,
  isGridType: boolean,
  optionsList: string[],
  headersList: string[]
) {
  if (isGridType) {
    cy.get(recordEditor).within(() => {
      cy.get('.record-field')
        .find('.record-field__field-label')
        .contains(new RegExp(`^\\s*${fieldName}\\s*$`))
        .closest('.reference-field__grid')
        .within(() => {
          cy.get('.datatable-header .datatable-row-center').within(() => {
            cy.get('.datatable-header-cell-label').then($headers => {
              expect($headers).to.have.lengthOf(headersList.length);
              cy.wrap($headers).each($el => {
                expect($el.text()).to.be.oneOf(headersList);
              });
            });
          });
          cy.get('.datatable-footer').within(() => {
            cy.get('.reference-field__grid__page-count').should('contain', ' 0 records ');
            cy.get('.reference-field__grid__controls').within(() => {
              cy.get('button').then($buttons => {
                expect($buttons).to.have.lengthOf(optionsList.length);
                cy.wrap($buttons).each($el => {
                  expect($el.attr('tooltiptitle')).to.be.oneOf(optionsList);
                });
              });
            });
          });
        });
    });
  } else {
    cy.get(recordEditor).within(() => {
      cy.getByLabel(fieldName)
        .closest('.record-field')
        .find('.reference-field__select__controls')
        .within(() => {
          cy.get('button').then($buttons => {
            expect($buttons).to.have.lengthOf(optionsList.length);
            cy.wrap($buttons).each($el => {
              expect($el.attr('tooltiptitle')).to.be.oneOf(optionsList);
            });
          });
        });
    });
  }
}

export function openReferencedRecord(fieldName: string, recordID: string, isGridType: boolean) {
  cy.intercept('POST', '/api/app/**/record/**/references').as('postReferences');
  cy.intercept('GET', '/api/app/**/record/**').as('getRecord');
  cy.intercept('GET', '/api/app/**').as('getApp');

  if (isGridType) {
    cy.get(recordEditor).within(() => {
      cy.getByLabel(fieldName).closest('.record-field').find('.reference-field__tag').first().click();
    });
  } else {
    cy.get(recordEditor).within(() => {
      cy.getByLabel(fieldName).closest('.record-field').find('.reference-field__tag__value').click();
    });
  }
  cy.wait('@getRecord', { timeout: 50000 }).its('response.statusCode', { timeout: 500 }).should('eq', 200);
  cy.wait('@getApp', { timeout: 50000 }).its('response.statusCode', { timeout: 500 }).should('eq', 200);
  cy.wait('@postReferences', { timeout: 50000 }).its('response.statusCode', { timeout: 500 }).should('eq', 200);
}

export function verifyRecordOpenedInDrawer(recordPageTitle: string, listItems: string[], fieldValuesJSON) {
  cy.get('ngx-drawer app-record').within(() => {
    cy.get('ngx-toolbar-title h2').should('contain.text', recordPageTitle);
    cy.get('.record-state__toolbar__controls__save').should('not.be.enabled');
    cy.get('ngx-dropdown.record-state__toolbar__controls__ellipses')
      .click()
      .within(() => {
        cy.get('ngx-dropdown-menu .vertical-list')
          .find('button')
          .then($selectedList => {
            expect($selectedList).to.have.lengthOf(listItems.length);
            cy.wrap($selectedList).each($el => {
              cy.wrap($el)
                .its('0.innerText')
                .then($textValue => {
                  expect($textValue).to.be.oneOf(listItems);
                });
            });
          });
      });

    cy.get('div.record-state__layout').should('be.visible');
    for (const fieldName of Object.keys(fieldValuesJSON)) {
      if (!Array.isArray(fieldValuesJSON[fieldName])) {
        cy.getByLabel(fieldName)
          .ngxGetValue()
          .should('match', new RegExp(`^\\s*${fieldValuesJSON[fieldName]}\\s*$`));
      } else {
        cy.getByLabel(fieldName)
          .find('.reference-field__tag')
          .then($fieldValues => {
            expect($fieldValues).to.have.lengthOf(fieldValuesJSON[fieldName].length);
            cy.wrap($fieldValues).each($el => {
              expect($el.text().trim()).to.be.oneOf(fieldValuesJSON[fieldName]);
            });
          });
      }
    }
  });
}

export function closeRecordDrawer() {
  // Have to use the force here
  cy.get('.ngx-drawer').next('ngx-overlay').find('.ngx-overlay').click({ force: true });
  //  Wait for record drawer to clear
  cy.get('ngx-drawer').should('not.exist');
}

export function addAttachment(fieldName: string, fileName: string, fileTooLarge = false, expectedErrorMessage = '') {
  const filenameWithPath = '/attachments/' + fileName;
  cy.intercept('POST', '/api/attachment/**').as('postAttachment');
  cy.get(recordEditor).within(() => {
    cy.fixture(filenameWithPath, 'binary').then(fileContent => {
      cy.getByLabel(fieldName)
        .closest('.attachment-field')
        .find('.attachment-field__dropzone .ngx-dropzone--input')
        .attachFile({
          fileContent,
          fileName,
          contentType: 'multipart/form-data',
          encoding: 'utf-8'
        });
      if (!fileTooLarge) {
        // wait for spinner to go away
        cy.get('.swimlane-loading-bar').should('not.exist');
        cy.wait('@postAttachment').its('response.statusCode', { timeout: 500 }).should('eq', 200);
      }
    });
  });

  if (fileTooLarge) {
    verifyPopup3({ title: 'Attachment Upload Error', subtext: expectedErrorMessage });
  }
}

export function addMSAttachment(fieldName: string, fileName: string, fileTooLarge = false, expectedErrorMessage = '') {
  const filenameWithPath = '/attachments/' + fileName;
  cy.intercept('POST', '/api/attachment/**').as('postAttachment');
  cy.get(recordEditor).within(() => {
    cy.fixture(filenameWithPath, 'binary')
      .then(Cypress.Blob.binaryStringToBlob)
      .then(fileContent => {
        cy.getByLabel(fieldName)
          .closest('.attachment-field')
          .find('.attachment-field__dropzone .ngx-dropzone--input')
          .attachFile({
            fileContent,
            fileName,
            mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            encoding: 'utf8'
          });
        if (!fileTooLarge) {
          cy.wait('@postAttachment').its('response.statusCode', { timeout: 500 }).should('eq', 200);

          // wait for spinner to go away
          cy.get('.swimlane-loading-bar').should('not.exist');
        }
      });
  });

  if (fileTooLarge) {
    verifyPopup3({ title: 'Attachment Upload Error', subtext: expectedErrorMessage });
  }
}

export function deleteAttachment(fieldName: string, fileName: string | number | RegExp) {
  cy.intercept('DELETE', '/api/attachment/**').as('deleteAttachment');
  interactWithAttachment(fieldName, fileName, '.attachment-field__delete-btn');
}

export function previewAttachment(fieldName: string, fileName: string | number | RegExp) {
  cy.intercept('GET', '/api/attachment/**').as('getAttachment');
  interactWithAttachment(fieldName, fileName, '.attachment-field__preview-btn', 'getAttachment');
  cy.get('.ngx-dialog-content').within(() => {
    cy.get('.ngx-large-format-dialog-header-title__text-wrapper').should('contain', fileName);
  });
}

export function downloadAttachment(fieldName: string, fileName: string | number | RegExp) {
  cy.intercept('GET', '/api/attachment/**').as('getAttachment');
  interactWithAttachment(fieldName, fileName, '.attachment-field__download-btn', 'getAttachment');
}

function interactWithAttachment(fieldName: string, fileName: string | number | RegExp, interaction, waitCall = null) {
  cy.get(recordEditor).within(() => {
    cy.getByLabel(fieldName)
      .find('datatable-body-row')
      .within(() => {
        cy.contains('datatable-body-cell', fileName)
          .scrollIntoView()
          .closest('datatable-body-row')
          .find(interaction)
          .click();
        waitCall != null
          ? cy.wait(`@${waitCall}`).its('response.statusCode', { timeout: 500 }).should('eq', 200)
          : cy.log('Nothing to wait for when deleting');
      });
  });
}

export function verifyAttachmentsList(fieldName: string, fileNameList: string[]) {
  cy.get(recordEditor).within(() => {
    if (fileNameList.length === 0) {
      cy.getByLabel(fieldName).find('datatable-body-row').should('have.length', 0);
    } else {
      cy.getByLabel(fieldName)
        .find('datatable-body-row')
        .then($fieldsList => {
          expect($fieldsList).to.have.lengthOf(fileNameList.length);
          cy.wrap($fieldsList).each($el => {
            expect($el.text().trim()).to.be.oneOf(fileNameList);
          });
        });
    }
  });
}

export function clickEditCommentButton(fieldName) {
  cy.get(recordEditor);
  cy.get('.record-field__field-label')
    .contains(fieldName)
    .parent()
    .within(() => {
      cy.get('div.comment')
        .trigger('mouseover')
        .find('span.help-block.ng-star-inserted')
        .find('[tooltiptitle="Edit Comment"]')
        .click();
    });
}

export function editExistingComment(text: any) {
  cy.intercept('PUT', '/api/app/**/record/**/comment/*').as('updateComment');
  cy.get('blockquote.edit-comment-mode').within(() => {
    cy.getRTE().focus().type(`{movetoend}${text}`);
    cy.get('button')
      .contains(/^\s*Save\s*$/)
      .click();
  });
  cy.wait('@updateComment').its('response.statusCode').should('eq', 204);
}

export function closePreview() {
  cy.get('.ngx-dialog-content').find('button').contains('Close').click();
}

export function lockUnlockRecord(LockRecord = true) {
  cy.intercept('POST', `/api/app/**/record/**/lock`).as('recordLock');
  cy.intercept('POST', `/api/app/**/record/**/unlock`).as('recordUnlock');

  cy.get('.record-state__toolbar').within(() => {
    cy.get('.ngx-dropdown-toggle > button').click();
    cy.get('.vertical-list')
      .contains('button', LockRecord ? 'Lock Record' : 'Unlock Record')
      .click();
  });
  verifyPopup3({ subtext: LockRecord ? 'Record locked successfully' : 'Record unlocked successfully' });
  cy.wait(LockRecord ? '@recordLock' : '@recordUnlock');
}

export function verifyLockedRecord(locked = true, lockingUserName?: string) {
  if (locked) {
    cy.get('.record-state__toolbar__title .ngx-icon.ngx-lock')
      .should('exist')
      .whileHovering(() => {
        cy.root().closest('body').find('.ngx-tooltip-content').should('contain', `Locked by ${lockingUserName}`);
      });
  } else {
    cy.get('.record-state__toolbar__title .ngx-icon.ngx-lock').should('not.exist');
  }
}

export function deleteRecord() {
  cy.get('button[type=button]').contains('Delete').click();
  cy.get('.modal-footer > .btn-primary').click();
}

export function verifyHistoryRecord(fieldNames) {
  if (!Array.isArray(fieldNames)) {
    fieldNames = [fieldNames];
  }
  cy.get(recordEditor).within(() => {
    fieldNames.forEach($fieldName => {
      cy.get('div.history--field__table')
        .find('.datatable-body-cell-label')
        .contains(new RegExp(`^\\s*${$fieldName}\\s*$`));
    });
  });
}

// tslint:disable: tsr-detect-non-literal-regexp

import { verifyPopup2, verifyPopup3, verifyDoubleCheck } from '../../common-pieces/popupMessages';
import * as interactions from '../../common-pieces/interactions';
import * as pluginDetails from '../plugins/plugin-details';
import * as field from '../../../../../../shared/helpers/field-inputs/field';
export { pluginDetails };
type sensorJSON = {
  sensorType?: string;
  sensorName?: string;
  paramData?: string[];
  noSensors?: boolean;
  invalid?: boolean;
  sourcePluginCheck?: boolean;
  invalidName?: boolean;
};

export function verifyElements(noSensors = true) {
  cy.get('.do-page-no-elements')
    .contains(/^\s*Start by adding your first event stream\s*$/)
    .should('be.visible');
  cy.get('.do-page-no-elements__connect > span')
    .contains(/^\s*Create an Event Stream\s*$/)
    .should('be.visible');
  cy.get('.do-page-no-elements__connect > ngx-icon')
    .should('be.visible')
    .should('have.attr', 'fonticon', 'add-circle-medium');
}

export function verifyLogsTab(sensorName, checkData = null) {
  cy.get('.ngx-card--sensor')
    .find('.ngx-card-header--title-group .ngx-card-title')
    .contains(new RegExp(`^\\s*${sensorName}Test_Sensor_Updated\\s*$`))
    .click();
  cy.get('ngx-large-format-dialog-content[dialogtitle="Edit Event Stream"]').within(() => {
    cy.get('.ngx-tabs-list button.ngx-tab')
      .should('have.class', 'active')
      .contains(/^\s*LOGS\s*$/);
    cy.get('.ngx-large-format-dialog-header-title').contains(/^\s*Edit Event Stream\s*$/);

    cy.get('.sensor-logs')
      .closest('ngx-tab')
      .within(() => {
        cy.get('.ngx-card--sensor').within(() => {
          cy.get('.ngx-toggle > div .ngx-toggle-text').contains(/^\s*Enabled\s*$/);
          cy.get('.ngx-dropdown')
            .as('deleteSensorDropdownTrigger')
            .click()
            .within(() => {
              cy.get('.vertical-list')
                .find('li')
                .contains(/^\s*Delete Event Stream\s*$/)
                .should('be.visible');
            });
        });

        cy.get('.sensor-logs').within(() => {
          cy.get('.sensor-logs__header-label').contains(/^\s*Event Stream Logs\s*$/);
          cy.get('.word-wrap-checkbox').within(() => {
            cy.get('.ngx-checkbox--label').contains(/^\s*Word Wrap\s*$/);
            cy.get('.ngx-checkbox--box').should('have.class', 'checked');
          });
          cy.get('.sensor-logs__header')
            .find('.ngx-dropdown-toggle')
            .contains(/^\s*Jump to date\s*$/);

          cy.get('.sensor-logs__content-wrapper .sensor-logs__log-entry-wrapper')
            .contains(/^\s*Changed status starting -> running\s*$/)
            .then($sensorLogMessageOutput => {
              if (checkData) {
                cy.wrap($sensorLogMessageOutput)
                  .closest('.logs')
                  .find('.log-entry .message')
                  .contains(new RegExp('^.*' + checkData + '*$'));
              }
            });
        });
      });
    cy.get('button')
      .contains(/^\s*Close\s*$/)
      .click();
  });
}

export function createSensor(sensorJSON: sensorJSON = {}) {
  cy.intercept('POST', '/orchestration/api/v1/sensor').as('postSensor');
  cy.get('.do-page__header-utilities-section .do-page__add-button').find('.ngx-add-circle-medium').click();
  cy.getByPlaceholder('Search').ngxFill(sensorJSON.sensorType);

  cy.get('.ngx-card-title')
    .contains(new RegExp(`^\\s*${sensorJSON.sensorType}\\s*$`))
    .closest('.ngx-card--sensor')
    .should('be.visible')
    .as('sensorCard');
  if (sensorJSON.hasOwnProperty('sourcePluginCheck')) {
    cy.get('@sensorCard')
      .find('.ngx-card-section .view-details')
      .contains(/^\s*Details\s*$/)
      .should('be.visible')
      .click();
    pluginDetails.close();
  }
  cy.get('@sensorCard').find('.ngx-card--select').click();

  // This says the elements are hidden when they are cleared, but only when run in headless mode.
  // running through the cypress UI and it works fine... WHY!!!! #ngx-ui
  // cy.wait(5000);
  // cy.getByLabel('Sensor Title').ngxFill(`${sensorJSON.sensorName}Test_Sensor`);
  // cy.getByLabel('Sensor Name')
  //   .should('be.visible')
  //   .ngxFill(
  //     sensorJSON.invalidName
  //       ? `${sensorJSON.sensorName.replace(/ /g, '')}QADOFUNC Invalid Name`
  //       : `${sensorJSON.sensorName}QADOFUNC_Test_Sensor`.replace(/ /g, '')
  //   );
  // cy.getByLabel('Sensor Description').ngxFill(`${sensorJSON.sensorName}Test_Description`);
  cy.get('do-sensor-create-dialog .do-dialog-details-form__section').within(() => {
    cy.get('.ngx-input__lock-toggle').click();
    field.setValue(
      {
        fieldType: 'text',
        inputType: 'text',
        attribute: `[data-cy="sensor-form__name__input"]`
      },
      sensorJSON.invalidName
        ? `${sensorJSON.sensorName.replace(/ /g, '')}QADOFUNC Invalid Name`
        : `${sensorJSON.sensorName}`.replace(/ /g, ''),
      true
    );
    field.setValue(
      {
        fieldType: 'text',
        inputType: 'text',
        attribute: `[data-cy="sensor-form__title__input"]`
      },
      `${sensorJSON.sensorName}Test_Sensor`,
      true
    );
    field.setValue(
      {
        fieldType: 'text',
        inputType: 'text',
        attribute: `[formcontrolname="sensorDesc"]`
      },
      `${sensorJSON.sensorName}Test_Description`,
      true
    );
  });
  cy.get('.ngx-json-editor-flat')
    .find('div > .ng-star-inserted .ngx-input-box')
    .as('inputFields')
    .then($fields => {
      let i = 0;
      cy.get('@inputFields').each($inputField => {
        // field.setValue($inputField, paramData[i]);
        interactions.typeInField($inputField, sensorJSON.paramData[i], true, true);
        i += 1;
      });
    });
  cy.get('.ngx-stepper--content').within(() => {
    cy.get(`ngx-input[data-cy="sensor-form__name__input"]`).then($field => {
      if (sensorJSON.invalidName) {
        cy.wrap($field)
          .should('have.class', 'ng-invalid')
          .closest('.dialog-container')
          .find('ngx-large-format-dialog-footer button')
          .contains(/^\s*Create\s*$/)
          .should('be.disabled')
          .as('saveButton');
        field.setValue(
          {
            fieldType: 'text',
            inputType: 'text',
            attribute: `[data-cy="sensor-form__name__input"]`
          },
          `${sensorJSON.sensorName}`.replace(/ /g, ''),
          true
        );
        cy.get('@saveButton').should('not.be.disabled');
      } else {
        cy.wrap($field).should('have.class', 'ng-valid');
      }
    });
  });
  cy.get('ngx-large-format-dialog-footer')
    .find('button')
    .contains(/^\s*Create\s*$/)
    .click();
  cy.wait('@postSensor').its('response.statusCode').should('eq', 201);
  verifyPopup3({
    title: 'Event Stream created',
    subtext: 'The event stream has been successfully created.'
  });
  cy.get('do-sensor-create-dialog').should('not.exist');
}

export function createSensorWithNoSensorsAvailable() {
  cy.get('.do-page-no-elements__connect').find('ngx-icon[fonticon="add-circle-medium"]').click();
  cy.get('do-sensor-create-dialog').within(() => {
    cy.get('header ngx-large-format-dialog-header-title').should('have.text', 'Select an Event Stream');

    cy.get('.do-modal-dialog__item-selection-sidebar')
      .find('.do-modal-dialog__item-selection-inline-link')
      .should('have.text', ' Head over to plugins to find more sensor types ');
    cy.get('.do-modal-dialog__item-selection-list .no-sensor-matches').should('have.text', 'No sensor types found');

    cy.get('button')
      .contains(/^\s*Close\s*$/)
      .click();
  });
}
function toggleSensorEnable(sensorName, enable = true) {
  const enableText = /^\s*Enabled\s*$/;
  const disableText = /^\s*Disabled\s*$/;
  cy.intercept('PUT', '/orchestration/api/v1/sensor/**').as('putSensor');
  cy.get('.ngx-card--sensor')
    .find('.ngx-card-title')
    .contains(new RegExp(`^\\s*${sensorName}\\s*$`))
    .closest('.ngx-card--sensor')
    .as('selectedSensorCard');
  cy.get('@selectedSensorCard').find('.ngx-card-section .ngx-toggle').as('sensorToggle');
  cy.get('@sensorToggle')
    .find('.ngx-toggle-text')
    .contains(enable ? disableText : enableText)
    .click();
  cy.wait('@putSensor');
  cy.get('@sensorToggle')
    .find('.ngx-toggle-text')
    .contains(enable ? enableText : disableText);
}

export function disableSensor(sensorName, toggleFromSettings = false) {
  if (toggleFromSettings) {
    cy.get('.ngx-large-format-dialog-content[ng-reflect-dialog-title="Edit Event Stream"]').within(() => {
      cy.get('.ngx-tabs-list')
        .find('button')
        .contains(/^\s*SETTINGS\s*$/)
        .click();
      toggleSensorEnable(sensorName, false);
    });
  } else {
    toggleSensorEnable(sensorName, false);
  }
}

export function enableSensor(sensorName, toggleFromSettings = false) {
  if (toggleFromSettings) {
    cy.get('.ngx-large-format-dialog-content[ng-reflect-dialog-title="Edit Event Stream"]').within(() => {
      cy.get('.ngx-tabs-list')
        .find('button')
        .contains(/^\s*SETTINGS\s*$/)
        .should('be.visible')
        .click();
      toggleSensorEnable(sensorName);
    });
  } else {
    toggleSensorEnable(sensorName);
  }
}

export function deleteSensor(sensorName) {
  cy.intercept('DELETE', '/orchestration/api/v1/sensor/**').as('deleteSensor');
  cy.get('.ngx-card--sensor')
    .find('.ngx-card-header--title-group .ngx-card-title')
    .contains(new RegExp(`^\\s*${sensorName}Test_Sensor_Updated\\s*$`))
    .closest('.ngx-card--sensor')
    .within(() => {
      cy.get('.ngx-dropdown')
        .click()
        .within(() => {
          cy.get('.vertical-list')
            .find('li > button')
            .contains(/^\s*Delete Event Stream\s*$/)
            .click();
        });
    });

  verifyDoubleCheck(
    'Delete event stream',
    `Are you sure you want to delete the event stream '${sensorName}Test_Sensor_Updated'?`
  );
  cy.wait('@deleteSensor').its('response.statusCode').should('eq', 200);
}

export function updateSensor(sensorName, checkEnableDisable = false, paramData = null) {
  cy.intercept('PUT', '/orchestration/api/v1/sensor').as('updateSensor');
  cy.get('.ngx-card--sensor')
    .find('.ngx-card-header--title-group .ngx-card-title')
    .contains(new RegExp(`^\\s*${sensorName}Test_Sensor\\s*$`))
    .click();
  cy.get('.ngx-tabs-list')
    .find('button')
    .contains(/^\s*SETTINGS\s*$/)
    .click();
  cy.get('.ngx-input__lock-toggle').click();
  cy.get('.do-sensor-edit-dialog').within(() => {
    field.setValue(
      {
        fieldType: 'text',
        inputType: 'text',
        attribute: `[formcontrolname="sensorName"]`
      },
      `${sensorName}QADOFUNC_Test_Sensor_Updated`.replace(/ /g, '')
    );
    field.setValue(
      {
        fieldType: 'text',
        inputType: 'text',
        attribute: `[formcontrolname="sensorTitle"]`
      },
      `${sensorName}Test_Sensor_Updated`
    );
    field.setValue(
      {
        fieldType: 'text',
        inputType: 'text',
        attribute: `[formcontrolname="sensorDesc"]`
      },
      `${sensorName}Test_Description_Updated`
    );
  });
  if (checkEnableDisable) {
    disableSensor(`${sensorName}Test_Sensor_Updated`, true);
    enableSensor(`${sensorName}Test_Sensor_Updated`, true);
  }
  if (paramData) {
    cy.get('.ngx-json-editor-flat')
      .find('div > .ng-star-inserted .ngx-input-box')
      .as('inputFields')
      .then($fields => {
        let i = 0;
        cy.get('@inputFields').each($inputField => {
          interactions.typeInField($inputField, paramData[i], true, true);
          i += 1;
        });
      });
  }
  cy.get('.btn-bordered')
    .contains(/^\s*Save and Close\s*$/)
    .click();
  verifyPopup2('Event Stream updatedThe event stream has been successfully updated.', false);
}

export function clearAllFilters() {
  cy.get('.reset-filters > span')
    .contains(/^\s*RESET ALL FILTERS\s*$/)
    .click();
}

export function filterSensorByName(sensorName) {
  return cy
    .get('.ngx-input[name="filterInputValue"]')
    .find('.ngx-input-box[type="text"]')
    .then($el => {
      interactions.typeInField($el, sensorName.replace(/ /g, ''));
    });
}

import * as swimInstance from '../../../swimInstance';

export function verifySensorEventsHeader() {
  // verify header text
  const expectedHeaderText: string[] = ['', 'Event Type', 'Agent/Host', 'Time Received', 'Triggered Playbooks'];
  cy.get('datatable-header-cell').each(($e1, index) => {
    cy.wrap($e1).then(actual => {
      expect(actual.text().trim()).equals(expectedHeaderText[index]);
    });
  });
}

export function findInBody(searchItem) {
  cy.get('body').then($body => {
    if ($body.text().includes(searchItem)) {
      return true;
    }
  });
  return false;
}

export function verifyEventDetails(element, httpUrl) {
  // open event details
  cy.wrap(element.find('datatable-body-cell:nth-child(1)')).click();
  // verify header
  const headerText: string[] = ['Playbook', 'Playbook Run', 'Trigger Type', 'Trigger Name'];
  cy.wrap(element)
    .closest('.datatable-row-wrapper')
    .find('.datatable-header-cell')
    .each(($e2, index2) => {
      cy.wrap($e2.text()).then(actual => {
        expect(actual).equals(headerText[index2]);
      });
    });

  cy.get('div.CodeMirror-lines').then($textField => {
    expect($textField.text()).contain(httpUrl);
  });
}
export function openEventDetailsVerify(httpUrl) {
  swimInstance.openPlugins();
  swimInstance.openSensorEvents();
  cy.get('.datatable-body .datatable-row-center.datatable-row-group.ng-star-inserted').each($e1 => {
    cy.wrap(verifyEventDetails($e1, httpUrl));
  });
}

export function captureLegendTotalValue() {
  return cy.get('div.do-events-chart__legend-total div.do-events-chart__legend-item-value').should('be.visible');
}

export function checkForNoDataToDisplay() {
  cy.wait(3000);
  return cy.get('body').then($body => {
    if ($body.text().includes('No data to display')) {
      cy.wrap($body.text())
        .should('include', 'Activity (Last 24 hours)')
        .then(() => {
          return true;
        });
    } else {
      return false;
    }
  });
}

export function triggerWebEvent(httpUrl, x) {
  swimInstance.openSensors();
  Cypress._.times(x, () => {
    swimInstance.openSensorEvents();
    // trigger an event
    cy.request(httpUrl).its('body').should('include', 'ok');
    swimInstance.openSensors();
  });
}

export function findTheServerAgent(postSensorName) {
  swimInstance.openSensors();
  cy.get('.ngx-card--sensor')
    .find('.ngx-card-header--title-group .ngx-card-title')
    .contains(postSensorName)
    .closest('.ngx-card--sensor')
    .click();
  cy.get('button').contains('SETTINGS').click();
  return cy.get('.ngx-select-input-name').invoke('text');
}

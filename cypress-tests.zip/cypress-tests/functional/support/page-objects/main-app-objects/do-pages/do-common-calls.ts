// tslint:disable: tsr-detect-non-literal-regexp

export function returnRandomAlphaString(length) {
  let result = '';
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}

type playbookDetailsStateJSON = {
  playbookElement?: string;
  hasRuntimeDetails?: boolean;
  fromOpenPlaybook?: boolean;
};

type playbookDetailsDataJSON = {
  title?: string;
  name?: string;
  acronym?: string;
  type?: string;
  runsPerDay?: string;
  avgRunTime?: string;
};

type popoutMenuJSON = {
  orchItem?: string;
  menuItemIcon?: string;
  optionName?: string;
  popoutMenuItemLabel?: string;
  noOrchItems?: boolean;
};

export function openPopoutMenu(popoutMenuJSON: popoutMenuJSON = {}) {
  cy.get(`[data-cy=orchestration-tab__${popoutMenuJSON.orchItem.toLowerCase()}s]`)
    .closest('.orchestration')
    .find(`.do-page__header .position-right .ngx-plus-menu--circle .ngx-add-circle-medium`)
    .click();
  if (popoutMenuJSON.menuItemIcon != null) {
    cy.get(
      popoutMenuJSON.noOrchItems
        ? `.position-bottom .ngx-plus-menu--menu-title`
        : `.position-right .ngx-plus-menu--items-container .ng-star-inserted .ngx-${popoutMenuJSON.menuItemIcon}`
    ).as('targetButton');
    cy.get('@targetButton')
      .closest('.ngx-plus-menu')
      .within(() => {
        cy.get(
          popoutMenuJSON.noOrchItems
            ? '.ngx-plus-menu--menu-title'
            : '.ngx-plus-menu--items-container .ng-star-inserted .ngx-plus-menu--item'
        ).contains(`${popoutMenuJSON.noOrchItems ? popoutMenuJSON.optionName : popoutMenuJSON.popoutMenuItemLabel}`);
      })
      .closest(popoutMenuJSON.noOrchItems ? '.position-bottom' : '.position-right')
      .find(`.ngx-plus-menu--icon ngx-icon i.ngx-${popoutMenuJSON.menuItemIcon}`)
      .click({ force: true });
  }
}

export function getPlaybookDetails(
  playbookDetailsStateJSON: playbookDetailsStateJSON = {},
  playbookDetailsDataJSON: playbookDetailsDataJSON = {}
) {
  /* TODO: Currently ngx-ui updates are in-flight per SPT-8371, SPT-8370, etc. We have to check for both states
     in the DOM currently as a result from the high level playbook cards (filtered view) and opened state
     respectively
  */
  if (playbookDetailsStateJSON.fromOpenPlaybook) {
    cy.get(playbookDetailsStateJSON.playbookElement)
      .find('.ngx-card-title')
      .its('0.innerText')
      .then($playbookTitle => {
        playbookDetailsDataJSON.title = $playbookTitle;
      })
      .get(playbookDetailsStateJSON.playbookElement)
      .find('.ngx-card-subtitle span')
      .its('0.innerText')
      .then($playbookName => {
        playbookDetailsDataJSON.name = $playbookName;
      })
      .get(playbookDetailsStateJSON.playbookElement)
      .then($ => {
        if (playbookDetailsStateJSON.hasRuntimeDetails) {
          getPlaybookRuntimeDetails(playbookDetailsDataJSON, playbookDetailsStateJSON.playbookElement);
        }
      });
    return cy
      .get(playbookDetailsStateJSON.playbookElement)
      .parent()
      .find('.ngx-card-avatar .ngx-card-avatar--content')
      .its('0.innerText')
      .then($playbookAcronym => {
        playbookDetailsDataJSON.acronym = $playbookAcronym;
        return playbookDetailsDataJSON;
      });
  } else {
    cy.get(playbookDetailsStateJSON.playbookElement)
      .find('.ngx-card-title')
      .its('0.innerText')
      .then($playbookTitle => {
        playbookDetailsDataJSON.title = $playbookTitle;
      });
    cy.get(playbookDetailsStateJSON.playbookElement)
      .find('.ngx-card-subtitle')
      .its('0.innerText')
      .then($playbookName => {
        playbookDetailsDataJSON.name = $playbookName;
      });
    cy.get(playbookDetailsStateJSON.playbookElement)
      .find('.ngx-card-header--label')
      .its('0.innerText')
      .then($playbookType => {
        playbookDetailsDataJSON.type = $playbookType;
      });
    cy.get(playbookDetailsStateJSON.playbookElement).then($ => {
      if (playbookDetailsStateJSON.hasRuntimeDetails) {
        getPlaybookRuntimeDetails(playbookDetailsDataJSON, playbookDetailsStateJSON.playbookElement);
      }
    });
    return cy
      .get(playbookDetailsStateJSON.playbookElement)
      .parent()
      .find('.ngx-card-avatar .ngx-card-avatar--content')
      .its('0.innerText')
      .then($playbookAcronym => {
        playbookDetailsDataJSON.acronym = $playbookAcronym;
        return playbookDetailsDataJSON;
      });
  }
}

function getPlaybookRuntimeDetails(
  playbookDetailsDataJSON: playbookDetailsDataJSON = {},
  playbookElement: playbookDetailsStateJSON['playbookElement']
) {
  cy.get(playbookElement)
    .find('.do-playbook-list__stats-item .do-playbook-list__stats-value')
    .first()
    .its('0.innerText')
    .then($playbookRunsPerHrs => {
      playbookDetailsDataJSON.runsPerDay = $playbookRunsPerHrs;
    });
  cy.get(playbookElement)
    .find('.do-playbook-list__stats-item .do-playbook-list__stats-value')
    .last()
    .its('0.innerText')
    .then($playbookAvgRunTime => {
      playbookDetailsDataJSON.avgRunTime = $playbookAvgRunTime;
    });
}

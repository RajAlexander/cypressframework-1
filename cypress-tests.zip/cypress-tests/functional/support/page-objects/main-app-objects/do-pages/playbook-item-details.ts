import { getPlaybookDetails } from './do-common-calls';

export function getPlaybookItemDetails(fromVisualEditor = false) {
  const playbookDetailsStateJSON = {
    playbookElement: '@playbookDetailsSection',
    hasRuntimeDetails: false,
    fromOpenPlaybook: fromVisualEditor
  };

  cy.get(fromVisualEditor ? '.playbook-edit-dialog' : '.do-playbook-list__pb-card')
    .find('.ngx-card-header')
    .as('playbookDetailsSection');
  return getPlaybookDetails(playbookDetailsStateJSON);
}

export function close() {
  cy.get('.ngx-large-format-dialog-header-action__button').click();
  cy.get('.playbook-edit-dialog-container').should('not.exist');
}

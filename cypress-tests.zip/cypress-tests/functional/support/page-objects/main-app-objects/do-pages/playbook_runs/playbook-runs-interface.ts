export function verifyElements(noPlaybookRuns = true) {
  cy.get('.do-playbook-runs')
    .as('playbookRunsSection')
    .find('.do-playbook-runs__header')
    .contains(/^\s*Playbook Runs for Past 6 Months\s*$/);
  cy.get('@playbookRunsSection')
    .find('.do-playbook-runs__header')
    .contains(/^\s*Runs Grouped by Playbook\s*$/);
  cy.get('@playbookRunsSection').find('.do-playbook-runs__chart-container').as('playbookRunsChart');
  cy.get('.datatable-body')
    .find('datatable-selection .ng-star-inserted')
    .should(noPlaybookRuns ? 'have.class' : 'not.have.class', 'empty-row')
    .and(noPlaybookRuns ? 'have.text' : 'not.have.text', 'No data to display');
}

export function selectPlaybookRun(playbookName, validateRun = false, playbookRunStatus = 'success') {
  cy.get('.datatable-body')
    .find('.datatable-row-group .datatable-body-cell .datatable-body-cell-label')
    .contains(new RegExp(`^\\s*${playbookName}\\s*$`))
    .as('playbookNameLinked');
  !validateRun
    ? cy.get('@playbookNameLinked').click()
    : cy
        .get('@playbookNameLinked')
        .closest('.datatable-row-group')
        .as('playbookRunRow')
        .find('.do-playbook-runs__expand-btn')
        .wait(500)
        // force is needed here since the click hangs and times out in Cypress otherwise; UI renders fine
        .click({ force: true })
        .get('@playbookRunRow')
        .closest('.datatable-row-wrapper')
        .within(() => {
          cy.get('.datatable-body-cell .do-playbook-runs__status-orb').as('playbookRunStatus');
          switch (true) {
            case playbookRunStatus === 'active':
              cy.get('@playbookRunStatus').should('have.class', 'do-playbook-runs__status-orb--active');
              break;
            case playbookRunStatus === 'success':
              cy.get('@playbookRunStatus').should('have.class', 'do-playbook-runs__status-orb--success');
              break;
            case playbookRunStatus === 'fail':
              cy.get('@playbookRunStatus').should('have.class', 'do-playbook-runs__status-orb--fail');
              break;
            case playbookRunStatus === 'timeout':
              cy.get('@playbookRunStatus').should('have.class', 'do-playbook-runs__status-orb--timeout');
              break;
          }
        })
        .find('.datatable-row-detail')
        .within(() => {
          cy.get('.do-playbook-runs__run-details .run-details section')
            .scrollIntoView()
            .find('.btn[title="Click to view additional details about this run"]')
            .contains(/^\s*More Details\s*$/)
            // force is needed here since the click hangs and times out in Cypress otherwise; UI renders fine
            .click({ force: true });
        });
}

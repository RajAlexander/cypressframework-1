import { verifyPopup3 } from '../../common-pieces/popupMessages';

export function uploadFile(pluginFileName, invalidFile = false) {
  cy.intercept('POST', '/orchestration/api/v1/plugin').as('postPlugin');
  cy.get('div.ngx-dialog-content').should('be.visible');
  cy.get('.do-drag-and-drop--input').attachFile(pluginFileName);
  if (invalidFile) {
    const fileName = typeof pluginFileName === 'string' ? pluginFileName : pluginFileName.filePath;
    verifyPopup3(
      {
        title: 'Upload Error',
        subtext: `File "${fileName.split('/').reverse()[0]}" doesn't have a valid file extension.`
      }
      // forceClosure,
      // closeMultiple
    );
  } else {
    cy.wait('@postPlugin');
  }
}

export function close() {
  cy.get('div.ngx-dialog-content').find('button').should('have.text', ' Close ').click();
  cy.get('div.ngx-dialog-content').should('not.exist');
}

export function checkUploadComplete(title) {
  cy.get('div.do-plugin-upload-dialog__status-text').should('have.text', ' Upload complete ');
  cy.get('div.plugin-upload-status--title').should('contain.text', title);
  cy.get('div.plugin-upload-status--status-text').should('have.text', ' Installed ');
}

export function doneAddingPlugins() {
  cy.get('div.do-plugin-upload-dialog__status-step')
    .find('div.close-action')
    .contains(/^\s*I'm done adding plugins\s*$/)
    .click();
  cy.get('div.close-action').should('not.exist');
}

export function uploadMorePlugins() {
  cy.get('div.do-plugin-upload-dialog__status-step')
    .find('div.reset-action')
    .contains(/^\s*Upload more plugins\s*$/)
    .click();
}

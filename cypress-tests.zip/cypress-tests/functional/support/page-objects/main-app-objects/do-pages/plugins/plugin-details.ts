// tslint:disable: tsr-detect-non-literal-regexp

export function close() {
  cy.get('ngx-drawer').find('div.plugin-details-title > img[alt="back"]').click();
  cy.get('ngx-drawer').should('not.exist');
}

function switchTab(tabName) {
  cy.get('ngx-drawer')
    .find('ngx-tabs button')
    .contains(new RegExp(`^\\s*${tabName}\\s*$`))
    .click();
}

export function getOverviewDetails() {
  const overviewJSON: any = {};
  const tabName = 'OVERVIEW';

  switchTab(tabName);
  cy.get(`ngx-tab[label=${tabName}]`).should('be.visible').as('currentTab');
  return cy
    .get('@currentTab')
    .find('div.plugin-details-overview div.plugin-details-subtext')
    .its('0.innerText')
    .then($text => {
      overviewJSON.description = $text;
      return overviewJSON;
    });
}

export function getActionsDetails(hasOutputParams = true) {
  // could grab this on the fly in the future??
  const columnNames = ['name', 'type', 'description', 'example'];
  const tabName = 'ACTIONS';
  const actionsJSON = {};

  switchTab(tabName);
  cy.get(`ngx-tab[label=${tabName}]`).as('currentTab');
  cy.get('@currentTab')
    .find('.plugin-io-card[type="action"]')
    .each($actionItem => {
      const currentDetails: any = { inputs: [], outputs: [] };
      cy.wrap($actionItem).click();

      cy.wrap($actionItem)
        .find('div.plugin-io-card--title')
        .its('0.innerText')
        .then($text => {
          currentDetails.title = $text;
        });
      cy.wrap($actionItem)
        .find('div.plugin-io-card--description')
        .its('0.innerText')
        .then($text => {
          currentDetails.description = $text;
        });
      cy.wrap($actionItem)
        .get('div')
        .contains('Input Parameters')
        .parent()
        .find('.plugin-io-descriptor')
        .within(() => {
          cy.wrap($actionItem)
            .find('table')
            .first()
            .find('tbody tr')
            .each($eachRow => {
              const rowDetails = {};
              cy.wrap($eachRow)
                .find('td')
                .each(($rowCell, index) => {
                  cy.wrap($rowCell)
                    .its('0.innerText')
                    .then($text => {
                      rowDetails[columnNames[index]] = $text;
                      return true;
                    });
                });
              currentDetails.inputs.push(rowDetails);
            });
        })
        .then($div => {
          if (hasOutputParams) {
            cy.get('div')
              .contains('Output Parameters')
              .parent()
              .find('.plugin-io-descriptor')
              .within(() => {
                cy.wrap($actionItem)
                  .find('table')
                  .last()
                  .find('tbody tr')
                  .each($eachRow => {
                    const rowDetails = {};
                    cy.wrap($eachRow)
                      .find('td')
                      .each(($rowCell, index) => {
                        cy.wrap($rowCell)
                          .its('0.innerText')
                          .then($text => {
                            rowDetails[columnNames[index]] = $text;
                            return true;
                          });
                      });
                    currentDetails.outputs.push(rowDetails);
                  });
              });
          }
        });
      cy.wrap($actionItem)
        .find('div.plugin-io-card--subtitle')
        .its('0.innerText')
        .then($text => {
          actionsJSON[$text] = currentDetails;
          return true;
        });
    });
  return actionsJSON;
}

export function getSensorsDetails() {
  const columnNames = ['name', 'type', 'description', 'example'];
  const sensorsJSON = {};
  const tabName = 'EVENT STREAMS';

  switchTab(tabName);
  cy.get(`ngx-tab[label="${tabName}"]`).as('currentTab');
  cy.get('@currentTab')
    .find('.plugin-io-card[type="sensor"]')
    .each($sensorItem => {
      const currentDetails: any = { inputs: [] };
      cy.wrap($sensorItem).click();

      cy.wrap($sensorItem)
        .find('div.plugin-io-card--title')
        .its('0.innerText')
        .then($text => {
          currentDetails.title = $text;
        });
      cy.wrap($sensorItem)
        .find('div.plugin-io-card--description')
        .its('0.innerText')
        .then($text => {
          currentDetails.description = $text;
        });
      cy.wrap($sensorItem)
        .get('div')
        .contains('Input Parameters')
        .parent()
        .find('.plugin-io-descriptor')
        .within(() => {
          cy.wrap($sensorItem)
            .find('table')
            .find('tbody tr')
            .each($eachRow => {
              const rowDetails = {};
              cy.wrap($eachRow)
                .find('td')
                .each(($rowCell, index) => {
                  cy.wrap($rowCell)
                    .its('0.innerText')
                    .then($text => {
                      rowDetails[columnNames[index]] = $text;
                      return true;
                    });
                });
              currentDetails.inputs.push(rowDetails);
            });
        });
      cy.wrap($sensorItem)
        .find('div.plugin-io-card--subtitle')
        .its('0.innerText')
        .then($text => {
          sensorsJSON[$text] = currentDetails;
          return true;
        });
    });
  return sensorsJSON;
}

export function getDetails(hasSensors = true, hasOutputParams = true) {
  const detailsJSON: any = {};
  cy.get('ngx-drawer').find('div.plugin-details-container').as('pluginDetailsTop');
  cy.get('@pluginDetailsTop')
    .find('div.plugin-details-name')
    .its('0.innerText')
    .then($text => {
      detailsJSON.name = $text;
    });
  cy.get('@pluginDetailsTop')
    .find('div.plugin-details-contributed')
    .its('0.innerText')
    .then($text => {
      detailsJSON.contributed = $text;
    });
  getOverviewDetails().then($overview => {
    detailsJSON.overview = $overview;
  });
  detailsJSON.actions = getActionsDetails(hasOutputParams);

  if (hasSensors) {
    detailsJSON.sensors = getSensorsDetails();
  }

  cy.get('@pluginDetailsTop')
    .find('div.plugin-version-text > div:last-child')
    .its('0.innerText')
    .then($text => {
      detailsJSON.version = $text;
    });
  cy.get('@pluginDetailsTop')
    .find('div.plugin-info-subtext')
    .its('0.innerText')
    .then($text => {
      detailsJSON.subtext = $text;
    });

  return cy
    .get('@pluginDetailsTop')
    .find('div.plugin-info-subtext')
    .last() // Temporary till cleaned classes
    .its('0.innerText')
    .then($text => {
      detailsJSON.licensing = $text;
      return detailsJSON;
    });
}

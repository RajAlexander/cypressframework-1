// tslint:disable: tsr-detect-non-literal-regexp

import { getPlaybookDetails, openPopoutMenu } from './do-common-calls';
import { verifyPopup3, verifyDoubleCheck } from '../common-pieces/popupMessages';
import * as interactions from '../common-pieces/interactions';
import * as playbookUploader from './playbook-upload';
import * as playbookDetails from './playbook-item-details';

export { playbookUploader };
export { playbookDetails };

type playbookJSON = {
  playbookName?: string;
  playbookTitle?: string;
  playbookDescription?: string;
};

type playbookInputJSON = {
  playbookInputName: string;
  playbookInputTitle?: string;
  playbookInputDescription?: string;
  playbookInputType: string;
  addEnumValue?: string;
  min?: number;
  max?: number;
  patternToMatch?: string;
  required?: boolean;
};

export function verifyNoPlaybooks() {
  cy.get('[data-cy=orchestration-tab__playbooks]').should('be.visible');
  cy.get('.do-page-no-elements')
    .contains(/^\s*Start by connecting your first playbook\s*$/)
    .should('be.visible');
}

export function verifyElements(noPlaybooks = true) {
  cy.intercept('POST', '/orchestration/api/v1/playbook').as('postPlaybook');
  cy.get('.do-page-no-elements .do-page-no-elements__header')
    .contains(/^\s*Start by connecting your first playbook\s*$/)
    .should('be.visible');
  cy.get('ngx-plus-menu .ngx-plus-menu--circle-container > span')
    .contains(/^\s*Add a playbook\s*$/)
    .should('be.visible');
  cy.get('.ngx-plus-menu--circle-container .ngx-plus-menu--circle')
    .should('be.visible')
    .should('have.attr', 'fonticon', 'add-circle-medium');
}

export function verifyPlaybookDetailsUponUpload(playbookTitle, pluginTitle) {
  cy.get('.ngx-card--playbook .ngx-card-section').find('div.view-details').click();
  cy.get('do-playbook-detail-dialog')
    .find('.dialog-header__details .dialog-header__title')
    .contains(new RegExp(`^\\s*${playbookTitle}\\s*$`))
    .should('be.visible');
  cy.get('.ngx-tabs')
    .find('button')
    .contains(/^\s*PLAYBOOK OVERVIEW\s*$/)
    .closest('.do-playbook-detail-dialog')
    .find('.graph-menu')
    .find('.menu-item[tooltiptitle="Zoom out"]')
    .as('ZoomOutButtonOnDialog')
    .closest('.graph-menu')
    .find('.menu-item[tooltiptitle="Zoom in"]')
    .as('ZoomInButtonOnDialog')
    .closest('.graph-menu')
    .find('.menu-item[tooltiptitle="Center graph"]')
    .as('CenterGraphButtonOnDialog')
    .closest('.graph-menu')
    .find('.menu-item[tooltiptitle="Fit to view"]')
    .get('.graph')
    .as('PlaybookTriggersAndActionsOnDialog')
    .closest('.do-playbook-detail-dialog')
    .find('.dialog-overview__plugin-details .dialog-overview__title')
    .contains(/^\s*Plugins used\s*$/)
    .as('pluginsUsedHeader')
    .closest('.dialog-overview__plugin-details')
    .find('.playbook-detail-plugin__title')
    .contains(new RegExp(`^\\s*${pluginTitle}\\s*$`))
    .as('PluginTitleOnDialog');
}

export function verifyPlaybookVisualEditor(playbookTitle, fromPlaybookRunsView = false, testRun = false) {
  if (!fromPlaybookRunsView) {
    cy.intercept('POST', '/orchestration/api/v1/node/rql').as('postNodeRql');
    cy.get('.do-playbook-list__pb-card')
      .find('.ngx-card-title')
      .contains(new RegExp(`^\\s*${playbookTitle}\\s*$`))
      .closest('.do-playbook-list__pb-card')
      .find('ngx-icon[fonticon="playbook-outline-small"]')
      .click();
    cy.wait('@postNodeRql').its('response.statusCode').should('eq', 200);
  } else {
    cy.get('.playbook-editor').should('be.visible');
  }
  cy.get('.playbook-name-label')
    .contains(new RegExp(`^\\s*${playbookTitle}\\s*$`))
    .as('playbookVisualEditorTitle');
  cy.get('.playbook-menu').as('playbookTopNavButtons');
  cy.get('.graph-menu').as('visualEditorNavBarButtons');
  cy.get('.primary-nav').find('.ngx-dropdown .ngx-dropdown-toggle').as('dropdownEllipsesForOptions');
  if (testRun) {
    cy.get('@dropdownEllipsesForOptions')
      .click()
      .get('.ngx-dropdown-menu .vertical-list')
      .within(() => {
        cy.get('button')
          .contains(/^\s*Test\s*$/)
          .click();
      })
      .wait(500)
      .get('.playbook-tester')
      .find('.tester-inputs .run-btn')
      .click();
  } else {
    // SPT-13801  This code currently does nothing, needs to be re-written so that it actually checks something
    //   cy.get('@visualEditorNavBarButtons')
    //     .find('.menu-item[tooltiptitle="Zoom out"]')
    //     .as('ZoomOutButton')
    //     .get('@visualEditorNavBarButtons')
    //     .find('.menu-item[tooltiptitle="Zoom in"]')
    //     .as('ZoomInButton')
    //     .get('@visualEditorNavBarButtons')
    //     .find('.menu-item[tooltiptitle="Left-to-right layout"]')
    //     .as('LeftToRightLayoutButton')
    //     .get('@visualEditorNavBarButtons')
    //     .find('.menu-item[tooltiptitle="Top-to-bottom layout"]')
    //     .as('TopToBottomLayoutButton')
    //     .get('@visualEditorNavBarButtons')
    //     .find('.menu-item[tooltiptitle="Center graph"]')
    //     .as('CenterGraphButton')
    //     .get('@visualEditorNavBarButtons')
    //     .find('.menu-item[tooltiptitle="Fit to view"]')
    //     .as('FitToViewButton');
  }
  // cy.get('@playbookTopNavButtons')
  //   .find('li[tooltiptitle="Code View"]')
  //   .as('CodeViewButton')
  //   .get('@playbookTopNavButtons')
  //   .find('li[tooltiptitle="Split View"]')
  //   .as('SplitViewButton')
  //   .get('@playbookTopNavButtons')
  //   .find('li[tooltiptitle="Graph View"]')
  //   .as('GraphViewButton');
  cy.get('g.links', { timeout: 10000 }).then($element => {
    $element.find('path.invisible-line').length > 0;
  });
}

// export function verifyEditPlaybookButton(playbookTitle) {
//   cy.get('.do-playbook-list__pb-card')
//     .find('.ngx-card-title')
//     .contains(new RegExp(`^\\s*${playbookTitle}\\s*$`))
//     .closest('.do-playbook-list__pb-card')
//     .find('.ngx-dropdown .ngx-dropdown-toggle')
//     .click();
//   cy.get('.ngx-dropdown-menu')
//     .find('li')
//     .contains(/^\s*Edit Playbook Details\s*$/)
//     .click();
// }

export function createNewPlaybook() {
  cy.intercept('POST', '/orchestration/api/v1/playbook').as('postPlaybook');
  const popoutMenuJSON = {
    orchItem: 'playbook',
    menuItemIcon: 'upload-outline-small',
    optionName: 'Add a playbook',
    popoutMenuItemLabel: 'Upload a playbook',
    noOrchItems: true
  };

  openPopoutMenu(popoutMenuJSON);
  cy.get('.ngx-large-format-dialog-content[dialogtitle="Create a New Playbook"]').within(() => {
    cy.getByLabel('Name').ngxFill('QA-E2E-Test_Playbook_Created');
    cy.getByLabel('Key').ngxFill('QAE2ETest_Name_Created');
    cy.getByLabel('Description').ngxFill('QA-E2E-Test_Description_Created');
    cy.get('.btn-primary')
      .contains(/^\s*Create and Build\s*$/)
      .click();
  });
  cy.wait('@postPlaybook').its('response.statusCode').should('eq', 201);
  verifyPopup3('Playbook created');
  cy.get('do-playbook-create-dialog').should('not.exist');
}

export function createPlaybook(playbookJSON: playbookJSON = {}) {
  cy.intercept('POST', '/orchestration/api/v1/playbook').as('postPlaybook');
  let existingPlaybooks = false;

  cy.intercept('POST', '/orchestration/api/v1/node/rql').as('postRql');

  // Check for existing Playbooks, set existingPlaybooks accordingly so that openPopoutMenu() works correctly
  cy.makeTurbineAPICall('GET', 'v1/playbook').then($response => {
    existingPlaybooks = $response.items.length === 0;
  });

  const popoutMenuJSON = {
    orchItem: 'playbook',
    menuItemIcon: 'add-circle-medium',
    optionName: 'Add a playbook',

    popoutMenuItemLabel: 'Create a new playbook',
    noOrchItems: existingPlaybooks
  };

  openPopoutMenu(popoutMenuJSON);
  cy.get('.ngx-large-format-dialog-content[dialogtitle="Create a New Playbook"]').within(() => {
    cy.getByLabel('Title').ngxFill(playbookJSON.playbookTitle);
    cy.get('.ngx-input__lock-toggle').click();
    cy.getByLabel('Name').ngxFill(playbookJSON.playbookName);
    cy.getByLabel('Description').ngxFill(playbookJSON.playbookDescription);
    cy.get('.btn-primary')
      .contains(/^\s*Create and Build\s*$/)
      .click();
  });
  cy.wait('@postPlaybook').its('response.statusCode').should('eq', 201);
  verifyPopup3('Playbook created');
  cy.get('do-playbook-create-dialog').should('not.exist');
  cy.get('@postRql');
}

export function uploadPlaybook(fileName = '', properties = null, noPlaybooks = true) {
  const popoutMenuJSON = {
    orchItem: 'playbook',
    menuItemIcon: 'upload-outline-small',
    optionName: 'Add a playbook',
    popoutMenuItemLabel: ' Upload a playbook',
    noOrchItems: noPlaybooks
  };

  const uploadPlaybookJSON = {
    playbookFileName: fileName,
    invalidFile: false,
    forceClosure: false,
    closeMultiple: false
  };

  openPopoutMenu(popoutMenuJSON);
  if (fileName !== '') {
    playbookUploader.uploadFile(uploadPlaybookJSON);
    if (properties !== null) {
      playbookUploader.setProperties(properties);
      playbookUploader.submit();
    }
  }
}

export function updatePlaybook(playbookTitle) {
  clickOnPlaybook(playbookTitle);
  cy.get('.ngx-input[formcontrolname="title"]')
    .find('.ngx-input-box[type="text"]')
    .should('be.visible')
    .then($el => {
      interactions.typeInField($el, playbookTitle + 'Test_Playbook_Updated');
    });
  cy.get('.ngx-input[formcontrolname="description"]')
    .find('.ngx-input-box[type="text"]')
    .should('be.visible')
    .then($el => {
      interactions.typeInField($el, playbookTitle + 'Test_Description_Updated');
    });
  cy.get('.btn-bordered')
    .contains(/^\s*Save and Close\s*$/)
    .click();
  verifyPopup3({
    title: 'Playbook updated',
    subtext: 'The playbook has been successfully updated.'
  });
}

export function findPlaybookInListing(playbookName, fromVisualEditor = false) {
  return cy
    .get(fromVisualEditor ? '.playbook-edit-dialog' : '.do-playbook-list__pb-card')
    .find('.ngx-card-title')
    .contains(new RegExp(`^\\s*${playbookName}\\s*$`))
    .closest(fromVisualEditor ? '.playbook-edit-dialog' : '.do-playbook-list__pb-card')
    .as('foundPlaybook');
}

export function getPlaybooksCount() {
  return cy.get('do-playbooks.do-playbooks').then(playbooksContainer$ => {
    if (playbooksContainer$.find('.do-page-no-elements').length) {
      return 0;
    }
    return cy
      .get('ngx-card.do-playbook-list__pb-card')
      .its('length')
      .then($len => {
        return $len;
      });
  });
}

export function getPlaybookItemDetails(playbookName, hasRuntimeDetails = false, fromVisualEditor = false) {
  return findPlaybookInListing(playbookName, fromVisualEditor).then(() => {
    cy.get('@foundPlaybook').scrollIntoView();
    return getPlaybookDetails({
      playbookElement: '@foundPlaybook',
      hasRuntimeDetails,
      fromOpenPlaybook: fromVisualEditor
    });
  });
}

export function clickOnPlaybook(playbookName) {
  findPlaybookInListing(playbookName).then(() => {
    cy.get('@foundPlaybook')
      .find('.do-playbook-list__actions-wrapper .ellipsis')
      .click()
      .within(() => {
        cy.get('.vertical-list button').contains(new RegExp(`^\\s*Edit Playbook Details\\s*$`)).click();
      });
    cy.get('.playbook-edit-dialog').should('be.visible');
  });
}

export function addPlaybookTrigger(sensorName) {
  // Select Trigger type
  // NOTE: Trigger type of Event won't work until TO DO item is not resolved bellow
  cy.wait(500);
  cy.get('.node').contains('Add a trigger').click();
  cy.contains('Real-Time Event').click();

  // Select a Plugin or Sensor depending on the trigger type
  // TO DO: In case if trigger type is Eevent select a cron job
  cy.get('[name="sensorName"]')
    .click()
    .get('.ngx-select')
    .find('.vertical-list .ngx-select-dropdown-options span')
    .should('be.visible')
    .contains(sensorName)
    .click();
}

export function addPlaybookAction(titleName: string, playbookActionName: string, customAction = false) {
  // Add new Action for a trigger

  cy.wait(500);
  cy.get('.node').contains('Add an action').click();
  if (customAction == true) {
    cy.get('[name="action"]').click();
    cy.get('.ngx-select-filter').ngxFill(titleName);
    cy.get('.template-select-option').click();
  } else {
    cy.get('[name="action"]')
      .click()
      .find('li')
      .should('be.visible')
      .as('selectActionValue')
      .then(() => {
        cy.get('@selectActionValue').contains(playbookActionName).click();
      });
  }

  // Select first action item from the list based on Sensor Options

  cy.getByLabel('Title').ngxFill(titleName);
  // wait for refresh event after filling the title
  cy.wait(500);
}

export function addPlaybookActionfromPlugin(actionName: string) {
  // Add new Action for a the playbookEditor
  cy.get('.invisible-line', { timeout: 10000 }).should('be.visible');
  cy.wait(500);
  cy.get('.node').contains('Add an action').click();
  cy.get('div.action-config').find('h2.panel-header', { timeout: 10000 }).contains('Action').should('be.visible');

  selectActionInformation(actionName);
}

export function selectActionInformation(action: string) {
  cy.dataCy('input__action__Select').click();
  cy.get('h3.title').contains(action).click();
  cy.getByLabel('Title').ngxFill(action);

  // wait for refresh event after filling the title
  cy.wait(500);
}

export function openDialog(actionName: string) {
  cy.dataCy('visual-editor__edit__action').click();
  cy.get('ngx-large-format-dialog-header-title').find('h1').should('have.text', actionName);
}

export function addChildAction(triggerType: string, actionTitle: string) {
  // Wait needed to select circle
  cy.wait(500);
  cy.dataCy('visual-editor__trigger-node__playbook-node-0').within(() => {
    cy.get(`circle.drag-circle.${triggerType}`).dblclick();
  });
  cy.dataCy('input__action__title').clear().ngxFill(actionTitle);
}

export function changeActionName(newName: string, newTitle: string, isDuplicate = false) {
  cy.get('turbine-action-config').within(() => {
    if (!isDuplicate) {
      cy.dataCy('input__action__Name')
        .within(() => {
          cy.get('button.btn.btn-link.ngx-input__lock-toggle').click();
        })
        .clear()
        .type(newName);
    } else {
      cy.dataCy('input__action__Name').type(newName);
    }
    cy.dataCy('input__action__title').clear().ngxFill(newTitle);
  });
}

export function clickAdditionalConfiguration() {
  cy.get('turbine-action-config').find('button').contains(' Additional Configuration ').click();
}

export function enterExpression(expression: string) {
  cy.getByLabel('Expression').ngxFill(expression);
  //  Click Apply to exit out of Expression dialog
  cy.get('div.expression-dialog__container').contains('button', ' Apply ').click();
}

export function addPlaybookInput(playbookInputJSON: playbookInputJSON) {
  // Add new Playbook Input

  cy.get('.playbook-editor .editor-panel-inner__header')
    .find('.playbook-input__btn')
    .contains(new RegExp(`^\\s*Playbook Inputs\\s*$`))
    .click();
  cy.get('do-playbook-inputs-manager-dialog').contains('button', 'Add a property').click();
  cy.get('ngx-dropdown-menu').should('exist').contains('button', playbookInputJSON.playbookInputType).click();
  cy.get('ngx-property-config')
    .should('exist')
    .within(() => {
      for (const key of Object.keys(playbookInputJSON)) {
        switch (key) {
          case 'playbookInputName':
            cy.getByLabel('PROPERTY TITLE').ngxFill(playbookInputJSON[key]);
            break;
          case 'playbookInputKey':
            // TODO: Add code to handle the Playbook Input Property Key
            break;
          case 'playbookInputDescription':
            cy.getByLabel('PROPERTY DESCRIPTION').ngxFill(playbookInputJSON[key]);
            break;
          case 'playbookInputType':
            //  TODO:  Add code to handle changing the Playbook Input Type, alternately we may need a separate function to change the Type of an existing Playbook input
            break;
          case 'addEnumValue':
            cy.getByLabel('ADD ENUM VALUE').ngxFill(playbookInputJSON[key]);
            break;
          case 'min':
            cy.getByLabel('MINIMUM LENGTH').ngxFill(playbookInputJSON[key].toString());
            break;
          case 'max':
            cy.getByLabel('MAXIMUM LENGTH').ngxFill(playbookInputJSON[key].toString());
            break;
          case 'patternToMatch':
            cy.getByLabel('PATTERN TO MATCH').ngxFill(playbookInputJSON[key]);
            break;
          case 'required':
            cy.get('.ngx-checkbox--box').click();
            break;
          default:
            cy.log('You added a key value pair that does not work for Playbook Inputs!');
            break;
        }
      }
      //  Click Apply to exit out of Property Configuration
      cy.contains('button', 'Apply').click();
    });
  // Click Apply to exit out of the Playbook Inputs Manager
  cy.contains('button', 'Apply').click();
}

export function clickPlaybookOutput() {
  cy.get('.playbook-editor .editor-panel-inner__header')
    .find('.playbook-output__btn')
    .contains('Playbook Outputs')
    .click();
}

export function checkPlaybookOutputLables() {
  // Verify for the newly added UI elements
  cy.get('[dialogtitle="Playbook Outputs"]').within(() => {
    cy.get('.ngx-large-format-dialog-header-title').should('contain.text', 'Playbook Outputs');
    cy.get('.outputs-dialog-content__variables__header h4').should('contain.text', 'Promoted Playbook Outputs');
    cy.get('.outputs-dialog-content__variables__header p').should(
      'contain.text',
      "Action output promoted to this playbook's outputs"
    );
    cy.get('.outputs-dialog-content__information h5').should('contain.text', 'Using playbook outputs');
    cy.get('.outputs-dialog-content__information p:first').should(
      'contain.text',
      `From this dialog, or from each action in your playbook, you may denote action outputs that map results from a run to an application—or to another playbook that references this playbook.`
    );
    cy.get('.outputs-dialog-content__information p:last').should(
      'contain.text',
      `All outputs shown here will be available for mapping to an application in Application Mapping`
    );
  });
}

// For Child Properties radio button should not display
export function promotePlaybookOutputs(dataType) {
  // selecting a parent playbook
  cy.get('.ngx-icon.ngx-tree-expand').siblings('span').should('contain.text', `Promote an action's output`).click();
  cy.get('.ngx-dialog-drawer-content').should('exist');
  cy.get('do-playbook-action-inputs-drawer-card').click();
  if (dataType == 'array') {
    cy.contains('.property__container__content__title', 'result')
      .closest('.property__container')
      .should('contain.text', dataType);
    cy.get('.properties-container ').within(() => {
      cy.get('div.ngx-checkbox--box').should('have.length', 1);
    });
  } else {
    cy.contains('.property__container__content__title', 'result')
      .closest('.property__container')
      .should('contain.text', dataType);
    cy.get('.properties-container ').within(() => {
      cy.get('div.ngx-checkbox--box').should('have.length.greaterThan', 1);
    });
  }
  cy.get('div.ngx-checkbox--box').first().click();
}

export function removePromotedPlaybookOutputs(isconfirm = true) {
  cy.get('turbine-action-outputs button').click();
  verifyDoubleCheck(
    'Are you sure?',
    'Removing this promoted output will remove it anywhere else it is used.',
    true,
    isconfirm ? 'Ok' : 'Cancel'
  );
}

export function checkpromotePlaybookOutputsLables(ispromoted = true, playbookTitle = null, actionName = null) {
  if (ispromoted) {
    cy.get('.playbook-action-output-wrapper').within(() => {
      cy.get('.inner-logo').should('be.visible');
      cy.contains(playbookTitle).should('be.visible');
      cy.get('span.type').contains('ACTION').should('be.visible');
      cy.contains(actionName).should('be.visible');
    });
  } else cy.get('.playbook-action-output-wrapper').should('not.be.visible');
}

export function checkpromotePlaybookOutput(dataType) {
  if (dataType == 'array') {
    cy.get('.name-actions-container .title').should('have.length', 1);
    cy.get('.turbine-action-outputs button').should('have.length', 1);
  } else {
    cy.get('.name-actions-container .title').should('have.length.greaterThan', 1);
    cy.get('.turbine-action-outputs button').should('have.length.greaterThan', 1);
  }
}

export function checkRadioButtonForRemovedPlaybookOutputs() {
  // radio button should display for removed playbook outputs
  cy.get('.ngx-icon.ngx-tree-expand').siblings('span').should('contain.text', `Promote an action's output`).click();
  cy.get('.ngx-dialog-drawer-content').should('exist');
  cy.get('do-playbook-action-inputs-drawer-card:first').click();
  if (cy.get('.property__container__content__subtitle__type').first().contains('array')) {
    cy.get('div.ngx-checkbox--box').should('have.length', 1);
  }
  cy.get('div.ngx-drawer-content').within(() => {
    cy.contains('Dismiss').click();
  });
}

export function searchActionOutupt(promotedProperties) {
  clickPlaybookOutput();
  // Search action's ouputs
  cy.get('.ngx-dialog .ngx-dialog-content.ngx-dialog-content--large').within(() => {
    cy.get('input[placeholder="Search"]').type('there are no outputs matching the search');
    cy.get('turbine-playbook-promoted-action-output').should('not.exist');
    cy.get('button.clear-search-btn').should('exist').click();
    cy.get('input[placeholder="Search"]').type(promotedProperties);
    cy.wait(1000);
    cy.get('.playbook-action-output-wrapper').then(count => {
      if (count.find('turbine-action-outputs .node').length > 0) {
        cy.get('turbine-action-outputs .node div span').contains(promotedProperties);
      } else {
        cy.get('turbine-action-outputs .node').should('not.exist');
      }
    });
  });
}
export function addPlaybookInputInline(playbookInputJSON: playbookInputJSON) {
  // Add new Playbook Input within Action Inputs Dialog
  cy.get('do-playbook-action-inputs-mapper-field-control').click();
  cy.get('h2.ngx-dialog-drawer-content__header-title').should('have.text', 'Select an available playbook property');
  cy.get('do-playbook-action-inputs-drawer-card').within(() => {
    cy.get('i.ngx-icon.ngx-chevron-bold-right').click();
  });
  cy.get('.playbook-action-inputs-drawer-card-section').contains('button', 'Add a playbook input').click();
  cy.get('div.properties-container__new-property')
    .should('contain', 'New Playbook Input')
    .within(() => {
      for (const key of Object.keys(playbookInputJSON)) {
        switch (key) {
          case 'playbookInputName':
            cy.getByLabel('Title').ngxFill(playbookInputJSON[key]);
            break;
          case 'playbookInputKey':
            // TODO: Add code to handle the Playbook Input Property Key
            break;
          case 'playbookInputDescription':
            cy.getByLabel('Description').ngxFill(playbookInputJSON[key]);
            break;
          case 'required':
            cy.get('.ngx-checkbox--box').click();
            break;
          default:
            cy.log('You added a key value pair that does not work for inline Playbook Inputs!');
            break;
        }
      }
      //  Click Done to exit out of inline PlaybookProperty Configuration
      cy.contains('button', 'Done').click();
    });

  cy.get('do-playbook-action-inputs-drawer-card-property').find('ngx-checkbox.ngx-checkbox.round').click();

  // Click Apply to exit out of the Playbook Inputs Manager
  cy.contains('button', 'Apply').should('be.enabled').click();
}

export function modifyPlaybookInput(playbookInputName: string, playbookInputJSON: playbookInputJSON) {
  // Modify a Playbook Input
  cy.get('.playbook-editor .editor-panel-inner__header')
    .find('.playbook-input__btn')
    .contains(new RegExp(`^\\s*Playbook Inputs\\s*$`))
    .click();
  cy.get('do-playbook-inputs-manager-dialog').contains('span.name', playbookInputName).closest('div.node-container');
  cy.get('button.node-options-btn i.ngx-icon.ngx-cog').click();
  cy.get('ngx-property-config')
    .should('exist')
    .within(() => {
      for (const key of Object.keys(playbookInputJSON)) {
        switch (key) {
          case 'playbookInputName':
            cy.getByLabel('PROPERTY TITLE').ngxFill(playbookInputJSON[key]);
            break;
          case 'playbookInputKey':
            // TODO: Add code to handle the Playbook Input Property Key
            break;
          case 'playbookInputDescription':
            cy.getByLabel('PROPERTY DESCRIPTION').ngxFill(playbookInputJSON[key]);
            break;
          case 'playbookInputType':
            //  TODO:  Add code to handle changing the Playbook Input Type, alternately we may need a separate function to change the Type of an existing Playbook input
            break;
          case 'addEnumValue':
            cy.getByLabel('ADD ENUM VALUE').ngxFill(playbookInputJSON[key]);
            break;
          case 'min':
            cy.getByLabel('MINIMUM LENGTH').ngxFill(playbookInputJSON[key].toString());
            break;
          case 'max':
            cy.getByLabel('MAXIMUM LENGTH').ngxFill(playbookInputJSON[key].toString());
            break;
          case 'patternToMatch':
            cy.getByLabel('PATTERN TO MATCH').ngxFill(playbookInputJSON[key]);
            break;
          case 'required':
            cy.get('.ngx-checkbox--box').click();
            break;
          default:
            cy.log('You added a key value pair that does not work for Playbook Inputs!');
            break;
        }
      }
      //  Click Apply to exit out of Property Configuration
      cy.contains('button', 'Apply').click();
    });

  // Click Apply to exit out of the Playbook Inputs Manager
  cy.contains('button', 'Apply').click();
}

export function removePlaybookInput(playbookInputName: string) {
  // Remove a Playbook Input
  cy.get('.playbook-editor .editor-panel-inner__header')
    .find('.playbook-input__btn')
    .contains(new RegExp(`^\\s*Playbook Inputs\\s*$`))
    .click();
  cy.get('do-playbook-inputs-manager-dialog')
    .contains('span.name', playbookInputName)
    .closest('div.node-container')
    .within(() => {
      cy.get('button.node-options-btn i.ngx-icon.ngx-dots-vert-round').click();
      cy.get('ngx-dropdown-menu').get('ul');
      cy.get('button').contains(new RegExp('^\\s*Remove\\s*$')).click();
    });

  // Click Apply to exit out of the Playbook Inputs Manager
  cy.contains('button', 'Apply').click();

  verifyDoubleCheck(
    'You have removed input(s)',
    'If you remove these input(s), they will become undefined anywhere they are referenced.',
    true,
    'Ok'
  );
}

export function findInput(input: number, actioninput: string) {
  cy.get('do-playbook-action-inputs-mapper')
    .find('do-playbook-action-inputs-mapper-card')
    .eq(input)
    .within(() => {
      cy.get('do-playbook-action-inputs-mapper-field').find('ngx-dropdown.ngx-dropdown').click();
      cy.get('ngx-dropdown-menu')
        .get('ul')
        .within(() => {
          cy.get('button').contains(' Playbook property ');
          cy.get('button').contains(' Expression ');
          cy.get('button').contains(' Static value ').click();
        });
      cy.get('do-playbook-action-inputs-mapper-field-control').find('ngx-input.ngx-input').ngxFill(actioninput);
    });
}

export function openExpressionDialog(actionInputName: string) {
  selectPlaybookActionInputOption(actionInputName, ' Expression ');
}

export function selectPlaybookActionInputOption(actionInputName: string, inputType: string) {
  cy.get('do-playbook-action-inputs-mapper-card')
    .contains(new RegExp(`^\\s*${actionInputName}\\s*$`))
    .closest('do-playbook-action-inputs-mapper-card')
    .within(() => {
      cy.get('do-playbook-action-inputs-mapper-field').find('ngx-dropdown.ngx-dropdown').click();
      cy.get('ngx-dropdown-menu').get('button').contains(inputType).click();
      if (inputType === ' Expression ') {
        cy.get('do-playbook-action-inputs-mapper-field-control')
          .find('do-playbook-action-inputs-mapper-field-control-tag')
          .click();
      }
    });
}

export function expressionDialog(expression: string) {
  cy.get('ngx-dialog').within(() => {
    cy.get('do-playbook-action-expression-dialog').find('input.ngx-input-box').type(expression);
    cy.get('div.ngx-dialog-footer').contains(' Apply ').click();
  });
}

export function checkInputs(input: number, actioninput: string) {
  cy.get('do-playbook-action-inputs-mapper')
    .find('do-playbook-action-inputs-mapper-card')
    .eq(input)
    .within(() => {
      cy.get('do-playbook-action-inputs-mapper-field-control')
        .find('ngx-input')
        .ngxGetValue()
        .should('eq', actioninput);
    });
}

export function checkExpression(inputName: string, actioninput: string) {
  cy.get('do-playbook-action-inputs-mapper')
    .find('do-playbook-action-inputs-mapper-card')
    .contains(inputName)
    .closest('do-playbook-action-inputs-mapper-card')
    .within(() => {
      cy.get('do-playbook-action-inputs-mapper-field-control-tag').find('span').should('have.text', actioninput);
    });
}

export function promoteOutput(outputName: string) {
  cy.get('do-playbook-action-outputs').within(() => {
    cy.get('main.property')
      .find('div.title')
      .contains(outputName)
      .closest('div.node.compressed')
      .within(() => {
        cy.get('button.btn').contains(' Promote ').click();
      });
  });
}

export function promotedOutputs() {
  cy.get('do-playbook-action-outputs-promoted').within(() => {
    cy.get('turbine-action-outputs-promoted').get('button').should('have.text', ' Remove ');
  });
}

export function removePromoted() {
  cy.get('do-playbook-action-outputs-promoted').within(() => {
    cy.get('turbine-action-outputs-promoted').get('button').contains(' Remove ').click();
  });
}

export function checkPromoted(outputName: string) {
  cy.get('do-playbook-action-outputs').within(() => {
    cy.get('main.property')
      .find('div.ng-star-inserted')
      .contains(outputName)
      .parents('.node-content')
      .within(() => {
        cy.get('button.btn-style.promoted').should('have.text', ' Promoted ');
      });
  });
}

export function clickApplyCloseButton(key: string) {
  cy.get('ngx-large-format-dialog-footer').within(() => {
    cy.get('button').contains(key).click();
  });
}

export function changesDialog(action: string) {
  verifyDoubleCheck('You Have Unsaved Changes', null, true, action);
}

export function findSpecificPlaybook(cardName: string) {
  cy.intercept('POST', '/orchestration/api/v1/connector/rql').as('postConnector');
  cy.intercept('POST', '/orchestration/api/v1/plugin/rql').as('postPlugin');
  cy.intercept('POST', '/orchestration/api/v1/sensor/rql').as('postSensor');

  cy.get('do-playbooks.do-page').within(() => {
    cy.get('ngx-card-body').contains(cardName).click();
  });

  cy.wait('@postConnector').its('response.statusCode').should('eq', 200);
  cy.wait('@postPlugin').its('response.statusCode').should('eq', 201);
  cy.wait('@postSensor').its('response.statusCode').should('eq', 201);
}

export function findSpecificAction(actionTitle: string) {
  cy.get('do-playbook-visual-editor').within(() => {
    cy.get('g.node.action').contains(actionTitle).click();
  });
}

export function findActionByName(actionName: string) {
  cy.get('do-playbook-visual-editor').within(() => {
    cy.get('g.nodes').find('text.node-name').contains(actionName).click();
  });
}

export function checkPromotedMessage() {
  cy.get('do-playbook-action-outputs-promoted').within(() => {
    cy.get('turbine-action-outputs-promoted')
      .get('span')
      .should('have.text', 'Promote an output from the list to the left')
      .click();
  });
}

export function checkRootProperty() {
  cy.get('do-playbook-action-outputs').within(() => {
    cy.get('main.property')
      .find('div.ng-star-inserted')
      .eq(0)
      .within(() => {
        cy.get('.name-actions-container .title').contains('result ');
        cy.get('button.btn').contains(' Promote ');
      });
  });
}

export function editPlaybookActionName(titleName: string, actionName: string) {
  cy.get('.node > .node-label').contains(titleName).click();
  cy.get('.ngx-input__lock-toggle').click();
  cy.getByLabel('Name').ngxFill(actionName).wait(500);
}

export function editPlaybookActionTitle(titleName: string, newTitle: string) {
  cy.get('.node > .node-label').contains(titleName).click();
  cy.getByLabel('Title').ngxFill(newTitle).wait(500);
}

export function verifyActionNameLockIcon(exists: boolean) {
  const condition = exists ? 'exist' : 'not.exist';
  cy.get('.ngx-input__lock-toggle').should(condition);
}

export function verifyActionNameText(actionName: string) {
  cy.getByLabel('Name').within(() => {
    cy.get('input').should('have.value', actionName);
  });
}

export function verifyActionTitleText(actionTitle: string) {
  cy.getByLabel('Title').within(() => {
    cy.get('input').should('have.value', actionTitle);
  });
}

export function clickPlaybookInput(playbookInputName: string) {
  cy.get('do-playbook-action-inputs-mapper-card')
    .contains(new RegExp(`^\\s*${playbookInputName}\\s*$`))
    .closest('do-playbook-action-inputs-mapper-card')
    .within(() => {
      cy.get('do-playbook-action-inputs-mapper-field-control')
        .find('div.playbook-action-inputs-mapper-field-control__wrapper')
        .click();
    });
}

export function selectPlaybookProperty(playbookPropertyName: string, cardName: string) {
  cy.get('ngx-dialog-drawer-content').within(() => {
    cy.get('h2.ngx-dialog-drawer-content__header-title').should('have.text', 'Select an available playbook property');
    cy.get('do-playbook-action-inputs-drawer-card')
      .contains(new RegExp(`^\\s*${playbookPropertyName}\\s*$`))
      .closest('do-playbook-action-inputs-drawer-card')
      .click();
    cy.get('main.playbook-action-inputs-drawer-card-section').within(() => {
      cy.get('do-playbook-action-inputs-drawer-card-property')
        .contains(cardName)
        .closest('do-playbook-action-inputs-drawer-card-property')
        .find('ngx-checkbox.ngx-checkbox.round')
        .click();
    });
  });
}

export function checkQtyCardsOnDrawer(totalExpectedCards: number) {
  cy.get('ngx-dialog-drawer-content do-playbook-action-inputs-drawer-card').should('have.length', totalExpectedCards);
}

export function dismissDrawer() {
  cy.get('ngx-dialog-drawer-content button.ngx-dialog-drawer-content__dismiss-btn').click();
}

export function verifyPlaybookFormError(errorExists: boolean) {
  const condition = errorExists ? 'exist' : 'not.exist';
  cy.get('.ng-invalid').should(condition);
}

export function verifyNodeCount(numberOfNodes: number) {
  cy.get('.node-rect').should('have.length', numberOfNodes);
}

export function savePlaybookChanges() {
  cy.intercept('PUT', '/orchestration/api/v1/playbook/**').as('putPlaybook');
  cy.get(`[data-cy=playbook__editor-save__btn]`).should('contain', 'Save').click();
  cy.wait('@putPlaybook').its('response.statusCode').should('eq', 200);
  verifyPopup3({ title: 'Playbook Saved Successfully', subtext: '' });
}

export function moveintoTabs(tab: string) {
  cy.get('do-playbook-action-dialog').within(() => {
    cy.get('.ngx-tabs-list').within(() => {
      cy.get('button.ngx-tab').contains(tab).click();
    });
  });
}

export function applyChangesRepeats() {
  cy.get('.ngx-large-format-dialog-content').find('ngx-large-format-dialog-footer button').contains('Apply').click();
}

export function nodesValidationRepeats() {
  cy.get('.nodes').within(() => {
    cy.get('[data-cy=repeat-icon]').should('be.visible');
  });
}

export function findlink() {
  cy.get(`path.line.line-success`).closest('g').should('exist').click();
}

export function addConditionLine() {
  cy.get('foreignObject').find('ngx-icon.icon.icon-conditional').click();
}

export function checkConditionBuilder() {
  cy.get('do-condition-builder-dialog').within(() => {
    cy.get('h1').contains('Edit Condition');
    cy.get('button').contains(' Remove all conditions ');
  });
}

export function addNewConditionPlus() {
  cy.get('do-condition-builder-dialog').within(() => {
    cy.get('i.ngx-icon.ngx-add-circle').click();
  });
}

export function modifycondition(statusCode: string) {
  cy.get('do-condition-builder-dialog').within(() => {
    cy.get('.do-condition-group--conditions-wrapper').find('input').ngxFill(statusCode);
  });
}

export function openRun(type: string, twoActions: boolean) {
  cy.get(`[data-cy=playbook__editor-ellipsis__dropdown]`).click();
  cy.get('ngx-dropdown-menu').find('button').contains(' Test ').click();
  clickRun(type, twoActions);
}

export function clickRun(type: string, twoActions: boolean) {
  cy.intercept('POST', '/orchestration/api/v1/playbook/*/run?async=true').as('playbookRun');
  cy.get('do-playbook-tester').within(() => {
    cy.get('button').contains('Run').click();
    cy.wait('@playbookRun')
      .its('response.statusCode')
      .should('eq', 201)
      .then(() => {
        getRunDetails(type, twoActions);
      });
  });
}

export function closeRun() {
  cy.get('div.right-panel').find('button.close-button').click();
}

export function getRunDetails(type: string, twoActions: boolean) {
  cy.get('turbine-run-details')
    .scrollIntoView()
    .find(`span.job-status.job-status-${type}`)
    .should('have.text', `${type}`);

  if (twoActions == false) {
    cy.get('ngx-tree-node.success')
      .find('span.ngx-node-label.ng-star-inserted')
      .should('have.text', 'Action: Action_Parent');
  } else {
    cy.get('ngx-tree-node.success')
      .find('span.ngx-node-label.ng-star-inserted')
      .eq(0)
      .should('have.text', 'Action: Action_Parent');
    cy.get('ngx-tree-node.success')
      .find('span.ngx-node-label.ng-star-inserted')
      .eq(1)
      .should('have.text', 'Action: Action_Child');
  }
}

export function getRunDetailsCondition() {
  cy.get('turbine-run-details')
    .scrollIntoView()
    .find('span.job-status.job-status-success')
    .should('have.text', 'success');
}

export function clickEdtiCondition() {
  cy.get('foreignObject').find('i.ngx-icon.ngx.ngx-edit-outline-small').click();
}

export function checkEntryPoint(isOn: boolean) {
  cy.get('turbine-action-config ngx-toggle[name=entrypoint]').ngxGetValue().should('eq', isOn);
}

export function openAdvancedSettings() {
  cy.get('do-collapse-panel .turbine-collapsible-panel__title').click();
}

export function checkActionPoolValue(value: string) {
  cy.get('do-collapse-panel ngx-select[name=pool]').ngxGetValue().should('eq', value);
}

export function setActionPoolValue(value: string) {
  cy.get('do-collapse-panel ngx-select[name=pool]').ngxFill(value).select(value);
}

export function selectActionType() {
  cy.get('turbine-action-config [name="action"]')
    .click()
    .find('li')
    .should('be.visible')
    .as('selectActionValue')
    .then(() => {
      cy.get('@selectActionValue').first().click();
    });
}

export function duplicateAction(
  actionName: string,
  actionTitle: string,
  duplicateActionName: string,
  duplicateActionTitle: string
) {
  findSpecificAction(actionTitle);
  cy.wait(500);
  cy.get('g[editor-context-menu] ngx-icon.copy-icon').should('be.visible').click();
  // Wait for the new Action to show up in the UI
  cy.wait(500);

  findActionByName(`${actionName}_`);
  changeActionName(duplicateActionName, duplicateActionTitle);
  cy.get('[name="action"]').click().find('li').should('be.visible').first().click();
}

export function createRecordEventTrigger() {
  cy.get('g.trigger .node__trigger--placeholder-action').should('contain', 'Add a trigger').click();
  cy.get('g.trigger-menu-item').contains('Record Event').should('be.visible').click();
  cy.get('g[data-cy="visual-editor__trigger-node__event-node-0"]').within(() => {
    cy.get('image')
      .should('be.visible')
      .should('have.attr', 'xlink:href', '/assets/turbine-ui-common/record-event-trigger-logo.svg');
  });
}

export function recordEventTriggerConfigMenu(applicationName, recordEventType) {
  cy.get('.panel-body record-event-trigger-config').within(() => {
    cy.get('h5.trigger-config-form__header').should('contain', 'Record Event');
    cy.get('.record-event-container-configure .ngx-button button')
      .should('contain', 'Configure')
      .should('have.attr', 'disabled');
    cy.get('.ngx-select').select(applicationName);
    if (recordEventType == 'Record Create') {
      cy.get('.ngx-checkbox').contains('Record Created').click();
    } else if (recordEventType == 'Record Update') {
      cy.get('.ngx-checkbox').contains('Record Updated').click();
    } else {
      cy.get('.ngx-checkbox').contains('Record Created').click();
      cy.get('.ngx-checkbox').contains('Record Updated').click();
    }
  });
}

export function nodeValidatorRecordEventTrigger(applicationName, recordEventType) {
  cy.get('g[data-cy="visual-editor__trigger-node__event-node-0"]').within(() => {
    cy.get('.node-sub-label').should('contain', applicationName);
    if (recordEventType == 'Record Created') {
      cy.get('.node-label').should('contain', 'Created');
    } else if (recordEventType == 'Record Update') {
      cy.get('.node-label').should('contain', 'Updated');
    } else {
      cy.get('.node-label').should('contain', 'Created/Updated');
    }
  });
}

export function inputsRecordEventTrigger(inputType) {
  cy.get('.record-event-container-configure .ngx-button button').should('contain', 'Configure').click();
  cy.get('.ngx-dialog do-record-trigger-inputs-mapper-dialog')
    .find('section.dialog-container__body')
    .should('be.visible')
    .should(
      'contain',
      'There are no playbook inputs to map. To use playbook inputs, configure them in your playbook input manager.'
    );
  cy.get('.ngx-dialog do-record-trigger-inputs-mapper-dialog')
    .find('ngx-large-format-dialog-footer button')
    .should('be.visible')
    .should('contain', 'Close')
    .click();
  cy.get('.playbook-editor .editor-panel-inner__header').find('.playbook-input__btn').click();
  cy.get('do-playbook-inputs-manager-dialog').within(() => {
    cy.contains('button', 'Add a property').click();
    cy.get('ngx-dropdown-menu').should('exist').contains('button', inputType).click();
  });
  cy.get('ngx-property-config')
    .should('exist')
    .within(() => {
      cy.getByLabel('PROPERTY TITLE').ngxFill(inputType);
      cy.contains('button', 'Apply').click();
    });
  cy.get('.ngx-large-format-dialog-footer button').contains('Apply').should('be.visible').click();
}

export function mapInputsRecordEventTrigger(inputType, fieldtoMap) {
  cy.get('.record-event-container-configure').within(() => {
    cy.get('.ngx-button button').click();
  });
  cy.get('.ngx-dialog do-record-trigger-inputs-mapper-dialog')
    .should('be.visible')
    .within(() => {
      cy.get('.do-trigger-inputs-mapper-card__title').should('contain', inputType);
      cy.get('.do-trigger-inputs-mapper-card__field .ngx-select').select(fieldtoMap);
    });
  cy.get('.ngx-large-format-dialog-footer button').contains('Apply').should('be.visible').click();
}
// here we are using an index to know which node to copy since the nodes are identical
export function copyNodeRecordEventTrigger(applicationName, recordEventType, nodeToCopy) {
  cy.contains('Record Event')
    .closest('g[data-cy="visual-editor__trigger-node__event-node-0"]')
    .eq(nodeToCopy)
    .click()
    .within(() => {
      cy.get('foreignObject .copy-icon').should('be.visible').click();
    });
  // wait for trigger to be added
  cy.wait(1000);
  cy.get('g[data-cy="visual-editor__trigger-node__event-node-0"]')
    .eq(nodeToCopy + 1)
    .should('be.visible')
    .within(() => {
      cy.get('image').should('have.attr', 'xlink:href', '/assets/turbine-ui-common/record-event-trigger-logo.svg');
      cy.get('.node-label').should('contain', recordEventType);
      cy.get('.node-sub-label').should('contain', applicationName);
    });
}
// here we are using an index to know which node to delete since the nodes are identical
export function deleteNodeRecordEventTrigger(nodeToDelete) {
  cy.get('g[data-cy="visual-editor__trigger-node__event-node-0"]')
    .eq(nodeToDelete)
    .click()
    .within(() => {
      cy.get('foreignObject .delete-icon').should('be.visible').click();
    });
  verifyDoubleCheck('Delete trigger', 'Are you sure you want to delete the trigger?');
}

export function verifyCodeEditorByLine(name, expectedText) {
  cy.get('.view-line > span')
    .contains(new RegExp('^' + name + '$', 'g'))
    .closest('div')
    .then(element => {
      expect(element.text().replace(/\s+/g, '')).equal(name + ':' + expectedText.replace(/\s+/g, ''));
    });
}

export function verifyCodeEditorByDisplayedText(expectedText) {
  cy.get('.view-lines').each(element => {
    expect(element.text().replace(/\s+/g, '')).contains(expectedText.replace(/\s+/g, ''));
  });
}

export function recenterPlaybookView() {
  cy.get('.menu-item[tooltiptitle="Center graph"]').click();
}

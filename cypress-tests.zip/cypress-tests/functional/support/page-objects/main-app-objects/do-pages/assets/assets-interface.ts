// tslint:disable: tsr-detect-non-literal-regexp

import { verifyPopup3 } from '../../common-pieces/popupMessages';
import * as interactions from '../../common-pieces/interactions';
import * as pluginDetails from '../plugins/plugin-details';
export { pluginDetails };
type assetJSON = {
  assetName?: string;
  assetType?: string;
  paramData?: string[];
  noAssets?: boolean;
  invalid?: boolean;
  sourcePluginCheck?: boolean;
  invalidName?: boolean;
  invalidTitle?: boolean;
};

export function verifyElements(noAssets = true) {
  cy.intercept('POST', '/orchestration/api/v1/asset').as('postAsset');
  cy.get('.do-assets .do-page-no-elements')
    .find('.do-page-no-elements__header')
    .contains(/^\s*Start by creating your first asset\s*$/)
    .should('be.visible')
    .as('startByCreatingFirstAssetMessage');
  cy.get('.do-page-no-elements__connect > span')
    .contains(/^\s*Create an asset\s*$/)
    .should('be.visible')
    .as('createAnAssetButtonMessage');
  cy.get('.do-page-no-elements__connect > ngx-icon')
    .should('be.visible')
    .should('have.attr', 'fonticon', 'add-circle-medium')
    .as('createAnAssetButtonIcon');
}

export function createAsset(assetJSON: assetJSON = {}) {
  cy.intercept('POST', '/orchestration/api/v1/asset').as('postAsset');
  cy.intercept('POST', '/orchestration/api/v1/asset/test-connection').as('testAssetConnection');
  cy.get('.do-assets')
    .find(
      assetJSON.noAssets
        ? `.do-page-no-elements__connect .do-page__add-button[fonticon="add-circle-medium"]`
        : `.do-page__add-button[fonticon="add-circle-medium"]` + ' .ngx-add-circle-medium'
    )
    .click();
  cy.get('.do-modal-dialog__item-selection-sidebar')
    .find('.ngx-input-box[placeholder="Search Assets..."]')
    .should('be.visible')
    .then($el => {
      interactions.typeInField($el, assetJSON.assetType);
    });
  cy.get('.do-modal-dialog__content-wrapper')
    .should('be.visible')
    .find('.ngx-card .ngx-card-title')
    .contains(assetJSON.assetType)
    .closest('.ngx-card')
    .should('be.visible')
    .as('assetCard');
  cy.get('@assetCard')
    .find('.ngx-card-section .view-details')
    .contains(/^\s*Plugin Details\s*$/)
    .should('be.visible')
    .then($pluginDetailsLink => {
      if (assetJSON.sourcePluginCheck) {
        cy.wrap($pluginDetailsLink).click();
        pluginDetails.close();
      }
    })
    .get('@assetCard')
    .find('.ngx-card--select input[type="checkbox"]')
    // Have to use the force here as the element is not visible
    .click({ force: true });
  cy.get('.do-dialog-details-form__article')
    .find('.ngx-input[formcontrolname="title"] .ngx-input-box-wrap .ngx-input-box')
    .as('assetTitleInputField')
    .then($el => {
      interactions.typeInField(
        $el,
        assetJSON.invalidTitle ? `${assetJSON.assetName}Invalid Title` : `${assetJSON.assetName}`,
        true,
        true
      );
    });
  cy.get('.do-dialog-details-form__article')
    .find('.ngx-input[formcontrolname="name"] .ngx-input-box-wrap .ngx-input-box')
    .as('assetNameInputField')
    .then($el => {
      cy.get('.ngx-input__lock-toggle').click();
      interactions.typeInField(
        $el,
        assetJSON.invalidName ? `${assetJSON.assetName}Invalid Name` : `${assetJSON.assetName}`,
        true,
        true
      );
    });
  cy.get('.ngx-input[formcontrolname="description"]')
    .find('.ngx-input-textarea')
    .then($el => {
      interactions.typeInField($el, assetJSON.assetName + '_Test_Description', true, true);
    });
  cy.get('.ngx-toggle[formcontrolname="testingEnabled"]')
    .find('div > .ngx-toggle-input[type="checkbox"]')
    .should('have.class', 'ng-invalid');
  cy.get('.ngx-input[formcontrolname="interval"]').should('have.class', 'ng-valid');
  cy.get('.ngx-select[formcontrolname="poolId"]').should('have.class', 'ng-valid');
  cy.get('.ngx-json-editor-flat')
    .find('textarea,input')
    .as('inputFields')
    .then($fields => {
      let i = 0;
      cy.get('@inputFields').each($inputField => {
        interactions.typeInField($inputField, assetJSON.paramData[i], true, true);
        i += 1;
      });
    });
  cy.get('@assetNameInputField').then($field => {
    if (assetJSON.invalidName) {
      cy.wrap($field)
        .closest('ngx-input[formcontrolname="name"]')
        .should('have.class', 'ng-invalid')
        .get('.do-asset-create-dialog__test-btn')
        .contains(/^\s*Test Connection\s*$/)
        .should('be.disabled')
        .get('.btn-primary')
        .contains(/^\s*Create\s*$/)
        .should('be.disabled');
      cy.wrap($field).then($el => {
        interactions.typeInField($el, 'Corrected_Test_Asset_Name', true, true);
      });
    } else {
      cy.wrap($field)
        .closest('ngx-input[formcontrolname="name"]')
        .should('have.class', 'ng-valid')
        .get('.do-asset-create-dialog__test-btn')
        .contains(/^\s*Test Connection\s*$/)
        .should('not.be.disabled')
        .get('.btn-primary')
        .contains(/^\s*Create\s*$/)
        .should('not.be.disabled');
    }
  });
  cy.get('.do-asset-create-dialog__test-btn')
    .contains(/^\s*Test Connection\s*$/)
    .click();
  cy.get('.ngx-alert-dialog')
    .find('.ngx-dialog-body')
    .then($testConnectionResponse => {
      if (assetJSON.invalid) {
        cy.wrap($testConnectionResponse)
          .should('be.visible')
          .contains(/^.*Asset test failed.*$/);
      } else {
        cy.wrap($testConnectionResponse)
          .should('be.visible')
          .contains(/^\s*Asset test was successful\.\s*$/);
      }
    })
    .should('be.visible');
  cy.get('.ngx-alert-dialog')
    .find('.ngx-dialog-header .close-button')
    .contains(/^\s*Ok\s*$/)
    .should('be.visible')
    .click();
  cy.get('.btn-primary')
    .contains(/^\s*Create\s*$/)
    .click()
    .wait('@postAsset');
  verifyPopup3({
    title: 'Asset created',
    subtext: 'The asset has been successfully created.'
  });
}

export function createAssetWithNoAssetsAvailable() {
  cy.get('.do-assets')
    .find('.do-page__header .do-page__header-utilities-section ngx-icon[fonticon="add-circle-medium"]')
    .click();
  cy.get('.ngx-large-format-dialog-header-title')
    .contains(/^\s*Select An Asset Type\s*$/)
    .should('exist');
  cy.get('.do-modal-dialog__item-selection-sidebar')
    .find('.do-modal-dialog__item-selection-inline-link')
    .contains(/^\s*Head over to plugins to find more asset types\s*$/)
    .get('button')
    .contains(/^\s*Close\s*$/)
    .click();
}

export function deleteAsset(assetName) {
  cy.intercept('DELETE', '/orchestration/api/v1/asset/**').as('delAsset');
  cy.get('.ngx-card--asset')
    .find('.ngx-card-title')
    .contains(new RegExp(`^\\s*${assetName}\\s*$`))
    .closest('.ngx-card--asset')
    .find('.ngx-dropdown ngx-dropdown-toggle')
    .as('deleteAssetDropdownTrigger')
    .click();
  cy.get('@deleteAssetDropdownTrigger')
    .closest('.ngx-dropdown')
    .find('.vertical-list')
    .find('li > button')
    .contains(/^\s*Delete Asset\s*$/)
    .click();
  cy.get('.asset-delete').find('.ngx-long-press').first().trigger('mousedown').wait('@delAsset').wait(1000);
}

export function updateAsset(assetName) {
  cy.get('.ngx-card--asset')
    .find('.ngx-card-title')
    .contains(new RegExp(`^\\s*${assetName}\\s*$`))
    .click();
  cy.get('.ngx-large-format-dialog-content[dialogtitle="Edit Asset"]').should('be.visible');
  cy.get('.ngx-input__lock-toggle').click();
  cy.get('.ngx-input[formcontrolname="name"]')
    .find('.ngx-input-box-wrap .ngx-input-box')
    .then($el => {
      interactions.typeInField($el, assetName + '_Update', true, true);
    });
  cy.get('.ngx-input[formcontrolname="description"]')
    .find('.ngx-input-textarea')
    .then($el => {
      interactions.typeInField($el, assetName + '_Update', true, true);
    });
  cy.get('.btn-primary')
    .contains(/^\s*Save\s*$/)
    .click();
  verifyPopup3({
    title: 'Asset updated',
    subtext: 'The asset has been successfully updated.'
  });
}

// tslint:disable: tsr-detect-non-literal-regexp

import { openPopoutMenu } from './do-common-calls';
import * as pluginUploader from './plugins/plugin-upload';
export { pluginUploader };
import * as pluginDetails from './plugins/plugin-details';
import { checkUploadComplete } from './plugins/plugin-upload';
export { pluginDetails };

type PLUGIN_TYPE = {
  filePath: string;
  encoding: string;
};

const mainEle = 'do-plugins';

export function openUploadDialog() {
  cy.get(mainEle).within(() => {
    cy.get('ngx-plus-menu.position-right')
      .click()
      .within(() => {
        cy.get('.ngx-plus-menu--item')
          .contains(/^\s*Upload a plugin\s*$/)
          .click();
      });
  });
}

export function installPlugin() {
  cy.get(mainEle).then(body => {
    if (body.find('ngx-plus-menu.position-bottom').length > 0) {
      cy.get('ngx-plus-menu.position-bottom')
        .click()
        .within(() => {
          cy.get('.ngx-plus-menu--item')
            .contains(/^\s*Upload a plugin\s*$/)
            .click();
        });
    } else {
      cy.get('.ngx-plus-menu--circle-container').click();
      cy.get(mainEle).within(() => {
        cy.get('.ngx-plus-menu--item')
          .contains(/^\s*Upload a plugin\s*$/)
          .click();
      });
    }
  });
}

export function uploadPlugin(fileName: PLUGIN_TYPE | string = '', noPluginsInstalled = true) {
  const popoutMenuJSON = {
    orchItem: 'plugin',
    menuItemIcon: 'upload-outline-small',
    optionName: 'Install a plugin',
    popoutMenuItemLabel: ' Upload a plugin ',
    noOrchItems: noPluginsInstalled
  };

  openPopoutMenu(popoutMenuJSON); // , 'upload');
  if (fileName !== '') {
    pluginUploader.uploadFile(fileName);
  }
}

export function getPluginsCount() {
  return (
    cy
      .get('.do-plugins')
      .find('.do-page__content-wrapper div')
      // .invoke('text')
      .then($el => {
        if ($el.text().includes('Start by adding your first plugin')) {
          return 0;
        } else {
          cy.get('.do-plugins__group-content').find('.ngx-card--plugin').its('length');
        }
      })
  );
}

export function getPluginInstalledCountByVendor(vendorName, numInstalled) {
  cy.get('.do-plugins__group-header')
    .contains(new RegExp(`^\\s*${vendorName}\\s*$`))
    .closest('.do-plugins__group-header')
    .within(() => {
      cy.get('div').contains(new RegExp(`^\\s*${numInstalled}\\s*$`));
      // .closest('.do-plugins__group-header')
      cy.get('div').contains(numInstalled > 1 ? /^\s*Plugins\s*$/ : /^\s*Plugin\s*$/);
    });
}

export function findPluginInListing(pluginName) {
  return cy
    .get('.ngx-card--plugin')
    .find('.ngx-card-title')
    .contains(new RegExp(`^\\s*${pluginName}\\s*$`))
    .closest('.ngx-card--plugin')
    .as('foundPlugin')
    .scrollIntoView();
}

export function getPluginListItemDetails(pluginName) {
  const pluginDetailsJSON = {
    title: '',
    version: '',
    name: '',
    description: ''
  };

  return findPluginInListing(pluginName).then(() => {
    return cy
      .get('@foundPlugin')
      .scrollIntoView()
      .then(() => {
        cy.get('@foundPlugin')
          .find('.ngx-card-title')
          .its('0.innerText')
          .then($text => {
            pluginDetailsJSON.title = $text;
          });
        cy.get('@foundPlugin')
          .find('.ngx-card-subtitle .secondary')
          .its('0.innerText')
          .then($text => {
            pluginDetailsJSON.version = $text.trim();
          });
        cy.get('@foundPlugin')
          .find('.ngx-card-subtitle > span')
          .last()
          .its('0.innerText')
          .then($text => {
            pluginDetailsJSON.name = $text.trim();
          });
        return cy
          .get('@foundPlugin')
          .find('.ngx-card-section--description')
          .its('0.innerText')
          .then($text => {
            pluginDetailsJSON.description = $text;
            return pluginDetailsJSON;
          });
      });
  });
}

export function scrollToVendorName(vendorName, pluginName) {
  return findPluginInListing(pluginName).then(() => {
    cy.get('@foundPlugin')
      .closest('.do-plugins__group')
      .find('.do-plugins__group-header')
      .contains(new RegExp(vendorName));
    return cy.get('.do-plugins__group-content').within(() => cy.get('@foundPlugin').contains(pluginName));
  });
}

export function checkDisabledVendorNavItems(vendorName) {
  return cy
    .get('.plugin-alphabet-nav-host')
    .get('.disabled')
    .should('not.contain', new RegExp(`^\\s*${vendorName}\\s*$`))
    .as('foundDisabledNavItems');
}

export function clickOnPluginDetails(pluginName) {
  return findPluginInListing(pluginName).then(() => {
    return cy.get('@foundPlugin').find('.view-details').click();
  });
}

export function filterPluginsByName(pluginName) {
  return cy
    .get('.filters-container input')
    .type(pluginName)
    .get('.ngx-card--plugin')
    .find('.ngx-card-title')
    .contains(new RegExp(`^\\s*${pluginName}\\s*$`));
}

export function deletePlugin(pluginName, doNotDelete = false) {
  cy.intercept('DELETE', '/orchestration/api/v1/plugin/**').as('delPlugin');
  cy.intercept('GET', '/orchestration/api/v1/plugin/**/linked').as('getPluginsLink');

  return findPluginInListing(pluginName).then(() => {
    cy.get('.ngx-card--plugin')
      .find('.ngx-card-title')
      .contains(new RegExp(`^\\s*${pluginName}\\s*$`))
      .closest('.ngx-card--plugin')
      .find('.ngx-dropdown')
      .within(() => {
        cy.get('ngx-dropdown-toggle').click();
        cy.get('.vertical-list')
          .find('li > button')
          .contains(/^\s*Delete Plugin\s*$/)
          .click();
      });

    cy.wait('@getPluginsLink');
    cy.get('.ngx-dialog-content').within(() => {
      if (doNotDelete) {
        cy.get('button.close').click();
      } else {
        cy.get('.ngx-long-press').trigger('mousedown').wait('@delPlugin');
      }
    });
    cy.get('.ngx-dialog-content').should('not.exist');
  });
}

export function checkPlugin(uploadFileJSON, pluginName, pluginVersion) {
  cy.makeTurbineAPICall('GET', 'v1/plugin').then(bodyJSON => {
    const matchingPlugins = bodyJSON.items.filter(
      items => items.item.plugin.title && items.item.plugin.title === pluginName
    );
    if (matchingPlugins.length <= 0) {
      cy.log('plugin needs to be upload');
      uploadPlugin(uploadFileJSON, false);
      checkUploadComplete(pluginName);
      pluginUploader.close();
    } else if (!matchingPlugins.some(items => items.item.plugin.title && items.item.plugin.version === pluginVersion)) {
      // An improper version of the plugin is already there, remove that and install the desired version
      cy.log('Removing incorrect version of plugin');
      deletePlugin(pluginName);
      cy.log('Installing correct version of plugin');
      uploadPlugin(uploadFileJSON, false);
      checkUploadComplete(pluginName);
      pluginUploader.close();
    } else {
      cy.log('Plugin exists');
    }
  });
}

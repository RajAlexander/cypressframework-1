// tslint:disable: tsr-detect-non-literal-regexp

export function verifyPlaybookName(playBookName) {
  cy.get('do-playbook-edit-dialog').within(() => {
    cy.get('div.playbook-dialog-inputs--form').find('.ngx-input[formcontrolname="name"]');
    cy.get('.ngx-input__lock-toggle').should('be.visible').click();
    cy.get('div.playbook-dialog-inputs--form .ngx-input-box[formcontrolname="name"]').contains(
      new RegExp(`^\\s*${commonCalls.escapeForRegex(playBookName)}\\s*$`)
    );
  });
}

export function getPluginsUsed() {
  const playbookList = { danger: [], good: [] };
  return cy
    .get('do-playbook-detail-dialog')
    .find('do-playbook-detail-plugin')
    .each(($el, index, $list) => {
      cy.wrap($el)
        .as('aPlugin')
        .find('.playbook-detail-plugin__content div.playbook-detail-plugin__title')
        .its('0.innerText')
        .then($text => {
          cy.get('@aPlugin')
            .invoke('attr', 'class')
            .then($class => {
              if ($class.includes('danger')) {
                playbookList.danger.push($text);
              } else {
                playbookList.good.push($text);
              }
            });
        });
    })
    .then(() => {
      return playbookList;
    });
}

export function getPlaybookOverview() {
  // TODO: get more details on the PlaybookOverview to check details
}

export function close() {
  cy.get('.dialog-bar__action')
    .contains(/^\s*Dismiss\s*$/)
    .click();
}

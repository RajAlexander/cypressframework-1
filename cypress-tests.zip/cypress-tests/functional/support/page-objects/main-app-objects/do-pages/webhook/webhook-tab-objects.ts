// tslint:disable: tsr-detect-non-literal-regexp
import * as swimInstance from '../../../../page-objects/swimInstance';

export function verifyWebhookPlaybookCount(expected) {
  cy.get('do-webhooks__group').its('length').should('eq', expected);
}

export function verifyWebhookGroup(webhookTitle, playbookTitle) {
  cy.get('div.do-webhooks__group-header').contains(playbookTitle);
  // verify image
  findCurrentCard(webhookTitle)
    .as('currentCard')
    .find('.ngx-card-avatar--img')
    .should('be.visible')
    .should('have.attr', 'src', '/assets/turbine-ui-common/webhook-logo-color.svg');
  // verify webhook name
  cy.get('@currentCard').find('[data-cy="sensors__sensor-card-title"]').contains(webhookTitle).should('be.visible');
  // verify playbook label
  cy.get('@currentCard').find('.playbook-name__spacer').should('be.visible').should('have.text', 'Playbook');
  // verify playbook name
  cy.get('@currentCard').find('.secondary').should('be.visible').should('have.text', playbookTitle);
  verifyEnabledDisabled('@currentCard', true);
}

export function verifyWebhookHeaderByPlaybook(playbookTitle, expectedCount, webhookLabel = 'Webhook') {
  // verify playbook name
  cy.get('div.do-webhooks__group-header')
    .contains(playbookTitle)
    .closest('div.do-webhooks__group-header')
    .as('playbookHeader');
  // verify count
  cy.get('@playbookHeader')
    .find('div')
    .contains(new RegExp('^' + expectedCount + '$'))
    .invoke('text')
    .then(text => +text)
    .should('eq', expectedCount);
  // verify webhooks label
  cy.get('@playbookHeader').closest('div').contains('Webhook').invoke('text').should('eq', webhookLabel);
}

// add edit webhook
export function verifyWebhookTab(expectedCount) {
  cy.dataCy('orchestration-tab__webhooks').as('webhookTab');
  cy.get('@webhookTab')
    .invoke('text')
    .then(text => text)
    .should('eq', ' WEBHOOKS ' + expectedCount);
}

export function verifyEnabledDisabled(card, enabled = true) {
  cy.get(card).within(() => {
    verifyTextIsNotVisible('.ngx-toggle-text > .ng-star-inserted', enabled ? /^\s*Disabled\s*$/ : /^\s*Enabled\s*$/);
    verifyTextIsVisible('.ngx-toggle-text > .ng-star-inserted', enabled ? /^\s*Enabled\s*$/ : /^\s*Disabled\s*$/);
  });
}

function verifyTextIsVisible(element, expectedText) {
  cy.get(element, { timeout: 10000 }).contains(expectedText, { timeout: 10000 }).should('be.visible');
}
function verifyTextIsNotVisible(element, expectedText) {
  cy.get(element).invoke('text').should('not.equal', expectedText);
}

export function setEnableDisabledWebhook(webhookName, enabled = true) {
  cy.intercept('PUT', '/orchestration/api/v1/sensor/*').as('putSensor');
  findCurrentCard(webhookName).within(() => {
    cy.get('label.ngx-toggle-text > span')
      .contains(enabled ? 'Disabled' : 'Enabled')
      .should('be.visible')
      .click();
  });
  cy.wait('@putSensor').its('response.statusCode').should('eq', 200);
  // the screen refreshes / flickers.   There isn't request to intercept or a text items to wait for that is stable
  verifyEnabledDisabled('@currentCard', enabled);
}

export function openEllipsisDropdown(webhookTitle) {
  findCurrentCard(webhookTitle).within(() => {
    cy.get('.ngx-dropdown-toggle > ngx-icon > .ngx-icon').click();
    cy.dataCy('sensors__edit-sensor__btn')
      .contains(/^\s*Edit Webhook\s*$/)
      .should('be.visible');
  });
}

export function verifyEllipsisDropdownEditSensor(webhookName) {
  openEllipsisDropdown(webhookName);
  cy.get('.ngx-dropdown-toggle > ngx-icon > .ngx-icon').click();
}
export function verifyWebhookIsNotPlugin(webhookName) {
  swimInstance.openPlugins();
  cy.contains(webhookName).should('not.exist');
  swimInstance.openWebhooks();
}

export function findCurrentCard(webhookName) {
  return cy.dataCy('sensors__sensor-card-title').contains(webhookName).parentsUntil('.do-connectors__group-content');
}

export function clickEditWebhook(webhookTitle) {
  cy.intercept('POST', 'orchestration/api/v1/sensor/*/logs/rql').as('postSensorLogs');
  openEllipsisDropdown(webhookTitle);
  cy.get('Button').contains('Edit Webhook').click();
  cy.wait('@postSensorLogs');
}

// tslint:disable: tsr-detect-non-literal-regexp

export function getwebhookUrl() {
  return cy.getByLabel('Webhook URL');
}

export function getWebhookName() {
  cy.contains('Webhook Name', { timeout: 120000 });
  return cy.getByLabel('Webhook Name');
}

export function getWebhookTitle() {
  cy.contains('Webhook Title', { timeout: 120000 });
  return cy.getByLabel('Webhook Title');
}

export function getCopyUrl() {
  return cy.get('a').contains('Copy URL');
}

export function getDescription() {
  return cy.getByLabel('Description');
}

export function getEnableDisabled() {
  return cy.get('webhook-trigger-config .ngx-toggle').find('label');
}

export function getNodeWithText(textInNode) {
  cy.get('.node', { timeout: 10000 }).should('be.visible');
  return cy.get('.node').contains(textInNode).should('be.visible');
}

export function verifyNodeTriggerDropDown(triggerItems) {
  // there are no requests to intercept or UI items to wait for.
  // However, a delay is needed
  cy.wait(500);
  cy.get('#triggers > g > g').within(() => {
    cy.get('.trigger-menu-item').should('be.visible');
  });
  cy.get('#triggers > g > g').within(() => {
    cy.get('.trigger-menu-item').each((item, index) => {
      expect(item.text().trim()).to.equal(triggerItems[index]);
    });
  });
}

export function clickOnNodeTriggerType(triggerType) {
  // there are no requests to intercept or UI items to wait for.
  // However, a delay is needed
  cy.wait(1000);
  cy.contains(triggerType).should('be.visible').click();
}

export function waitForLinesToDraw() {
  cy.get('g.links', { timeout: 10000 }).then($element => {
    $element.find('path.invisible-line').length > 0;
  });
}

export function enterWebhookName(webhookName) {
  cy.get('.ngx-input-box-wrap > .btn > .ngx-icon').click();
  getWebhookName().find('input').ngxFill(webhookName);
}

export function enterWebhookTitle(webhookTitle) {
  getWebhookTitle().find('input').ngxFill(webhookTitle);
}

export function enterWebhookDescription(webhookDescription) {
  getDescription().find('textarea').ngxFill(webhookDescription);
}

export function clickGenerateUrl() {
  cy.intercept('POST', '/orchestration/api/v1/sensor').as('generateUrl');
  // click on the generate URL button
  cy.get('.content').contains('Generate URL').should('be.visible').click();
  cy.wait('@generateUrl');
}

export function verifyPanelHeader() {
  cy.get('.trigger-config > .panel-header').then(header => {
    expect(header.text().trim()).equals('Trigger');
  });
}

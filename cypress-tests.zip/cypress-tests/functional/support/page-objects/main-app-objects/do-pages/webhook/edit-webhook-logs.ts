// tslint:disable: tsr-detect-non-literal-regexp

export function verifyHeaderInfo() {
  cy.get('ngx-large-format-dialog-content[class="ngx-large-format-dialog-content"]').within(() => {
    cy.get('.ngx-tabs-list button.ngx-tab')
      .should('have.class', 'active')
      .contains(/^\s*LOGS\s*$/);
    verifyTextIsVisible('.ngx-large-format-dialog-header-title__text-wrapper > h1', /^\s*Edit Webhook\s*$/);
  });
}

export function verifyHeaderTitle(webhookTitle) {
  cy.get('section').within(() => {
    cy.get('ngx-card-title').should('contain.text', webhookTitle);
  });
}
export function verifyHeaderSecondardyName(webhookName) {
  cy.get('section').within(() => {
    cy.get('.ngx-card-subtitle').should('contain.text', webhookName);
  });
}
export function verifyEnabledDisabled(enabled = true) {
  cy.get('.do-modal-dialog__content-wrapper > .ngx-card--sensor').within(() => {
    verifyTextIsVisible('.ngx-toggle > div .ngx-toggle-text', enabled ? /^\s*Enabled\s*$/ : /^\s*Disabled\s*$/);
  });
}

export function verifyWebhookLogsWrapExist() {
  cy.get('.sensor-logs').within(() => {
    verifyTextIsVisible('.sensor-logs__header-label', /^\s*Webhook Logs\s*$/);
    cy.get('.word-wrap-checkbox').within(() => {
      verifyTextIsVisible('.ngx-checkbox--label', /^\s*Word Wrap\s*$/);
      cy.get('.ngx-checkbox--box').should('have.class', 'checked');
    });
  });
}

export function verifyJumpToDateExist() {
  cy.get('.sensor-logs__header')
    .find('.ngx-dropdown-toggle')
    .contains(/^\s*Jump to date\s*$/);
}

export function verifyWebhookLogStatusRunning(checkData = null) {
  cy.get('.sensor-logs__content-wrapper .sensor-logs__log-entry-wrapper')
    .contains(/^\s*Changed status starting -> running\s*$/)
    .should('be.visible');
}

export function verifyWebhookLogEntry(eventText) {
  cy.get('.sensor-logs__log-entry-message')
    .contains(eventText.toString().replace(Cypress.config().baseUrl + '/webhooks', ''))
    .should('be.visible');
}

function verifyTextIsVisible(element, expectedText) {
  cy.get(element).contains(expectedText).should('be.visible');
}

export function clickButtonWithText(text) {
  cy.get('button').contains(text).should('be.visible').click();
}

export function setEnableDisabledWebhook(enabled = true) {
  cy.intercept('PUT', '/orchestration/api/v1/sensor/*').as('putSensor');
  cy.get('.do-modal-dialog__content-wrapper > .ngx-card--sensor').within(() => {
    cy.get('label.ngx-toggle-text > span')
      .contains(enabled ? 'Disabled' : 'Enabled')
      .should('be.visible')
      .click();
  });

  // the following is needed to refresh the log
  cy.wait('@putSensor');
  // Unfortunately, there isn't anything to intercept or wait for
  // but a delay is needed.  It seems to fail with a value less than 2000
  cy.wait(2000);
  cy.get('.ngx-dropdown-toggle > span').contains('Jump to date').click();
  cy.intercept('POST', 'orchestration/api/v1/sensor/*/logs/rql').as('postSensorLogs');
  cy.get('button.day.today.active.focus').click();
  cy.wait('@postSensorLogs');
  verifyEnabledDisabled(enabled);
}
export function verifyLoggedEvents(items) {
  cy.get('.sensor-logs__log-entry-message')
    .should('have.length', items.length)
    .each((element, index) => {
      expect(element.text().toString().trim()).to.equal(items[index]);
    });
}

// tslint:disable: tsr-detect-non-literal-regexp

import { verifyPopup3 } from '../../common-pieces/popupMessages';
import * as editWebhookLog from './edit-webhook-logs';
import * as playbookWebhook from '../playbook-webhook';
const authItems = ['Basic Authentication', 'Shared Secret Authentication'];
const secretFormatItems = ['base64', 'jwt', 'plaintext'];
const secretLocationItems = ['Request Body', 'Request Header', 'Request Query Parameter'];

export function getHeaderTitle(webhookTitle) {
  cy.get('section').within(() => {
    cy.get('ngx-card-title').should('contain.text', webhookTitle);
  });
}
export function getHeaderSecondaryName(webhookName) {
  cy.get('section').within(() => {
    cy.get('ngx-card-subtitle').should('contain.text', webhookName);
  });
}
export function getHeaderDescription(webhookDescription) {
  cy.get('ngx-card-section.ngx-card-section--description.ngx-card-section > p').should(
    'contain.text',
    webhookDescription
  );
}
export function editDialog() {
  return cy.get('do-sensor-edit-dialog');
}
export function getSettingsEnableDisableCheckbox() {
  return editDialog().find('input[type="checkbox"]');
}
export function getSettingsTitle() {
  return cy.dataCy('sensor-form__title__input');
}
export function getSettingsName() {
  return cy.dataCy('sensor-form__name__input');
}
export function getWebhookNameLockIcon() {
  return cy.get('.ngx-icon.ngx-lock');
}
export function getSettingsDescription() {
  return cy.dataCy('sensor-form__desc__input');
}
export function verifySettingsTitle(webhookTitle) {
  getSettingsTitle().ngxGetValue().should('equal', webhookTitle);
}
export function verifySettingsName(webhookName) {
  getSettingsName().ngxGetValue().should('equal', webhookName);
}
export function verifySettingsDescription(webhookDescription) {
  getSettingsDescription().ngxGetValue().should('equal', webhookDescription);
}
export function verifySettingsLogo() {
  cy.get('.do-dialog-details-form__card-section').within(() => {
    cy.get('.inner-logo > .ngx-card-avatar--img')
      .should('be.visible')
      .should('have.attr', 'src', '/assets/turbine-ui-common/webhook-logo-color.svg');
  });
}
export function clickCloseButton() {
  cy.get('Button').contains('Close').click();
}
export function clickSaveCloseButton() {
  cy.get('Button').contains('Save and Close').click();
}
export function clickPropertyDropdown(text) {
  cy.get(' ngx-dropdown-toggle > button > span').contains(text).click();
}

export function verifyAuthMethodsDropdown() {
  cy.get('ngx-dropdown')
    .contains('Add a property')
    .closest('ngx-dropdown.ngx-dropdown')
    .within(() => {
      cy.get('ul button')
        .should('have.length', 2)
        .each((element, index) => {
          expect(element.text().toString().trim()).to.equal(authItems[index]);
        });
    });
}

export function selectSecretFormatDropdown(secretFormatText) {
  cy.get('.ngx-select-caret').click();
  cy.get('span')
    .contains('Secret Format')
    .closest('div.node-content')
    .within(() => {
      cy.get('ul.vertical-list.ngx-select-dropdown-options span')
        .should('have.length', 3)
        .each((element, index) => {
          expect(element.text().toString().trim()).to.equal(secretFormatItems[index]);
        });
      cy.get('ul.vertical-list.ngx-select-dropdown-options span').contains(secretFormatText).click();
    });
}
export function enterSecretText(secretText) {
  cy.get('span.type')
    .contains('Password')
    .closest('div.node-content')
    .within(() => {
      cy.get('input').type(secretText);
    });
}
export function verifySecretLocationDropdown() {
  cy.get('ngx-dropdown')
    .contains('Add a property')
    .closest('ngx-dropdown.ngx-dropdown')
    .within(() => {
      cy.get('ul button')
        .should('have.length', 3)
        .each((element, index) => {
          expect(element.text().toString().trim()).to.equal(secretLocationItems[index]);
        });
    });
}

export function enterFieldName(fieldName) {
  cy.get('span')
    .contains('Field Name')
    .closest('div.node-content')
    .within(() => {
      cy.get('ngx-input').ngxFill(fieldName);
    });
}

export function enterHeadName(name) {
  cy.get('span')
    .contains('Header Name')
    .closest('div.node-content')
    .within(() => {
      cy.get('ngx-input').ngxFill(name);
    });
}

export function enterQueryName(name) {
  cy.get('span')
    .contains('Parameter Name')
    .closest('div.node-content')
    .within(() => {
      cy.get('ngx-input').ngxFill(name);
    });
}

export function saveAndCloseWebhookSettings() {
  cy.intercept('PUT', '/orchestration/api/v1/sensor/*').as('putSensor');
  cy.dataCy('sensor-edit-dialog__save-and-close-btn').click();
  verifyPopup3({ title: 'Webhook updated', subtext: 'The webhook has been successfully updated.' });
  cy.intercept('PUT', '/orchestration/api/v1/sensor/*').as('putSensor');
  // needed for CI
  cy.wait(1000);
}

export function addSharedSecretAuth(sharedSecretAuthJson) {
  playbookWebhook.clickEditWebhookFromPlaybook();
  // add type of auth
  clickPropertyDropdown('Add a property');
  editWebhookLog.clickButtonWithText('Authentication');
  clickPropertyDropdown('Add a property');
  // verify authentication
  verifyAuthMethodsDropdown();
  editWebhookLog.clickButtonWithText('Shared Secret Authentication');
  // add shared secret
  enterSecretText('test');
  // add secret format
  selectSecretFormatDropdown(sharedSecretAuthJson.format);
  verifySecretLocationDropdown();
  // add location
  clickPropertyDropdown('Add a property');
  editWebhookLog.clickButtonWithText(sharedSecretAuthJson.location);
  switch (sharedSecretAuthJson.location) {
    case 'Request Body':
      enterFieldName(sharedSecretAuthJson.fieldName);
      break;
    case 'Request Header':
      enterHeadName(sharedSecretAuthJson.fieldName);
      break;
    case 'Request Query Parameter':
      enterQueryName(sharedSecretAuthJson.fieldName);
      break;
  }
  saveAndCloseWebhookSettings();
}
export function addBasicAuth(username, password) {
  playbookWebhook.clickEditWebhookFromPlaybook();
  clickPropertyDropdown('Add a property');
  // Verify auth methods drop dowb and add basic auth
  editWebhookLog.clickButtonWithText('Authentication');
  clickPropertyDropdown('Add a property');
  verifyAuthMethodsDropdown();
  editWebhookLog.clickButtonWithText('Basic Authentication');
  cy.get('div.node')
    .contains('Username')
    .closest('div.node-content')
    .within(() => {
      cy.get('textarea').ngxFill(username);
    });
  cy.get('div.node')
    .contains('Password')
    .closest('div.node-content')
    .within(() => {
      // using ngxfill or type alone doesn't work
      cy.get('input').ngxFill(password);
    });
  // press save here
  saveAndCloseWebhookSettings();
}

// tslint:disable: tsr-detect-non-literal-regexp

export function verifyElements(values: {}) {
  // Verify Nodes Run chart
  cy.get('.do-nodes')
    .as('nodesRunSection')
    .find('.do-nodes__chart-title')
    .contains(/^\s*Unprocessed Jobs ◦ 1 hour\s*$/);
  cy.get('@nodesRunSection').find('.do-nodes__chart-container');
  // Map Nodes Cards displayed bellow the chart line
  cy.get('@nodesRunSection')
    .find('.do-nodes__card')
    .each($el => {
      cy.wrap($el).within(() => {
        cy.get('.do-nodes__card-title')
          .its('0.innerText')
          .then($value => {
            cy.get('.do-nodes__card-count').should('contain.text', values[$value]);
            cy.get('.do-nodes__card-button').should('contain.text', 'View ' + $value.split(' ').pop());
          });
      });
    });
}

// All buttons have same selector but their value is different, pass button value in order to interact with wanted button
export function selectViewButton(viewOption) {
  cy.get('.do-nodes__card-button').contains(viewOption).click();
}

// Navigating through Agents, Pools and Engines displays different DataTable, pass table title and verify corresponding table is displayed
export function verifyDataTableIsDisplayed(dataTableName) {
  cy.get('.node-info-table').find('.title').contains(dataTableName);
}

export function selectDeployAgentButton() {
  cy.get('.deploy-agent-btn').contains('Deploy Agent').click();
}

export function verifyInstallAgentScriptDialogIsDisplayed() {
  cy.get('.deploy-agent').find('.dialog-title').contains('Install an agent');
}

export function closeInstallAgentScriptDialog() {
  cy.get('.dialog-close .btn').contains('Close').click();
}

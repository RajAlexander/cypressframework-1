import { verifyPopup2, verifyPopup3 } from '../common-pieces/popupMessages';
import * as playbookDetails from './playbook-upload-details';
import * as field from '../../../../../shared/helpers/field-inputs/field';
export { playbookDetails };

type uploadFileJSON = {
  playbookFileName?: string;
  invalidFile?: boolean;
  forceClosure?: boolean;
  closeMultiple?: boolean;
};

export function uploadFile(uploadFileJSON: uploadFileJSON = {}) {
  cy.get('div.ngx-dialog-content').should('be.visible');
  cy.get('.do-drag-and-drop--input').attachFile(uploadFileJSON.playbookFileName);
  if (uploadFileJSON.invalidFile) {
    const fileName =
      typeof uploadFileJSON.playbookFileName === 'string'
        ? uploadFileJSON.playbookFileName
        : uploadFileJSON.playbookFileName['filePath'];
    if (fileName.includes('.yml') || fileName.includes('.yaml')) {
      verifyPopup3({
        title: 'Validation Error',
        subtext: "An error ocurred while trying to parse the playbook. Please make sure it's a valid playbook."
      });
    } else {
      verifyPopup3({
        title: 'Upload Error',
        subtext: `File "${fileName.split('/').reverse()[0]}" doesn't have a valid file extension.`
      });
    }
  } else {
    /*
    Workaround to force the DOM state after animation.
    Seems to be a bug with browser or Cypress specifically which needs
    to be looked into further
    */
    cy.get('ngx-stepper .ngx-stepper--content')
      .eq(1)
      .should('have.class', 'active')
      .should('have.attr', 'style', 'transform: none; visibility: visible;')
      .each($el => {
        $el[0].style = 'visibility: visible !important; transform: none !important';
      });
    cy.get('do-playbook-upload-dialog.do-playbook-upload-dialog').should('be.visible');
  }
}

export function setProperties(playbookJSON, closeDialog = false) {
  cy.get('div.do-modal-dialog__content-wrapper').should('be.visible');
  cy.wrap(Object.keys(playbookJSON)).each($el => {
    cy.get('article.do-dialog-details-form__settings-step')
      .find(`.playbook-dialog-inputs--form .ngx-input[formcontrolname=${$el.toLowerCase()}]`)
      .should('be.visible');
    if ($el === 'name') {
      cy.get('.ngx-input__lock-toggle').should('be.visible').click();
    }
    field.setValue(
      {
        fieldType: 'text',
        inputType: 'text',
        attribute: `[formcontrolname=${$el.toLowerCase()}]`
      },
      playbookJSON[$el]
    );
  });
  if (closeDialog) {
    cy.get('.ngx-large-format-dialog-footer button.btn')
      .contains(/^\s*Create and Build\s*$/)
      .click({ force: true });
    verifyPopup2('Playbook successfully uploaded.');
  }
}

export function openDetails() {
  cy.get('.ngx-card--playbook .ngx-card-section').find('div.view-details').click();
}

export function uploadDiffPlaybook() {
  cy.get('.playbook-plus-menu')
    .first()
    .within(() => {
      cy.get('.ngx-plus-menu--circle-container').click();
      cy.get('.ngx-plus-menu--icon-0').click();
      cy.get('.do-drag-and-drop--icon')
        .contains(/^\s*Drag \+ Drop\s*$/)
        .should('be.visible');
    });
}

export function getpropertyBar() {
  const propertyJSON = {
    label: '',
    name: '',
    acronym: ''
  };

  cy.get('.ngx-large-format-dialog-content[dialogtitle="Upload a Playbook"]')
    .should('be.visible')
    .find('.ngx-card--playbook')
    .should('be.visible')
    .as('playbookDetails');
  cy.get('@playbookDetails')
    .find('.ngx-card-title')
    .its('0.innerText')
    .then($text => {
      propertyJSON.label = $text;
    });

  cy.get('@playbookDetails').find('.ngx-card-avatar--content').should('be.visible').as('playbookAcronymDetails');

  cy.get('@playbookDetails')
    .find('.ngx-card-subtitle')
    .its('0.innerText')
    .then($text => {
      propertyJSON.name = $text;
    });
  return cy
    .get('@playbookAcronymDetails')
    .should('be.visible')
    .its('0.innerText')
    .then($text => {
      propertyJSON.acronym = $text;
      return propertyJSON;
    });
}

export function submit(submitCode = 201) {
  cy.intercept('POST', '/orchestration/api/v1/playbook/upload').as('postUploadPlaybook');
  cy.get('.ngx-large-format-dialog-footer button.btn')
    .contains(/^\s*Create and Build\s*$/)
    .should('be.enabled')
    .click();
  cy.wait('@postUploadPlaybook').its('response.statusCode').should('eq', submitCode);
  if (submitCode === 201) {
    verifyPopup2('Playbook successfully uploaded.');
    cy.get('div.ngx-dialog-content').should('not.exist');
  }
}

export function validateIfDupePlaybookName(dupePlaybookName) {
  if (dupePlaybookName) {
    cy.get('.btn-primary')
      .contains(/^\s*Create and Build\s*$/)
      .should('be.disabled');
    cy.get('.ngx-input-hint').contains('That name already exists!');
    close();
  } else {
    submit();
  }
}

export function close() {
  cy.get('ngx-large-format-dialog-content[dialogtitle="Upload a Playbook"]')
    .find('button')
    .contains(/^\s*Close\s*$/)
    .click();
}

// tslint:disable: tsr-detect-non-literal-regexp

import { verifyPopup3 } from '../common-pieces/popupMessages';
import * as playbookUploader from './playbook-upload';
import * as playbookDetails from './playbook-item-details';
import * as webhook from './webhook/playbook-webhook-objects';
import * as editWebhookSettings from './webhook/edit-webhook-settings';
import * as editWebhookLogs from './webhook/edit-webhook-logs';
import * as playbookInterface from '../do-pages/playbook-interface';
export { playbookUploader };
export { playbookDetails };

const triggerItems = [
  // 'Real-Time Event',  // SPT-13435: Hide event stream
  'Catch Webhook',
  'Record Event',
  'Schedule'
];
const triggerType = 'Catch Webhook';

export function addWebhookTrigger() {
  cy.get('div.line-numbers').contains('1').should('be.visible');
  // there are no requests to intercept or UI items to wait for.
  // However, a delay is needed
  // anything less 1500 prevents the test from passing in ci/cd
  cy.wait(1500);
  webhook.waitForLinesToDraw();
  webhook.getNodeWithText('Add a trigger').click();
  // Verify the trigger types dropdown
  webhook.verifyNodeTriggerDropDown(triggerItems);
  webhook.clickOnNodeTriggerType(triggerType);
}

export function addPlaybookWebHookGenerateUrl(webhookTitle, webhookName, webhookDescription) {
  // Select Trigger type
  addWebhookTrigger();
  webhook.enterWebhookTitle(webhookTitle);
  webhook.enterWebhookName(webhookName);
  webhook.enterWebhookDescription(webhookDescription);
  webhook.clickGenerateUrl();
  verifyPopup3('Webhook created');
  playbookInterface.savePlaybookChanges();
  // for the panel on the right hand side - verify the trigger types
  verifySavedWebhookPanel(webhookTitle, webhookName, webhookDescription);
  webhook.getCopyUrl().click();
  verifyPopup3('Link was copied to the clipboard');
}

export function openSavedWebhookFromPlaybook(webhookTitle) {
  cy.get('div.line-numbers').contains('1').should('be.visible');
  cy.get('g.links', { timeout: 10000 }).then($element => {
    $element.find('path.invisible-line').length > 0;
  });
  // There isn't a request or web element to wait for.
  // I added delay because this sometimes fails when running from ci/cd.
  cy.wait(1000);
  cy.get('.node-label').contains(webhookTitle.slice(0, 17)).should('be.visible').click();
}

export function verifySavedWebhookPanel(webhookTitle, webHookName, webHookDescription) {
  // there is no requests to intercept or items to wait for
  // a delay is neded though
  cy.wait(500);
  cy.get('.node-label').contains(webhookTitle.slice(0, 17)).click();
  webhook.getWebhookName().click();
  webhook.getCopyUrl().should('be.visible');
  webhook.verifyPanelHeader();
  const isEnabled = true;
  verifyWebhookEnabledDisabled(isEnabled);
  // verify after clicking the generate url button
  webhook.getwebhookUrl().ngxGetValue().should('contain', '/webhooks/v1/webhook').and('contain', webHookName);
  webhook.getWebhookName().find('input').should('have.attr', 'disabled');
  webhook.getDescription().find('textarea').last().should('have.attr', 'disabled');
  webhook.getwebhookUrl().find('input').should('have.attr', 'disabled');
  cy.get('.node-type')
    .contains('webhook')
    .invoke('text')
    .then(nodeHookType => {
      expect(nodeHookType.toString().trim()).to.equal('webhook');
    });
  webhook
    .getWebhookName()
    .find('input')
    .ngxGetValue()
    .then(actualHookName => {
      expect(actualHookName.toString()).to.equal(webHookName);
    });
  webhook
    .getDescription()
    .find('textarea')
    .ngxGetValue()
    .then(desc => {
      expect(desc.toString()).to.equal(webHookDescription);
    });
  return webhook.getwebhookUrl().ngxGetValue();
}

export function verifyEditWebhookSettingsTab(webhookTitle, webhookName, webhookDescription, skip = false) {
  cy.get('Button').contains('SETTINGS').click();
  // there is no requests to intercept but the screen takes some time to redraw
  cy.wait(300);
  editWebhookSettings.getHeaderTitle(webhookTitle);
  editWebhookSettings.getHeaderSecondaryName(webhookName);
  editWebhookSettings.getHeaderDescription(webhookDescription);
  verifyTextIsVisible('.do-modal-dialog__content-wrapper', /^\s*Webhook Title\s*$/);
  verifyTextIsVisible('.do-modal-dialog__content-wrapper', /^\s*Webhook Name\s*$/);
  verifyTextIsVisible('.do-modal-dialog__content-wrapper', /^\s*Webhook Description\s*$/);
  if (skip == false) {
    editWebhookSettings.verifySettingsLogo();
  }
  editWebhookSettings.getSettingsEnableDisableCheckbox().should('be.checked');
  editWebhookSettings.verifySettingsTitle(webhookTitle);
  editWebhookSettings.verifySettingsName(webhookName);
  editWebhookSettings.verifySettingsDescription(webhookDescription);
  editWebhookSettings.clickCloseButton();
}

export function editWebhookSettingsTab(webhookTitle, webhookName, webhookDescription, skip = false) {
  cy.get('Button').contains('SETTINGS').click();
  // there is no requests to intercept but the screen takes some time to redraw
  cy.wait(300);
  editWebhookSettings.getWebhookNameLockIcon().click();
  editWebhookSettings.getSettingsDescription().ngxFill(webhookDescription);
  editWebhookSettings.getSettingsName().ngxFill(webhookName);
  editWebhookSettings.getSettingsTitle().ngxFill(webhookTitle);
  editWebhookSettings.getHeaderSecondaryName(webhookName);
  editWebhookSettings.getHeaderDescription(webhookDescription);
  verifyTextIsVisible('.do-modal-dialog__content-wrapper', /^\s*Webhook Title\s*$/);
  verifyTextIsVisible('.do-modal-dialog__content-wrapper', /^\s*Webhook Name\s*$/);
  verifyTextIsVisible('.do-modal-dialog__content-wrapper', /^\s*Webhook Description\s*$/);
  if (skip == false) {
    editWebhookSettings.verifySettingsLogo();
  }
  editWebhookSettings.getSettingsEnableDisableCheckbox().should('be.checked');
  editWebhookSettings.verifySettingsTitle(webhookTitle);
  editWebhookSettings.verifySettingsName(webhookName);
  editWebhookSettings.verifySettingsDescription(webhookDescription);
  cy.intercept('PUT', '/orchestration/api/v1/sensor/*').as('putSensor');
  editWebhookSettings.clickSaveCloseButton();
  verifyPopup3('Webhook updated');
  cy.wait('@putSensor');
}

export function clickEditWebhookFromPlaybook() {
  cy.intercept('POST', 'orchestration/api/v1/sensor/*/logs/rql').as('postSensorLogs');
  cy.get('Button').contains('Edit Webhook').click();
  cy.wait('@postSensorLogs');
}

export function verifyTextIsVisible(element, expectedText) {
  cy.get(element).contains(expectedText).should('be.visible');
}

export function triggerWebEvent(httpUrl) {
  cy.request(httpUrl).its('body').should('include', 'ok');
}

export function verifyWebhooksLogsTab(webhookTitle, webhookName, checkData = null) {
  cy.get('button').contains('LOGS').click();
  editWebhookLogs.verifyHeaderTitle(webhookTitle);
  editWebhookLogs.verifyHeaderSecondardyName(webhookName);
  editWebhookLogs.verifyEnabledDisabled();
  editWebhookLogs.verifyHeaderInfo();
  editWebhookLogs.verifyWebhookLogsWrapExist();
  editWebhookLogs.verifyJumpToDateExist();
  editWebhookLogs.verifyWebhookLogStatusRunning();
}

export function verifyWebhookEnabledDisabled(enabled = true) {
  webhook.getEnableDisabled().contains(enabled ? 'Enabled' : 'Disabled');
  webhook.getEnableDisabled().should(!enabled ? 'be.hidden' : 'be.visible');
}

export function generateEventNoLogin() {
  return webhook
    .getwebhookUrl()
    .ngxGetValue()
    .then(aUrl => {
      cy.request('POST', aUrl.toString()).should(response => {
        expect(response.status).to.eq(200);
      });
      // there are no requests to intercept or UI items to wait for.
      // However, a delay is needed
      cy.wait(1500);
      return cy.wrap(aUrl.toString());
    });
}

export function generateEventBasicAuth(aUsername, aPassword) {
  webhook
    .getwebhookUrl()
    .ngxGetValue()
    .then(aUrl => {
      cy.request({
        url: aUrl.toString(),
        method: 'POST',
        auth: { username: 'someUser', pass: 'somePassword' }
      }).should(response => {
        expect(response.status).to.eq(200);
      });
    });
  webhook
    .getwebhookUrl()
    .ngxGetValue()
    .then(aUrl => {
      cy.request({
        url: aUrl.toString(),
        method: 'POST',
        failOnStatusCode: false,
        auth: { username: aUsername, pass: 'invalidPassword' }
      }).should(response => {
        expect(response.status).to.eq(401);
      });
    });
  webhook
    .getwebhookUrl()
    .ngxGetValue()
    .then(aUrl => {
      cy.request({
        url: aUrl.toString(),
        method: 'POST',
        failOnStatusCode: false,
        auth: { username: 'invalidUser', pass: aPassword }
      }).should(response => {
        expect(response.status).to.eq(401);
      });
    });
  // there are no requests to intercept or UI items to wait for.
  // However, a delay is needed
  cy.wait(1500);
}

export function generateEventSharedSecretAuth(reqJson) {
  webhook
    .getwebhookUrl()
    .ngxGetValue()
    .then(() => {
      cy.request(reqJson).should(response => {
        expect(response.status).to.eq(200);
        ('=');
      });
    });
  // there are no requests to intercept or UI items to wait for.
  // However, a delay is needed for CI
  cy.wait(1500);
}

export function generateEventSharedSecretInvalidAuth(reqJson, statusCode = 401) {
  webhook
    .getwebhookUrl()
    .ngxGetValue()
    .then(() => {
      cy.request(reqJson).should(response => {
        expect(response.status).to.eq(statusCode);
      });
    });
}

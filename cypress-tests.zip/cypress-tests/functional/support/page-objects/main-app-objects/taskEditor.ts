export function createNewKeyStore(taskDetails: Record<string, any>) {
  cy.intercept('POST', `/api/credentials`).as('saveCredentialsCall');
  cy.get('.task-page')
    .find('.nav-tabs li')
    .contains(/^\s*Configuration\s*$/)
    .click();
  cy.get('.task-page').find('.add-key-btn').click();
  cy.get('.modal-content')
    .should('exist')
    .within(() => {
      cy.get('input[name="name"]').ngxFill(taskDetails.name);
      cy.get('input[name="value"]').ngxFill(taskDetails.value);
      cy.get('button').contains('Save').click();
      cy.wait('@saveCredentialsCall').its('response.statusCode').should('eq', 200);
      cy.get('.modal-content').should('not.exist');
    });
}

export function saveTask(isNew = true) {
  if (isNew) {
    cy.intercept('POST', '/api/task').as('apiTaskCall');
  } else {
    cy.intercept('PUT', '/api/task/**').as('apiTaskCall');
  }

  cy.get('button span')
    .contains(/^\s*Save\s*$/)
    .click();
  cy.wait('@apiTaskCall').its('response.statusCode').should('eq', 200);
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(250);
}

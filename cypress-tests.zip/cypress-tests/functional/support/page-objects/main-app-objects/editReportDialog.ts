// tslint:disable: tsr-detect-non-literal-regexp

import { escapeForRegex } from './common-pieces/common-calls';
import { verifyDoubleCheck, verifyPopup3 } from './common-pieces/popupMessages';

const mainElement = '.stacks-sidebar.SaveReportController';

export function editScheduledReport(reportName: string) {
  cy.get(mainElement)
    .find('.edit-report-cards')
    .should('be.visible')
    .within(() => {
      cy.get('div.card')
        .contains(new RegExp(`^\\s*${escapeForRegex(reportName)}\\s*$`))
        .closest('div.card--actions')
        .find('i.ngx-edit')
        .click();
    });
}

export function close() {
  cy.get(mainElement).find('div.page-toolbar button').click();
  cy.get(mainElement).should('not.exist', { timeout: 1000 });
}

export function deleteScheduledReport(reportName: string, continueAction = true) {
  cy.get(mainElement)
    .find('.edit-report-cards')
    .within(() => {
      cy.get('div.card')
        .contains(new RegExp(`^\\s*${escapeForRegex(reportName)}\\s*$`))
        .closest('div.card--actions')
        .find('i.ngx-trash')
        .click();
    });
  verifyDoubleCheck('Delete Schedule?', 'Are you sure you want to delete this schedule?', continueAction, 'Delete');
  verifyPopup3({ subtext: 'Report Schedule Deleted' });
}

export function verifySchedulesListed(reportList: string[]) {
  cy.get(mainElement)
    .find('.edit-report-cards')
    .within(() => {
      if (reportList.length > 0) {
        cy.get('div.card').then(schedules => {
          cy.wrap(schedules)
            .should('have.length', reportList.length)
            .withinEach($el => {
              cy.get('label.ellipse').then($el => {
                expect($el.text().trim()).to.be.oneOf(reportList);
              });
            });
        });
      }
    });
}

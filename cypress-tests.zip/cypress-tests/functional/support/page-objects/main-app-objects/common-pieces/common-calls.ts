// tslint:disable: tsr-detect-non-literal-regexp

import { typeInField } from './interactions';

export function escapeForRegex(searchText: string) {
  return searchText.replace(/([\[\]<>*+()?$&\/])/g, '\\$1');
}

export function interactWithDropdownChooser(dropdownElement: any, itemText: string, dropdownCloseEl = null) {
  cy.get(dropdownElement)
    .click()
    .find('div,span')
    .contains(new RegExp(`^\\s*${escapeForRegex(itemText)}\\s*$`))
    .scrollIntoView()
    .click();
  if (dropdownCloseEl) {
    cy.get(dropdownCloseEl).click();
  }
}

export function interactWithSearchDropdownChooser(dropdownElement: any, itemText: string, waitForCalls = []) {
  cy.get(dropdownElement)
    .click()
    .find('input.ui-select-search,input.ngx-select-filter-input')
    .then($inputEle => {
      typeInField($inputEle, itemText, false);
    });
  if (waitForCalls.length > 0) {
    cy.wait(waitForCalls);
  }
  cy.wait(1000);
  cy.get(dropdownElement)
    .find('div.ui-select-dropdown,ngx-select-dropdown div,span')
    .contains(new RegExp(`^\\s*${escapeForRegex(itemText)}\\s*$`))
    .scrollIntoView()
    .click();
}

export function interactWithDropdownChooser2(dropdownElement: any, itemText: string) {
  cy.get(dropdownElement).click();
  cy.wait(500);
  cy.get('div.ui-select-dropdown,ngx-select-dropdown,ngx-select-dropdown-option')
    .find('div,span')
    .contains(new RegExp(`^\\s*${escapeForRegex(itemText)}\\s*$`))
    .scrollIntoView()
    .click();
}

export function interactWithQuillEditor(baseElement: any, text: string) {
  // .fill does not work with the quill editor
  cy.get(baseElement).find('div.editor').click().type(text);
}

export function verifyDropdownItems(dropdownElement: any, dropdownItems: string[]) {
  cy.get(dropdownElement).click();
  cy.get(dropdownElement)
    .find('.ngx-select-dropdown-options')
    .each((dropdownOption, i) => {
      cy.wrap(dropdownOption).contains(new RegExp(`^\\s*${escapeForRegex(dropdownItems[i])}\\s*$`));
    });
}

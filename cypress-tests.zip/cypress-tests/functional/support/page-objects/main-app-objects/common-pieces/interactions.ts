// tslint:disable: tsr-detect-non-literal-regexp
import { escapeForRegex } from './common-calls';

export function typeInField(targetElement: any, text: string, doBlur = true, forceFlag = false) {
  cy.get(targetElement).click({ force: forceFlag }).clear({ force: forceFlag });
  if (text !== '') {
    // Could use fill if we had the option to NOT blur
    cy.get(targetElement).focus().type(text, { force: forceFlag });
  }
  if (doBlur === true) {
    cy.get(targetElement).focus().blur({ force: forceFlag });
  }
}

function findUserGroupInput(attribute = '') {
  return cy.get(`.ngx-select${attribute}`);
}

export function setUserGroupValue(value: string, selectionType: string, waitCalls = [], attribute = '') {
  findUserGroupInput(attribute)
    .click('right')
    .within(() => {
      cy.get('.ngx-select-dropdown').within(() => {
        cy.get('.ngx-select-filter-input').clear().type(value.substring(0, 5));
        if (waitCalls.length > 0) {
          cy.wait(waitCalls);
          cy.wait(700);
        }
        cy.contains('.ngx-select-dropdown-option', new RegExp(`^\\s*${escapeForRegex(value)}\\s*$`))
          .scrollIntoView()
          .click();
      });
      if (selectionType === 'multi') {
        cy.get('.ngx-select-caret').click({ force: true });
      }
    });
}

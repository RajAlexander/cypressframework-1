// tslint:disable: tsr-detect-non-literal-regexp

import { escapeForRegex } from './common-calls';

export enum MessageType {
  SUCCESS = 0,
  ERROR = 1,
  WARNING = 2
}

export function verifyPopup(popupMessage) {
  cy.get('div.ng-notification', { timeout: 30000 }).within(() => {
    cy.get('span.title')
      .invoke('text')
      .then(text => {
        if (text.includes(popupMessage)) {
          cy.get('span.title').should('have.text', popupMessage);
        } else {
          cy.get('span.title').should('have.text', 'Record saved');
        }
      });
    cy.get('button.close').iff(el => {
      el.trigger('click');
    });
  });
  cy.get('div.ng-notification-content').should('not.exist');
}

// TODO: Hopefully this can be cleaned up to use the same elements.
export function verifyPopup2(popupMessage, forceClosure = true, closeMultiple = false) {
  cy.get('.ngx-notification-container')
    .should('be.visible')
    .within(() => {
      cy.get('.notification-content').should('have.text', popupMessage);
      cy.get('.ngx-notification-close').iff(el => {
        el.trigger('click');
      });
      cy.get('.ngx-notification-body').should('not.exist');
    });
}

function returnMessageType(messageType: MessageType) {
  switch (messageType) {
    case 0:
      return '.ngx-notification-success';
    case 1:
      return '.ngx-notification-error';
    case 2:
      return '.ngx-notification-warning';
    default:
      return '.ngx-notification';
  }
}

// TODO: Hopefully this can be cleaned up to use the same elements.
export function verifyPopup3(popupMessage, messageType: MessageType = null) {
  if (typeof popupMessage === 'string') {
    popupMessage = { title: popupMessage };
  }

  cy.get('.ngx-notification-container').should('exist');
  cy.get(`.ngx-notification-container ${returnMessageType(messageType)}`)
    .should('exist')
    .within(() => {
      if (popupMessage.hasOwnProperty('title')) {
        cy.get('.ngx-notification-title')
          .should('be.visible')
          .invoke('text')
          .should('match', new RegExp(`^\\s*${escapeForRegex(popupMessage.title)}\\s*$`));
      }
      if (popupMessage.hasOwnProperty('subtext')) {
        cy.get('.ngx-notification-body')
          .invoke('text')
          .should('match', new RegExp(`^\\s*${escapeForRegex(popupMessage.subtext)}\\s*$`));
      }
      cy.get('.ngx-notification-close').iff(el => {
        el.trigger('click');
      });
      cy.get('.ngx-notification-content').should('not.exist');
    });
}

export function verifyModalDirtyDialog(dialogTitle, dialogBody, buttonText = 'Cancel') {
  cy.get('div.ngx-dialog').within(() => {
    cy.get('.ngx-dialog-title')
      .should('have.text', dialogTitle)
      .siblings('p')
      .should('have.text', dialogBody)
      .closest('.ngx-dialog')
      .find('button')
      .contains(buttonText)
      .click();
  });
}

// angular 1 dialogs
export function verifyModalConfirmDialog(dialogTitle, dialogBody, buttonText = 'Ok') {
  cy.get('div.modal-dialog').as('modalDialog');
  cy.get('@modalDialog').find('h3').should('have.text', dialogTitle).siblings().should('have.text', dialogBody);
  cy.get('@modalDialog').find('button').contains(buttonText).click();
}

// ngx-ui dialogs
export function verifyModalConfirmDialogNew(dialogTitle, dialogBody, buttonText = 'Ok') {
  cy.get('div.ngx-dialog-content.save-button-leave-dialog').within(() => {
    cy.get('h2').should('have.text', dialogTitle);
    cy.get('p').should('have.text', dialogBody);
    cy.get('button').contains(buttonText).click();
  });
}

export function verifyDoubleCheck(title, body = null, continueAction = true, buttonText = 'Ok') {
  cy.get('div.ngx-alert-dialog')
    .should('be.visible')
    .within(() => {
      cy.get('div.ngx-dialog-header')
        .invoke('text')
        .should('match', new RegExp(`^\\s*${escapeForRegex(title)}\\s*$`));
      if (body != null) {
        cy.get('div.ngx-dialog-body')
          .invoke('text')
          .should('match', new RegExp(`^\\s*${escapeForRegex(body)}\\s*$`));
      }
      if (continueAction) {
        cy.get('div.ngx-dialog-footer button')
          .contains(new RegExp(`^\\s*${escapeForRegex(buttonText)}\\s*$`))
          .click();
      }
    });
}
// tslint:disable: tsr-detect-non-literal-regexp

import { escapeForRegex } from './common-pieces/common-calls';

const mainElement = 'div.create-card';
const mainSection = `${mainElement} section.main`;

export function setCardDetails(
  name: string,
  reportType: string | number | Array<string | number>,
  details: string | number | Array<string | number>,
  description = ''
) {
  cy.get(mainSection).within(() => {
    cy.get('ngx-input[type="text"]').ngxFill(name);
    cy.get('ngx-input[type="textarea"]').ngxFill(description);
    cy.getByLabel('Type').select(reportType);
    if (reportType == 'Report') {
      cy.getByLabel('Report*').select(details);
    } else {
      // HTML and USage Stats to be done
    }
  });
}

export function setCardAutoRefresh(autoRefreshTime: string | number | Array<string | number>) {
  cy.get(mainSection).within(() => {
    cy.getByLabel('Auto Refresh').select(autoRefreshTime);
  });
  verifyCardAutoRefreshSetting(autoRefreshTime);
}

export function createCard() {
  cy.get(`${mainElement} header.help-banner`)
    .find('button span')
    .contains(/^\s*Create\s*$/)
    .click();
}

export function verifyCardAutoRefreshSetting(autoRefreshTime: any) {
  cy.get(mainSection).within(() => {
    cy.getByLabel('Auto Refresh').ngxGetValue(autoRefreshTime); // TODO: bug.. this isn't verifying the value
  });
}

export function verifyCardAutoRefreshOptions(expectedValues: string[]) {
  cy.get(mainSection).within(() => {
    cy.getByLabel('Auto Refresh')
      .click()
      .within(() => {
        cy.get('.ngx-select-dropdown-option').then($dropdownOptions => {
          expect($dropdownOptions.length).to.equal(expectedValues.length);
          $dropdownOptions.each((i, dropdownOption) => {
            cy.wrap(dropdownOption).contains(new RegExp(`^\\s*${escapeForRegex(expectedValues[i])}\\s*$`));
          });
        });
        cy.get('.ngx-select-caret').click();
      });
  });
}

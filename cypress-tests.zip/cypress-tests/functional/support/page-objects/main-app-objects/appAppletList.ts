import { verifyPopup3, verifyDoubleCheck } from './common-pieces/popupMessages';
import * as appWizard from './admin-pages/app-wizard';
import * as appAppletSSPWizard from './app-applet-ssp-wizard';
import { saveCopy } from './admin-pages/app-builder';
export { appWizard, appAppletSSPWizard };

const listingElement = '[data-cy=app-applet__listing]';
const appAppletLink = '[data-cy=app-applet__link]';

export function getCountOfList() {
  return cy
    .get(listingElement)
    .children()
    .then(childList => {
      const element = childList[0];
      if (element.localName === 'p') {
        return cy
          .wrap(element)
          .should('have.text', 'No applications or applets')
          .then(() => {
            return childList.length - 1;
          });
      } else {
        return childList.length;
      }
    });
}

export function startNewApp() {
  cy.get('ngx-plus-menu').should('be.visible').click();
  cy.get('.ngx-plus-menu--item-1').should('exist').click();
}

export function startNewApplet() {
  cy.get('ngx-plus-menu').should('be.visible').click();
  cy.get('.ngx-plus-menu--item-2').should('exist').click();
}

export function startImportPlus() {
  cy.get('ngx-plus-menu').should('be.visible').click();
  // Have to use the force here as this is not visible
  cy.get('.ngx-plus-menu--item-0').should('exist').click({ force: true });
}

function getListingElement(appName: string) {
  cy.get(listingElement)
    .find(`${appAppletLink}:contains('${appName}')`)
    .as('theAppApplet')
    .its('length')
    .should('eq', 1);
}

export function verifyAppListEllipsisDropDown(listItems, appName) {
  getListingElement(appName);
  cy.get('@theAppApplet')
    .closest('[data-cy=app-applet__item]')
    .find('[data-cy=app-applet__dropdown]')
    .click()
    .within(() => {
      cy.get('ngx-dropdown-menu')
        .find('button,a')
        .then($selectedList => {
          expect($selectedList).to.have.lengthOf(listItems.length);
          cy.wrap($selectedList).each($el => {
            cy.wrap($el)
              .its('0.innerText')
              .then($textValue => {
                expect($textValue).to.be.oneOf(listItems);
              });
          });
        });
    });
}

export function copyApp(appName: string, newAppName: string, newAcronym: string) {
  cy.intercept('POST', '/api/app/**/copy').as('copyApp');

  // @ts-ignore
  getCountOfList().then(($origCount: number) => {
    getListingElement(appName);
    cy.get('@theAppApplet')
      .closest('[data-cy=app-applet__item]')
      .find('[data-cy=app-applet__dropdown]')
      .as('dropdownSelector')
      .click();
    cy.get('@dropdownSelector')
      .find('ngx-dropdown-menu button')
      .contains(/^\s*Copy\s*$/)
      .click();
    appWizard.setAppName(newAppName);
    appWizard.setAppAcronym(newAcronym);
    saveCopy();
    cy.get(listingElement).find(`${appAppletLink}:contains('${newAppName}')`).should('exist');
    cy.wait('@copyApp').its('response.statusCode').should('eq', 200);
    verifyPopup3({ subtext: 'Application copied' });
    getCountOfList().should('equal', $origCount + 1);
  });
}

export function editExistingApp(appName: string, isApp = true) {
  cy.intercept('GET', isApp ? '/api/app/**' : '/api/applet/**').as('getApp');
  if (isApp) {
    cy.intercept('GET', '/api/workflow/**').as('getWorkflow');
  }
  getListingElement(appName);
  cy.get('@theAppApplet').click();
  cy.wait(isApp ? ['@getApp', '@getWorkflow'] : ['@getApp']);
}

export function verifyPlusMenuOptions(optionsList) {
  cy.get('.ngx-plus-menu').as('navbar-apps');
  cy.get('@navbar-apps').find('.ngx-plus-menu--circle-container').click();
  cy.get('@navbar-apps').find('.ngx-plus-menu--item').should('have.length', optionsList.length);
  optionsList.forEach(option => {
    cy.get('@navbar-apps').find('.ngx-plus-menu--item').contains(option).should('be.visible');
  });
  cy.get('@navbar-apps').find('.ngx-plus-menu--circle-container').click();
}

export function deleteExistingApp(appName: string) {
  cy.intercept('DELETE', '/api/app/**').as('delApp');

  // @ts-ignore
  getCountOfList().then(($origCount: number) => {
    getListingElement(appName);
    cy.get('@theAppApplet')
      .closest('[data-cy=app-applet__item]')
      .find('[data-cy=app-applet__dropdown]')
      .as('dropdownSelector')
      .click();
    cy.get('@dropdownSelector')
      .find('ngx-dropdown-menu button')
      .contains(/^\s*Delete\s*$/)
      .click();
    verifyDoubleCheck(
      'Are you sure?',
      `You are about to delete this application: '${appName}'. Do you want to continue?`
    );
    cy.wait('@delApp').its('response.statusCode').should('eq', 204);
    verifyPopup3({ subtext: 'Application deleted' });
    cy.get(listingElement).find(`${appAppletLink}:contains('${appName}')`).should('not.exist');
    getCountOfList().should('equal', $origCount - 1);
  });
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(250);
}

export function deleteExistingApplet(appName: string) {
  cy.intercept('DELETE', '/api/applet/**').as('delApplet');

  // @ts-ignore
  getCountOfList().then(($origCount: number) => {
    cy.get(listingElement)
      .find(`${appAppletLink}:contains('${appName}')`)
      .as('theAppApplet')
      .its('length')
      .should('eq', 1);
    cy.get('@theAppApplet')
      .closest('[data-cy=app-applet__item]')
      .find('[data-cy=app-applet__dropdown]')
      .as('dropdownSelector')
      .click();
    cy.get('@dropdownSelector')
      .find('ngx-dropdown-menu button')
      .contains(/^\s*Delete\s*$/)
      .click();
    verifyDoubleCheck('Are you sure?', `You are about to delete this applet: '${appName}'. Do you want to continue?`);
    cy.wait('@delApplet').its('response.statusCode').should('eq', 204);
    verifyPopup3({ subtext: 'Applet deleted' });
    cy.get(listingElement).find(`${appAppletLink}:contains('${appName}')`).should('not.exist');
    getCountOfList().should('equal', $origCount - 1);
  });
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(250);
}

export function verifyExistingAppApplet(name: string) {
  cy.get(listingElement).find(`${appAppletLink}:contains('${name}')`).its('length').should('eq', 1);
}

// tslint:disable: tsr-detect-non-literal-regexp

import { escapeForRegex } from '../common-pieces/common-calls';
const mainElement = 'div.field-selection-dialog';

export function applySelection() {
  cy.get(mainElement).within(() => {
    cy.get('div.dialog-header')
      .find(`ngx-button`)
      .contains(/^\s*Apply\s*/)
      .closest('button')
      .click();
  });
  cy.get(mainElement).should('not.exist');
}

export function selectFields(fieldNameList: string[]) {
  cy.get(mainElement).within(() => {
    cy.get('div.field-selection-content').within(() => {
      fieldNameList.forEach(fieldName => {
        cy.get('div.field-item')
          .contains(new RegExp(`^\\s*${escapeForRegex(fieldName)}\\s*$`))
          .click();
      });
    });
  });
}

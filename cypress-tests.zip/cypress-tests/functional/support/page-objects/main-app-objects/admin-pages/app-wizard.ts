import { MessageType, verifyPopup3 } from '../common-pieces/popupMessages';

const mainElement = 'ngx-dialog div.ngx-dialog-content';
const appTabsSelector = 'app-wizard__tabs';
const appletTabsSelector = 'applet-wizard__tabs';

export function setAppName(appName: string, isApp = true) {
  cy.dataCy(isApp ? appTabsSelector : appletTabsSelector).within(() => {
    getCurrentTab().then($tabText => {
      if ($tabText !== 'GENERAL') {
        cy.get('button.ngx-tab').should('be.visible').contains('GENERAL').click();
      }
      cy.getByLabel('Name').ngxFill(appName);
    });
  });
}

export function setAppAcronym(newAcronym: string, isApp = true) {
  cy.dataCy(isApp ? appTabsSelector : appletTabsSelector).within(() => {
    getCurrentTab().then($tabText => {
      if ($tabText !== 'GENERAL') {
        cy.get('button.ngx-tab').should('be.visible').contains('GENERAL').click();
      }
      cy.getByLabel('Acronym').ngxFill(newAcronym);
    });
  });
}

function getCurrentTab() {
  return cy.get('.ngx-tab.active').should('be.visible').its('0.innerText');
}

export function setAppDescription(descriptionText: string, isApp = true) {
  cy.dataCy(isApp ? appTabsSelector : appletTabsSelector).within(() => {
    getCurrentTab().then($tabText => {
      if ($tabText !== 'GENERAL') {
        cy.get('button.ngx-tab').should('be.visible').contains('GENERAL').click();
      }
      cy.getByLabel('Description').ngxFill(descriptionText);
    });
  });
}

export function createApp(message = 'Application created') {
  cy.intercept('POST', '/api/app').as('postApp');
  cy.get(mainElement).find('div.btn-group-save').contains('Create').click();
  cy.wait('@postApp').then(intercept => {
    expect(intercept.response.statusCode).to.equal(
      200,
      intercept.response.hasOwnProperty('error') ? intercept.response['error'].text : 'PASS'
    );
  });

  // Note: this is conditional pending closer look at SPT-13720
  verifyPopup3({ subtext: message }, MessageType.SUCCESS);
  cy.wait(500);

  cy.get('div.ngx-dialog-content ngx-tabs').should('not.exist');
}

export function createApplet(message = 'Applet created') {
  cy.intercept('POST', '/api/applet').as('postApplet');
  cy.get('ngx-dialog div.ngx-dialog-content').find('div.btn-group-save').contains('Create').click();
  cy.wait('@postApplet').then(intercept => {
    expect(intercept.response.statusCode).to.equal(
      200,
      intercept.response.hasOwnProperty('error') ? intercept.response.error.text : 'PASS'
    );
  });

  // Note: this is conditional pending closer look at SPT-13720
  verifyPopup3({ subtext: message }, MessageType.SUCCESS);
  cy.wait(500);

  cy.get('div.ngx-dialog-content ngx-tabs').should('not.exist');
}

export function getAppAcronym(isApp = true) {
  cy.dataCy(isApp ? appTabsSelector : appletTabsSelector)
    .should('be.visible')
    .as('appWizardTabs');
  return getCurrentTab().then($tabText => {
    if ($tabText === 'GENERAL') {
      return cy.get('@appWizardTabs').find('ngx-tab #input-acronym:only-of-type').should('be.visible').its('0.value');
    } else {
      return cy
        .get('@appWizardTabs')
        .find('button.ngx-tab')
        .should('be.visible')
        .contains('GENERAL')
        .click()
        .then(() => {
          return cy
            .get('@appWizardTabs')
            .find('ngx-tab #input-acronym:only-of-type')
            .should('be.visible')
            .its('0.value');
        });
    }
  });
}

export function setAppWorkspace(
  workspaceName: string | number | Array<string | number>,
  isApp = true,
  existingApp = false
) {
  cy.dataCy(isApp ? appTabsSelector : appletTabsSelector).within(() => {
    getCurrentTab().then($tabText => {
      if ($tabText !== 'WORKSPACE') {
        cy.get('button.ngx-tab').should('be.visible').contains('WORKSPACE').click();
      }
      if (!existingApp) {
        cy.getByLabel('Automatically create workspace').click();
      }
      cy.getByLabel('Workspaces').select(workspaceName);
    });
  });
}

function setUpPermissions(roles: Array<Record<string, any>>) {
  roles.forEach(role => {
    cy.get('ngx-select').select(role.name);
    cy.get('td')
      .contains(role.name)
      .closest('tr')
      .within(() => {
        Object.keys(role.permissions).forEach(permission => {
          cy.dataCy(permission)[role.permissions[permission] ? 'check' : 'uncheck']();
        });
      });
  });
}

export function setAppPermissions(roles: Array<Record<string, any>>, isApp = true) {
  cy.dataCy(isApp ? appTabsSelector : appletTabsSelector).within(() => {
    getCurrentTab().then($tabText => {
      if ($tabText !== 'ADMINISTRATION') {
        cy.get('button.ngx-tab').should('be.visible').contains('ADMINISTRATION').click();
      }

      cy.get('[data-cy=app-permissions__section]').within(() => {
        setUpPermissions(roles);
      });
    });
  });
}

export function setRecordPermissions(roles: Array<Record<string, any>>, isApp = true) {
  cy.dataCy(isApp ? appTabsSelector : appletTabsSelector).within(() => {
    getCurrentTab().then($tabText => {
      if ($tabText !== 'RECORDS') {
        cy.get('button.ngx-tab').should('be.visible').contains('RECORDS').click();
      }

      cy.get('[data-cy=record-permissions__section]').within(() => {
        setUpPermissions(roles);
      });
    });
  });
}

export function setWorkspacePermissions(roles, isApp = true) {
  cy.dataCy(isApp ? appTabsSelector : appletTabsSelector).within(() => {
    getCurrentTab().then($tabText => {
      if ($tabText !== 'WORKSPACE') {
        cy.get('button.ngx-tab').should('be.visible').contains('WORKSPACE').click();
      }

      cy.get('[data-cy=workspace-permissions__section]').within(() => {
        setUpPermissions(roles);
      });
    });
  });
}

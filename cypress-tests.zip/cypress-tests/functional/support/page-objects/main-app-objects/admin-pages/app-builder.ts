// tslint:disable: tsr-detect-non-literal-regexp

import { verifyPopup3, verifyDoubleCheck } from '../common-pieces/popupMessages';
import { escapeForRegex, interactWithQuillEditor } from '../common-pieces/common-calls';

import * as recordEditor from '../record-editor';
import * as calculationBuilder from './calculation-builder';

import * as field from '../../../../../shared/helpers/field-inputs/field';

const downloadsFolder = 'temp/downloads';
import path from 'path';

const mainAppElement = '[data-cy=app__editor]';
const mainAppletElement = '[data-cy=applet__editor]';
const headerBar = 'ngx-toolbar';
const exportReadyMessage = 'Your export is ready for download.';

export function clickOnField(fieldName: string) {
  cy.contains('app-field', new RegExp(`^\\s*${escapeForRegex(fieldName)}\\s*$`))
    .should('be.visible')
    .click();
}

export function verifyElements(appName = '', isApp = true) {
  cy.url().should('match', isApp ? /\/app\-builder\/[a-zA-Z0-9_]{10,17}$/ : /\/applet\-builder\/[a-zA-Z0-9_]{10,17}$/);
  if (appName !== '') {
    cy.get(headerBar).find('h2.ngx-toolbar-title').should('have.text', ` ${appName} `);
  }
}

export function addField(fieldType: string, listType = '', isApp = true) {
  cy.get(isApp ? mainAppElement : mainAppletElement).within(() => {
    cy.get('.builder-target:only-of-type').should('be.visible').as('appBuilderForm');
    cy.get('.builder-source').within(() => {
      cy.get('ngx-section-header > h3')
        .contains('Field Types') // This could have a field subtype tab open.
        .scrollIntoView()
        .invoke('text')
        .then(($FieldsSubset: unknown) => {
          const _$FieldsSubset = ($FieldsSubset as string).trim();
          switch (fieldType.toLowerCase()) {
            case 'text':
            case 'date/time':
            case 'users/groups':
            case 'reference':
            case 'numeric':
            case 'selection':
            case 'attachments':
            case 'comments':
            case 'history':
              if (_$FieldsSubset !== 'Field Types') {
                cy.get('button.back-button').should('be.visible').click();
              }
              break;
            case 'single-line':
            case 'email':
            case 'url':
            case 'rich text':
            case 'telephone':
            case 'ip':
            case 'json':
            case 'multi-line':
              if (_$FieldsSubset !== 'Field Types: Text') {
                cy.log(`|${_$FieldsSubset}|`);
                if (_$FieldsSubset !== 'Field Types') {
                  cy.get('button.back-button').scrollIntoView().should('be.visible').click();
                }
                cy.get('div.app-field').contains('Text').should('be.visible').click();
              }
              break;
            case 'date':
            case 'time':
            case 'date & time':
            case 'first created':
            case 'timespan':
            case 'last updated':
              if (_$FieldsSubset !== 'Field Types: Date/Time') {
                if (_$FieldsSubset !== 'Field Types') {
                  cy.get('button.back-button').scrollIntoView().should('be.visible').click();
                }
                cy.get('div.app-field').contains('Date/Time').should('be.visible').click();
              }
              break;
            case 'usergroup single-select':
            case 'usergroup multi-select':
              fieldType = fieldType.substring(10);
            case 'created by':
            case 'last updated by':
              if (_$FieldsSubset !== 'Field Types: Users/Groups') {
                if (_$FieldsSubset !== 'Field Types') {
                  cy.get('button.back-button').scrollIntoView().should('be.visible').click();
                }
                cy.get('div.app-field').contains('Users/Groups').should('be.visible').click();
              }
              break;
            case 'single-select':
            case 'multi-select':
            case 'grid':
              if (_$FieldsSubset !== 'Field Types: Reference') {
                if (_$FieldsSubset !== 'Field Types') {
                  cy.get('button.back-button').scrollIntoView().should('be.visible').click();
                }
                cy.get('div.app-field').contains('Reference').should('be.visible').click();
              }
              break;
            case 'selection multi-select':
            case 'selection single-select':
              fieldType = fieldType.substring(10);
            case 'radio buttons':
            case 'checkboxes':
              if (_$FieldsSubset !== 'Field Types: Selection') {
                if (_$FieldsSubset !== 'Field Types') {
                  cy.get('button.back-button').scrollIntoView().should('be.visible').click();
                }
                cy.get('div.app-field').contains('Selection').should('be.visible').click();
              }
              break;
            case 'list':
              if (listType === 'numeric') {
                if (_$FieldsSubset !== 'Field Types: Numeric') {
                  if (_$FieldsSubset !== 'Field Types') {
                    cy.get('button.back-button').scrollIntoView().should('be.visible').click();
                  }
                  cy.get('div.app-field').contains('Numeric').should('be.visible').click();
                }
              } else {
                if (_$FieldsSubset !== 'Field Types: Text') {
                  if (_$FieldsSubset !== 'Field Types') {
                    cy.get('button.back-button').scrollIntoView().should('be.visible').click();
                  }
                  cy.get('div.app-field').contains('Text').should('be.visible').click();
                }
              }
              break;
          }
          cy.get('div.builder-source-item.app-field').contains(fieldType).should('be.visible').as('fieldToAdd');
          cy.dragAndDrop('@fieldToAdd', '@appBuilderForm');
        });
    });
  });
}

export function addLayout(layoutType: string, isApp = true) {
  cy.get(isApp ? mainAppElement : mainAppletElement).within(() => {
    cy.get('.builder-target:only-of-type').should('be.visible').as('appBuilderForm');
    cy.get('ngx-section-header > h3')
      .contains(/^\s*Layout\s*$/)
      .scrollIntoView();
    cy.get('div.builder-source-item').contains(layoutType).should('be.visible').as('layoutToAdd');
    cy.dragAndDrop('@layoutToAdd', '@appBuilderForm');
  });
}

export function editAppComponent(componentName: string, settingsJSON: any, isApp = true) {
  cy.get(isApp ? mainAppElement : mainAppletElement).within(() => {
    clickOnField(componentName);
    cy.get('.settings-panel ngx-tab > div:visible').as('appElementProperties');
  });

  Object.keys(settingsJSON).forEach(keyName => {
    if (keyName === 'AddEditValues') {
      cy.get('@appElementProperties').find('button').contains('Add / Edit Values').scrollIntoView().click();
      cy.get('ngx-dialog').within(() => {
        settingsJSON[keyName].forEach($valueName => {
          cy.get('button.add-value-button').click();
          cy.get('div.scroll-container')
            .find('div.ngx-dnd-item:first-child')
            .within(() => {
              cy.get('button[tooltiptitle="Edit value"]').click();
              cy.getByLabel('Name').ngxFill($valueName);
            });
        });
        cy.get('ngx-button.save-btn').click();
      });

      cy.get('ngx-dialog').should('not.exist');
    } else if (
      [
        'Required',
        'Unique',
        'Read-only',
        'Calculated',
        'Write Once',
        'Ability to add new on target',
        'Create and maintain reciprocal reference'
      ].includes(keyName)
    ) {
      cy.get('@appElementProperties')
        .find(`label`)
        .contains(new RegExp(`^\\s*${escapeForRegex(keyName)}\\s*$`))
        .should('be.visible')
        .closest('ngx-checkbox')
        .as('checkBox');
      if (settingsJSON[keyName] === false) {
        cy.get('@checkBox').uncheck();
      } else {
        cy.get('@checkBox').check();
        if (keyName === 'Calculated' && settingsJSON[keyName] !== '') {
          calculationBuilder.typeFormula(settingsJSON[keyName]);
          calculationBuilder.applyFormula();
        }
      }
    } else if (['Prefix', 'Suffix', 'Placeholder', 'Max Size [kB]'].includes(keyName)) {
      cy.get('@appElementProperties').within(() => {
        cy.getByLabel(keyName).ngxFill(settingsJSON[keyName]);
      });
    } else if (keyName === 'Size') {
      cy.get('app-properties-container')
        .find('section h1')
        .contains(/^\s*Size\s*$/)
        .closest('section');
      cy.get('div.btn')
        .contains(new RegExp(`^\\s*${escapeForRegex(settingsJSON[keyName])}\\s*$`))
        .click();
    } else if (keyName === 'Help Text Content') {
      cy.get('@appElementProperties').find(`app-quill-editor[label="${keyName}"]`).as('currentProperty');
      interactWithQuillEditor('@currentProperty', settingsJSON[keyName]);
    } else if (keyName === 'Default Value') {
      cy.get('@appElementProperties')
        .find(`[label="${keyName}"]`)
        .scrollIntoView()
        .should('be.visible')
        .select(Object.keys(settingsJSON[keyName])[0])
        .as('currentProperty');
      if (settingsJSON[keyName].hasOwnProperty('Specific date-time')) {
        cy.get('@currentProperty')
          .siblings('div')
          .find('ngx-date-display')
          .ngxFill(settingsJSON[keyName]['Specific date-time']);
      } else if (settingsJSON[keyName].hasOwnProperty('Current date-time')) {
        // noop
      }
    } else if (keyName === 'Length') {
      cy.get('@appElementProperties')
        .find(`label`)
        .contains(new RegExp(`^\\s*${escapeForRegex(keyName)}\\s*$`))
        .scrollIntoView()
        .closest('div')
        .within(() => {
          if (settingsJSON[keyName].hasOwnProperty('Units')) {
            cy.get('ngx-select').select(settingsJSON[keyName].Units);
          }
          if (settingsJSON[keyName].hasOwnProperty('Min')) {
            cy.getByLabel('Min').ngxFill(settingsJSON[keyName].Min);
          }
          if (settingsJSON[keyName].hasOwnProperty('Max')) {
            cy.getByLabel('Max').ngxFill(settingsJSON[keyName].Max);
          }
        });
    } else if (keyName === 'Fields to Display') {
      cy.get('@appElementProperties');
      cy.wait(500).getByLabel(keyName).find('i.ngx-edit').click();
      cy.get('ngx-dialog div.ngx-dialog-content')
        .find('.app-field-label')
        .contains(new RegExp(`^\\s*${escapeForRegex(settingsJSON[keyName])}\\s*$`))
        .click();

      applyChanges();
    } else {
      cy.get('@appElementProperties').within(() => {
        cy.wait(500)
          .getByLabel(keyName)
          .scrollIntoView()
          .then($el => {
            if ($el.hasClass('ngx-select')) {
              cy.wrap($el).select(settingsJSON[keyName]);
            } else if ($el.hasClass('ngx-input')) {
              cy.wrap($el).ngxFill(settingsJSON[keyName]);
            } else {
              interactWithQuillEditor($el, settingsJSON[keyName]);
            }
          });
      });
    }
  });
}

export function setAppAdditionalSettings(isApp = true) {
  cy.get(isApp ? mainAppElement : mainAppletElement).within(() => {
    cy.get('app-properties-container')
      .find('button')
      .contains(/^\s*Additional Settings\s*$/)
      .click();
  });
}

export function applyChanges(message = 'Application saved') {
  cy.get('.ngx-dialog-content').find('button').contains('Apply').click();
}

function save() {
  cy.get(headerBar).find('button').contains('Save').click({ force: true });
}

export function saveCopy() {
  cy.get('.ngx-dialog-content').find('button').contains('Copy').click();
}

type DoubleCheckMessage = {
  title?: string;
  body?: string;
};

export function saveApplication(
  message = { subtext: 'Application saved' },
  checkMessage = true,
  doubleCheckMessage: DoubleCheckMessage = null
) {
  cy.intercept('PUT', '/api/app/**').as('putApp');
  save();
  if (doubleCheckMessage !== null) {
    verifyDoubleCheck(doubleCheckMessage.title, doubleCheckMessage.body);
  }
  cy.wait('@putApp').its('response.statusCode').should('eq', 200);
  if (checkMessage) {
    verifyPopup3(message);
  }
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(250);
}

export function saveApplet(message = 'Applet saved') {
  cy.intercept('PUT', '/api/applet/**').as('putApplet');
  save();
  cy.wait('@putApplet').its('response.statusCode').should('eq', 200);
  verifyPopup3({ subtext: message });
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(250);
}

function selectEllipsisOption(menuOption: string | number | RegExp, isApp = true) {
  cy.get('.content-area')
    .find(`.app${isApp ? '' : 'let'}-builder-toolbar ngx-toolbar-content`)
    .within(() => {
      cy.get('ngx-dropdown-toggle').click();
      cy.get('ngx-dropdown-menu').contains(menuOption).click();
    });
}

export function verifyEditEllipsisDropdownList(listItems, isApp = true) {
  cy.get('.content-area')
    .find(`.app${isApp ? '' : 'let'}-builder-toolbar ngx-toolbar-content`)
    .within(() => {
      cy.get('ngx-dropdown-toggle').click();
      cy.get('ngx-dropdown-menu')
        .find('button,a')
        .then($selectedList => {
          expect($selectedList).to.have.lengthOf(listItems.length);
          cy.wrap($selectedList).each($el => {
            cy.wrap($el)
              .its('0.innerText')
              .then($textValue => {
                expect($textValue).to.be.oneOf(listItems);
              });
          });
        });
    });
}

export function editWorkflow() {
  cy.intercept('GET', '/api/workflow/**').as('getWorkflow');
  cy.intercept('GET', '/api/task/common').as('getTasks');
  cy.intercept('GET', '/api/task?parentId=**').as('getAppTasks');
  cy.intercept('GET', '/api/app/**').as('getApp');
  cy.intercept('GET', '/api/usage/app/**').as('getAppUsage');
  cy.intercept('GET', '/api/usage/app/common').as('getAppCommonUsage');

  cy.get('.ngx-navbar--nav-items').find('i.ngx-workflow').click();
  cy.isFeatureOn('DynamicOrchestration').then(enabled => {
    if (enabled) {
      return cy.wait(['@getWorkflow', '@getApp']);
    }
    return cy.wait(['@getWorkflow', '@getTasks', '@getApp', '@getAppTasks', '@getAppUsage', '@getAppCommonUsage']);
  });
}

export function getAppID() {
  return cy.url().then($url => {
    const urlArray = $url.split('/').filter(function () {
      return true;
    });
    return urlArray.slice(-1)[0];
  });
}

export function checkFieldProperties(fieldName: string, propertyList: any, isApp = true) {
  const propertyKeys = Object.keys(propertyList);
  cy.get(isApp ? mainAppElement : mainAppletElement).within(() => {
    clickOnField(fieldName);

    if (fieldName != 'Integration') {
      if (propertyKeys.length === 0) {
        cy.get('app-field-properties').find('ul.toggle-list ngx-checkbox').should('not.exist');
      } else {
        cy.get('app-field-properties')
          .find('ul.toggle-list ngx-checkbox')
          .then($fieldProperties => {
            expect($fieldProperties).to.have.lengthOf(propertyKeys.length);
            cy.wrap($fieldProperties).each($property => {
              expect($property.text()).to.be.oneOf(propertyKeys);
              cy.wrap($property).ngxGetValue().should('eq', propertyList[$property.text()]);
            });
          });
      }
    } else {
      cy.get('app-integration-properties').find('ngx-select-input.ngx-select-input').should('exist');
    }
  });
}

export function checkFieldPermissions(fieldName: string, roles = null, isApp = true) {
  cy.get(isApp ? mainAppElement : mainAppletElement).within(() => {
    clickOnField(fieldName);

    cy.get('app-properties-container')
      .find('section h1')
      .contains(/^\s*Permissions\s*$/)
      .closest('section')
      .within(() => {
        cy.get('div i').contains(
          /^\s*Note: Field-level roles defined above supersede application level Record permissions\s*$/
        );
        if (roles === null) {
          cy.get('table.permissions-table').should('not.exist');
        } else {
          // TODO: Do verify on permissions table rows.
        }
      });
  });
}

type AdvanceOptions = {
  Prefix?: string;
  Suffix?: string;
  Min?: string;
  Max?: string;
  'Max Size'?: string;
  'Delete attachments'?: boolean;
  'Default Value'?: string;
  'Ability to add new on target'?: boolean;
  'Create and maintain reciprocal reference'?: boolean;
  Placeholder?: string;
  Length?: { Min?: string; Max?: string; Units?: string };
};

export function checkFieldAdvancedOptions(fieldName: string, options: AdvanceOptions = null, isApp = true) {
  cy.get(isApp ? mainAppElement : mainAppletElement).within(() => {
    clickOnField(fieldName);

    if (options === null) {
      cy.get('app-properties-container')
        .find('section h1')
        .contains(/^\s*Advanced\s*$/)
        .should('not.exist');
    } else {
      cy.get('app-properties-container')
        .find('section h1')
        .contains(/^\s*Advanced\s*$/)
        .closest('section')
        .within(() => {
          Object.keys(options).forEach($property => {
            if ($property === 'Length') {
              cy.get('label')
                .contains(/^\s*Length\s*$/)
                .closest('div')
                .as('lengthSettings');
              Object.keys(options.Length).forEach($option => {
                switch ($option) {
                  case 'Min':
                  case 'Max':
                    cy.getByLabel($option).ngxGetValue().should('eq', options.Length[$option]);
                    break;
                  case 'Units':
                    cy.get('@lengthSettings').find(`ngx-select`).ngxGetValue().should('eq', options.Length[$option]);
                    break;
                  default:
                }
              });
            } else if ($property === 'Max Size') {
              cy.getByLabel('Max Size [kB]').ngxGetValue().should('eq', options[$property]);
            } else if ($property === 'Ability to add new on target') {
              cy.get(`ngx-checkbox label`)
                .contains(/^\s*Ability to add new on target\s*$/)
                .closest('ngx-checkbox')
                .ngxGetValue()
                .should('eq', options[$property]);
            } else if ($property === 'Create and maintain reciprocal reference') {
              cy.get(`ngx-checkbox label`)
                .contains(/^\s*Create and maintain reciprocal reference\s*$/)
                .closest('ngx-checkbox')
                .ngxGetValue()
                .should('eq', options[$property]);
              // } else if ($property === 'Delete Attachments') {
              //   cy.getByLabel(`Delete attachments`).ngxGetValue().should('eq', options[$property]);
              // } else if ($property === 'Default Value') {
              //   cy.getByLabel(`Default Value`).ngxGetValue().should('eq', options[$property]);
            } else {
              cy.getByLabel($property).ngxGetValue().should('eq', options[$property]);
            }
          });
        });
    }
  });
}

type ExportOptions = {
  hasCredIssues?: boolean;
  performSave?: boolean;
};

export function exportApplication(exportOptions: ExportOptions = {}) {
  cy.intercept('POST', '/api/content/export/download').as('getAppExportDownload');
  cy.intercept('POST', '/api/content/export/try').as('getAppExportTry');

  selectEllipsisOption('Export Application');
  if (exportOptions.hasOwnProperty('performSave')) {
    verifyDoubleCheck(
      'Save Confirmation',
      'You must save this application before exporting it. Save now?',
      true,
      exportOptions.performSave ? 'Ok' : 'Cancel'
    );
  } else {
    cy.wait('@getAppExportTry').its('response.statusCode').should('eq', 200);
    if (exportOptions.hasCredIssues) {
      cy.get('.app-export--message').should('contain', exportReadyMessage);
      cy.get('.app-export--message ngx-tip').should(
        'contain',
        'Secure credentials are not included in exported tasks and assets and can be configured later.'
      );
    }

    cy.get('.ngx-dialog-footer .btn').contains('Continue Export').click();
    cy.wait('@getAppExportDownload').then(xhr => {
      const downloadedFilename = path.join(
        downloadsFolder,
        decodeURIComponent(
          // @ts-ignore
          xhr.response.headers['content-disposition'].split('; ')[2].split('=')[1].replace("UTF-8''", '')
        )
      );
      cy.wait(1000);
      cy.readFile(downloadedFilename, 'binary', { timeout: 60000 }).should(buffer => {
        expect(buffer.length).to.be.gt(100);
      });
    });
    verifyPopup3({ subtext: 'Application exported' });
  }
}

export function exportApplet(exportOptions: ExportOptions = {}) {
  cy.intercept('POST', '/api/content/export/try').as('getAppletExportTry');
  cy.intercept('POST', '/api/content/export/download').as('getAppletExportDownload');

  selectEllipsisOption('Export Applet', false);
  if (exportOptions.hasOwnProperty('performSave')) {
    verifyDoubleCheck(
      'Save Confirmation',
      'You must save this applet before exporting it. Save now?',
      true,
      exportOptions.performSave ? 'Ok' : 'Cancel'
    );
  } else {
    cy.wait('@getAppletExportTry').its('response.statusCode').should('eq', 200);
    if (exportOptions.hasCredIssues) {
      cy.get('.app-export--message').should('contain', exportReadyMessage);
      cy.get('.app-export--message ngx-tip').should(
        'contain',
        'Secure credentials are not included in exported tasks and assets and can be configured later.'
      );
    }
    cy.get('.ngx-dialog-footer .btn').contains('Continue Export').click();
    cy.wait('@getAppletExportDownload').then(xhr => {
      verifyPopup3({ subtext: 'Applet exported' });
      const downloadedFilename = path.join(
        'temp/downloads',
        decodeURIComponent(
          // @ts-ignore
          xhr.response.headers['content-disposition'].split('; ')[2].split('=')[1].replace("UTF-8''", '')
        )
      );
      cy.wait(1000);
      cy.readFile(downloadedFilename, 'binary', { timeout: 60000 }).should(buffer => {
        expect(buffer.length).to.be.gt(100);
      });
    });
  }
}

export function checkFieldSize(fieldName: string, size = '25%', isApp = true) {
  cy.get(isApp ? mainAppElement : mainAppletElement).within(() => {
    clickOnField(fieldName);

    cy.get('app-properties-container')
      .find('section h1')
      .contains(/^\s*Size\s*$/)
      .closest('section')
      .find('div.btn-primary')
      .contains(new RegExp(`^\\s*${escapeForRegex(size)}\\s*$`));
  });
}

export function setFieldSize(fieldName: string, size = '25%', isApp = true) {
  cy.get(isApp ? mainAppElement : mainAppletElement).within(() => {
    clickOnField(fieldName);

    cy.get('app-properties-container')
      .find('section h1')
      .contains(/^\s*Size\s*$/)
      .closest('section');
    cy.get('div.btn')
      .contains(new RegExp(`^\\s*${escapeForRegex(size)}\\s*$`))
      .click();
  });
}

export function verifyFieldKey(fieldName: string, keyValue: string, isApp = true) {
  cy.get(isApp ? mainAppElement : mainAppletElement).within(() => {
    clickOnField(fieldName);

    cy.get('app-field-properties').within(() => {
      cy.getByLabel('Key').ngxGetValue().should('eq', keyValue);
    });
  });
}

export function openWidgetEditor() {
  cy.get('app-widget-properties').within(() => {
    cy.get('button').contains('Edit Widget').click();
  });
  cy.get('widget-editor').within(() => {
    cy.get('.panel-header ngx-tabs').contains('button', 'preview record data').click();
    cy.get('span').should('contain', 'Select the Record to Load the Data From');
  });
}

export function editRecordFromWidget(_results, inputs = null, timeout = null) {
  if (inputs.hasOwnProperty('fromRecord')) {
    cy.get('record-select').within(() => {
      field.setValue(
        {
          fieldType: 'valuesList',
          attribute: '[placeholder="Select a Record"]'
        },
        inputs.fromRecord
      );
      cy.get('ngx-button.btn').contains('Open Record').click();
    });

    recordEditor.setFieldValue(inputs.updateRecord);
    recordEditor.saveAndClose('Record updated', false, true, true);
    // recordEditor.save('Record saved', false, true);
  } else if (inputs.hasOwnProperty('newRecord')) {
    cy.get('record-select').within(() => {
      field.setValue(
        {
          fieldType: 'valuesList',
          attribute: '[placeholder="Select a Record"]'
        },
        'Create New Record'
      );
    });
    recordEditor.setFieldValue(inputs.newRecord);

    recordEditor.save('Record saved', false, true, true);
  } else {
    cy.get('.inputs-table').within(() => {
      Object.keys(inputs).forEach(inputName => {
        cy.get('samp')
          .contains(new RegExp(`^\\s*${escapeForRegex(inputName)}\\s*$`))
          .closest('tr')
          .within(() => {
            field.setValue({ fieldType: 'text', inputType: 'text' }, inputs[inputName]);
          });
      });
    });
  }
}

export function closeWidgetEditor() {
  cy.get('button').contains('Cancel').click();
}

export function addAppletToApplication(appletName: string, clickAddButton = true, message = null) {
  cy.intercept('POST', '/api/task').as('addAppletTasks');
  cy.intercept('GET', '/api/task/light').as('getAppletTasks');
  cy.intercept('GET', '/api/usage/app/**').as('getAppUsage');
  cy.intercept('GET', '/api/usage/app/common').as('getAppCommonUsage');
  // have to use the .first to get the main builder-target as once an applet is added, there will be two builder-targets, one for the application and one for each embedded applet
  cy.get('.builder-target.ngx-dnd-container:only-of-type').first().should('be.visible').as('appBuilderForm');
  cy.get('.builder-source').within(() => {
    cy.get('ngx-section-header > h3')
      .contains(/^\s*Applets\s*$/)
      .scrollIntoView();
    cy.get('div.applet-name').contains(appletName).should('be.visible').click();
    cy.get('div.builder-source-applet').contains(appletName).should('be.visible').as('appletToAdd');
    cy.dragAndDrop('@appletToAdd', '@appBuilderForm');
    cy.get('@appBuilderForm').within(() => {
      cy.get('.confirmation-message').should(
        'contain',
        ' This action creates application tasks for each of the applet tasks.'
      );
      if (clickAddButton) {
        cy.get('ngx-button').should('have.length', 2);
        cy.get('ngx-button').contains('Add').click();
        cy.wait(['@addAppletTasks']).its('response.statusCode').should('eq', 200);
        if (!message === null) {
          verifyPopup3({ subtext: message });
        }
        cy.wait(['@getAppletTasks', '@getAppUsage', '@getAppCommonUsage']).then(intercepts => {
          intercepts.forEach(apiCall => expect(apiCall.response.statusCode).to.equal(200));
        });
      }
    });
  });
}

export function integrationTask(input: string, taskName?: string) {
  switch (input) {
    case 'create':
      cy.intercept('GET', '/api/task/actions').as('getActions');
      cy.intercept('GET', '/api/task/list').as('getTaskList');
      cy.get('app-integration-properties').find('ngx-select.ngx-select').click();
      cy.get('li.ngx-select-dropdown-option')
        .contains(/^\s*Create a Task\s*$/)
        .click();
      cy.wait(['@getActions', '@getTaskList']); // See SPT-11535
      break;

    case 'edit':
      cy.get('app-usage-task-properties').within(() => {
        cy.get('ngx-input.manual-time').should('be.visible');
        cy.get('ngx-input.manual-cost').should('be.visible');
      });
      verifyTaskName(taskName);
      cy.get('a.edit-task-link').click();
      cy.get('.ngx-dialog-content').within(() => {
        cy.contains('button.btn', /^\s*Ok\s*$/).click();
      });
      break;

    case 'remove':
      cy.get('app-integration-properties').find('label.ngx-select-label').contains('Task');
      cy.get('a.edit-task-link').should('not.exist');
      break;
  }
}

export function verifyTaskName(taskName: string) {
  cy.get('app-integration-properties').find('li.ngx-select-input-option').contains(taskName);
}

export function referenceFieldSelectionInTrackingField(fieldName: string) {
  cy.get('.grid-control-selections.ng-star-inserted').within(() => {
    cy.get('.btn.btn-link.ngx-button').click();
  });
  cy.get('.field-item.ng-star-inserted').within(() => {
    cy.contains(fieldName).click();
  });
  cy.contains('Apply').click();
}

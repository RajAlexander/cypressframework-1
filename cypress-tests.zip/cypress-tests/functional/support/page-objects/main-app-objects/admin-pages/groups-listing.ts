// tslint:disable: tsr-detect-non-literal-regexp

import { verifyPopup3, verifyDoubleCheck } from '../common-pieces/popupMessages';
import { setUserGroupValue } from '../common-pieces/interactions';
import { escapeForRegex } from '../common-pieces/common-calls';

const groupsListing = 'groups_list';
const groupsTitlebar = 'groups__titlebar';

export function createNewGroup(groupJSON: Record<string, any>) {
  cy.intercept('POST', '/api/groups').as('createGroup');
  cy.intercept('GET', '/api/user/search?query=**').as('getUsers');

  cy.dataCy(groupsTitlebar)
    .should('be.visible')
    .within(() => {
      cy.dataCy('new-group__btn').click();
    });
  cy.get('.ngx-dialog-content').within(() => {
    Object.keys(groupJSON).forEach(key => {
      switch (key) {
        case 'Name':
        case 'Description':
          cy.getByLabel(key).ngxFill(groupJSON[key]);
          break;
        case 'Roles':
          break;
        case 'Groups':
          break;
        case 'Users':
          groupJSON.Users.forEach($user => {
            setUserGroupValue($user, 'multi', ['@getUsers'], '[data-cy="users__select"]');
          });
          break;
        case 'Disabled':
          break;
      }
    });
    cy.get('state-save-button button').click();
  });
  cy.wait('@createGroup').its('response.statusCode').should('eq', 200);
  verifyPopup3('Group created');
  // Commenting out to see if the network waits are really helpful
  //  cy.waitForNetworkIdle(250);
}

export function deleteGroup(groupName: string) {
  cy.intercept('DELETE', '/api/groups/**').as('deleteGroup');
  cy.dataCy(groupsListing)
    .should('be.visible')
    .within(() => {
      cy.get('ngx-datatable datatable-row-wrapper')
        .contains(new RegExp(`^\\s*${escapeForRegex(groupName)}\\s*$`))
        .closest('datatable-row-wrapper')
        .find('.ngx-trash')
        .click();
    });
  verifyDoubleCheck('Delete Confirmation', `You are about to delete ${groupName}. Do you want to continue?`);
  cy.wait('@deleteGroup').its('response.statusCode').should('eq', 204);
  verifyPopup3('Group Deleted');
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(250);
}

export function keywordSearchingGroups(groupName: string) {
  cy.get('input').type(groupName);
  cy.dataCy(groupsListing)
    .should('be.visible')
    .within(() => {
      cy.get('datatable-row-wrapper').contains(new RegExp(`^\\s*${escapeForRegex(groupName)}\\s*$`));
    });
}

export function sortingGroupsByName(groupName: string) {
  cy.contains('Name').click();
  cy.get('datatable-row-wrapper').eq(0).should('contain', groupName);
}

export function sortingGroupsByDescription(groupDescription: string) {
  cy.contains('Description').click();
  cy.get('datatable-row-wrapper').eq(0).should('contain', groupDescription);
}

export function typeGroupPrefix(groupPrefix: string) {
  cy.get('input').type(groupPrefix);
}

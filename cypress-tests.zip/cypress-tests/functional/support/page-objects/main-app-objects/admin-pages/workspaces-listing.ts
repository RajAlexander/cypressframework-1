// tslint:disable: tsr-detect-non-literal-regexp

import { verifyDoubleCheck, verifyPopup3 } from '../common-pieces/popupMessages';

const mainElement = 'workspaces_listing';

export function getCountOfList() {
  return cy
    .dataCy(mainElement)
    .children()
    .then(childList => {
      const element = childList[0];
      if (element.localName == 'p') {
        return cy
          .wrap(element)
          .should('have.text', 'No workspaces')
          .then(() => {
            return 0;
          });
      } else {
        return cy
          .wrap(element)
          .find('datatable-row-wrapper')
          .then(childList => {
            return childList.length;
          });
      }
    });
}

export function deleteWorkspace(workspaceName: string): void {
  cy.intercept('DELETE', '/api/workspaces/**').as('delWorkspace');

  getCountOfList().then($origCount => {
    cy.dataCy(mainElement)
      .find('a')
      .contains(new RegExp(`^\\s*${workspaceName}\\s*$`))
      .parents('datatable-row-wrapper')
      .find('span.ngx-trash')
      .scrollIntoView()
      .click();
    verifyDoubleCheck(
      'Are you sure?',
      `You are about to delete this workspace: '${workspaceName}'. Do you want to continue?`
    );
    cy.wait('@delWorkspace').its('response.statusCode').should('eq', 204);
    verifyPopup3({ subtext: 'Workspace deleted' });
    getCountOfList().then($newCount => {
      expect($newCount).to.equal($origCount - 1);
    });
  });
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(250);
}

export function verifyWorkspaceExists(workspaceName: string) {
  cy.dataCy(mainElement)
    .find('a')
    .contains(new RegExp(`^\\s*${workspaceName}\\s*$`))
    .its('length')
    .should('eq', 1);
}

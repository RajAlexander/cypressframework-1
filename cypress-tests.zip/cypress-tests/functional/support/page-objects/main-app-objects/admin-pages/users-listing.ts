// tslint:disable: tsr-detect-non-literal-regexp

import { verifyDoubleCheck, verifyPopup3 } from '../common-pieces/popupMessages';
import * as userDialog from './user-dialog';
import { escapeForRegex } from '../common-pieces/common-calls';
export { userDialog };

const toolBar = 'users__toolbar';
const listing = 'users__listing';

export function clickNewUser() {
  cy.dataCy(toolBar)
    .find('button')
    .contains(/^\s*New User\s*$/)
    .click();
}

export function removeUserInListing(displayName: string, i = null) {
  const userDelAlias = `userDelete${i ? i : Math.random()}`;
  const userGetAlias = `getUsers${i ? i : Math.random()}`;

  cy.intercept('DELETE', '/api/user/**').as(userDelAlias);
  cy.intercept('GET', '/api/user?size=16**').as(userGetAlias);
  cy.dataCy(listing).within(() => {
    cy.get('datatable-body-row')
      .contains(new RegExp(`^\\s*${displayName}\\s*$`))
      .parents('datatable-body-row')
      .find('.ngx-trash')
      .scrollIntoView()
      .click();
  });

  verifyDoubleCheck('Delete Confirmation', `You are about to delete ${displayName}. Do you want to continue?`);

  cy.wait(`@${userDelAlias}`).its('response.statusCode').should('eq', 204);
  verifyPopup3('User deleted');
  cy.wait(`@${userGetAlias}`).its('response.statusCode').should('eq', 200);
  cy.dataCy(listing)
    .find('datatable-body-row')
    .contains(new RegExp(`^\\s*${displayName}\\s*$`))
    .should('not.exist');
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(250);
}

export function clickUserToEdit(displayName: string | number | RegExp) {
  cy.intercept('GET', '/api/user/**').as('getUser');
  cy.intercept('GET', '/api/settings').as('getSettings');

  cy.dataCy(listing).find('a').contains(displayName).click();
  cy.wait(['@getUser', '@getSettings']);
}

export function sortingUsersByName(userName: string) {
  cy.contains('Name').click();
  cy.get('datatable-row-wrapper').eq(0).should('contain', userName);
}

export function keywordSearchingUsers(userName: string) {
  cy.get('input').type(userName);
  cy.dataCy(listing)
    .should('be.visible')
    .within(() => {
      cy.get('datatable-row-wrapper').contains(new RegExp(`^\\s*${escapeForRegex(userName)}\\s*$`));
    });
}

export function unlockUser(displayname: string | number | RegExp, loginCode = 200) {
  cy.intercept('PUT', '/api/user/**').as('unlockUser');
  cy.get('.user-displayname').should('be.visible').contains(displayname);
  cy.get('.btn-warning').should('have.text', 'Unlock').click();

  cy.wait('@unlockUser')
    .its('response')
    .then(response => {
      expect(response.statusCode).to.equal(loginCode);
      if (loginCode === 200) {
        expect(response.body.isLocked).equals(false);
        expect(response.body.currentFailedLogInAttempts).equals(0);
        cy.get('.btn-warning', { timeout: 10000 }).should('not.exist');
      }
    });
}

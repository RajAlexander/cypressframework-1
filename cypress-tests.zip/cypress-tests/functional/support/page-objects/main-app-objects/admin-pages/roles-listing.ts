// tslint:disable: tsr-detect-non-literal-regexp

import { verifyPopup3, verifyDoubleCheck } from '../common-pieces/popupMessages';
import { escapeForRegex } from '../common-pieces/common-calls';
import { setUserGroupValue } from '../common-pieces/interactions';

const rolesListing = 'roles_list';
const rolesTitlebar = 'roles__titlebar';

export function createNewRole(roleJSON: Record<string, any>) {
  cy.intercept('POST', '/api/roles').as('createRole');
  cy.intercept('GET', '/api/roles/**').as('getRoles');
  cy.intercept('GET', '/api/user/search?query=**').as('getUsers');

  cy.dataCy(rolesTitlebar)
    .should('be.visible')
    .within(() => {
      cy.dataCy('new-role__btn').click();
    });
  cy.get('.ngx-dialog-content').within(() => {
    Object.keys(roleJSON).forEach(key => {
      switch (key) {
        case 'Name':
        case 'Description':
          cy.getByLabel(key).ngxFill(roleJSON[key]);
          break;
        case 'Groups':
          break;
        case 'Users':
          roleJSON.Users.forEach($user => {
            setUserGroupValue($user, 'multi', ['@getUsers'], '[data-cy="users__select"]');
          });
          break;
      }
    });
    if (roleJSON.hasOwnProperty('Permissions')) {
      cy.get('.ngx-tabs').find('button').contains('Permissions').click();
      Object.keys(roleJSON.Permissions).forEach(key => {
        cy.get('.ngx-tab').find('button').contains(key).click();
        cy.get(`.permissions-table.${key.toLowerCase().slice(0, -1)}`).within(() => {
          roleJSON.Permissions[key].forEach(permissionRow => {
            cy.get('div.name')
              .contains(permissionRow.name)
              .closest('tr')
              .within(() => {
                permissionRow.settings.forEach(setting => {
                  cy.dataCy(setting).check();
                });
              });
          });
        });
      });
    }
    cy.get('state-save-button').click();
  });
  cy.wait('@createRole').its('response.statusCode').should('eq', 200);
  verifyPopup3('Role created');

  cy.wait('@getRoles').its('response.statusCode').should('eq', 200);
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(250);
}

export function deleteRole(roleName: string) {
  cy.intercept('DELETE', '/api/roles/**').as('deleteRole');
  cy.dataCy(rolesListing)
    .should('be.visible')
    .within(() => {
      cy.get('datatable-row-wrapper')
        .contains(new RegExp(`^\\s*${escapeForRegex(roleName)}\\s*$`))
        .closest('datatable-row-wrapper')
        .find('.ngx-trash')
        .click();
    });
  verifyDoubleCheck('Delete Confirmation', `You are about to delete ${roleName}. Do you want to continue?`);
  cy.wait('@deleteRole').its('response.statusCode').should('eq', 204);
  verifyPopup3('Role Deleted');
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(250);
}

export function keywordSearchingRoles(roleName: string) {
  cy.get('input').type(roleName);
  cy.dataCy(rolesListing)
    .should('be.visible')
    .within(() => {
      cy.get('datatable-row-wrapper').contains(new RegExp(`^\\s*${escapeForRegex(roleName)}\\s*$`));
    });
}

export function sortingRolesByName(roleName: string) {
  cy.contains('Name').click();
  cy.get('datatable-row-wrapper').eq(0).should('contain', roleName);
}

export function sortingRolesByDescription(roleDescription: string) {
  cy.contains('Description').click();
  cy.get('datatable-row-wrapper').eq(0).should('contain', roleDescription);
}

export function typeRolePrefix(rolePrefix: string) {
  cy.get('input').type(rolePrefix);
}

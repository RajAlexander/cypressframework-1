import { verifyPopup3 } from '../common-pieces/popupMessages';

const mainElement = 'div.user-container';

export function disable(disable = true) {
  cy.get(mainElement).within(() => {
    cy.getByLabel('Disable Account')[disable ? 'check' : 'uncheck']();
  });
}

export function save() {
  cy.intercept('PUT', '/api/user/**').as('updateUser');

  cy.get(mainElement).within(() => {
    cy.get('state-save-button').contains('Save').click();
  });
  cy.wait('@updateUser').its('response.statusCode').should('eq', 200);
  verifyPopup3({ subtext: 'User updated' });
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(250);
}

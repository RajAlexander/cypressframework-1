import { verifyPopup3 } from '../../common-pieces/popupMessages';
import * as pdfFormatting from '../../pdfFormatting';

const mainEle = 'email-pdf__settings';
const pdfFormattingEle = '[data-cy=pdf-formatting__section]';

export function setOutgoingMailServer(newDataJSON: Record<string, any>) {
  cy.dataCy(mainEle)
    .find('ngx-section[sectiontitle="Outgoing Mail Server"]')
    .within(() => {
      cy.get('button.ngx-section-toggle .ngx-icon.ngx-chevron-bold-right').iff($el => {
        cy.wrap($el).click();
      });
      cy.get('div.ngx-section-content').within(() => {
        Object.keys(newDataJSON).forEach(key => {
          cy.getByLabel(key).ngxFill(newDataJSON[key]);
        });
      });
    });
  cy.wait(500);
  saveChanges();
}

export function setPageOrientation(orientation: string | number | RegExp) {
  cy.dataCy(mainEle)
    .find(pdfFormattingEle)
    .within(() => {
      pdfFormatting.setPageOrientation(orientation);
    });
}

export function verifyPageOrientation(orientation: string | number | RegExp) {
  cy.dataCy(mainEle)
    .find(pdfFormattingEle)
    .within(() => {
      pdfFormatting.verifyPageOrientation(orientation);
    });
}
export function setHeaderCode(htmlCode: string) {
  cy.dataCy(mainEle)
    .find(pdfFormattingEle)
    .within(() => {
      pdfFormatting.setHTMLCode('Header', htmlCode);
    });
}
export function verifyHeaderCode(htmlCode: string) {
  cy.dataCy(mainEle)
    .find(pdfFormattingEle)
    .within(() => {
      pdfFormatting.checkHTMLCode('Header', htmlCode);
    });
}

export function setFooterCode(htmlCode: string) {
  cy.dataCy(mainEle)
    .find(pdfFormattingEle)
    .within(() => {
      pdfFormatting.setHTMLCode('Footer', htmlCode);
    });
}

export function verifyFooterCode(htmlCode: string) {
  cy.dataCy(mainEle)
    .find(pdfFormattingEle)
    .within(() => {
      pdfFormatting.checkHTMLCode('Footer', htmlCode);
    });
}
export function saveChanges() {
  cy.intercept('PUT', '/api/settings').as('putSettings');
  cy.get('div.content-panel > div.content-area')
    .find('section.main.settings')
    .within(() => {
      cy.get('div.email-content state-save-button').click();
      cy.wait('@putSettings').its('response.statusCode').should('eq', 200);
    });

  verifyPopup3({ subtext: 'Email and PDF Settings Updated' });
}

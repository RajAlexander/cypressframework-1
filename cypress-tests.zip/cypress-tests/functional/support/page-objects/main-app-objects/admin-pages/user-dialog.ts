import { verifyPopup3 } from '../common-pieces/popupMessages';

const mainElement = 'div.create-user-modal';

export function enterUserInfo(userJSON: any = {}) {
  cy.get(mainElement).within(() => {
    Object.keys(userJSON).forEach($key => {
      switch ($key) {
        case 'roles':
          userJSON.roles.forEach(element => {
            cy.get('[formcontrolname="roles"]').select(element);
          });
          break;
        case 'groups':
          userJSON.groups.forEach(element => {
            cy.get('[formcontrolname="groups"]').select(element);
          });
          break;
        default:
          cy.get(`[formControlName="${$key}"]`).ngxFill(userJSON[$key]);
      }
    });
  });
}

export function saveUserEdit() {
  cy.intercept('POST', '/api/user').as('userPost');
  cy.get(mainElement).find('button.btn.btn-primary').contains('Save').should('be.visible').click();
  cy.wait('@userPost').its('response.statusCode').should('eq', 200);
  verifyPopup3('User created');
}

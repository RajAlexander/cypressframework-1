const mainElement = 'div.formula-builder-dialog';

export function typeFormula(formulaText: string) {
  cy.get('ngx-codemirror').ngxFill(formulaText);
}

export function applyFormula() {
  cy.intercept('POST', '/api/app/formula-validate').as('postValidate');
  cy.get(mainElement).find('div.help-banner ngx-button.save-btn').click();
  cy.wait('@postValidate').its('response.statusCode').should('eq', 200);
  cy.get(mainElement).should('not.exist');
}

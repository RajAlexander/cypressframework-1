// tslint:disable: tsr-detect-non-literal-regexp

import { escapeForRegex } from './common-pieces/common-calls';
import * as assetEditor from './assetEditor';
import * as taskEditor from './taskEditor';
import { verifyPopup, verifyPopup3, verifyDoubleCheck } from './common-pieces/popupMessages';
import { editTaskConfiguration, saveCurrentTask } from './integrationsPage';

type PACKAGE_TYPE = Array<{
  name: string;
  version: string;
  message: string;
  pluginversion: string;
  errors?: string;
  issues?: string;
}>;

type ASSET_TYPE = Array<{
  name: string;
  version?: string;
  message: string;
  message1?: string;
  errors?: string;
  issues?: string;
}>;

type TASK_TYPE = Array<{
  name?: string;
  version?: string;
  errors?: number;
  reason?: string;
  message?: string;
}>;

type WORKFLOW_TYPE = Array<{
  reason: string;
  name: string;
  errors: string;
}>;

type DESCRIPTORS_TYPE = {
  package?: PACKAGE_TYPE;
  asset?: ASSET_TYPE;
  workflow?: WORKFLOW_TYPE;
  task?: TASK_TYPE;
  applet?: ASSET_TYPE;
};

type ISSUES_LIST = {
  appName?: string;
  packageContents?: any[];
  descriptors?: DESCRIPTORS_TYPE;
};

export function uploadPackage(sspPath: string) {
  cy.intercept('POST', 'import').as('apiContentImport');
  cy.intercept('GET', 'status').as('apiContentImportStatus');
  cy.get('.app-import__dropzone-container').within(() => {
    cy.fixture(sspPath, 'binary')
      .then(Cypress.Blob.binaryStringToBlob)
      .then(fileContent => {
        cy.get('input.ngx-dropzone--input').attachFile({
          fileContent,
          filePath: sspPath,
          mimeType: 'application/octet-stream',
          encoding: 'utf-8'
        });
      });
  });
  // The verification of the API  call status  call needs to  be verified.
  cy.wait('@apiContentImport');
  cy.wait('@apiContentImportStatus');
}

export function verifyUpload(
  importHeaderMessage: string,
  importError: string,
  importErrorMessage: string,
  importErrorMessage2 = null,
  importTaskIssuesMessage = null,
  taskCount: number,
  issuesList: ISSUES_LIST = {},
  isApp = true,
  closeDialog = true
) {
  const entityType = isApp ? 'application' : 'applet';
  cy.get('.app-import--container').within(() => {
    cy.get('.app-import__header h1', { timeout: 60000 }).should('contain', importHeaderMessage);
    if (importHeaderMessage === 'Import Success') {
      // noop
    }
    if (importHeaderMessage === 'Import') {
      cy.get('.app-import__progress-container').within(() => {
        cy.get('.ngx-progress-spinner').should('contain', importError);
        cy.get('.error-message').should('contain', importErrorMessage);
      });
    }
    if (importHeaderMessage === 'Import Summary') {
      cy.get('.app-import__content').within(() => {
        cy.get('.app-import-messages').should('contain', importError).should('contain', importErrorMessage);
        if (importErrorMessage2 !== null) {
          cy.get('.app-import-messages').should('contain', importErrorMessage2);
        }
        if (importTaskIssuesMessage !== null) {
          cy.get('.app-import-messages__task-enable-container').should('contain', importTaskIssuesMessage);
          cy.get('.ngx-toggle-text').should('contain', 'Include scheduled tasks');
          if (taskCount > 1) {
            cy.get('.btn').should('contain', `Enable ${taskCount} Tasks`);
          } else {
            cy.get('.btn').should('contain', `Enable ${taskCount} Task`);
          }
        }
        cy.get(`ngx-card.connections-preview--${entityType}`).within(() => {
          cy.get('ngx-card-title').should('contain', issuesList.appName);
          cy.get('.connections-preview__connections').within(() => {
            cy.get('.connections-preview__entity-count').then($entityList => {
              expect($entityList.length).to.equal(issuesList.packageContents.length);
              $entityList.each((i, entity) => {
                cy.wrap(entity).contains(new RegExp(`^\\s*${escapeForRegex(issuesList.packageContents[i])}\\s*$`));
              });
            });
          });
        });
        if (issuesList.hasOwnProperty('descriptors')) {
          cy.get('.content-action-results-container').within(() => {
            if (issuesList.descriptors.hasOwnProperty('package')) {
              cy.get('.plugin-upload-status').then($descriptors => {
                expect($descriptors.length).to.equal(issuesList.descriptors.package.length);
                $descriptors.each((i, description) => {
                  cy.wrap(description).within(() => {
                    cy.get('.plugin-upload-status--title').should('contain', issuesList.descriptors.package[i].name);
                    cy.get('.plugin-upload-status--sub-title').should(
                      'contain',
                      issuesList.descriptors.package[i].version
                    );
                    if (issuesList.descriptors.package[i].hasOwnProperty('errors')) {
                      cy.get('.plugin-upload-status--status-text').should(
                        'contain',
                        `${issuesList.descriptors.package[i].errors} Error`
                      );
                      cy.get('.entity-error__message').should('contain', issuesList.descriptors.package[i].message);
                    }
                    if (issuesList.descriptors.package[i].hasOwnProperty('issues')) {
                      cy.get('.entity-card__issues-section--edit-mode').should(
                        'contain',
                        `Resolve ${issuesList.descriptors.package[i].issues} Issue`
                      );
                      cy.get('.entity-error__message').should('contain', issuesList.descriptors.package[i].message);
                    }
                    if (issuesList.descriptors.package[i].hasOwnProperty('pluginversion')) {
                      if (issuesList.descriptors.package[i].pluginversion == 'upgrade') {
                        cy.get('.plugin-upload-status--status-text')
                          .invoke('text')
                          .should('match', /^\s*New Plugin Version Detected:\s*Upgrade Now\s*$/);
                      } else {
                        cy.get('.plugin-upload-status--status-text')
                          .invoke('text')
                          .should('match', /^\s*Plugin Requires Downgrade\s*$/);
                      }
                    }
                  });
                });
              });
            }
            if (issuesList.descriptors.hasOwnProperty('asset')) {
              cy.get('ngx-section.entity-section--asset').then($descriptors => {
                expect($descriptors.length).to.equal(issuesList.descriptors.asset.length);
                issuesList.descriptors.asset.forEach(eachAsset => {
                  cy.get('.entity-card__name')
                    .contains(eachAsset.name)
                    .scrollIntoView()
                    .closest('ngx-section.entity-section--asset')
                    .within(() => {
                      cy.get('.descriptor__version').should('contain', eachAsset.version);
                      if (eachAsset.hasOwnProperty('errors')) {
                        cy.get('.entity-card__errors-section').should('contain', `${eachAsset.errors} Error`);
                      }
                      if (eachAsset.hasOwnProperty('issues')) {
                        cy.get('.entity-card__issues-section--edit-mode').should(
                          'contain',
                          `Resolve ${eachAsset.issues} Issue`
                        );
                      }
                      cy.get('.entity-issue__message').should('contain', eachAsset.message);
                      if (eachAsset.hasOwnProperty('message1')) {
                        cy.get('.entity-issue__message').should('contain', eachAsset.message1);
                      }
                    });
                });
              });
            }
            if (issuesList.descriptors.hasOwnProperty('task')) {
              cy.get('ngx-section.entity-section--task').then($descriptors => {
                expect($descriptors.length).to.equal(issuesList.descriptors.task.length);
                issuesList.descriptors.task.forEach(eachTask => {
                  cy.get('.entity-card__name')
                    .contains(eachTask.name)
                    .scrollIntoView()
                    .closest('ngx-section.entity-section--task')
                    .within(() => {
                      if (eachTask.version) {
                        cy.get('.descriptor__version').should('contain', eachTask.version);
                      }
                      if (eachTask.hasOwnProperty('errors')) {
                        cy.get('.entity-card__errors-section').should('contain', `${eachTask.errors} Error`);
                      }
                      // The next three lines are questionable
                      cy.get('.entity-card__name').should('contain', eachTask.name);
                      if (eachTask.version) {
                        cy.get('.descriptor__version').should('contain', eachTask.version);
                      }
                      if (eachTask.hasOwnProperty('errors')) {
                        cy.get('.entity-card__errors-section').should('contain', `${eachTask.errors} Error`);
                      }
                      if (eachTask.hasOwnProperty('reason')) {
                        const isIssue = eachTask.hasOwnProperty('issues');
                        if (isIssue) {
                          cy.get('.entity-issue__message').as('problemText');
                        } else {
                          cy.get('.entity-error__message').as('problemText');
                        }
                        cy.get('@problemText')
                          .invoke('text')
                          .should('match', new RegExp(`^\\s*${eachTask.reason}\\s*$`));
                      }
                    });
                });
              });
            }
            if (issuesList.descriptors.hasOwnProperty('workflow')) {
              cy.get('ngx-section.entity-section--workflow').then($descriptors => {
                expect($descriptors.length).to.equal(issuesList.descriptors.workflow.length);
                $descriptors.each((i, description) => {
                  cy.wrap(description).within(() => {
                    cy.get('.entity-card__name').should('contain', issuesList.descriptors.workflow[i].name);
                    if (issuesList.descriptors.workflow[i].hasOwnProperty('reason')) {
                      cy.get('.entity-issue__message')
                        .invoke('text')
                        .should('match', new RegExp(`^\\s*${issuesList.descriptors.workflow[i].reason}\\s*$`));
                    }
                  });
                });
              });
            }
          });
        } else {
          cy.get('.app-import-messages').should('contain', `Your ${entityType} has imported successfully.`);
        }
      });
    }
    if (closeDialog) {
      if (importHeaderMessage !== 'Import') {
        close();
      } else {
        headerClose();
      }
    }
  });
}

export function verifyUploadFailure(failure: string, message: string, closeDialog = true) {
  cy.get('.app-import--container').within(() => {
    cy.get('.app-import-messages')
      .should('contain', failure)
      .should('contain', 'You must address any errors in order to import successfully.');
    cy.get('.tip-container').should('contain', message);
    if (closeDialog) {
      cy.get('.app-import__footer__close').click();
    }
  });
}

export function close() {
  cy.get('.ngx-dialog-footer').find('.app-import__footer__close').click();
}

function headerClose() {
  cy.get('ngx-button').contains('Close').click();
}

function openIssueResolution(itemName: string) {
  cy.get('.content-action-results-container').within(() => {
    cy.get('ngx-card-title')
      .contains(new RegExp(`^\\s*${escapeForRegex(itemName)}\\s*$`))
      .closest('ngx-card')
      .within(() => {
        cy.get('.manage-button').click();
      });
  });
}

export function resolveIssue(itemName: string, itemType: string, edits: Record<string, any> | string, subedits = null) {
  cy.intercept('GET', '/api/asset/**').as('getAsset');
  cy.intercept('GET', '/api/task/**').as('getTask');
  cy.intercept('POST', '/api/task/packages/upgrade/**').as('postUpgrade');
  cy.intercept('POST', '/api/task/packages/upload/**').as('postUpload');

  if (itemType === 'Asset') {
    openIssueResolution(itemName);
    cy.wait('@getAsset').its('response.statusCode').should('eq', 200);
    cy.get('.edit-asset-drawer').within(() => {
      cy.wait(500);
      assetEditor.editAsset(edits as Record<string, any>);
      assetEditor.saveAsset(false);
      cy.get('.edit-asset-footer__close').click();
    });
    cy.get('.edit-asset-drawer').should('not.exist');
    verifyPopup3('Asset Saved');
  }
  if (itemType === 'Task') {
    openIssueResolution(itemName);
    cy.wait('@getTask').its('response.statusCode').should('eq', 200);
    cy.wait(500);
    taskEditor.createNewKeyStore(edits as Record<string, any>);
    taskEditor.saveTask(false);
    verifyPopup('Task saved');
    cy.get('.back-btn').click();
    cy.get('.edit-task-drawer').should('not.exist');
  }
  if (itemType === 'Plugin' && edits === 'upgrade') {
    cy.get('.content-action-results-container').within(() => {
      cy.get('.plugin-upload-status--title')
        .contains(itemName)
        .closest('int-plugin-upload-status')
        .within(() => {
          cy.get('ngx-button')
            .contains(/^\s*Upgrade Now\s*$/)
            .click();
        });
    });
    if (subedits !== null) {
      cy.get('ngx-drawer').within(() => {
        cy.get('button')
          .contains(/^\s*Continue Upgrade\s*$/)
          .click();
      });
      verifyDoubleCheck('You are about to upgrade a plugin. This will create breaking issues.');
      cy.wait('@postUpgrade').its('response.statusCode').should('eq', 200);

      Object.keys(subedits).forEach(update => {
        cy.get('.issue-card--header--title-group--name')
          .contains(new RegExp(`^\\s*${escapeForRegex(update)}\\s*$`))
          .closest('ngx-section-header')
          .within(() => {
            cy.get('button').contains('Resolve 1 Issue').click();
            cy.wait('@getTask').its('response.statusCode').should('eq', 200);
          });
        editTaskConfiguration(subedits[update]);
        saveCurrentTask();
        cy.get('.issue-card--header--title-group--name')
          .contains(new RegExp(`^\\s*${escapeForRegex(update)}\\s*$`))
          .closest('ngx-section-header')
          .get('.issue-card--count--issues-resolved')
          .invoke('text')
          .should('match', /^\s*Issues Resolved\s*$/);
      });

      cy.get('ngx-drawer').within(() => {
        cy.get('button')
          .contains(/^\s*Done\s*$/)
          .click();
      });
    } else {
      // The verification of the API call status call needs to  be verified.
      cy.wait('@postUpload').its('response.statusCode').should('eq', 200);
    }
  }
}

export function verifyPluginResolved(itemName: string | number | RegExp) {
  cy.get('.content-action-results-container')
    .should('exist')
    .within(() => {
      cy.get('.plugin-upload-status--title')
        .contains(itemName)
        .closest('.plugin-upload-status.plugin-upload-status--upgraded')
        .within(() => {
          cy.get('.plugin-upload-status--status-text').should('contain', 'Plugin Upgraded');
        });
    });
}

export function continueUpload() {
  cy.get('.ngx-dialog-footer').find('.app-import__footer__continue').click();
}

export function enableAllTasks(includeScheduledTasks = false, taskCount: number) {
  cy.intercept('POST', '/api/task/enable').as('enableTasks');

  cy.get('.app-import__content').within(() => {
    if (includeScheduledTasks) {
      cy.get('.ngx-toggle-text').should('contain', 'Include scheduled tasks').click();
    }
    if (taskCount === 0) {
      cy.get('.btn').should('contain', `Enable ${taskCount} Tasks`).should('be.disabled');
    } else if (taskCount > 1) {
      cy.get('.btn').should('contain', `Enable ${taskCount} Task`).click();
    } else {
      cy.get('.btn').should('contain', `Enable ${taskCount} Task`).click();
    }
  });
  if (taskCount > 0) {
    verifyPopup3('Tasks Enabled');
    cy.wait('@enableTasks').its('response.statusCode').should('eq', 200);
  }
}

export function verifyTasksEnabled(items = []) {
  cy.get('.content-action-results-container').within(() => {
    items.forEach(option => {
      cy.get('.ngx-card--status.success').should('exist');
    });
  });
}

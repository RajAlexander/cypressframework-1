export function editAsset(assetDetails: Record<string, any>) {
  cy.get('int-asset-form').within(() => {
    // Name
    if (assetDetails.hasOwnProperty('Name')) {
      cy.getByLabel('Asset Name').ngxFill(assetDetails.Name);
    }

    // Asset properties
    for (const key of Object.keys(assetDetails.parameters)) {
      cy.get('.node').contains(key.toLowerCase()).closest('.node').as('node').click();

      cy.get('@node').within(() => {
        cy.get('ngx-input').ngxFill(assetDetails.parameters[key]);
      });
    }
  });
}

export function saveAsset(isNew = true) {
  if (isNew) {
    cy.intercept('POST', '/api/asset').as('apiAssetCall');
  } else {
    cy.intercept('PUT', '/api/asset/**').as('apiAssetCall');
  }

  cy.get('button span')
    .contains(/^\s*Save\s*$/)
    .click();
  cy.wait('@apiAssetCall').its('response.statusCode').should('eq', 200);
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(250);
}

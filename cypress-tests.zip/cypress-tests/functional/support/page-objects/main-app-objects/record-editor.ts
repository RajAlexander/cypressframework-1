// tslint:disable: tsr-detect-non-literal-regexp

import faker from 'faker/locale/en';
import { verifyPopup, verifyModalDirtyDialog } from './common-pieces/popupMessages';
import {
  interactWithDropdownChooser,
  escapeForRegex,
  interactWithSearchDropdownChooser
} from './common-pieces/common-calls';
import { typeInField } from './common-pieces/interactions';

const recordEditor = '[data-cy=record-editor__form]';

const getIframeDocument = (selector: any) => {
  return cy.get(selector).find('iframe').its('0.contentDocument').should('exist');
};

const getEditor = (selector: string) => {
  return getIframeDocument(selector).its('body').should('not.be.undefined').then(cy.wrap);
};

const aliasControlByLabel = (label: string | number | RegExp) => {
  cy.get('label').contains(label).closest('.field-container').as('control-container');
};

export function verifyHelpText(helpTextJSON: Record<string, any>, aboveBellow: string) {
  cy.get(recordEditor)
    .find('div.form-group.field-container')
    .each($el => {
      cy.wrap($el)
        .children()
        .then(childrenList => {
          if (childrenList.length === 1) {
            // This is a reference field
            cy.log('I GOT A REF FIELD!!!');
          } else {
            cy.wrap($el)
              .find('label > span.field-name > span')
              .then($field => {
                if (helpTextJSON.hasOwnProperty($field.text())) {
                  cy.wrap($el).find(`p.help-block-${aboveBellow}`).should('have.text', helpTextJSON[$field.text()]);
                }
              });
          }
        });
    });
}

function inputTextValue(textValue: string) {
  cy.get('@currentField')
    .find('input')
    .then($inputEle => {
      typeInField($inputEle, textValue);
    });
}

// Has not been updated yet.
export function enterRandomData(textData = null, numData = null) {
  cy.get(recordEditor)
    .find('div.form-group.field-container')
    .each($el => {
      cy.wrap($el)
        .children()
        .then(childrenList => {
          if (childrenList.length === 1) {
            // This is a reference field
            cy.log('I GOT A REF FIELD!!!');
          } else {
            cy.wrap($el)
              .find('div[ng-switch="field.fieldType"] > div')
              .as('currentField')
              .then($fieldType => {
                switch ($fieldType.attr('ng-switch-when')) {
                  case 'text':
                    cy.log('Found a text field');
                    cy.get('@currentField')
                      .find('div div')
                      .then($ngIf => {
                        let ngIf = $ngIf.attr('ng-if');
                        if (ngIf) {
                          ngIf = ngIf.split(' ').reverse()[0].replace(/\'/g, '');
                        } else {
                          ngIf = 'list';
                        }
                        let textValue = '';
                        switch (ngIf) {
                          case 'text':
                            textData ? (textValue = textData) : (textValue = faker.random.word());
                            inputTextValue(textValue);
                            break;
                          case 'telephone':
                            textValue = faker.phone.phoneNumber();
                            inputTextValue(textValue);
                            break;
                          case 'email':
                            textValue = faker.internet.email();
                            inputTextValue(textValue);
                            break;
                          case 'ip':
                            textValue = faker.internet.ip();
                            inputTextValue(textValue);
                            break;
                          case 'multiline':
                            textValue = faker.random.words(5);
                            cy.get('@currentField')
                              .find('textarea')
                              .then($inputEle => {
                                typeInField($inputEle, textValue);
                              });
                            break;
                          case 'rich':
                            textValue = faker.random.words(10);
                            inputTextValue(textValue);
                            break;
                        }
                      });
                    break;
                  case 'list':
                    cy.get('@currentField')
                      .find('div.list-field-entry input')
                      .then($inputEle => {
                        typeInField($inputEle, `${faker.random.word()}{enter}`);
                      });
                    break;
                  case 'numeric':
                    cy.get('@currentField')
                      .find('input')
                      .then($inputEle => {
                        numData ? typeInField($inputEle, numData) : typeInField($inputEle, faker.random.number());
                      });
                    break;
                  case 'date':
                    cy.get('@currentField')
                      .find('input')
                      .then($inputEle => {
                        typeInField($inputEle, faker.date.past().toLocaleDateString());
                      });
                    break;
                  case 'userGroup':
                    // DO NOT RANDOM GENERATE, because we do not know possible values.
                    //
                    // interactWithSearchDropdownChooser('@currentField', 'admin', ['@getGroups', '@getUsers']);
                    break;
                  case 'valuesList':
                    // DO NOT RANDOM GENERATE, because we do not know possible values.
                    // interactWithDropdownChooser('@currentField', 'One');
                    break;
                  case 'comments':
                    // interactWithCommentEditor('@currentField', message);
                    // cy.get('@currentField').within(() => {
                    interactWithCommentEditor(faker.random.words(10));
                    // cy.wait(500);
                    cy.get('@currentField')
                      .find('button')
                      .contains(/^\s*Save\s*$/)
                      .should('be.disabled');

                    break;
                  default:
                    cy.log(`@@@@@@@@@@@@@@@${$fieldType}@@@@@@@@@@@@@@@@`);
                    break;
                }
              });
          }
          cy.log(`%%%%%%%%%%%%%%%${childrenList.length}%%%%%%%%%%%%%%%%`);
        });
    });
}

export function save(message = 'Record saved', expectRefUpdate = false, recordClosed = false, isWidget = false) {
  cy.intercept('PUT', '/api/app/**/record/**').as('putRecord');
  cy.intercept('GET', '/api/app/**/record/**').as('getRecord');
  cy.intercept('GET', '/api/workflow/**').as('getWorkflow');
  cy.intercept('POST', '/api/app/**/record').as('postRecord');

  cy.get(recordEditor)
    .closest('.RecordController,ui-view')
    .find('span')
    .contains(/^\s*Save\s*$/)
    .click();

  if (message === 'Record saved') {
    cy.wait('@postRecord').its('response.statusCode').should('eq', 200);
    if (recordClosed === false) {
      cy.wait(['@getRecord', '@getWorkflow']);
    }
  } else if (message === 'The record has validation error(s)!') {
    // There is no API calls going out, so nothing to wait on.
  } else {
    cy.wait('@putRecord').its('response.statusCode').should('eq', 200);
  }

  verifyPopup(message);

  if (expectRefUpdate === true) {
    waitForRefUpdate();
  }
  if (isWidget === false) {
    if (message === 'Record saved') {
      cy.get('ui-view').find('h4').its('0.innerText').should('not.equal', 'New Record');
    }
  }
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(1000);
}

export function saveAndClose(
  message = 'Record Updated',
  expectRefUpdate = false,
  recordClosed = false,
  isWidget = false
) {
  cy.get(recordEditor).closest('.RecordController,ui-view').find('button.save-button.btn.dropdown-toggle').click();
  cy.get('div.save-and-close.dropdown-menu.pull-right').contains('Save & Close').click();

  if (message === 'Record Updated') {
    cy.wait('@postRecord');
    if (recordClosed === false) {
      cy.wait(['@getRecord', '@getWorkflow']);
    }
  } else if (message === 'The record has validation error(s)!') {
    // noop
  }
  verifyPopup(message);

  if (expectRefUpdate === true) {
    waitForRefUpdate();
  }
  if (isWidget === false) {
    if (message === 'Record saved') {
      cy.get('ui-view').find('h4').its('0.innerText').should('not.equal', 'New Record');
    }
  }
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(250);
}

export function closePreview() {
  cy.get('.preview-container .preview-modal--close-button').click();
}

export function deleteRecord() {
  cy.get('button[type=button]').contains('Delete').click();
  cy.get('.modal-footer > .btn-primary').click();
}

export function getRecordTrackingID(isNew = false) {
  return cy
    .get(isNew ? 'ui-view.animated' : 'ui-view[name=record]')
    .should('be.visible')
    .find('h4')
    .its('0.innerText');
}

export function getRecordValues(onlyCheckList = null) {
  const recordValues = {};

  return cy
    .get(recordEditor)
    .within(() => {
      cy.get('div.form-group.field-container').each($el => {
        return cy
          .wrap($el)
          .children()
          .then(childrenList => {
            if (childrenList.length === 1) {
              // This is a reference field
              return (
                cy
                  .wrap($el)
                  .find('div.panel-heading span:first-child')
                  .invoke('text')
                  // @ts-ignore
                  .then(($fieldName: string) => {
                    return cy
                      .wrap($el)
                      .find('div.panel-body')
                      .its('0.innerText')
                      .then($refField => {
                        recordValues[$fieldName] = $refField;
                      });
                  })
              );
            } else {
              return (
                cy
                  .wrap($el)
                  .find('label > span.field-name > span')
                  .invoke('text')
                  // @ts-ignore
                  .then(($fieldName: string) => {
                    // cy.log($fieldName);
                    // cy.log($el);
                    if (onlyCheckList === null || onlyCheckList.includes($fieldName)) {
                      return (
                        cy
                          .wrap($el)
                          .find('div[ng-switch="field.fieldType"] > div')
                          .as('currentField')
                          .invoke('attr', 'ng-switch-when')
                          // @ts-ignore
                          .then(($fieldType: string) => {
                            switch ($fieldType) {
                              case 'numeric':
                                cy.log('Found a numeric field');
                                return cy
                                  .get('@currentField')
                                  .find('input')
                                  .then($inputField => {
                                    recordValues[$fieldName] = $inputField.val();
                                  });
                                break;
                              case 'text':
                                cy.log('Found a text field');
                                return cy
                                  .get('@currentField')
                                  .find('div[ng-if~="field.inputType"]')
                                  .invoke('attr', 'ng-if')
                                  .then(($ngIf: any) => {
                                    cy.log($ngIf);
                                    if ($ngIf) {
                                      $ngIf = $ngIf.split(' ').reverse()[0].replace(/\'/g, '');
                                    } else {
                                      $ngIf = 'list';
                                    }
                                    switch ($ngIf) {
                                      case 'text':
                                      case 'telephone':
                                      case 'email':
                                      case 'ip':
                                        return cy
                                          .get('@currentField')
                                          .find('input')
                                          .then($inputField => {
                                            recordValues[$fieldName] = $inputField.val();
                                          });
                                        break;
                                      case 'multiline':
                                        return cy
                                          .get('@currentField')
                                          .find('textarea')
                                          .then($inputField => {
                                            recordValues[$fieldName] = $inputField.val();
                                          });
                                        break;
                                      case 'rich':
                                        return cy
                                          .get('@currentField')
                                          .find('div.ql-editor')
                                          .its('0.innerText')
                                          .then($inputField => {
                                            recordValues[$fieldName] = $inputField;
                                          });
                                        break;
                                      case 'json':
                                        return cy
                                          .get('@currentField')
                                          .find('div.json-tree-wrapper')
                                          .its('0.innerText')
                                          .then($inputField => {
                                            recordValues[$fieldName] = $inputField;
                                          });
                                        break;
                                      default:
                                        cy.log(`!!!!!${$ngIf}!!!!!`);
                                        break;
                                    }
                                  });
                                break;
                              case 'list':
                                cy.log('Found a list field');
                                return cy
                                  .get('@currentField')
                                  .find('ul')
                                  .its('0.innerText')
                                  .then($inputField => {
                                    recordValues[$fieldName] = $inputField;
                                  });
                                break;
                              case 'comments':
                                return cy.get('@currentField').within(() => {
                                  recordValues[$fieldName] = [];
                                  cy.get('comment').each($comment => {
                                    cy.wrap($comment)
                                      .get('.comment--body--rich')
                                      .invoke('text')
                                      .then($value => recordValues[$fieldName].push(String($value)));
                                  });
                                });
                                break;
                              default:
                                cy.log(`@@@@@${$fieldType}@@@@`);
                                break;
                            }
                          })
                      );
                    } else {
                      return cy.wrap($el);
                    }
                  })
              );
            }
          });
      });
    })
    .then(() => recordValues);
}

export function setFieldValue(fieldValuesJSON: Record<string, any>) {
  cy.intercept('POST', '/api/app/**/record/**/unique/**').as('uniqueCheck');
  for (const key of Object.keys(fieldValuesJSON)) {
    cy.get(recordEditor)
      .find('span')
      .contains(new RegExp(`^\\s*${key}\\s*$`))
      .closest('div.field-container')
      .find('div[ng-switch="field.fieldType"] > div,div.reference-field')
      .as('currentField')
      .then($fieldType => {
        switch ($fieldType.attr('ng-switch-when')) {
          case 'numeric':
          case 'date':
          case 'text':
            cy.log('Found a text field');
            cy.get('@currentField')
              .find('input')
              .then($fieldInput => {
                cy.log(fieldValuesJSON[key]['value']);
                typeInField($fieldInput, fieldValuesJSON[key]['value'].toString());
              });
            break;
          case 'valuesList':
            // This works for single select, needs to handle multi-select as well as removing specific item(s)
            cy.get('@currentField')
              .find('div.ui-select-container')
              .then($fieldInput => {
                if (fieldValuesJSON[key]['value'] !== '') {
                  interactWithDropdownChooser($fieldInput, fieldValuesJSON[key]['value']);
                } else {
                  cy.wrap($fieldInput).find('abbr.select2-search-choice-close').click();
                }
              });
            break;
          case 'userGroup':
            cy.intercept('GET', '/api/groups/**').as('getGroups');
            cy.intercept('GET', '/api/user/**').as('getUsers');
            cy.get('@currentField')
              .find('div.ui-select-container')
              .then($fieldInput => {
                if (fieldValuesJSON[key]['value'] !== '') {
                  interactWithSearchDropdownChooser($fieldInput, fieldValuesJSON[key]['value'], [
                    '@getGroups',
                    '@getUsers'
                  ]);
                } else {
                  cy.wrap($fieldInput).find('abbr.select2-search-choice-close').click();
                }
              });
            break;
          default:
            // This field element does not have a ng-switch when.
            // So far this could be a ref field. Maybe others?
            cy.get('@currentField').then($classType => {
              if ($classType.hasClass('reference-field')) {
                cy.log('Found a ref field!!');

                cy.intercept('POST', '/api/search/keyword**').as('searchRecords');
                // Need to handle the different ref field types.
                cy.get('@currentField').find('a[tooltip="Lookup"]').click();
                fieldValuesJSON[key].forEach($trackingID => {
                  cy.get('div.modal-dialog')
                    .find('ngx-input input')
                    .then($fieldInput => {
                      typeInField($fieldInput, $trackingID, true, true);
                      cy.wait('@searchRecords').its('response.statusCode').should('eq', 200);
                      cy.get('div.search-results span')
                        .contains(new RegExp(`^\\s*${$trackingID}\\s*$`))
                        .siblings('div.record-selector')
                        .click();
                      cy.get('div.modal-dialog')
                        .find('ngx-button')
                        .contains(/^\s*Add Record\s*/)
                        .click();
                      cy.get('div.modal-dialog').should('not.exist');
                    });
                });
              } else {
                cy.log($classType.attr('class'));
              }
            });
        }
        if (fieldValuesJSON[key].workflowTrigger) {
          verifyPopup('Record updated');
        }
        if (fieldValuesJSON[key].isUnique) {
          // Note: The unique check may actually trigger multiple times.
          cy.wait('@uniqueCheck').its('response.statusCode').should('eq', 200);
        }
      });
  }
}

export function verifyFieldValues(fieldValuesJSON: Record<string, any>, verifyAllFields = true) {
  expect(fieldValuesJSON).to.not.deep.equal({});
  cy.get(recordEditor)
    .find('div.form-group.field-container')
    .should('be.visible')
    .as('fieldsList')
    .then($fieldList => {
      if (verifyAllFields === true) {
        expect($fieldList.length).to.equal(Object.keys(fieldValuesJSON).length);
      }
    });

  cy.get('@fieldsList').each($el => {
    cy.wrap($el)
      .find('span.field-name > span, div.panel-heading > span')
      .then($field => {
        const fieldName = $field.text();
        cy.log(`!${fieldName}!`);
        if (verifyAllFields || fieldValuesJSON.hasOwnProperty(fieldName)) {
          cy.wrap($el)
            .find(
              'div.reference-field, input:not(.ui-select-search), div[ng-if="isReadOnly()"], div[ng-if="isReadOnly() && field.inputType !== \'json\'"], div.comments-field, ul.select2-choices, ngx-json-tree'
            )
            .then($inputField => {
              if ($inputField[0].localName === 'input') {
                expect(
                  ($inputField.val() as string).replace(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z/g, '<DATE>')
                ).to.equal(fieldValuesJSON[fieldName]);
              } else {
                cy.wrap($inputField).then($class => {
                  if ($class && $class.hasClass('reference-field')) {
                    cy.wrap($inputField)
                      .find('dt-body div[data-title="Tracking Id"]')
                      .each($trackingID => {
                        expect(fieldValuesJSON[fieldName.trim()]).to.contain($trackingID[0].innerText);
                      });
                  } else if ($class && $class.hasClass('comments-field')) {
                    cy.get('comment').each($comment => {
                      cy.wrap($comment)
                        .get('.comment--body--rich')
                        .invoke('text')
                        .then($value => expect(fieldValuesJSON[fieldName.trim()]).to.contain($value));
                    });
                  } else if ($inputField[0].localName === 'ul') {
                    expect($inputField.text().trim()).to.equal(fieldValuesJSON[fieldName]);
                  } else if ($inputField[0].localName === 'ngx-json-tree') {
                    expect($inputField.find('span[hidden]:first').text().replace(/\n| /g, '')).to.equal(
                      fieldValuesJSON[fieldName]
                    );
                  } else {
                    cy.wrap($inputField).contains(
                      new RegExp(`^\\s*${escapeForRegex(fieldValuesJSON[fieldName])}\\s*$`)
                    );
                    cy.wrap($inputField).then($theElement => {
                      expect($theElement[0].innerText).to.match(
                        new RegExp(`^\\s*${escapeForRegex(fieldValuesJSON[fieldName])}\\s*$`)
                      );
                    });
                  }
                });
              }
            });
        }
      });
  });
}

export function shareRecordWithUser(displayName: string, comments = null) {
  cy.intercept('GET', '/api/user/search?query=**').as('getUserSearch');
  cy.intercept('POST', '/api/sharing').as('shareInfo');

  cy.get('@recordEditorPage')
    .find('div.page-toolbar li.dropdown')
    .click()
    .within(() => {
      cy.get('span')
        .contains(/^\s*Share\s*$/)
        .click();
    });
  cy.wait('@getUserSearch').its('response.statusCode').should('eq', 200);

  cy.get('div.modal-dialog').within(() => {
    cy.get('h4.modal-title').should('have.text', 'Share Record');

    cy.get('div.modal-body').within(() => {
      cy.get('input.ui-select-search input').then($inputEle => {
        typeInField($inputEle, displayName);
      });
      cy.get('li.select2-highlighted').click();
      if (comments !== null) {
        cy.get('textarea[@id=comment] input').then($inputEle => {
          typeInField($inputEle, comments);
        });
      }
    });

    cy.get('div.modal-footer button')
      .contains(/^\s*Send\s*$/)
      .click();
  });

  cy.wait('@shareInfo').its('response.statusCode').should('eq', 200);
}

export function clickIntegrationButton(
  buttonText,
  integrationName,
  taskPasses = true,
  doTask = false,
  checkNotifications = true,
  failedMessage = false,
  triggerIntegrationOnly = false
) {
  cy.wait(1000);

  cy.intercept('POST', doTask ? '/api/orchestrationTask/**' : '/api/task/execute/record').as('postExecTask');
  cy.get('ui-view')
    .find('button')
    .contains(new RegExp(`^\\s*${buttonText}\\s*$`))
    .click();
  if (triggerIntegrationOnly) {
    cy.get('.modal-content button').contains('Ok').click();
  }
  cy.wait('@postExecTask')
    .its('response.statusCode')
    /* TODO: Need to add testing support for signalr notification(s) after SPT-9956 addresses issues
       500 return is currently the expected result until this is fixed */
    .should('eq', doTask ? (taskPasses ? 200 : 500) : 200);
  if (checkNotifications) {
    if (taskPasses === true) {
      verifyPopup(`Integration "${integrationName}" ${failedMessage ? 'failed' : 'finished'}.`);
    } else {
      verifyPopup(`Integration task not found.`);
    }
  }
}

export function verifyRequiredFields(fieldNames) {
  if (!Array.isArray(fieldNames)) {
    fieldNames = [fieldNames];
  }
  cy.get(recordEditor).within(() => {
    fieldNames.forEach($fieldName => {
      cy.get('span[ng-bind="::field.name"]')
        .contains(new RegExp(`^\\s*${$fieldName}\\s*$`))
        .closest('label')
        .find('span[ng-if="field.required"]')
        .contains(/^\s*Required\s*$/);
    });
  });
}

export function verifyReadOnlyFields(fieldNames) {
  if (!Array.isArray(fieldNames)) {
    fieldNames = [fieldNames];
  }
  cy.get(recordEditor).within(() => {
    fieldNames.forEach($fieldName => {
      cy.get('span[ng-bind="::field.name"]')
        .contains(new RegExp(`^\\s*${$fieldName}\\s*$`))
        .closest('div.form-group')
        .within(() => {
          cy.get('div[ng-switch="field.fieldType"] > div').then($field => {
            switch ($field.attr('ng-switch-when')) {
              case 'Text':
              case 'Numeric':
              case 'Selection':
              case 'User/Groups':
                cy.get('div[ng-if^="isReadOnly()"]').should('exist');
                break;
              case 'Date & Time':
                cy.get('div[ng-switch^="isReadOnly()"]').should('exist');
                break;
              case 'Attachment':
                cy.get('table.attachment-table thead').as('tableHead');
                cy.get('@tableHead').find('div[ng-if^="!isReadOnly()"]').should('not.exist');
                break;
            }
          });
        });
    });
  });
}

export function verifyPrefixFields(fieldPrefixData: Record<string, any>) {
  cy.get(recordEditor).within(() => {
    Object.keys(fieldPrefixData).forEach($fieldName => {
      cy.get('span[ng-bind="::field.name"]')
        .contains(new RegExp(`^\\s*${$fieldName}\\s*$`))
        .closest('div.form-group')
        .find('span[ng-if="field.prefix"]')
        .contains(new RegExp(`^\\s*${fieldPrefixData[$fieldName]}\\s*$`));
    });
  });
}

export function verifySuffixFields(fieldSuffixData: Record<string, any>) {
  cy.get(recordEditor).within(() => {
    Object.keys(fieldSuffixData).forEach($fieldName => {
      cy.get('span[ng-bind="::field.name"]')
        .contains(new RegExp(`^\\s*${$fieldName}\\s*$`))
        .closest('div.form-group')
        .find('span[ng-if="field.suffix"]')
        .contains(new RegExp(`^\\s*${fieldSuffixData[$fieldName]}\\s*$`));
    });
  });
}

export function verifyPlaceholderFields(fieldPresetData) {
  cy.get(recordEditor).within(() => {
    Object.keys(fieldPresetData).forEach($fieldName => {
      cy.get('span[ng-bind="::field.name"]')
        .contains(new RegExp(`^\\s*${$fieldName}\\s*$`))
        .closest('div.form-group')
        .find('input')
        .then($input => {
          expect($input.attr('placeholder')).to.match(new RegExp(`^\\s*${fieldPresetData[$fieldName]}\\s*$`));
        });
    });
  });
}

export function verifyValueVerification(fieldErrorData: Record<string, any>) {
  cy.get(recordEditor).within(() => {
    Object.keys(fieldErrorData).forEach($fieldName => {
      cy.get('span[ng-bind="::field.name"]')
        .contains(new RegExp(`^\\s*${$fieldName}\\s*$`))
        .closest('div.form-group')
        .within(() => {
          if (fieldErrorData[$fieldName] !== '') {
            cy.get('div.error-messages')
              .should('be.visible')
              .contains(new RegExp(`^\\s*${fieldErrorData[$fieldName]}\\s*$`));
          } else {
            cy.get('div.error-messages').should($el => {
              try {
                expect($el).to.not.be.visible;
              } catch (e) {
                expect($el).to.not.exist;
              }
            });
          }
        });
    });
  });
}

export function verifySaveButton(isPresent = true) {
  cy.get('ui-view')
    .find('span')
    .contains(/^\s*Save\s*$/)
    .should(`${isPresent ? '' : 'not.'}be.visible`);
}

export function verifyFieldIsCalculated(fieldNames: string[]) {
  if (!Array.isArray(fieldNames)) {
    fieldNames = [fieldNames];
  }
  cy.get(recordEditor).within(() => {
    fieldNames.forEach($fieldName => {
      cy.get('span[ng-bind="::field.name"]')
        .contains(new RegExp(`^\\s*${$fieldName}\\s*$`))
        .closest('div.form-group')
        .find('span.ngx-formula[tooltip="Calculated Field"]')
        .should('be.visible');
    });
  });
}

export function addAttachment(fieldName: string, fileName: Cypress.FixtureData | Cypress.FixtureData[]) {
  cy.intercept('POST', '/api/attachment/**').as('postAttachment');
  cy.get(recordEditor)
    .find('span')
    .contains(new RegExp(`^\\s*${fieldName}\\s*$`))
    .closest('div.field-container')
    .within(() => {
      cy.get('div[uploader=uploader] input[type=file]').attachFile(fileName).wait(1000); // hard wait for the initial upload of the file to the webpage
      // The verification of the API  call status  call needs to  be verified.
      cy.wait('@postAttachment');
    });
}

export function deleteAttachment(fieldName: string, fileName: string | number | RegExp) {
  cy.intercept('DELETE', '/api/attachment/**').as('deleteAttachment');
  cy.get(recordEditor)
    .find('span')
    .contains(new RegExp(`^\\s*${fieldName}\\s*$`))
    .closest('div.field-container')
    .within(() => {
      cy.get('table a[tooltip=Download]')
        .contains(fileName)
        .closest('tr')
        .within(() => {
          cy.get('a[tooltip=Delete]').click();
          cy.wait('@deleteAttachment').its('response.statusCode').should('eq', 204);
        });
    });
}

export function getAttachment(fieldName: string, fileName: string | number | RegExp) {
  cy.intercept('GET', '/api/attachment/**').as('getAttachment');
  cy.get(recordEditor)
    .find('span')
    .contains(new RegExp(`^\\s*${fieldName}\\s*$`))
    .closest('div.field-container')
    .within(() => {
      cy.get('table a[tooltip=Download]')
        .contains(fileName)
        .closest('tr')
        .within(() => {
          cy.get('a[tooltip=Preview]').click();
          cy.wait('@getAttachment').its('response.statusCode').should('eq', 200);
        });
    });
  cy.get('.modal')
    .should('be.visible')
    .within(() => {
      cy.get('.file-name').contains(fileName);
    });
}

export function verifyAttachmentsList(fieldName: string, fileNameList: string[]) {
  cy.get(recordEditor)
    .find('span')
    .contains(new RegExp(`^\\s*${fieldName}\\s*$`))
    .closest('div.field-container')
    .then(fieldContainer => {
      cy.wrap(fieldContainer)
        .find('table a[tooltip=Download]')
        .then($fieldsList => {
          expect($fieldsList).to.have.lengthOf(fileNameList.length);
          cy.wrap($fieldsList).each($el => {
            expect($el.text()).to.be.oneOf(fileNameList);
          });
        });
    });
}

export function verifyRefFieldOptions(fieldName: string, optionsList: string[]) {
  cy.get(recordEditor)
    .find('span')
    .contains(new RegExp(`^\\s*${fieldName}\\s*$`))
    .closest('div.field-container')
    .then(fieldContainer => {
      cy.wrap(fieldContainer)
        .find('div.section-heading span.pull-right')
        .children('a')
        .then($buttonOptions => {
          expect($buttonOptions).to.have.lengthOf(optionsList.length);
          cy.wrap($buttonOptions).each($el => {
            expect($el.attr('toolTip')).to.be.oneOf(optionsList);
          });
        });
    });
}

export function waitForRefUpdate() {
  cy.intercept('POST', '/api/app/**/record/**/references').as('postRefs');
  cy.wait('@postRefs', { timeout: 50000 }).its('response.statusCode').should('eq', 200);
}

export function loadRecordPage() {
  cy.intercept('GET', '/api/workflow/**').as('getWorkflow');
  cy.intercept('GET', '/api/app/**/**').as('getRecord');

  cy.get('.page-toolbar .record-header-link a').click();
  cy.wait(['@getWorkflow', '@getRecord']);
}

export function clickEditCommentButton() {
  cy.get(recordEditor)
    .find('div.comment')
    .trigger('mouseover')
    .find('span.help-block.ng-star-inserted')
    .find('[tooltiptitle="Edit Comment"]')
    .click();
}

export function editExistingComment(text: any) {
  cy.intercept('PUT', '/api/app/**/record/**/comment/*').as('updateComment');
  cy.get('blockquote.edit-comment-mode').within(() => {
    cy.getRTE().focus().type(`{movetoend}${text}`);
    cy.get('button')
      .contains(/^\s*Save\s*$/)
      .click();
  });
  cy.wait('@updateComment').its('response.statusCode').should('eq', 204);
}

export function interactWithCommentEditor(text: string | number | RegExp) {
  aliasControlByLabel('Comments');
  cy.get('@control-container')
    .scrollIntoView()
    .within(() => {
      cy.getRTE().focus().type(`{movetoend}${text}`);
      cy.get('button')
        .contains(/^\s*Save\s*$/)
        .click();
    });
  cy.get('@control-container').find('div.comment').contains(text);
}

export function cancelUpdateButton() {
  const message = faker.random.words(2);
  cy.get('blockquote.edit-comment-mode').as('container');
  cy.get('@container').scrollIntoView();
  getEditor('@container').focus().clear();
  getEditor('@container').focus().type(message);
  cy.get('@container')
    .find('button')
    .contains(/^\s*Cancel\s*$/)
    .click();
  verifyModalDirtyDialog(
    'Leave Without Saving',
    "You haven't finished editing your comment yet. Are you sure you want to leave?",
    'Leave'
  );
  cy.get('blockquote.edit-comment-mode').should('not.exist');
}

export function checkSelectionFieldValue(fieldValue: string) {
  cy.wait(1000);
  cy.get('.select2-chosen').find('span').should('have.text', fieldValue);
}

export function addReferenceRecord(fieldValue: string) {
  cy.get('a[tooltip="Add New"]').click();
  cy.get('.form-input.ng-pristine.ng-valid').ngxFill(fieldValue);
  cy.get('div.stacks-content').within(() => {
    cy.contains('Save').click();
  });
}

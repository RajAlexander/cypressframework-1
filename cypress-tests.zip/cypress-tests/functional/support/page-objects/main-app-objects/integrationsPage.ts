// tslint:disable: tsr-detect-non-literal-regexp

import {
  verifyPopup,
  verifyPopup3,
  verifyDoubleCheck,
  verifyModalConfirmDialog,
  MessageType
} from './common-pieces/popupMessages';
import {
  escapeForRegex,
  interactWithDropdownChooser,
  interactWithDropdownChooser2
} from './common-pieces/common-calls';
import * as appWizard from './admin-pages/app-wizard';
import * as recordEditor from './record-editor';
import * as assetEditor from './assetEditor';
import { typeInField } from './common-pieces/interactions';

export { appWizard };

const defaultTaskOutputs = ['sw_task_status', 'sw_task_error_message', 'sw_task_error_type', 'sw_task_stack_trace'];
const mainElement = 'div.content-area';

const datePattern = /(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})Z/g;
function replaceDate(value, replaceWith) {
  return value.replace(datePattern, replaceWith);
}

export function createNewTask(firstTime = false) {
  cy.intercept('GET', '/api/task/actions').as('getActions');
  cy.intercept('GET', '/api/task/list').as('getTaskList');
  cy.intercept('GET', '/api/app').as('getAppList');
  cy.intercept('GET', '/api/applet').as('getAppletList');

  cy.get(`${mainElement}`)
    .find('div.integration-page')
    .within(() => {
      cy.get('.nav-tabs li')
        .contains(/^\s*Tasks\s*$/)
        .click();
      if (firstTime) {
        cy.wait(['@getTaskList', '@getAppList', '@getAppletList']).then(intercepts => {
          intercepts.forEach(apiCall => expect(apiCall.response.statusCode).to.equal(200));
        });
      }
      cy.get('int-tasks-list .plus-menu-container').within(() => {
        cy.get('.ngx-plus-menu--circle').click();
        cy.get('.ngx-plus-menu--icon-1').click();
      });
      cy.wait(['@getActions', '@getTaskList']).then(intercepts => {
        // See SPT-11535
        intercepts.forEach(apiCall => expect(apiCall.response.statusCode).to.equal(200));
      });
    });
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(250);
}

export function setupTask(taskType, taskName, appName = null) {
  cy.intercept('POST', '/api/task').as('postTask');
  cy.get('int-new-task-dialog').within(() => {
    cy.get('.ngx-dialog-header').contains(/^\s*Create a Task\s*$/);
    cy.get('.ngx-card')
      .contains('.ngx-card-title', taskType)
      .closest('ngx-card')
      .contains('ngx-button', /^\s*Create\s*$/)
      .click();

    cy.getByLabel('Task Name').ngxFill(taskName);

    if (appName !== null) {
      cy.getByLabel('Application or Applet').select(appName);
    }
    cy.contains('button', /^\s*Save\s*$/)
      .should('be.enabled')
      .click();

    cy.wait('@postTask').its('response.statusCode').should('eq', 200);
  });

  verifyPopup3({
    title: 'Task Created',
    subtext: 'The task has been successfully created'
  });

  cy.get('int-new-task-dialog').should('not.exist');
}

export function runTaskDebugger(
  results,
  inputs = null,
  timeout = null,
  checkVisibility = true
): Cypress.Chainable<string> {
  cy.get('.task-page')
    .find('.nav-tabs li')
    .contains(/^\s*Configuration\s*$/)
    .click();
  cy.get('div.tab-pane.active').find('.editor-tester').as('stackTabsBottom');
  cy.get('@stackTabsBottom')
    .find('a')
    .contains(/^\s*Debugger\s*$/)
    .click();
  if (inputs !== null) {
    cy.get('div.tab-pane.active')
      .find('.editor-tester a')
      .contains(/^\s*Debugger\s*$/)
      .click();
    cy.get('.debugger-section.inputs button')
      .contains(/^\s*Input Values\s*$/)
      .click();
    if (inputs.hasOwnProperty('fromRecord')) {
      cy.get('record-select').within(() => {
        cy.getByPlaceholder('Select a Record').select(inputs.fromRecord);
      });
    } else if (inputs.hasOwnProperty('newRecord')) {
      cy.get('record-select').within(() => {
        cy.getByPlaceholder('Select a Record').select('Create New Record');
      });
      recordEditor.setFieldValue(inputs.newRecord);
      recordEditor.save('Record saved', false, true);
    } else {
      cy.get('.inputs-table').within(() => {
        Object.keys(inputs).forEach(inputName => {
          cy.get('samp')
            .contains(new RegExp(`^\\s*${escapeForRegex(inputName)}\\s*$`))
            .closest('tr')
            .within(() => {
              cy.get('ngx-input').ngxFill(inputs[inputName]);
            });
        });
      });
    }
  }
  if (timeout && timeout.hasOwnProperty('bypass')) {
    setBypassTimeout();
  }
  cy.get('@stackTabsBottom').find('div.tab-content').as('debugTab');
  cy.get('[data-cy=run__task__debugger]').click();
  if (timeout == null) {
    cy.get('@debugTab').find('div.spinner-overlay', { timeout: 120000 }).should('not.exist');
    if (results != null) {
      cy.get('@debugTab')
        .find('div.content--output pre')
        .should('be.visible')
        .then($output => {
          if (typeof results === 'object') {
            const finalOutput =
              $output['raw_text'] != null || $output['raw_text'] !== ''
                ? replaceDate($output.text(), '%date%')
                : $output.text();
            expect(JSON.parse(finalOutput)).to.deep.equal(results);
          } else {
            expect($output.text()).to.equal(results);
          }
        });
    } else {
      if (checkVisibility) {
        return cy.get('@debugTab').find('div.content--output pre').should('be.visible').invoke('text');
      } else {
        return cy.get('@debugTab').find('div.content--output pre').should('exist').invoke('text');
      }
    }
  } else {
    if (timeout.hasOwnProperty('stop')) {
      cy.get('[data-cy=cancel__task__debugger]').should('contain', 'Stop Task').click();
    }
    cy.get('@debugTab').find('div.spinner-overlay', { timeout: 120000 }).should('not.exist');
    if (results != null) {
      cy.get('@debugTab')
        .find('div.content--output pre')
        .should('be.visible')
        .then($output => {
          if (typeof results === 'object') {
            expect(JSON.parse($output.text())).to.deep.equal(results);
          } else {
            expect($output.text()).to.equal(results);
          }
        });
    } else {
      return cy.get('@debugTab').find('div.content--output pre').should('be.visible').invoke('text');
    }
  }
}

export function setBypassTimeout(bypass = true) {
  cy.get('.task-page')
    .find('.nav-tabs li')
    .contains(/^\s*Configuration\s*$/)
    .click();
  cy.get('div.tab-pane.active')
    .find('.editor-tester')
    .within(() => {
      cy.get('a')
        .contains(/^\s*Debugger\s*$/)
        .click();
      cy.get('.debugger-section.inputs').within(() => {
        cy.get('button')
          .contains(/^\s*Settings\s*$/)
          .click();
        if (bypass) {
          cy.get('.bypass-section-toggle input').check({ force: true });
        } else {
          cy.get('.bypass-section-toggle input').uncheck({ force: true });
        }
      });
    });
}

export function editCurrentTask(generalJSON) {
  cy.get('.task-page')
    .find('.nav-tabs li')
    .contains(/^\s*General\s*$/)
    .click();
  cy.get('div.tab-pane.active').within(() => {
    Object.keys(generalJSON).forEach(keyName => {
      switch (keyName) {
        case 'Name':
          cy.get('label')
            .contains(`${keyName}:`)
            .next()
            .then(siblingElement => {
              if (siblingElement[0].localName === 'input') {
                cy.wrap(siblingElement).ngxFill(generalJSON[keyName]);
              } else {
                cy.log(siblingElement[0].localName);
              }
            });
          break;
        case 'Asset':
          cy.get('.ngx-select-input-box').click();

          cy.get('ngx-select-dropdown.ngx-select-dropdown')
            .find('div.asset-name')
            .contains(new RegExp(`^\\s*${escapeForRegex(generalJSON[keyName])}\\s*$`))
            .click();
          break;
      }
    });
  });
}

export function editTaskConfiguration(configurationJSON) {
  cy.get('.task-page')
    .find('.nav-tabs li')
    .contains(/^\s*Configuration\s*$/)
    .click();
  if (configurationJSON.hasOwnProperty('script')) {
    // This is an  old angular1 codemirror.
    cy.get('div.tab-pane.active')
      .find('div.CodeMirror')
      .click()
      .find('textarea')
      .type('{ctrl+a}{backspace}', { force: true }) // These { force: true } statments are required due to Cypress seeing this frame behind another.
      .type('{meta+a}{backspace}', { force: true })
      .type(configurationJSON.script, { force: true })
      .blur();
    if (configurationJSON.hasOwnProperty('inputs')) {
      cy.get('div.tab-pane.active')
        .find('.editor-tester a')
        .contains(/^\s*Inputs\s*$/)
        .click();
      cy.get('div.script-tester div.tab-pane.active')
        .find('a')
        .contains(/^\s*Add Parameter\s*$/)
        .click();
      cy.get('task-parameters')
        .find('li.list-group-item')
        .last() // The newest parameter input created is always at the end.
        .within(() => {
          cy.get('span')
            .contains(/^\s*Variable:\s*$/)
            .closest('label')
            .next('div')
            .find('input')
            .ngxFill(configurationJSON.inputs.Variable);
          cy.get('label')
            .contains(/^\s*Type:\s*$/)
            .next('div')
            .find('div.ui-select-container')
            // This is old Angular 1.
            // .select(configurationJSON.inputs.Type);
            .as('inputTypeDropdown');
          interactWithDropdownChooser('@inputTypeDropdown', configurationJSON.inputs.Type);
          const inputLabels = ['Field', 'Key', 'Trigger Name', 'Asset', 'Literal', 'Link type'];
          Object.keys(configurationJSON.inputs).forEach(label => {
            if (!configurationJSON.isAppTask) {
              if (inputLabels.includes(label)) {
                if (label === 'Literal') {
                  cy.get('label').contains(label).next('div').find('input').as('inputEl');
                  typeInField('@inputEl', configurationJSON.inputs[label]);
                } else {
                  cy.get('label').contains(label).next('div').find('.ui-select-container').as('inputTypeDropdown');
                  interactWithDropdownChooser('@inputTypeDropdown', configurationJSON.inputs[label]);
                }
              }
            } else {
              if (inputLabels.includes(label)) {
                if (label === 'Literal') {
                  cy.get('[data-cy=input-params__literal-input]');
                  cy.get('.ngx-select-input-box').should('contain', '+ Insert Parameter');
                  cy.get('[data-cy=input-params__literal-input]')
                    .last()
                    .type(configurationJSON.inputs[label], { parseSpecialCharSequences: false });
                } else {
                  cy.get('label').contains(label).next('div').find('.ui-select-container').as('inputTypeDropdown');
                  interactWithDropdownChooser('@inputTypeDropdown', configurationJSON.inputs[label]);
                }
              }
            }
          });
        });
    }
  } else {
    // These dropdown selectors are outside of the row, making it hard to find them with respect to the row. Cannot nest in here.
    Object.keys(configurationJSON).forEach(keyName => {
      cy.get('task-parameters')
        .find('span')
        .contains(new RegExp(`^\\s*${escapeForRegex(keyName)}\\s*$`))
        .closest('div.row')
        .as('configParam');
      cy.get('@configParam')
        .find('label')
        .contains(/^\s*Type:\s*$/)
        .siblings('div')
        // this is old angular 1
        // .select(configurationJSON[keyName][0]);
        .as('typeChooser');
      interactWithDropdownChooser2('@typeChooser', configurationJSON[keyName][0]);
      switch (configurationJSON[keyName][0]) {
        case 'Literal Value':
          cy.get('@configParam')
            .find('label')
            .contains(/^\s*Literal:\s*$/)
            .siblings('div')
            .as('inputField');
          if (configurationJSON[keyName].length > 1) {
            if (typeof configurationJSON[keyName][1] == 'boolean') {
              cy.get('@inputField').find('input')[configurationJSON[keyName][1] ? 'check' : 'uncheck']({
                force: true
              });
            } else {
              cy.get('@inputField').find('ngx-codemirror,input').ngxFill(configurationJSON[keyName][1]);
            }
          }
          break;
        case 'Record':
          cy.get('@configParam')
            .find('label')
            .contains(/^\s*Field:\s*$/)
            .siblings('div')
            // this is old angular 1.
            // .select(configurationJSON[keyName][1]);
            .as('inputField');
          interactWithDropdownChooser2('@inputField', configurationJSON[keyName][1]);
          break;
        default:
          // This input has not been handled yet
          expect(configurationJSON[keyName][0]).to.be.empty('This input has not been handled yet');
      }
    });
  }
}

export function editTaskOutputMapping(outputMappingJSON) {
  cy.get('body').should('have.class', 'task-page');
  cy.get('.nav-tabs li')
    .contains(/^\s*Outputs\s*$/)
    .click();
  if ('sendEmail' in outputMappingJSON) {
    cy.get('h3')
      .contains(/^\s*Send an Email\s*$/)
      .click();
    cy.get('ngx-section.task-table')
      .contains(/^\s*Send an Email\s*$/)
      .closest('ngx-section.task-table')
      .ngxOpen()
      .within(() => {
        cy.get('td.target').each($el => {
          if (outputMappingJSON.sendEmail.hasOwnProperty($el.text()) === true) {
            cy.wrap($el).siblings('td').find('ngx-select').select(outputMappingJSON.sendEmail[$el.text()].type);
            cy.wrap($el)
              .siblings('td.ng-star-inserted')
              .find('ngx-input')
              .ngxFill(outputMappingJSON.sendEmail[$el.text()].name);
          }
        });
        cy.get('ngx-tabs button')
          .contains(/^\s*Configuration\s*$/)
          .click();
        cy.get('ngx-select').select(outputMappingJSON.sendEmail.emailAsset);
      });
  }
  if ('updateRecord' in outputMappingJSON) {
    cy.get('h3')
      .contains(/^\s*Update Current Record\s*$/)
      .click();
    cy.get('.default.view')
      .find('a')
      .contains(/^\s*Skip this step to use other mapping options.\s*$/)
      .click();
    cy.get('ngx-section.task-table')
      .contains(/^\s*Update Current Record\s*$/)
      .closest('ngx-section.task-table')
      .as('updateOutput');
    cy.get('@updateOutput')
      .find('button')
      .contains(/^\s*Unmapped Parameters\s*/)
      .click();
    mapParamsToFields(outputMappingJSON.updateRecord, 'Update Current Record');
  }
  if ('createUpdateRecord' in outputMappingJSON) {
    const settings = outputMappingJSON.createUpdateRecord;
    cy.get('.tab-pane.active').as('currentTab');
    cy.get('@currentTab').find('fieldset.output-types').as('outputButtonsGroup');
    cy.get('@outputButtonsGroup')
      .find('h3')
      .contains(/^\s*Create\/Update Records\s*$/)
      .click();
    cy.get('.output-mapping-flow-screen').within(() => {
      cy.get('h1').should('be.visible').and('have.text', 'Which app would you like to use?');
      cy.get('span')
        .contains(new RegExp(`^\\s*${escapeForRegex(settings.targetAppName)}\\s*$`))
        .scrollIntoView()
        .click();
      cy.get('i.ngx-arrow-bold-circle-right').click();
    });

    if (settings.targetAppName === 'Create New Application') {
      if (settings.newAppDetailsJSON !== null) {
        // TODO: handle making adjustments.
      }
      appWizard.createApp();
      cy.get('.ngx-dialog-content')
        .find('h1')
        .should('be.visible')
        .its('0.innerText')
        .then($headingText => {
          if ($headingText === "Let's get started.") {
            cy.get('.ngx-dialog-content').find('i.ngx-arrow-bold-circle-right').click();
          }
          mapParamsToFields(settings.mappingJSON, 'Create/Update Records');
        });
    } else {
      cy.get('.map-to-existing').click();
      cy.get('.ngx-dialog-content').find('i.ngx-arrow-bold-circle-right').click();
      mapParamsToFields(outputMappingJSON.createUpdateRecord, 'Create/Update Records');
    }
  }
}

export function openTask(taskName) {
  cy.get('int-tasks-list .ngx-card-title')
    .contains(new RegExp(`^\\s*${escapeForRegex(taskName)}\\s*$`))
    .closest('ngx-card')
    .scrollIntoView()
    .find('ngx-card-title')
    .click();
}

export function verifyExistingTask(taskDetails) {
  cy.get(mainElement).within(() => {
    cy.get('div.integration-page')
      .find('.nav-tabs li')
      .contains(/^\s*Tasks\s*$/)
      .click();

    cy.get('int-tasks-list .ngx-card-title')
      .contains(new RegExp(`^\\s*${escapeForRegex(taskDetails.name)}\\s*$`))
      .its('length')
      .should('eq', 1);
  });
}

export function verifyNonExistingTask(taskDetails) {
  cy.get(mainElement).within(() => {
    cy.get('div.integration-page')
      .find('.nav-tabs li')
      .contains(/^\s*Tasks\s*$/)
      .click();

    cy.get('int-tasks-list .ngx-card-title')
      .contains(new RegExp(`^\\s*${escapeForRegex(taskDetails.name)}\\s*$`))
      .should('not.exist');
  });
}

export function verifyTaskGeneralSettings(generalSettings) {
  cy.get('.task-page')
    .find('.nav-tabs li')
    .contains(/^\s*General\s*$/)
    .click();
  cy.get('div.tab-pane.active').within(() => {
    Object.keys(generalSettings).forEach(keyName => {
      switch (keyName) {
        case 'Asset' || 'Task Parent' || 'Task Type':
          cy.get('label').contains(`${keyName}:`).next('p').should('contain', generalSettings[keyName]);
          break;
        case 'Description':
          cy.get('label')
            .contains(`${keyName}:`)
            .next('textarea')
            .its('0.value')
            .should('contain', generalSettings[keyName]);
          break;
        case 'Disabled':
          // TODO: implement me
          break;
      }
    });
  });
}

export function closeTask() {
  cy.get('img.back-btn').click();
  cy.get('.task-page').should('not.exist');
}

export function openTaskOutputs() {
  cy.get('.task-page .nav-tabs li')
    .contains(/^\s*Outputs\s*$/)
    .click();
}

export function openCreateUpdateRecords(appName, proceedOption) {
  cy.get('div.tab-pane.active')
    .find('fieldset.output-types')
    .within(() => {
      cy.get('h3')
        .contains(/^\s*Create\/Update Records\s*$/)
        .click();
    });
  cy.get('.output-mapping-flow-screen').within(() => {
    cy.get('h1').should('be.visible').and('have.text', 'Which app would you like to use?');
    cy.get('span')
      .contains(new RegExp(`^\\s*${escapeForRegex(appName)}\\s*$`))
      .scrollIntoView()
      .click();
    cy.get('i.ngx-arrow-bold-circle-right').click();
  });
  cy.get('.update-current-record-dialog').within(() => {
    cy.get('h2')
      .contains(new RegExp(`^\\s*${escapeForRegex(proceedOption)}\\s*$`))
      .closest('div.dialog-option')
      .find('ngx-icon.arrow-icon')
      .click();
    cy.get('h2').contains('The Basics').closest('div.basics.view').find('ngx-icon.arrow-icon').click();
  });
}

export function exitCreateUpdateRecords() {
  cy.get('ngx-dialog button.close').click();
}

export function mappingActionsDropdown(mappingAction, enabled = true) {
  cy.get('ngx-dropdown-toggle').contains('Mapping Actions').click();
  cy.get('ngx-dropdown-menu').within(() => {
    if (enabled) {
      cy.get('button').contains(mappingAction).click();
      // wait for the data to refresh
      cy.wait(500);
    } else {
      cy.get('button').contains(mappingAction).should('be.disabled');
    }
  });
}

export function verifyMappings(mappingJSON) {
  cy.get('table.fields-mapping-table').within(() => {
    Object.keys(mappingJSON).forEach(eachKey => {
      cy.get('samp')
        .contains(new RegExp(`^\\s*${escapeForRegex(eachKey)}\\s*$`))
        .closest('tr')
        .within(() => {
          cy.get('ngx-select[placeholder]').ngxGetValue().should('eq', mappingJSON[eachKey]);
        });
    });
  });
}

export function verifyCreateField(createFieldJSON) {
  cy.get('table.fields-mapping-table').within(() => {
    Object.keys(createFieldJSON).forEach(eachKey => {
      cy.get('samp')
        .contains(new RegExp(`^\\s*${escapeForRegex(eachKey)}\\s*$`))
        .closest('tr')
        .within(() => {
          cy.get('.ngx-toggle-input').should(createFieldJSON[eachKey] ? `be.checked` : `not.be.checked`);
        });
    });
  });
}

export function mapParamsToFields(mappingJSON, pageTitle, toggleDefaultTaskOutputs = null) {
  cy.intercept('GET', '/api/app**/**').as('getAppApplet');
  cy.get('div.unmapped-flow-dialog').within(() => {
    cy.get('h1').should('have.text', pageTitle);

    cy.log(mappingJSON);
    if ('createOutputs' in mappingJSON) {
      mappingJSON.createOutputs.forEach(outputName => {
        cy.get('div.add-outputs-mapping-panel').within(() => {
          cy.get('ngx-input[placeholder="Output Parameter"]').ngxFill(outputName + '{enter}');
        });
      });
    }
    cy.get('table.fields-mapping-table').within(() => {
      if (toggleDefaultTaskOutputs) {
        defaultTaskOutputs.forEach(output => {
          cy.get('samp')
            .contains(new RegExp(`^\\s*${output}\\s*$`))
            .closest('tr')
            .find('.ngx-toggle-label')
            .click();
        });
      }

      if ('newMappings' in mappingJSON) {
        Object.keys(mappingJSON.newMappings).forEach(eachKey => {
          cy.get('samp')
            .contains(new RegExp(`^\\s*${escapeForRegex(eachKey)}\\s*$`))
            .closest('tr')
            .find('ngx-select[placeholder]')
            .select(mappingJSON.newMappings[eachKey]);
        });
      }

      if ('newTargetMappings' in mappingJSON) {
        Object.keys(mappingJSON.newTargetMappings).forEach(eachKey => {
          cy.get('samp')
            .contains(new RegExp(`^\\s*${escapeForRegex(eachKey)}\\s*$`))
            .closest('tr')
            .within(() => {
              cy.get('ngx-toggle').check();
              cy.get('ngx-select[placeholder]').select(mappingJSON.newTargetMappings[eachKey]);
            });
        });
      }
    });

    cy.get('button')
      .contains(/^\s*Add Mappings to App\s*$/)
      .click();
  });

  cy.get('div.approve-mapping-dialog')
    .find('button')
    .contains(/^\s*Approve\s*$/)
    .should('be.visible')
    .click();
  cy.wait('@getAppApplet');
  cy.get('div.approve-mapping-dialog').should('not.exist');
}

export function addTriggerToTask() {
  cy.get('.task-page').within(() => {
    cy.get('.nav-tabs li a')
      .contains(/^\s*Triggers\s*$/)
      .click();
    cy.get('div.tab-pane.active div.tab-pane.active').within(() => {
      cy.get('button')
        .contains(/^\s*Add a trigger\s*$/)
        .click();
      cy.get('label')
        .contains(/^\s*Type:\s*$/)
        .siblings('div')
        // This is old angular 1, not even a select object.
        // .select('Scheduled');
        .as('triggerTypeSelector');
      interactWithDropdownChooser('@triggerTypeSelector', 'Scheduled');

      cy.get('ngx-button')
        .contains(/^\s*Minutely.*\s*$/)
        .click();
    });
    cy.get('small:contains("Custom accepts Cron expression")')
      .children()
      .should('have.attr', 'href', 'https://en.wikipedia.org/wiki/Cron');
  });
}

export function saveCurrentTask(close = true, fromTasksLists = true) {
  cy.intercept('PUT', '/api/task/**').as('putTask');
  cy.intercept('GET', '/api/task/list').as('getTaskList');

  cy.get('.task-page').within(() => {
    cy.contains('button', /^\s*Save\s*$/)
      .should('be.enabled')
      .click({ force: true });
    cy.wait('@putTask').its('response.statusCode').should('eq', 200);
  });
  // This is still an old pop message.
  verifyPopup('Task saved');
  if (close) {
    closeTask();
  }
  if (fromTasksLists) {
    cy.wait('@getTaskList').its('response.statusCode').should('eq', 200);
  }

  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(3000);
}

export function createNewAsset(assetType, detailsJSON) {
  cy.intercept('GET', '/api/asset/list').as('assetListCall');

  cy.get(mainElement)
    .find('div.integration-page')
    .within(() => {
      cy.get('.nav-tabs li')
        .contains(/^\s*Assets\s*$/)
        .click();
      cy.wait('@assetListCall').its('response.statusCode').should('eq', 200);
      cy.get('int-assets-list .plus-menu-container ngx-icon').click();
    });

  cy.get('int-new-asset-dialog').within(() => {
    cy.get('.create-asset-content-container')
      .find(`.ngx-card-title`)
      .contains(assetType)
      .closest('ngx-card')
      .find('ngx-button')
      .click();

    assetEditor.editAsset(detailsJSON);

    assetEditor.saveAsset();
  });

  verifyPopup3({
    title: 'Asset Created',
    subtest: 'The asset has been successfully created.'
  });
  cy.get('.ngx-dialog-header .dialog-close > .btn').click();
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(250);
}

export function checkForExistingBundle(bundleName, bundleVersion) {
  cy.makeAPICall('GET', 'task/packages').then(bodyJSON => {
    const matchingBundles = bodyJSON.filter(item => item.name && item.name === bundleName);
    if (matchingBundles.length <= 0) {
      cy.log('Bundle needs to be added');
      const fileName = `${bundleName}-${bundleVersion}-linux.python36.swimbundle`;
      cy.fixture(`bundles/${fileName}`, 'base64')
        .then(fileData => Cypress.Blob.base64StringToBlob(fileData))
        .then(blob => cy.importBundle(blob, fileName));
      // Commenting out to see if the network waits are really helpful
      // cy.waitForNetworkIdle(250);
    } else if (!matchingBundles.some(item => item.version === bundleVersion)) {
      // An improper version of the bundle is already there, remove that and install the desired version
      matchingBundles.forEach(item => {
        cy.log('Removing incorrect version of bundle');
        cy.deleteBundle({ name: item.name, version: item.version, pythonVersion: item.pythonVersion });
      });
      cy.log('Installing correct version of bundle');
      const fileName = `${bundleName}-${bundleVersion}-linux.python36.swimbundle`;
      cy.fixture(`bundles/${fileName}`, 'base64')
        .then(fileData => Cypress.Blob.base64StringToBlob(fileData))
        .then(blob => cy.importBundle(blob, fileName));
      // Commenting out to see if the network waits are really helpful
      // cy.waitForNetworkIdle(250);
    } else {
      cy.log('Bundle exists');
    }
  });
}

export function openPluginsPage() {
  cy.intercept('GET', '/api/task/packages').as('getPlugins');
  cy.get(mainElement)
    .find('div.integration-page .nav-tabs li')
    .contains(/^\s*Plugins\s*$/)
    .click();
  cy.wait('@getPlugins');
}

export function uploadPlugins(filenames: any | any[]) {
  cy.intercept('POST', '/api/task/packages/upload').as('apiPluginUpload');

  cy.get('.plus-menu-container').find('ngx-icon[fonticon="add-circle-medium"]').click();
  // Tooltip from the previous click is getting in the way.. so doing another click to work around it.
  cy.get('div.plugin-upload-dialog--container').should('exist').click();
  cy.get('div.upload-graphic-container input.ngx-file-button-input').attachFile(filenames);
  cy.get('icon-progress-spinner').should('exist');
  // Need to get right code to verify the responseCode of the api Call.
  cy.wait('@apiPluginUpload', { timeout: 120000 });
}

export function verifyPluginsUploaded(pluginDetails, popups = null) {
  if (!Array.isArray(pluginDetails)) {
    pluginDetails = [pluginDetails];
  }
  if (popups != null) {
    verifyPopup3({ title: 'Plugin Upload Error', subtext: popups });
  }
  cy.get('icon-progress-spinner path.icon-progress-spinner--icon-icon', {
    timeout: 120000
  }).should('not.exist');
  cy.get('div.plugin-upload-dialog--upload-progress').within(() => {
    cy.get('div.plugin-upload-dialog--status-text').contains(/^\s*Here Are the Plugins You Have Uploaded\s*$/);
    cy.get('div.plugin-upload-dialog--plugins-scroll-region').within(() => {
      cy.get('int-plugin-upload-status').then($pluginsList => {
        expect($pluginsList).to.have.lengthOf(pluginDetails.length);
        $pluginsList.each((i, pluginItem) => {
          cy.wrap(pluginItem).within(() => {
            if (pluginDetails[i].hasOwnProperty('name')) {
              cy.get('div.plugin-upload-status--title')
                .invoke('text')
                .should(
                  'match',
                  new RegExp(`^\\s*${escapeForRegex(pluginDetails[i].name)}\\s*${pluginDetails[i].version || ''}\\s*$`)
                );
            }
            cy.get('div.plugin-upload-status--status-text').contains(
              new RegExp(`^\\s*${escapeForRegex(pluginDetails[i].status)}\\s*$`)
            );
          });
        });
      });
    });
  });
}

export function closePluginUpload() {
  cy.intercept('GET', '/api/task/packages').as('getPackages');
  cy.get('ngx-dialog .btn-close').click();
  cy.get('ngx-dialog .btn-close').should('not.exist');
  cy.wait('@getPackages').its('response.statusCode').should('eq', 200);
}

export function closeTaskUpload() {
  cy.get('.ngx-button').contains('Close').click();
}

export function deletePlugin(pluginDetails, alsoRemoved = null) {
  cy.intercept('DELETE', '/api/task/packages/**/**/**').as('deletePlugin');

  cy.get('int-plugins-list').within(() => {
    cy.get('.ngx-card-title')
      .contains(new RegExp(`^\\s*${pluginDetails.name}\\s*$`))
      .closest('.ngx-card-header')
      .siblings('.ngx-card-section--dropdown')
      .as('cardMenu')
      .click();
    cy.get('@cardMenu')
      .find('button')
      .contains(/^\s*Delete Plugin\s*$/)
      .click();
  });
  cy.get('int-plugin-delete-dialog').within(() => {
    cy.get('ngx-card').within(() => {
      cy.get('ngx-card-title').contains(new RegExp(`^\\s*${pluginDetails.name}\\s*$`));
      cy.get('div.version span').contains(new RegExp(`^\\s*${pluginDetails.version}\\s*$`));
    });
    cy.get('div.ngx-dialog-footer button')
      .contains(/^\s*Delete Plugin\s*$/)
      .click();
  });
  if (alsoRemoved !== null) {
    verifyDoubleCheck('Delete Confirmation', 'You are about to delete a plugin. This will create breaking issues.');
  }
  cy.wait('@deletePlugin').its('response.statusCode').should('eq', 204);
  verifyPopup3(
    {
      title: 'plugin Deleted',
      subtext: 'The plugin has been successfully deleted.'
    },
    MessageType.SUCCESS
  );
  cy.get('int-plugin-delete-dialog').should('not.exist');
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(250);
}

export function findPlugin(pluginDetails) {
  cy.url().then(page => {
    if (!page.endsWith('plugins')) {
      openPluginsPage();
    }
  });

  cy.get('int-plugins-list').within(() => {
    cy.get('.ngx-card-title')
      .contains(new RegExp(`^\\s*${pluginDetails.name}\\s*$`))
      .closest('ngx-card')
      .within(() => {
        cy.get('span.secondary:first-of-type').contains(new RegExp(`^\\s*${pluginDetails.version}\\s*$`));
        cy.get('[data-cy=plugin__name]').contains(new RegExp(`^\\s*${pluginDetails.subName}\\s*$`));
        cy.get('.ngx-card-section--description').contains(new RegExp(`^\\s*${pluginDetails.description}\\s*$`));
      });
  });
}

export function deleteAsset(assetName: string) {
  cy.intercept('DELETE', '/api/asset/**').as('deleteAsset');
  cy.get(mainElement)
    .find('div.integration-page .nav-tabs li')
    .contains(/^\s*Assets\s*$/)
    .click();

  cy.get('int-assets-list .ngx-card-title')
    .contains(new RegExp(`^\\s*${escapeForRegex(assetName)}\\s*$`))
    .closest('ngx-card')
    .as('asset');
  cy.get('@asset').scrollIntoView().find('ngx-dropdown-toggle').click();
  cy.get('@asset').find('button').contains('Delete Asset').click();

  verifyDoubleCheck('Delete Confirmation', 'Are you sure you want to delete this asset?');
  cy.wait('@deleteAsset').its('response.statusCode').should('eq', 204);
  verifyPopup3('asset Deleted');
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(3000);
}

export function verifyExistingAsset(assetDetails) {
  cy.get(mainElement).within(() => {
    cy.get('div.integration-page')
      .find('.nav-tabs li')
      .contains(/^\s*Assets\s*$/)
      .click();
    cy.get('int-assets-list .ngx-card-title')
      .contains(new RegExp(`^\\s*${escapeForRegex(assetDetails.name)}\\s*$`))
      .its('length')
      .should('eq', 1);
  });
}

export function deleteTask(taskName: string) {
  cy.intercept('DELETE', '/api/task/**').as('deleteTask');
  cy.intercept('GET', '/api/task/list').as('getTask');

  cy.get(mainElement).within(() => {
    cy.get('div.integration-page')
      .find('.nav-tabs li')
      .contains(/^\s*Tasks\s*$/)
      .click();

    cy.get('int-tasks-list .ngx-card-title')
      .contains(new RegExp(`^\\s*${escapeForRegex(taskName)}\\s*$`))
      .closest('ngx-card')
      .scrollIntoView()
      .within(() => {
        cy.get('ngx-dropdown-toggle').click({ force: true });
        cy.get('button').contains('Delete Task').click({ force: true });
      });
  });

  verifyDoubleCheck('Delete Confirmation', 'Are you sure you want to delete this task?');
  cy.wait('@deleteTask').its('response.statusCode').should('eq', 204);

  // SPT-12450 Still seeing this failure randomly
  verifyPopup3({
    title: 'task Deleted',
    subtext: 'The task has been successfully deleted.'
  });
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(3000);
  cy.wait('@getTask').its('response.statusCode').should('eq', 200);
  cy.get(mainElement).within(() => {
    cy.contains('int-tasks-list .ngx-card-title', new RegExp(`^\\s*${escapeForRegex(taskName)}\\s*$`)).should(
      'not.exist'
    );
  });
}

export function addPythonPackage(packageName: string, packageVersion: string, pythonVersion: string) {
  cy.get('p.help-block', { timeout: 60000 })
    .should('be.visible', { timeout: 60000 })
    .and('have.text', 'Install global Python packages that are available to all of your Python tasks and bundles.', {
      timeout: 60000
    });

  cy.get('int-packages-list .plus-menu-container .ngx-icon').click();
  cy.get('int-package-upload-dialog').within(() => {
    cy.getByLabel('Package Name').ngxFill(packageName);
    if (packageVersion !== '') {
      cy.getByLabel('Package Version').ngxFill(packageVersion);
    }
    cy.get('ngx-button.install-button').click();
    cy.wait('@postPipPackages').its('response.statusCode').should('eq', 200);
  });
  verifyPopup3('Package was installed successfully');
}

export function checkForExistingPipPackage(packageName: string, packageVersion = '', pythonVersion = '3') {
  cy.intercept('GET', '/api/pip/packages/Python3').as('getPipPackages3');
  cy.intercept('GET', 'api/pip/packages/migration/result').as('result');
  cy.intercept('POST', '/api/pip/packages/').as('postPipPackages');

  cy.get(mainElement).find('div.integration-page').as('integrationsWorkspace');
  cy.get('@integrationsWorkspace')
    .find('.nav-tabs li')
    .contains(/^\s*Python Packages\s*$/)
    .click();

  cy.wait('@result');
  cy.wait('@getPipPackages3')
    .its('response.body')
    .then($response => {
      if (!$response.some(item => item.name && item.name === packageName)) {
        cy.log('Bundle needs to be added');
        addPythonPackage(packageName, packageVersion, pythonVersion);
      } else {
        cy.log('Bundle exists');
        deletePythonPackage(packageName);
        addPythonPackage(packageName, packageVersion, pythonVersion);
      }
    });
  cy.wait('@getPipPackages3');
}

export function setupCreateUpdateConfiguration(configJSON, targetAppName: string) {
  cy.get('ngx-section.task-table')
    .find(`ngx-section-header small.task-table-subtitle`)
    .contains(new RegExp(`^\\s*${escapeForRegex(targetAppName)}\\s*$`))
    .scrollIntoView()
    .closest('section')
    .as('updateCurrentSection')
    .within(() => {
      cy.get('button[title="Toggle Content Visibility"] .ngx-icon')
        .as('toggleSection')
        .then($toggle => {
          if ($toggle.hasClass('icon-arrow-right')) {
            cy.wrap('@toggleSection').click();
          }
        });
      cy.get('field-mapping').within(() => {
        cy.get('button')
          .contains(/^\s*Configuration\s*$/)
          .click();
        if (configJSON.hasOwnProperty('CREATION TYPE')) {
          cy.get('label')
            .contains(/^\s*Creation Type\s*$/)
            .siblings('label')
            .contains(configJSON['CREATION TYPE'])
            .find('input')
            .check();
        }
        if (configJSON.hasOwnProperty('Key Field')) {
          cy.getByLabel('Key Field').select(configJSON['Key Field']);
        }
        if (configJSON.hasOwnProperty('Source Reference Field')) {
          cy.getByLabel('Source Reference Field').select(configJSON['Source Reference Field']);
        }
      });
    });
}

export function deletePythonPackage(packageName: string) {
  cy.intercept('DELETE', `api/pip/packages/${packageName}/Python**`).as('deletePipPackage');

  cy.get('.python-packages datatable-body datatable-body-cell')
    .contains(new RegExp(`^\\s*${escapeForRegex(packageName)}\\s*$`))
    .closest('datatable-body-row')
    .find('button.uninstall-btn')
    .click();
  verifyDoubleCheck('Are you sure you want to uninstall?', `This will uninstall the package '${packageName}'.`);
  cy.wait('@deletePipPackage').its('response.statusCode').should('eq', 204);
  verifyPopup3('Package was uninstalled successfully');
  cy.wait('@getPipPackages3');
}

export function openKeyStorePage() {
  cy.get('.integration-page').within(() => {
    cy.get('.nav-tabs li').contains('Key Store').click();
  });
}

export function addNewKeyStore(key: string, val: string) {
  cy.get('.integration-page--main').within(() => {
    cy.intercept('POST', `api/credentials`).as('addKeyStore');
    cy.get('[data-cy=new-key_btn]').click();
    cy.get('table tbody tr')
      .last()
      .within(() => {
        // These are old Angular 1 inputs.
        cy.get('td').eq(0).find('input').focus().type(key);
        cy.get('td').eq(1).find('input').focus().type(val);
        cy.get('td').eq(2).find('a.ngx-check').click();
        cy.wait('@addKeyStore').its('response.statusCode').should('eq', 200);
      });
  });
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(250);
}

export function deleteKeystore(_key: string) {
  cy.intercept('DELETE', `api/credentials/**`).as('deleteKeyStore');
  cy.get('.integration-page--main').find('table tbody tr').first().find('a.ngx-trash').click();
  verifyModalConfirmDialog('Delete Confirmation', 'Are you sure you want to delete these credentials?');
  cy.wait('@deleteKeyStore').its('response.statusCode').should('eq', 200);
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(250);
}

export function uploadTask(filename: string) {
  cy.get('ngx-plus-menu.position-right')
    .should('be.visible')
    .click()
    .within(() => {
      cy.get('.ngx-plus-menu--icon-0').should('be.visible').click();
    });

  cy.get('.upload-graphic-container').within(() => {
    cy.fixture(filename, 'binary')
      .then(Cypress.Blob.binaryStringToBlob)
      .then(fileContent => {
        cy.get('input').attachFile({
          filePath: filename,
          fileName: filename,
          mimeType: 'application/json',
          encoding: 'utf-8'
        });
      });
  });
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(250);
}

export function setTaskDetails(taskName: string, appAppletName = null) {
  cy.get('.file-container').within(() => {
    cy.get('ngx-input').ngxFill(taskName);
    cy.get('ngx-select').ngxSetValue(appAppletName);
  });
}

export function clickUploadPlugin(failureMessage = null) {
  cy.intercept('POST', '/api/task/upload').as('uploadTask');

  cy.get('ngx-button').contains('Upload').click();

  if (failureMessage != null) {
    cy.wait('@uploadTask').its('response.statusCode').should('eq', 400);
    verifyPopup3({
      title: failureMessage.title,
      subtext: failureMessage.subtext
    });
  } else {
    cy.wait('@uploadTask').its('response.statusCode').should('eq', 200);
  }
}

export function discoverParameters() {
  cy.contains('Discovered Parameters').click();
  cy.get('.output-parameters-section .select-all-properties ngx-checkbox').click();
  cy.contains('Add Selected Parameters').click();
}

export function removeTask() {
  cy.get('.page-toolbar')
    .find('span.text')
    .contains(/^\s*Delete\s*$/)
    .click();

  verifyModalConfirmDialog('Delete Confirmation', 'Are you sure you want to delete this task?');
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(250);
}

export function configureExistingIntegrationTask(taskName: string) {
  cy.get('.builder-target .builder-target-item.integration').click();
  cy.get('app-properties-container').within(() => {
    cy.getByLabel('Task').select(taskName);
  });
}

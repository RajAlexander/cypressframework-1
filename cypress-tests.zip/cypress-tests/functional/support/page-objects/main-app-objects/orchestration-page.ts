export function switchToAppView(navItem: string) {
  cy.get('.app-nav').find(`.ngx-${navItem}`).click({ force: true });
}

// tslint:disable: tsr-detect-non-literal-regexp

import { verifyPopup3 } from './common-pieces/popupMessages';

const mainElement = 'div.create-dashboard';

export function setDashboardWizardTab(tabName: string) {
  cy.get(mainElement)
    .find('section.main button')
    .contains(new RegExp(`^\\s*${tabName}\\s*$`))
    .click();
}

export function setDashboardNameAndDesc(name: string, description: string) {
  setDashboardWizardTab('General');
  cy.get(mainElement)
    .find('section.main')
    .within(() => {
      cy.get('ngx-input[type=text]').ngxFill(name);
      cy.get('ngx-input[type=textarea]').ngxFill(description);
    });
}

export function createDashboard() {
  cy.intercept('POST', '/api/dashboard').as('writeDashboard');
  cy.intercept('GET', '/api/dashboard/status/workspace/**').as('getDashboardsStatus');
  cy.get(mainElement)
    .find('footer button span')
    .contains(/^\s*Create\s*$/)
    .click();
  cy.wait('@writeDashboard').its('response.statusCode').should('eq', 200);
  verifyPopup3({ subtext: 'Dashboard created' });
  cy.get(mainElement).should('not.exist');
  cy.wait('@getDashboardsStatus').its('response.statusCode').should('eq', 200);
  cy.url().should('match', /\/workspace\/.+\/.+$/);
  cy.wait(2000);
}

export function verifyDashboardAutoRefreshSetting(autoRefreshTime: string) {
  setDashboardWizardTab('Advanced');
  cy.get('.ngx-select[label="Auto Refresh"]')
    .should('exist')
    .find('.ngx-select-input-option')
    .should('have.text', autoRefreshTime);
}

import * as swimInstance from '../../page-objects/swimInstance';
import * as applist from './app-list-all';

export function openWorkFlowHistoryfromRecordPage(recordID, appName: string) {
  swimInstance.OpenAppListAll(appName);
  applist.openRecord(recordID);
  cy.get('.page-toolbar').within(() => {
    cy.get('a.dropdown-toggle').last().click();
    cy.get('span:contains("Workflow Run History")').click();
  });
  cy.get('.workflow-run-history-modal').should('be.visible');
  cy.get('span:contains("Close")').click({ force: true });
  cy.go('back');
}

export function verifyWorkflowRunHistory(recordID, appName: string) {
  swimInstance.switchToWorkspace(`${appName} Workspace`);
  swimInstance.OpenAppListAll(appName);
  swimInstance.recordListing.openRecordWorkflowResults(recordID);
  cy.get("[id*='section']").then(run => {
    let flag = false;
    const runcount = Cypress.$(run).length;
    cy.log(runcount.toString());
    for (let i = 0; i < runcount; i++) {
      cy.log(i.toString());
      cy.get('.ngx-button').contains('Show details').eq(0).click();
      cy.get('body').then(body => {
        if (body.find('span.action-title').length > 0) {
          cy.get('span:contains("View Workflow Run")').eq(i).click();
          cy.contains(appName).should('be.visible');
          flag = true;
        }
      });
      if (flag) {
        break;
      }
    }
  });
}

export function openWorkFlowHistoryfromGraphPage(recordID, appName: string) {
  verifyWorkflowRunHistory(recordID, appName);
  cy.get('.workflow-dropdown').click();
  cy.get('a:contains("Workflow Run History")').click();
  cy.get('.workflow-run-history-modal').should('be.visible');
  cy.get('span:contains("Close")').click({ force: true });
  cy.get('.workflow-run-history-modal').should('not.exist');
}

// tslint:disable: tsr-detect-non-literal-regexp

/*
  Workflow nodes only show first 25 characters, so try to limit most, unless testing actual long name cutoff.
 */

import { verifyPopup3 } from './common-pieces/popupMessages';
import { escapeForRegex } from './common-pieces/common-calls';
import { setUserGroupValue } from './common-pieces/interactions';
import * as fieldSelectDialog from './admin-pages/field-selection-dialog';

const toolbarElement = '[data-cy=workflow__toolbar]';
const workflowEditorElement = '[data-cy=workflow__editor]';
const nodeEditor = '[data-cy=workflow-node__editor]';

export function verifyElements() {
  cy.url().should('match', /\/workflow\/[a-zA-Z0-9_]{10,17}$/);

  fitWorkflowToView(); // This will recenter the workflow to the display.
  cy.get(workflowEditorElement).find('g.nodes g.node-group').should('be.visible');
}

export function verifyNoOptionsAvailable(selectorLabel: string) {
  cy.getByLabel(selectorLabel).ngxOpen();
  cy.get('.vertical-list .ngx-select-empty-placeholder').should('have.text', 'No options available');
}

export function addNode(parentNode: string, newNodeType: string) {
  fitWorkflowToView();
  cy.get(workflowEditorElement)
    .find('g.nodes g.node')
    .contains(parentNode.substring(0, 25))
    .closest('.node-group')
    .click()
    .within(() => {
      cy.get('g.node').should('have.class', 'active');
      cy.get(`i.ngx-${newNodeType}`).click();
    });
}

export function disableNode(nodeType: string, nodeName: string) {
  fitWorkflowToView();
  cy.get('.nodes')
    .find('.node-group')
    .within(() => {
      cy.get(`.${nodeType}`)
        .find('.node-label')
        .contains(new RegExp(`^\\s*${nodeName}\\s*$`))
        .closest(`.${nodeType}`)
        .click()
        .find('.disable-icon[tooltiptitle="Disable"]')
        .click();
    });
}

export function editCurrentNode(nodeJSON: Record<string, any>) {
  cy.intercept('GET', '/api/app/**').as('getRefApp');
  cy.get(workflowEditorElement).find(nodeEditor).as('nodeEditor');
  for (const key of Object.keys(nodeJSON)) {
    switch (key) {
      case 'Name':
        cy.getByLabel('Name').should('exist').ngxFill(nodeJSON[key]);
        break;
      case 'Field':
      case 'Operator':
      case 'Action Type':
        // Rendering list within selection item takes longer than Cypress expects here
        cy.wait(500);
      case 'Selection Field':
      case 'Integration':
        cy.get('@nodeEditor')
          .find('span,label,button')
          .should('be.visible')
          .contains(new RegExp(`^\\s*${escapeForRegex(key)}\\s*$`))
          .parents('.form-group')
          .as('eachInput');

        cy.get('@eachInput').within(() => {
          cy.get('.ngx-select').select(nodeJSON[key]);
        });
        break;
      case 'Task':
        // Wait for workflow-action dropdown to load
        cy.get('workflow-action-trigger-task').should('exist');
        cy.get('workflow-action-trigger-task ngx-select').should('exist');

        cy.getByLabel('Task').select(nodeJSON[key]);
        break;
      case 'Evaluation Target':
        // The previous edit selected a ref field, so we need to wait on that too populate the rest.
        cy.wait('@getRefApp').its('response.statusCode').should('eq', 200);
        cy.get('@nodeEditor')
          .find('span,label,button')
          .should('be.visible')
          .contains(new RegExp(`^\\s*${escapeForRegex(key)}\\s*$`))
          .parents('.form-group')
          .as('eachInput');

        cy.get('@eachInput')
          .find('ngx-radiobutton')
          .contains(new RegExp(`^\\s*${escapeForRegex(nodeJSON[key])}\\s*$`))
          .click();
        cy.wait('@getRefApp').its('response.statusCode').should('eq', 200);
        cy.wait(500);
        break;
      case 'Value':
      case 'Selectable Values':
        cy.get('@nodeEditor')
          .find('span,label,button')
          .should('be.visible')
          .contains(new RegExp(`^\\s*${escapeForRegex(key)}\\s*$`))
          .parents('.form-group')
          .as('eachInput');

        const valueJSON = nodeJSON[key];
        switch (valueJSON.type) {
          case 'Text':
            // TODO: Don't care much for the force, look at this again, to see if we can use a diff element to click on.
            if (nodeJSON.hasOwnProperty('Action Type')) {
              cy.get('@eachInput').within(() => {
                cy.get('ngx-codemirror').ngxFill(valueJSON.value);
              });
              break;
            }
          case 'Numeric':
            cy.get('@eachInput').within(() => {
              cy.get('ngx-input').ngxFill(valueJSON.value);
            });
            break;
          case 'Selection':
            cy.log('Doing the selection');
            cy.get('@eachInput').within(() => {
              cy.get('ngx-select').select(valueJSON.value);
            });
            break;
          case 'UserGroup':
            cy.intercept('GET', '/api/groups/lookup?**').as('getGroups');
            cy.intercept('GET', '/api/user/search?**').as('getUsers');
            cy.get('@eachInput').within(() => {
              valueJSON.value.forEach($selectValue => {
                setUserGroupValue($selectValue, 'multi', ['@getGroups', '@getUsers']);
              });
            });
            break;
          case 'Reference':
          case 'DateTime':
            break;
        }
        break;
      case 'Select Target Field':
        cy.get('@nodeEditor')
          .find('span,label,button')
          .should('be.visible')
          .contains(new RegExp(`^\\s*${escapeForRegex(key)}\\s*$`))
          .parents('.form-group')
          .as('eachInput');

        cy.get('@eachInput').click();
        fieldSelectDialog.selectFields(nodeJSON[key]);
        fieldSelectDialog.applySelection();
        break;
      default:
        expect(key).to.equal('');
    }
  }
}

export function saveWorkflow(message = 'Workflow Saved', invalidWorkflow = false) {
  cy.intercept('PUT', '/api/workflow/**').as('putWorkflow');
  cy.get(toolbarElement).find('button').contains('Save').should('be.visible').click();
  cy.wait('@putWorkflow')
    .its('response.statusCode')
    .should('eq', invalidWorkflow ? 400 : 200);
  verifyPopup3(message);
}

function getSelectedList(nodeSettings: Record<string, any>, $eachKey: string) {
  cy.get('ul.ngx-select-input-list li').then($selectedList => {
    expect($selectedList).to.have.lengthOf(1);
    cy.wrap($selectedList).contains(new RegExp(`^\\s*${escapeForRegex(nodeSettings[$eachKey])}\\s*$`));
  });
}

export function verifyWorkflowNodeSettings(nodeSettings: Record<string, any>) {
  cy.get(workflowEditorElement)
    .find(nodeEditor)
    .within(() => {
      Object.keys(nodeSettings).forEach($eachKey => {
        cy.get('span,label')
          .contains(new RegExp(`^\\s*${escapeForRegex($eachKey)}\\s*$`))
          .parents('div.form-group')
          .within(() => {
            if ($eachKey == 'Name') {
              cy.get('input')
                .its('0.value')
                .should('match', new RegExp(`^\\s*${escapeForRegex(nodeSettings[$eachKey])}\\s*$`));
            } else if (['Field', 'Operator', 'Selection Field'].includes($eachKey)) {
              getSelectedList(nodeSettings, $eachKey);
            } else if (['Selectable Values', 'Value'].includes($eachKey)) {
              cy.get('ngx-select,date-input,ngx-input').then($input => {
                if ($input.hasClass('single-selection')) {
                  getSelectedList(nodeSettings, $eachKey);
                } else if ($input.hasClass('multi-selection')) {
                  if (!Array.isArray(nodeSettings[$eachKey])) {
                    nodeSettings[$eachKey] = [nodeSettings[$eachKey]];
                  }
                  cy.get('ul.ngx-select-input-list li').then($selectedList => {
                    expect($selectedList).to.have.lengthOf(nodeSettings[$eachKey].length);
                    cy.wrap($selectedList).each($el => {
                      cy.wrap($el)
                        .its('0.innerText')
                        .then($textValue => {
                          expect($textValue).to.be.oneOf(nodeSettings[$eachKey]);
                        });
                    });
                  });
                } else {
                  expect(1).to.equal(2);
                }
              });
            }
          });
      });
    });
}

export function verifyEditTaskLink() {
  cy.get(workflowEditorElement)
    .find(nodeEditor)
    .within(() => {
      cy.get('workflow-action-integration').find('label.ngx-select-label').contains('Integration');
      cy.get('a.edit-task-link').should('exist');
    });
}

export function clickNode(nodeName: string, forceClick = false) {
  cy.get(workflowEditorElement)
    .find('g.nodes g.node')
    .contains(nodeName.substring(0, 25))
    .closest('.node-group')
    .click(50, 25, { force: forceClick });
  // Commenting out to see if the network waits are really helpful
  // cy.waitForNetworkIdle(250);
}

export function fitWorkflowToView() {
  cy.get(workflowEditorElement).find('ngx-icon[fonticon="resize"]').click();
  cy.wait(500); // wait for the svg to animate
}

export function integrationWorkflow(input: string, taskName?: string) {
  switch (input) {
    case 'create':
      cy.get('workflow-action-integration').find('ngx-select.ngx-select').click();
      cy.get('li.ngx-select-dropdown-option')
        .contains(/^\s*Create a Task\s*$/)
        .click();
      break;

    case 'edit':
      cy.get('workflow-action-integration').within(() => {
        cy.get('ngx-input.manual-time').should('be.visible');
        cy.get('ngx-input.manual-cost').should('be.visible');
      });
      verifyTaskName(taskName);
      cy.get('a.edit-task-link').click();
      break;

    case 'remove':
      cy.get('workflow-action-integration').find('label.ngx-select-label').contains('Integration');
      cy.get('a.edit-task-link').should('not.exist');
      break;
  }
}

export function verifyTaskName(taskName: string) {
  cy.get('workflow-action-integration').find('li.ngx-select-input-option').contains(taskName);
}

export function triggerHangfireTask() {
  cy.get('.cdk-virtual-scroll-content-wrapper ngx-section').last().find('button').last().click();
  cy.get('.ngx-charts').find('.node.action.integration.run-success').click();
  cy.get('div[data-cy="workflow-node__editor"]').find('span').contains('Requeue Hangfire Job').click();
}

const mainElement = '[data-cy=login]';
const loginFailedMessage =
  'You have entered invalid login credentials. Please double-check your credentials or contact support for assistance.';

export function verifyElements() {
  cy.get(mainElement).within(() => {
    cy.dataCy('welcome__message')
      .should('be.visible')
      .contains(`Welcome to ${Cypress.env('productName')}`);
  });
}

export function performLogin(username: string, password: string, loginCode = 200, message = '') {
  cy.intercept('POST', '/api/user/login').as('loginRequest');
  cy.intercept('GET', '/api/workspaces/nav').as('getNav');

  cy.get(mainElement).within(() => {
    cy.dataCy('username__input').ngxFill(username);
    cy.dataCy('password__input').ngxFill(password);
    cy.dataCy('submit__btn').should('have.text', 'Login').click();
  });

  cy.wait('@loginRequest')
    .its('response')
    .then(response => {
      expect(response.statusCode).to.equal(loginCode);
      if (loginCode === 200) {
        expect(response.body.token).to.not.be.null;
        localStorage.setItem('jwt_token', response.body.token);
        cy.get(mainElement, { timeout: 10000 }).should('not.exist');
        cy.url({ timeout: 100000 }).should('not.include', '/login');
        cy.wait('@getNav').its('response.statusCode').should('eq', 200);
      } else if (loginCode === 401 && message === 'failed') {
        cy.get('.tip-content--template').should('be.visible').contains(loginFailedMessage);
      } else if (loginCode === 401 && message === 'warning') {
        cy.get('.tip-content--template').should('be.visible').contains(loginFailedMessage);
      } else if (loginCode === 401 && message === 'lock') {
        cy.get('.tip-content--template').should('be.visible').contains(loginFailedMessage);
      } else {
        localStorage.setItem('jwt_token', null);
      }
    });
}

export function performDisabledLogin(username: string, password: string) {
  cy.get(mainElement).within(() => {
    cy.dataCy('username__input').ngxFill(username);
    cy.dataCy('password__input').ngxFill(password);
    cy.dataCy('submit__btn').should('have.attr', 'disabled');
  });
}

Cypress.Screenshot.defaults({ disableTimersAndAnimations: false });

// disable clearing localstorage
Cypress.LocalStorage.clear = (keys, ls, rs) => {
  return;
};

let failed = false;
const isInteractive = Cypress.config('isInteractive');

before(() => {
  if (!isInteractive) {
    cy.recordHar({ content: false });
  }
});
afterEach(function () {
  if (this.currentTest.state !== 'passed') {
    failed = true;
  }
});

after(function () {
  if (!isInteractive && failed) {
    cy.saveHar();
  }
});

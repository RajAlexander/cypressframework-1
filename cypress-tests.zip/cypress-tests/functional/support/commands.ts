import faker from 'faker/locale/en';
import moment from 'moment';
import 'cypress-network-idle';

declare global {
  namespace Cypress {
    interface Chainable<Subject = any> {
      apiLogin(): Chainable<string>;
      batchRecordCreateAPI(appID: string, valueList: any): Chainable<Cypress.Response<void>>;
      cleanUpBundles(bundleList?: string[]): void;
      cleanUpCypressApplets(): Chainable<Cypress.Response<void>>;
      cleanUpCypressAssets(): Chainable<Cypress.Response<void>>;
      cleanUpCypressAssets(): Chainable<Cypress.Response<void>>;
      cleanUpCypressApps(): Chainable<Cypress.Response<void>>;
      cleanUpCypressGroups(): Chainable<Cypress.Response<void>>;
      cleanUpCypressRoles(): Chainable<Cypress.Response<void>>;
      cleanUpCypressTasks(): Chainable<Cypress.Response<void>>;
      cleanUpCypressUsers(): Chainable<Cypress.Response<void>>;
      cleanUpCypressWorkspaces(): Chainable<Cypress.Response<void>>;
      cleanupCypressDashboards(): Chainable<Cypress.Response<void>>;
      cleanupIngestionRules(): Chainable<Cypress.Response<any>>;
      cleanupOrchestrationTasks(): Chainable<Cypress.Response<any>>;
      cleanupSwimlane(): void;
      cleanupTurbine(): Chainable<Cypress.Response<void>>;
      cleanupTurbineAssets(): Chainable<Cypress.Response<void>>;
      cleanupTurbinePlaybooks(): Chainable<Cypress.Response<void>>;
      cleanupTurbinePlugins(): Chainable<Cypress.Response<void>>;
      cleanupTurbineSensors(): Chainable<Cypress.Response<void>>;
      dataCy(value: string): Cypress.Chainable<JQuery<HTMLElement>>;
      deleteApp(id: string): Chainable<Cypress.Response<any>>;
      deleteApplet(id: string): Chainable<Cypress.Response<any>>;
      deleteAsset(id: string): Chainable<Cypress.Response<any>>;
      deleteBundle(options: any): Chainable<Cypress.Response<any>>;
      deleteDashboard(id: string): Chainable<Cypress.Response<any>>;
      deleteGroup(id: string): Chainable<Cypress.Response<any>>;
      deleteIngestionRule(id: string): Chainable<Cypress.Response<any>>;
      deleteOrchestrationTask(id: string): Chainable<Cypress.Response<any>>;
      deletePlaybook(id: string): Chainable<Cypress.Response<any>>;
      deletePlugin(id: string): Chainable<Cypress.Response<any>>;
      deleteAssetOld(id: string): Chainable<Cypress.Response<any>>;
      deleteRole(id: string): Chainable<Cypress.Response<any>>;
      deleteSensor(id: string): Chainable<Cypress.Response<any>>;
      deleteTask(id: string): Chainable<Cypress.Response<any>>;
      deleteUser(id: string): Chainable<Cypress.Response<any>>;
      deleteWorkspace(id: string): Chainable<Cypress.Response<any>>;
      getRTE(): Chainable<JQuery<HTMLBodyElement>>;
      importBundle(bundleData: BlobPart, fileName: string): void;
      importApp(manifest: any, modifications: any[]): void;
      importApplet(manifest: any, modifications: any[]): void;
      isFeatureOn(flag: string): Chainable<boolean>;
      logout(): Chainable<Cypress.Response<void>>;
      makeAPICall(method: string, apiCall: string, body?: object, statusCode?: number): Chainable<any>;
      makeTurbineAPICall(method: string, apiCall: string, body?: object, statusCode?: number): Chainable<any>;
      setExpandedMenu(): void;
      setFeatureFlag(flag?: string, enable?: boolean): Chainable<void>;
      setFixture(fixturePath: string, fixtureType: string): Chainable<any>;
      skipIfFeatureOn(flag: string): Chainable<Cypress.Response<void>>;
      toggleFeatureFlag(flag: string, enabled: boolean): void;
      turbinelogin(): Chainable<Cypress.Response<void>>;
      updateIngestionRule(ingestionRuleId: string, bodyPayload: any): Chainable<Cypress.Response<any>>;
      updateOrchestrationTask(ingestionRuleId: string, bodyPayload: any): Chainable<Cypress.Response<any>>;    
    }
  }
}

Cypress.Commands.add('setFixture', (fixturePath, fixtureType) => {
  return cy.fixture(fixturePath).then($objectTestDetails => {
    if (fixtureType === 'plugin') {
      $objectTestDetails.superDetails.contributed = `Contributed by Swimlane, installed on ${moment().format(
        'MMMM D, YYYY'
      )}`;
    }
    return $objectTestDetails;
  });
});

Cypress.Commands.add('cleanupSwimlane', () => {
  cy.waitForNetworkIdle(1000);
  cy.cleanUpCypressApps();
  cy.cleanUpCypressWorkspaces();
  cy.cleanupCypressDashboards();
  cy.cleanUpCypressApplets();
  cy.cleanUpCypressAssets();
  cy.cleanUpCypressTasks();
  cy.cleanUpCypressUsers();
  cy.cleanUpCypressGroups();
  cy.cleanUpCypressRoles();
});

Cypress.Commands.add('logout', () => {
  cy.intercept('signalr/*', {});

  return cy
    .request({
      method: 'POST',
      url: '/api/user/logout',
      failOnStatusCode: false
    })
    .then(() => {
      localStorage.removeItem('jwt_token');
    });
});

Cypress.Commands.add('turbinelogin', () => {
  cy.intercept('signalr/*', {});

  return cy
    .request('POST', `${Cypress.config('turbineUrl' as unknown)}/api/v1/auth/login`, {
      username: Cypress.env('USERNAME'),
      password: Cypress.env('PASSWORD')
    })
    .then(result => {
      localStorage.setItem('token', result.body.token);
    });
});

Cypress.Commands.add('apiLogin', () => {
  return cy
    .request('POST', `/api/user/login`, {
      username: Cypress.env('USERNAME'),
      password: Cypress.env('PASSWORD')
    })
    .then(result => {
      localStorage.setItem('token', result.body.token);
      return result.body.token;
    });
});

Cypress.Commands.add('toggleFeatureFlag', (flag = '', enabled = true) => {
  cy.apiLogin().then(token => {
    return cy.uploadJson({
      method: 'POST',
      url: `/api/settings/features/${flag}`,
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        disabled: !enabled
      })
    });
  });
});

Cypress.Commands.add('cleanupTurbine', () => {
  cy.turbinelogin();
  cy.cleanupTurbineSensors();
  cy.cleanupTurbineAssets();
  cy.cleanupTurbinePlaybooks();
  return cy.cleanupTurbinePlugins();
});

Cypress.Commands.add('importBundle', (bundleData: BlobPart, fileName: string) => {
  const formData = new FormData();
  const file = new File([bundleData], fileName, {
    type: 'application/octet-stream'
  });
  formData.append('file', file);
  cy.uploadJson({
    method: 'POST',
    url: '/api/task/packages',
    headers: {
      Authorization: `Bearer ${localStorage.getItem('jwt_token')}`
    },
    body: formData
  });
});

Cypress.Commands.add('deleteApp', appId => {
  return cy.request({
    method: 'DELETE',
    url: `/api/app/${appId}`,
    headers: {
      Authorization: `Bearer ${localStorage.getItem('jwt_token')}`
    }
  });
});

Cypress.Commands.add('deleteApplet', appletId => {
  const bearer = localStorage.getItem('jwt_token');
  const auth = { bearer };
  return cy.request({ method: 'DELETE', url: `/api/applet/${appletId}`, auth });
});

Cypress.Commands.add('deleteAssetOld', assetId => {
  const bearer = localStorage.getItem('jwt_token');
  const auth = { bearer };
  return cy.request({ method: 'DELETE', url: `/api/asset/${assetId}`, auth });
});

Cypress.Commands.add('deleteAsset', assetId => {
  return cy.request({
    method: 'DELETE',
    url: `${Cypress.config('turbineUrl' as unknown)}/api/v1/asset/${assetId}`,
    headers: {
      Authorization: `Bearer ${localStorage.getItem('token')}`
    }
  });
});

Cypress.Commands.add('deletePlugin', pluginId => {
  return cy.request({
    method: 'DELETE',
    url: `${Cypress.config('turbineUrl' as unknown)}/api/v1/plugin/${pluginId}`,
    headers: {
      Authorization: `Bearer ${localStorage.getItem('token')}`
    }
  });
});

Cypress.Commands.add('deletePlaybook', playbookId => {
  return cy.request({
    method: 'DELETE',
    url: `${Cypress.config('turbineUrl' as unknown)}/api/v1/playbook/${playbookId}`,
    headers: {
      Authorization: `Bearer ${localStorage.getItem('token')}`
    }
  });
});

Cypress.Commands.add('deleteSensor', sensorId => {
  return cy.request({
    method: 'DELETE',
    url: `${Cypress.config('turbineUrl' as unknown)}/api/v1/sensor/${sensorId}`,
    headers: {
      Authorization: `Bearer ${localStorage.getItem('token')}`
    }
  });
});

Cypress.Commands.add('deleteIngestionRule', ingestionRuleId => {
  const bearer = localStorage.getItem('jwt_token');
  const auth = { bearer };
  return cy.request({
    method: 'DELETE',
    url: `/api/ingestion-rules/${ingestionRuleId}`,
    auth
  });
});

Cypress.Commands.add('deleteOrchestrationTask', orchestrationTaskId => {
  const bearer = localStorage.getItem('jwt_token');
  const auth = { bearer };
  return cy.request({
    method: 'DELETE',
    url: `/api/orchestrationtask/${orchestrationTaskId}`,
    auth
  });
});

Cypress.Commands.add('updateIngestionRule', (ingestionRuleId, bodyPayload) => {
  const bearer = localStorage.getItem('jwt_token');
  const auth = { bearer };
  return cy.request({
    method: 'PUT',
    url: `/api/ingestion-rules/${ingestionRuleId}`,
    auth,
    body: bodyPayload
  });
});

Cypress.Commands.add('updateOrchestrationTask', (orchestrationTaskId, bodyPayload) => {
  const bearer = localStorage.getItem('jwt_token');
  const auth = { bearer };
  return cy.request({
    method: 'PUT',
    url: `/api/orchestrationtask/${orchestrationTaskId}`,
    auth,
    body: bodyPayload
  });
});

Cypress.Commands.add('cleanupIngestionRules', () => {
  const bearer = localStorage.getItem('jwt_token');
  const auth = { bearer };
  return cy.request({ url: 'api/ingestion-rules', auth }).then(({ body }) => {
    body.forEach(({ name, id }) => {
      if (name.includes('QADOFUNC') || name.includes('QAE2E')) {
        cy.deleteIngestionRule(id);
      }
    });
  });
});

Cypress.Commands.add('cleanupOrchestrationTasks', () => {
  const bearer = localStorage.getItem('jwt_token');
  const auth = { bearer };
  return cy.request({ url: 'api/orchestrationtask', auth }).then(({ body }) => {
    body.forEach(({ name, id }) => {
      if (name.includes('QADOFUNC') || name.includes('QAE2E')) {
        cy.deleteOrchestrationTask(id);
      }
    });
  });
});

Cypress.Commands.add('cleanupTurbinePlugins', () => {
  return cy
    .request({
      method: 'GET',
      url: `${Cypress.config('turbineUrl' as unknown)}/api/v1/plugin`,
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`
      }
    })
    .then(response => {
      for (const plugins of response.body.items) {
        if (
          (plugins.item.plugin.vendor.includes('Swimlane') ||
            plugins.item.plugin.vendor.includes('Chronicle LLC') ||
            plugins.item.plugin.vendor.includes('Python Software Foundation') ||
            plugins.item.plugin.vendor.includes('GitHub, Inc.')) &&
          !plugins.item.meta.isSystem
        ) {
          cy.deletePlugin(plugins.item.id);
        }
      }
    });
});

Cypress.Commands.add('cleanupTurbinePlaybooks', () => {
  return cy
    .request({
      method: 'GET',
      url: `${Cypress.config('turbineUrl' as unknown)}/api/v1/playbook`,
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`
      }
    })
    .then(response => {
      for (const playbooks of response.body.items) {
        if (
          playbooks.item.playbook.title.includes('QA-E2E-') ||
          playbooks.item.playbook.title.includes('QAE2E-') ||
          playbooks.item.playbook.title.includes('QAE2E') ||
          playbooks.item.playbook.title.includes('chained_repeats') ||
          playbooks.item.playbook.title.includes('test') ||
          playbooks.item.playbook.title.includes('sensor_post')
        ) {
          cy.deletePlaybook(playbooks.item.id);
        }
      }
    });
});

Cypress.Commands.add('cleanupTurbineAssets', () => {
  return cy
    .request({
      method: 'GET',
      url: `${Cypress.config('turbineUrl' as unknown)}/api/v1/asset`,
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`
      }
    })
    .then(response => {
      for (const assets of response.body.items) {
        if (assets.item.name.includes('QADOFUNC')) {
          cy.deleteAsset(assets.item.id);
        }
      }
    });
});

Cypress.Commands.add('cleanupTurbineSensors', () => {
  return cy
    .request({
      method: 'GET',
      url: `${Cypress.config('turbineUrl' as unknown)}/api/v1/sensor`,
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`
      }
    })
    .then(response => {
      for (const sensors of response.body.items) {
        if (sensors.item.meta.name.includes('QADOFUNC')) {
          cy.deleteSensor(sensors.item.id);
        }
      }
    });
});

Cypress.Commands.add('deleteTask', id => {
  const bearer = localStorage.getItem('jwt_token');
  return cy.request({
    method: 'DELETE',
    url: `/api/task/${id}`,
    auth: { bearer },
    failOnStatusCode: false
  });
});

Cypress.Commands.add('deleteUser', id => {
  const bearer = localStorage.getItem('jwt_token');
  return cy.request({
    method: 'DELETE',
    url: `/api/user/${id}`,
    auth: { bearer }
  });
});

Cypress.Commands.add('deleteGroup', id => {
  const bearer = localStorage.getItem('jwt_token');
  return cy.request({
    method: 'DELETE',
    url: `/api/groups/${id}`,
    auth: { bearer }
  });
});

Cypress.Commands.add('deleteRole', id => {
  const bearer = localStorage.getItem('jwt_token');
  return cy.request({
    method: 'DELETE',
    url: `/api/roles/${id}`,
    auth: { bearer }
  });
});

Cypress.Commands.add('deleteWorkspace', id => {
  const bearer = localStorage.getItem('jwt_token');
  return cy.request({
    method: 'DELETE',
    url: `/api/workspaces/${id}`,
    auth: { bearer }
  });
});

Cypress.Commands.add('deleteDashboard', id => {
  const bearer = localStorage.getItem('jwt_token');
  return cy.request({
    method: 'DELETE',
    url: `/api/dashboard/${id}`,
    auth: { bearer }
  });
});

Cypress.Commands.add('setExpandedMenu', () => {
  localStorage.setItem('swimlane_navigation-expanded', 'true');
});

Cypress.Commands.add('deleteBundle', ({ name, version, pythonVersion }) =>
  cy.request({
    method: 'DELETE',
    url: `/api/task/packages/${name}/${version}/${pythonVersion}`,
    auth: { bearer: localStorage.getItem('jwt_token') }
  })
);

Cypress.Commands.add('cleanUpBundles', (bundleList = []) => {
  const auth = {
    bearer: localStorage.getItem('jwt_token')
  };
  if (typeof bundleList === 'string') {
    bundleList = [bundleList];
  }
  cy.request({
    url: '/api/task/packages',
    auth
  }).then(({ body }) =>
    Promise.all(
      body
        .filter(plugin => {
          return !Array.isArray(bundleList) || bundleList.length === 0 || bundleList.includes(plugin.name);
        })
        .map(cy.deleteBundle)
    )
  );
});

Cypress.Commands.add('cleanUpCypressApps', () => {
  const bearer = localStorage.getItem('jwt_token');
  return cy
    .request({
      url: '/api/app/light',
      auth: { bearer }
    })
    .then(({ body }) => {
      body.forEach(({ name, id }) => {
        if (name.includes('FEA') || name.includes('Cypress') || name.includes('QA-E2E-') || name.includes('QAE2E-')) {
          cy.deleteApp(id);
        }
      });
    });
});

Cypress.Commands.add('cleanUpCypressApplets', () => {
  const bearer = localStorage.getItem('jwt_token');
  const auth = { bearer };
  return cy.request({ url: 'api/applet', auth }).then(({ body }) => {
    body.forEach(({ name, id }) => {
      if (name.includes('FEA') || name.includes('Cypress') || name.includes('QA-E2E-')) {
        cy.deleteApplet(id);
      }
    });
  });
});

Cypress.Commands.add('cleanUpCypressAssets', () => {
  const bearer = localStorage.getItem('jwt_token');
  const auth = { bearer };
  return cy.request({ url: 'api/asset', auth }).then(({ body }) => {
    body.forEach(({ name, id }) => {
      if (name.includes('FEA') || name.includes('Cypress') || name.includes('QA-E2E-')) {
        cy.deleteAssetOld(id);
      }
    });
  });
});

Cypress.Commands.add('cleanUpCypressTasks', () => {
  const bearer = localStorage.getItem('jwt_token');
  const auth = { bearer };
  return cy.request({ url: 'api/task/list', auth }).then(({ body }) => {
    cy.log(body);
    body.tasks.forEach(({ name, id, taskId }) => {
      cy.log(name);
      if (name.includes('FEA') || name.includes('Cypress') || name.includes('QA-E2E-') || name.includes('qa-e2e-')) {
        cy.deleteTask(id);
      }
    });
  });
});

Cypress.Commands.add('cleanUpCypressUsers', () => {
  const bearer = localStorage.getItem('jwt_token');
  const auth = { bearer };
  return cy.request({ url: 'api/user/light', auth }).then(({ body }) => {
    body.forEach(({ name, id }) => {
      if (name.includes('FEA') || name.includes('Cypress') || name.includes('QA-E2E-')) {
        cy.deleteUser(id);
      }
    });
  });
});

Cypress.Commands.add('cleanUpCypressGroups', () => {
  const bearer = localStorage.getItem('jwt_token');
  const auth = { bearer };
  return cy.request({ url: 'api/groups', auth }).then(({ body }) => {
    body.items.forEach(({ name, id }) => {
      if (name.includes('FEA') || name.includes('Cypress') || name.includes('QA-E2E-')) {
        cy.deleteGroup(id);
      }
    });
  });
});

Cypress.Commands.add('cleanUpCypressRoles', () => {
  const bearer = localStorage.getItem('jwt_token');
  const auth = { bearer };
  return cy.request({ url: 'api/roles', auth }).then(({ body }) => {
    body.items.forEach(({ name, id }) => {
      if (name.includes('FEA') || name.includes('Cypress') || name.includes('QA-E2E-')) {
        cy.deleteRole(id);
      }
    });
  });
});

Cypress.Commands.add('cleanupCypressDashboards', () => {
  const bearer = localStorage.getItem('jwt_token');
  return cy
    .request({
      url: '/api/dashboard',
      auth: { bearer }
    })
    .then(({ body }) => {
      body.forEach(({ name, id }) => {
        if (name.includes('FEA') || name.includes('Cypress') || name.includes('QA-E2E-')) {
          cy.deleteDashboard(id);
        }
      });
    });
});

Cypress.Commands.add('cleanUpCypressWorkspaces', () => {
  const bearer = localStorage.getItem('jwt_token');
  const auth = { bearer };
  return cy.request({ url: '/api/workspaces', auth }).then(({ body }) => {
    body.forEach(({ name, id }) => {
      if (name.includes('FEA') || name.includes('Cypress') || name.includes('QA-E2E-') || name.includes('QAE2E-')) {
        cy.deleteWorkspace(id);
      }
    });
  });
});

Cypress.Commands.add('skipIfFeatureOn', flag => {
  return cy.request('/api/settings/features/enabled').then(res => {
    const ffOn = res.body.some(f => {
      return f.id === flag && f.disabled !== true;
    });
    if (ffOn) {
      // @ts-ignore
      cy.state('runnable').ctx.skip();
    }
  });
});

Cypress.Commands.add('isFeatureOn', flag => {
  return cy.request('/api/settings/features/enabled').then(res => {
    const ffOn = res.body.some(f => {
      return f.id === flag && f.disabled !== true;
    });
    return ffOn;
  });
});

Cypress.Commands.add('makeAPICall', (method, apiCall, body, statusCode = null) => {
  return cy
    .request({
      method,
      url: `${Cypress.config('baseUrl')}/api/${apiCall}`,
      headers: {
        accept: 'application/json',
        Authorization: `Bearer ${localStorage.getItem('jwt_token')}`
      },
      body
    })
    .then($appJSON => {
      if (statusCode !== null) {
        expect($appJSON.status).to.equal(statusCode);
      }
      return $appJSON.body;
    });
});

Cypress.Commands.add('batchRecordCreateAPI', (appID, valueList = []) => {
  const fields = {};
  const sendData = [];

  return cy.makeAPICall('GET', `app/${appID}`).then($appBody => {
    for (const eachField of $appBody.fields) {
      fields[eachField.name] = eachField.id;
    }
    for (const eachRecord of valueList) {
      const singleRecord = {
        applicationId: appID,
        disabled: false,
        id: faker.datatype.uuid(),
        values: {
          $type:
            'System.Collections.Generic.Dictionary`2[[System.String, System.Private.CoreLib],[System.Object, System.Private.CoreLib]], System.Private.CoreLib'
        }
      };
      for (const fieldName of Object.keys(eachRecord)) {
        singleRecord.values[fields[fieldName]] = eachRecord[fieldName];
      }
      sendData.push(singleRecord);
    }
    return cy.makeAPICall('POST', `app/${appID}/record/batch`, sendData);
  });
});

Cypress.Commands.add('getRTE', () => {
  return cy
    .get('rte', { timeout: 30000 })
    .should('exist')
    .within(() => {
      cy.get('editor', { timeout: 30000 }).should('exist');
      cy.get('.tox.tox-tinymce', { timeout: 30000 }).should('exist');
      cy.get('.tox-edit-area__iframe', { timeout: 30000 }).should('exist');
      cy.wait(500);
      cy.frameLoaded('.tox-edit-area__iframe');
    })
    .iframe('.tox-edit-area__iframe');
});

Cypress.Commands.add('setFeatureFlag', (flag = '', enable = true) =>
  cy.makeAPICall('POST', `settings/features/${flag}`, { disabled: !enable })
);

const makeImportCommand =
  (parentRoute: string) =>
  (manifest: any, modifications = []) => {
    const request = {
      modifications,
      manifest
    };
    return cy.uploadJson({
      method: 'POST',
      url: `/api/${parentRoute}/import`,
      headers: {
        Authorization: `Bearer ${localStorage.getItem('jwt_token')}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(request)
    });
  };

  Cypress.Commands.add('makeTurbineAPICall', (method, apiCall, body, statusCode = null) => {
    return cy
      .request({
        method,
        url: `${Cypress.config('baseUrl')}/${apiCall}`,
        headers: {
          accept: 'application/json',
          Authorization: `Bearer ${localStorage.getItem('token')}`
        },
        body
      })
      .then($appJSON => {
        if (statusCode !== null) {
          expect($appJSON.status).to.equal(statusCode);
        }
        return $appJSON.body;
      });
  });

Cypress.Commands.add('importApp', makeImportCommand('app'));

Cypress.Commands.add('importApplet', makeImportCommand('applet'));

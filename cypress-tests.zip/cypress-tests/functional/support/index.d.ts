/* tslint:disable:no-namespace */

// load type definitions that come with Cypress module
/// <reference types="cypress" />
/// <reference types="cypress-grep" />

import '@swimlane/ngx-ui-testing';
declare namespace Cypress {
  interface Chainable {
    /**
     * Custom command to find an element by the dataCy value.
     * @param value the dataCy value in the DOM
     */
    dataCy(value: string): Chainable<Element>;
    getRTE(): Chainable<JQuery<HTMLBodyElement>>;
    skipIfFeatureOn(flag: string): Chainable<void>;
  }
}

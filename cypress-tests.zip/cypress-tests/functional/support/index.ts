// ***********************************************************
// You can read more here:
// https://on.cypress.io/guides/configuration#section-global
// ***********************************************************

import 'cypress-file-upload';
import '@swimlane/ngx-ui-testing';

import './commands';
import '../../shared/commands';
import './defaults';

// load and register the grep feature
require('cypress-grep')();

if (Cypress.env('ENABLE_COVERAGE_PLUGIN')) {
  require('@cypress/code-coverage/support');
}
require('cypress-terminal-report/src/installLogsCollector')();

require('@neuralegion/cypress-har-generator/commands');

Cypress.on('uncaught:exception', () => {
  // returning false here prevents Cypress from
  // failing the test
  return false;
});

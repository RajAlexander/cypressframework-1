import faker from 'faker/locale/en';

export function makeApplicationWithFields(
  fields: string | any[],
  acronym: string,
  name: string,
  workspaceId = null
): object {
  const application = {
    name,
    acronym,
    createWorkspace: workspaceId === null,
    workspaces: workspaceId == null ? null : [workspaceId],
    fields: [],
    layout: [],
    disabled: false
  };

  for (let i = 0; i < fields.length; i++) {
    const field = fields[i];
    const key = (field.fieldType + faker.random.uuid()).toLowerCase();
    const fieldBody = {
      unique: Object.prototype.hasOwnProperty.call(field, 'unique') ? field.unique : false,
      id: Object.prototype.hasOwnProperty.call(field, 'id') ? field.id : faker.random.uuid(),
      name: Object.prototype.hasOwnProperty.call(field, 'name') ? field.name : key,
      key: Object.prototype.hasOwnProperty.call(field, 'key') ? field.key : key,
      maxSize: field.maxSize,
      fieldType: field.fieldType,
      inputType: Object.prototype.hasOwnProperty.call(field, 'inputType') ? field.inputType : false,
      formula: Object.prototype.hasOwnProperty.call(field, 'formula') ? field.formula : null,
      required: Object.prototype.hasOwnProperty.call(field, 'required') ? field.required : false,
      readOnly: Object.prototype.hasOwnProperty.call(field, 'readOnly') ? field.readOnly : false,
      targetId: Object.prototype.hasOwnProperty.call(field, 'targetId') ? field.targetId : false,
      columns: Object.prototype.hasOwnProperty.call(field, 'columns') ? field.columns : [],
      defaultValueType: Object.prototype.hasOwnProperty.call(field, 'defaultValueType') ? field.defaultValueType : null,
      controlType: Object.prototype.hasOwnProperty.call(field, 'controlType') ? field.controlType : null,
      selectionType: Object.prototype.hasOwnProperty.call(field, 'selectionType') ? field.selectionType : null,
      canAdd: Object.prototype.hasOwnProperty.call(field, 'canAdd') ? field.canAdd : null,
      createLink: Object.prototype.hasOwnProperty.call(field, 'createLink') ? field.createLink : false,
      showAllUsers: Object.prototype.hasOwnProperty.call(field, 'showAllUsers') ? field.showAllUsers : null,
      showAllGroups: Object.prototype.hasOwnProperty.call(field, 'showAllGroups') ? field.showAllGroups : null,
      values: Object.prototype.hasOwnProperty.call(field, 'values') ? field.values : null
    };

    const layoutBody = {
      fieldId: fieldBody.id,
      id: faker.random.uuid(),
      row: 1 + Math.floor(i / 2),
      col: i % 2 == 0 ? 1 : 3,
      sizex: 2,
      sizey: 0,
      layoutType: 'field'
    };

    application.fields.push(fieldBody);
    application.layout.push(layoutBody);
  }

  return application;
}

/**
 * TODO: (Not necessary but need to see fi we want to add any of these)
 *  ------ RAC ---- https://swimlane.atlassian.net/browse/SPT-5035
 *  - GROUPS
 *  - ROLES
 *  - SYSTEM SETTINGS (DO HAVE OUTGOING EMAIL SETTING TESTED)
 *  - LOGGING
 *  - APPLETS
 */

import * as swimInstance from '../../support/page-objects/swimInstance';

import faker from 'faker/locale/en';

const uniqueSubject = `QA-E2E-${faker.datatype.uuid()}`;
const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const appDescription = faker.lorem.sentence();
const textConditionValue = faker.lorem.word();
const numericFieldValue = faker.random.number();
const emailFieldValue = faker.internet.email();
const dashboardNameValue = 'QA-E2E-' + faker.commerce.productName();
const emailTaskName = `QA-E2E- email ingestion ${faker.company.catchPhrase()}`.substring(0, 128);
const pyDriverTaskName = `QA-E2E- driver ${faker.company.catchPhrase()}`.substring(0, 128);
const pyDriverRecordTaskName = `QA-E2E- record ${faker.company.catchPhrase()}`.substring(0, 128);
const pySendEmailTaskName = `QA-E2E- email output ${faker.company.catchPhrase()}`.substring(0, 128);
const pyPipTaskName = `QA-E2E- PIP ${faker.company.catchPhrase()}`.substring(0, 128);
const assetName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const assetSmtpName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const cardName = `QA-E2E-${faker.commerce.productName()}`;
const bulkRecords = [
  { Text: 'on', Numeric: 123 },
  { Text: 'off', Numeric: 123 },
  { Text: 'on', Numeric: -10 },
  { Text: 'off', Numeric: -100 }
];
const outgoingMailServerSettings = {
  Host: 'smtp.gmail.com',
  Port: '587',
  User: Cypress.env('EMAIL_USER'),
  Password: Cypress.env('EMAIL_PASSWORD')
};

const exchangeAssetSettings = {
  ews_url: 'https://outlook.office365.com/EWS/Exchange.asmx',
  Username_mailbox: Cypress.env('EXCHANGE_USER'),
  username_identifier: Cypress.env('EXCHANGE_USER'),
  auth_type: 'basic',
  Password: Cypress.env('EXCHANGE_PASSWORD')
};

const defaultTaskOutputs = `"sw_task_status": "success",\n    "sw_task_error_type": "",\n    "sw_task_error_message": "",\n    "sw_task_stack_trace": ""`;

let testUserJSON: swimInstance.UserJSON = {};
let recordData = {};
let appId = '';
let recordTrackingId = '';
let recordCount = 0;
const APPLIST = [];
const USERLIST = [];
const ASSETLIST = [];
const WORKSPACELIST = [];
const DASHBOARDLIST = [];
const TASKLIST = [];
let timestamp: number;

describe('Smoke Test', { retries: { runMode: 0, openMode: 0 } }, () => {
  before(() => {
    cy.login();
    cy.cleanupSwimlane();
    cy.logout();

    cy.setExpandedMenu();
    swimInstance.setLoginState();
  });

  describe('Login page', () => {
    it('Check Login Page', () => {
      // Can this be broken up between getting the base elements and verification of certain text?
      swimInstance.loginPage.verifyElements();
    });

    describe('Failed Logins', () => {
      it('Perform failed Login - No Password', () => {
        swimInstance.loginPage.performDisabledLogin(Cypress.env('USERNAME'), '');
      });

      it('Perform failed Login - No Username', () => {
        swimInstance.loginPage.performDisabledLogin('', Cypress.env('PASSWORD'));
      });

      it('Perform failed Login - No matching credentials', () => {
        swimInstance.loginPage.performLogin(Cypress.env('USERNAME'), faker.internet.password(), 401);
      });
    });

    describe('Valid login', () => {
      it('Perform Login with Valid Credentials', () => {
        swimInstance.loginPage.performLogin(Cypress.env('USERNAME'), Cypress.env('PASSWORD'));
      });
    });
  });

  describe('Create user for testing', () => {
    before(() => {
      testUserJSON = swimInstance.createUserJSON({ roles: ['Administrator'] });
    });

    it('Create user to send an email to', () => {
      swimInstance.openUsersListing();
      swimInstance.usersListing.clickNewUser();
      swimInstance.usersListing.userDialog.enterUserInfo(testUserJSON);
      swimInstance.usersListing.userDialog.saveUserEdit();
      USERLIST.push(testUserJSON.displayName);
    });

    it('Log in as Test User to finish testing', () => {
      swimInstance.logout();
      swimInstance.loginPage.verifyElements();
      swimInstance.loginPage.performLogin(testUserJSON.username, testUserJSON.password);
    });
  });

  describe('User post-login wizard', () => {
    it('Verify landing page, welcome wizard if present', () => {
      swimInstance.welcomeWizard.verifyPage(0, testUserJSON.displayName);
      swimInstance.welcomeWizard.clickContinue();
      swimInstance.welcomeWizard.verifyPage(1);
      swimInstance.welcomeWizard.clickContinue();
      swimInstance.welcomeWizard.verifyPage(2);
      swimInstance.welcomeWizard.previous();
      swimInstance.welcomeWizard.verifyPage(1);
      swimInstance.welcomeWizard.previous();
      swimInstance.welcomeWizard.verifyPage(0, testUserJSON.displayName);
      swimInstance.welcomeWizard.clickContinue();
      swimInstance.welcomeWizard.clickContinue();
      swimInstance.welcomeWizard.verifyPage(2);
      swimInstance.welcomeWizard.finish();
      swimInstance.waitForApps();
    });
  });

  describe('Setup SMTP asset and task to send an email', () => {
    before(() => {
      cy.skipIfFeatureOn('DynamicOrchestration');
    });

    it('Create SMTP asset', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewAsset('SMTP Email', {
        Name: assetSmtpName,
        Description: appDescription,
        parameters: outgoingMailServerSettings
      });
      ASSETLIST.push(assetSmtpName);
    });

    it('Create Python task to send Email', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', pySendEmailTaskName, null);
      TASKLIST.push(['Common', pySendEmailTaskName]);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: `sw_outputs.append({{}'subject': '${uniqueSubject}', 'recipient': '${exchangeAssetSettings['Username_mailbox']}'})`
      });
      swimInstance.integrationsPage.editTaskOutputMapping({
        sendEmail: {
          Sender: { type: 'Output Parameter', name: 'recipient' },
          Recipients: { type: 'Output Parameter', name: 'recipient' },
          Subject: { type: 'Output Parameter', name: 'subject' },
          emailAsset: assetSmtpName
        }
      });
      swimInstance.integrationsPage.saveCurrentTask();
    });
  });

  describe('Setup MS Exchange bundle for email ingestion', () => {
    before(() => {
      cy.skipIfFeatureOn('DynamicOrchestration');
      testUserJSON = swimInstance.createUserJSON({
        email: exchangeAssetSettings['Username_mailbox']
      });
    });

    it('Upload bundle', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.checkForExistingBundle('sw_microsoft_exchange', '5.2.0');
    });

    it('Create asset for bundle', () => {
      swimInstance.integrationsPage.createNewAsset('Microsoft Exchange', {
        Name: assetName,
        Description: appDescription,
        parameters: exchangeAssetSettings
      });
      ASSETLIST.push(assetName);
    });

    it('Create email ingestion task for asset', () => {
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Get Email Metadata', emailTaskName);
      swimInstance.integrationsPage.editCurrentTask({
        Name: emailTaskName,
        Asset: assetName
      });
      swimInstance.integrationsPage.editTaskConfiguration({
        'Subject Filter': ['Literal Value', uniqueSubject]
      });
      swimInstance.integrationsPage.editTaskOutputMapping({
        createUpdateRecord: {
          targetAppName: 'Create New Application',
          mappingJSON: {
            attachments: 'Attachments',
            text_body: 'Multi-Line',
            sender: 'Email'
          }
        }
      });
      APPLIST.push(emailTaskName);
      WORKSPACELIST.push(`${emailTaskName} Workspace`);
      swimInstance.integrationsPage.addTriggerToTask();
      swimInstance.integrationsPage.saveCurrentTask();
      TASKLIST.push(['Common', emailTaskName]);
    });
  });

  describe('Apps, Records, Workflow Test', () => {
    describe('Testing Application creation', () => {
      it('Create new App', () => {
        swimInstance.openAppAppletsList();
        swimInstance.appsAppletsListing.startNewApp();
        swimInstance.appsAppletsListing.appWizard.setAppName(appName);
        swimInstance.appsAppletsListing.appWizard.setAppDescription(appDescription);
        swimInstance.appsAppletsListing.appWizard.createApp();
        APPLIST.push(appName);
        WORKSPACELIST.push(`${appName} Workspace`);
      });

      it('Build fields into App', () => {
        swimInstance.appBuilder.verifyElements(appName);
        swimInstance.appBuilder.getAppID().then($appID => {
          appId = $appID;
        });
        swimInstance.appBuilder.addField('Single-Line');
        swimInstance.appBuilder.addField('Numeric');
        swimInstance.appBuilder.addField('Email');
      });

      it('Add Integration button', () => {
        cy.skipIfFeatureOn('DynamicOrchestration');
        swimInstance.appBuilder.addLayout('Integration');
        swimInstance.appBuilder.editAppComponent('Integration', {
          Task: pySendEmailTaskName
        });
      });

      it('Save Application', () => {
        swimInstance.appBuilder.saveApplication();
      });
    });

    describe('Testing Record editor', () => {
      it('Create new Record', () => {
        swimInstance.switchToWorkspace(`${appName} Workspace`);
        swimInstance.startNewRecordForApp(appName);
        swimInstance.recordEditor.enterRandomData();
        swimInstance.recordEditor.save();
        recordCount += 1;
        swimInstance.recordEditor.getRecordValues().then($recordData => (recordData = $recordData));
        swimInstance.recordEditor.getRecordTrackingID(true).then($trackingID => {
          recordTrackingId = $trackingID;
        });
      });

      it('Reopen and Verify Record Values', () => {
        swimInstance.OpenAppListAll(appName);
        swimInstance.recordListing.openRecord(recordTrackingId);
        swimInstance.recordEditor.getRecordTrackingID().then($trackingID => {
          expect($trackingID).to.equal(recordTrackingId);
        });
        cy.then(() => {
          swimInstance.recordEditor.verifyFieldValues(recordData);
        });
      });

      it('Click integration button', () => {
        cy.skipIfFeatureOn('DynamicOrchestration');
        swimInstance.recordEditor.clickIntegrationButton('Integration', pySendEmailTaskName);
        timestamp = new Date().getTime();
      });

      it('Close the record editor', () => {
        swimInstance.recordListing.closeRecordWindow();
      });
    });

    describe('Add python task to application', () => {
      before(() => {
        cy.skipIfFeatureOn('DynamicOrchestration');
      });

      it('Open integrations tab', () => {
        swimInstance.openIntegrations();
        swimInstance.integrationsPage.checkForExistingPipPackage('swimlane', swimInstance.expectedPyDriverVer());
        swimInstance.integrationsPage.createNewTask();
        swimInstance.integrationsPage.setupTask('Python 3', pyDriverTaskName, null);
        TASKLIST.push(['Common', pyDriverTaskName]);
        swimInstance.integrationsPage.editTaskConfiguration({
          script: 'from swimlane import Swimlane{enter}from swimlane import __version__{enter}print(__version__)'
        });
        swimInstance.integrationsPage.runTaskDebugger(
          `[\n  {\n    ${defaultTaskOutputs},\n    "stdOutput": "${swimInstance.expectedPyDriverVer()}"\n  }\n]`
        );
      });

      it('Save the task', () => {
        swimInstance.integrationsPage.saveCurrentTask();
      });
    });

    describe('Testing application workflow changes.', () => {
      it('Edit App Workflow', () => {
        swimInstance.openAppAppletsList();
        swimInstance.appsAppletsListing.editExistingApp(appName);
        swimInstance.appBuilder.verifyElements(appName);
        swimInstance.appBuilder.editWorkflow();
        swimInstance.workflowEditor.verifyElements();
        swimInstance.workflowEditor.addNode(appName, 'condition');
        swimInstance.workflowEditor.fitWorkflowToView();
        swimInstance.workflowEditor.editCurrentNode({
          Name: 'Text Field Equals',
          Field: 'Text',
          Operator: 'Equals',
          Value: { type: 'Text', value: textConditionValue }
        });
        swimInstance.workflowEditor.addNode('Text Field Equals', 'action');
        swimInstance.workflowEditor.editCurrentNode({
          Name: 'Set Numeric Value',
          'Action Type': 'Set Field Value',
          Field: 'Numeric',
          Value: { type: 'Numeric', value: numericFieldValue }
        });
        swimInstance.workflowEditor.saveWorkflow();
      });

      it('Workflow for empty text field', () => {
        swimInstance.workflowEditor.verifyElements();
        swimInstance.workflowEditor.addNode(appName, 'condition');
        swimInstance.workflowEditor.editCurrentNode({
          Name: 'Email Field Equals',
          Field: 'Email',
          Operator: 'Equals'
        });
        swimInstance.workflowEditor.addNode('Email Field Equals', 'action');
        swimInstance.workflowEditor.editCurrentNode({
          Name: 'Set Email Value',
          'Action Type': 'Set Field Value',
          Field: 'Email',
          Value: { type: 'Text', value: emailFieldValue }
        });
        swimInstance.workflowEditor.saveWorkflow();
      });

      it('Verify Workflow on Record Values', () => {
        swimInstance.switchToWorkspace(`${appName} Workspace`);
        swimInstance.OpenAppListAll(appName);
        swimInstance.recordListing.openRecord(recordTrackingId);
        swimInstance.recordEditor.setFieldValue({
          Text: { value: textConditionValue },
          Email: { value: '' }
        });
        cy.then(() => {
          recordData['Text'] = textConditionValue;
          recordData['Numeric'] = numericFieldValue.toString();
          recordData['Email'] = emailFieldValue;
          // Give workflow just a sec, otherwise will try to update after saving.
          cy.wait(500);
          swimInstance.recordEditor.verifyFieldValues(recordData);
        });
      });

      it('Close the record', () => {
        swimInstance.recordEditor.save('Record updated');
        swimInstance.recordListing.closeRecordWindow();
      });
    });
  });

  describe('Reporting on record data', () => {
    before(() => {
      cy.batchRecordCreateAPI(appId, bulkRecords);
      recordCount += bulkRecords.length;
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      return swimInstance.OpenAppListAll(appName);
    });

    it('Create Report on Application', () => {
      swimInstance.recordListing.toggleShowRecordFields(['Text', 'Numeric']);
      swimInstance.recordListing.getRecordCount().then($recordCount => {
        expect($recordCount, `Verify current record count is ${recordCount}`).to.equal(recordCount);
      });
      swimInstance.recordListing.saveReport();
      swimInstance.recordListing.openCharts();
      swimInstance.recordListing.buildChart('Tracking Id', 'Text');
      swimInstance.recordListing.saveReportAs('QA-E2E-Bob');
    });
  });

  describe('Dashboard and Charts', () => {
    it('Create a Dashboard for Cards', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.dashboardPage.createDashboardOnEmpty();
      swimInstance.dashboardWizard.setDashboardNameAndDesc(dashboardNameValue, faker.lorem.sentence());
      swimInstance.dashboardWizard.createDashboard();
      DASHBOARDLIST.push(dashboardNameValue);
    });

    it('Add custom report as cards into dashboard', () => {
      swimInstance.dashboardPage.addCard();
      swimInstance.cardWizard.setCardDetails(cardName, 'Report', `QA-E2E-Bob (${appName})`, faker.lorem.sentence());
      swimInstance.cardWizard.createCard();
      swimInstance.dashboardPage.save();
    });

    it('Add Default report as cards into dashboard', () => {
      swimInstance.dashboardPage.addCard();
      swimInstance.cardWizard.setCardDetails(
        'QA-E2E-' + faker.commerce.productName(),
        'Report',
        `Default (${appName})`,
        faker.lorem.sentence()
      );
      swimInstance.cardWizard.createCard();
      swimInstance.dashboardPage.save();
    });

    it('Drill down in chart', () => {
      swimInstance.dashboardPage.selectCardChartItem(cardName, 'off');
      swimInstance.recordListing.getRecordCount().then($recordCount => {
        expect($recordCount, `Verify current record count is 2`).to.equal(2);
      });
      swimInstance.recordListing.verifyFilters(['Text Equals: off']);
    });
  });

  describe('PIP Package', () => {
    before(() => {
      cy.skipIfFeatureOn('DynamicOrchestration');
    });

    it('Install the PIP Package', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.checkForExistingPipPackage('math-addition', '', '3.6');
    });

    it('Build Task to test PIP package', () => {
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', pyPipTaskName, null);
      TASKLIST.push(['Common', pyPipTaskName]);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: 'from addition.add import add{enter}print(add(2,3))'
      });
      swimInstance.integrationsPage.runTaskDebugger(`[\n  {\n    ${defaultTaskOutputs},\n    "stdOutput": "5"\n  }\n]`);
    });

    it('Save the task', () => {
      swimInstance.integrationsPage.saveCurrentTask();
    });
  });

  describe('Pydriver to create record', () => {
    before(() => {
      cy.skipIfFeatureOn('DynamicOrchestration');
    });

    it('Create Python task to make new record', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', pyDriverRecordTaskName, null);
      TASKLIST.push(['Common', pyDriverRecordTaskName]);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: `from swimlane import Swimlane{enter}swimlane = Swimlane(sw_context.config['InternalSwimlaneUrl'], '${Cypress.env(
          'USERNAME'
        )}', '${Cypress.env(
          'PASSWORD'
        )}', verify_ssl=False, verify_server_version=False){enter}{enter}app = swimlane.apps.get(name='${appName}'){enter}{enter}new_record = app.records.create(**{{}{enter}'Text': 'String',{enter}'Email': 'foo@work.com',{enter}'Numeric': 100{enter}}){enter}print(new_record)`
      });
      recordTrackingId = `${recordTrackingId.split('-')[0]}-${recordCount + 1}`;

      swimInstance.integrationsPage.runTaskDebugger(
        `[\n  {\n    ${defaultTaskOutputs},\n    "stdOutput": "${recordTrackingId}"\n  }\n]`
      );
      recordCount += 1;
    });

    it('Save the task', () => {
      swimInstance.integrationsPage.saveCurrentTask();
    });

    it('Reopen and Verify Record Values', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.OpenAppListAll(appName);
      swimInstance.recordListing.openRecord(recordTrackingId);
      swimInstance.recordEditor.getRecordTrackingID().then($trackingID => {
        expect($trackingID).to.equal(recordTrackingId);
      });
      swimInstance.recordEditor.verifyFieldValues({
        Text: 'String',
        Email: 'foo@work.com',
        Numeric: '100'
      });
      swimInstance.recordListing.closeRecordWindow();
    });
  });

  describe('Verify email ingestion', () => {
    before(() => {
      cy.skipIfFeatureOn('DynamicOrchestration');
    });

    it('Open app list all for email ingestion', () => {
      // give it 1.5 min since notification was sent, to process the email ingestion.
      cy.wait(Math.min(Math.max(90000 - (new Date().getTime() - timestamp), 1000), 90000));
      swimInstance.switchToWorkspace(`${emailTaskName} Workspace`);
      swimInstance.OpenAppListAll(emailTaskName);
      swimInstance.recordListing.getRecordCount().then($recordCount => {
        // This is to try to  handle the rare failure of the email not being ingested.
        // giving it another min to trigger the email ingestion.
        if ($recordCount === 0) {
          cy.wait(60000);
          swimInstance.recordListing.clickRefresh();
          swimInstance.recordListing.getRecordCount().then($recordCount2 => {
            expect($recordCount2, `Verify current record count is 1`).to.equal(1);
          });
        } else {
          expect($recordCount, `Verify current record count is 1`).to.equal(1);
        }
      });
      swimInstance.recordListing.openFirstRecord();
      // TODO: More fields to check?
      swimInstance.recordEditor.verifyFieldValues({ Sender: Cypress.env('EMAIL_USER'), Subject: uniqueSubject }, false);
      swimInstance.recordListing.closeRecordWindow();
    });
  });

  describe('Cleanup Apps Workspaces, etc', () => {
    it('Remove the created application', () => {
      swimInstance.openAppAppletsList();
      APPLIST.forEach(name => swimInstance.appsAppletsListing.deleteExistingApp(name));
    });

    it('Remove the app workspace', () => {
      const alias = 'getWorkspaces' + Math.random();
      cy.intercept('GET', '/api/workspaces').as(alias);
      swimInstance.leftNavExpandAndClick('Workspace Management', 'Workspaces');

      cy.wait(`@${alias}`).then(intercept => {
        expect(intercept.response.statusCode).to.equal(200);
        intercept.response.body.forEach(item => swimInstance.workspacesListing.deleteWorkspace(item.name));
      });
    });

    it('Remove the Dashboard', () => {
      swimInstance.openDashboardList();
      DASHBOARDLIST.forEach(name => swimInstance.dashboardsListing.deleteDashboard(name));
    });

    it('Remove the Tasks and Assets', () => {
      cy.skipIfFeatureOn('DynamicOrchestration');
      swimInstance.openIntegrations();
      ASSETLIST.forEach(name => swimInstance.integrationsPage.deleteAsset(name));
      TASKLIST.forEach(name => swimInstance.integrationsPage.deleteTask(name[1]));
    });
  });

  describe('Clean up users as admin', () => {
    it('Log in as Test User to finish testing', () => {
      swimInstance.logout();
      swimInstance.loginPage.verifyElements();
      swimInstance.loginPage.performLogin(Cypress.env('USERNAME'), Cypress.env('PASSWORD'));
    });

    it('Remove the Users', () => {
      swimInstance.openUsersListing();
      USERLIST.forEach(name => swimInstance.usersListing.removeUserInListing(name));
    });
  });

  describe('User Logout', () => {
    it('Log out', () => {
      swimInstance.logout();
    });
  });
});

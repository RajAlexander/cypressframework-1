import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 64);
const reportName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const reportName2 = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);

const APPLIST = [];
const WORKSPACELIST = [];
const tableColumnName1 = 'Text';
const tableColumnName2 = 'Numeric';
const tableColumnValue1 = 'Atest';
const tableColumnValue2 = '123';
let appId = '';
let appAcronym = '';
let reportURL = '';

describe('SPT 11205:Initial Page Setup', () => {
  before(() => {
    cy.login();
    cy.setFeatureFlag('SearchPage');
    cy.visitSwimlane('/');
  });

  describe('Create App', () => {
    it('build app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.getAppAcronym().then(acronym => {
        appAcronym = acronym;
      });
      swimInstance.appsAppletsListing.appWizard.createApp();
      APPLIST.push(appName);
      WORKSPACELIST.push(`${appName} Workspace`);
    });

    it('Add fields', () => {
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.getAppID().then($appID => {
        appId = $appID;
      });
      swimInstance.appBuilder.addField('Single-Line');
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Validations for NO data table view', () => {
    it('Validating table with and without rows', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.OpenAppListAll(appName);
      cy.url().then(url => {
        reportURL = url.replace('/search/', '/search2/');
        cy.visit(reportURL);
      });
      swimInstance.searchPage.validateTableViewNoData(false);
      swimInstance.searchPage.validateTableViewNoData();
      swimInstance.searchPage.addColumnTableSearchPage(tableColumnName1);
      swimInstance.searchPage.saveTableChanges();
      swimInstance.searchPage.addColumnTableSearchPage(tableColumnName2);
      swimInstance.searchPage.saveTableChanges();
    });
  });

  describe('Create records and report', () => {
    it('Create records', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecordForApp(appName);
      swimInstance.recordEditor.setFieldValue({ Text: { value: 'Atest' } });
      swimInstance.recordEditor.setFieldValue({ Numeric: { value: 123 } });
      swimInstance.recordEditor.save('Record saved');
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecordForApp(appName);
      swimInstance.recordEditor.setFieldValue({ Text: { value: 'Btest' } });
      swimInstance.recordEditor.setFieldValue({ Numeric: { value: 234 } });
      swimInstance.recordEditor.save('Record saved');
    });

    it('Create report', () => {
      swimInstance.OpenAppListAll(appName);
      swimInstance.recordListing.saveReport();
      swimInstance.recordListing.openCharts();
      swimInstance.recordListing.buildChart('Tracking Id', 'Text');
      swimInstance.recordListing.saveReportAs(reportName);
      swimInstance.openReport(reportName);
      cy.url().then(url => {
        reportURL = url.replace('/search/', '/search2/');
        cy.visit(reportURL);
      });
    });
  });

  describe('Search2Page Validations', () => {
    it('Validate Search2Page custom report, change report name and table view sorting', () => {
      swimInstance.searchPage.validateReportHeader(reportName);
      swimInstance.appList.validateSortingSearchPage(tableColumnName1, tableColumnValue1);
      swimInstance.appList.validateSortingSearchPage(tableColumnName2, tableColumnValue2);
      swimInstance.searchPage.saveTableChanges();
      swimInstance.searchPage.detailsAndSchedules(reportName2, false);
      swimInstance.searchPage.saveTableChanges();
      swimInstance.searchPage.validateReportHeader(reportName2);
    });

    it('Validate Search2Page Save Report As and Default Report', () => {
      swimInstance.searchPage.saveReportAs(reportName);
      swimInstance.searchPage.validateReportHeader(reportName);
      swimInstance.searchPage.deleteReport();
      swimInstance.searchPage.validateReportHeader('Default Report');
      swimInstance.searchPage.detailsAndSchedules(reportName2);
    });
  });

  after(() => {
    cy.setFeatureFlag('SearchPage', false);
    cy.cleanupSwimlane();
    cy.logout();
  });
});

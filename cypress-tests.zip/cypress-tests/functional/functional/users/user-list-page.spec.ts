import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const displayName = `QA-E2E-${faker.internet.userName()}`;
const displayNameUserAscSorting = 'aarole testingQA';
const displayNameUserDescSorting = 'zzrole testingQA';

let testUserJSON: Record<string, any> = {};

describe('SPT 6681:As a user, I want to be able to filter the users, groups, and roles list pages Subtask SPT-10502: Functional Test Keyword searching and sorting for users', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Create user for keyword searching', () => {
    before(() => {
      testUserJSON = swimInstance.createUserJSON({
        roles: ['Administrator'],
        displayName
      });
    });

    it('Create user for keyword searching', () => {
      swimInstance.openUsersListing();
      swimInstance.usersListing.clickNewUser();
      swimInstance.usersListing.userDialog.enterUserInfo(testUserJSON);
      swimInstance.usersListing.userDialog.saveUserEdit();
    });
  });

  describe('Create user for ASC sorting', () => {
    before(() => {
      testUserJSON = swimInstance.createUserJSON({
        roles: ['Administrator'],
        displayName: displayNameUserAscSorting
      });
    });

    it('Create user for ASC sorting', () => {
      swimInstance.usersListing.clickNewUser();
      swimInstance.usersListing.userDialog.enterUserInfo(testUserJSON);
      swimInstance.usersListing.userDialog.saveUserEdit();
    });
  });

  describe('Create user for DESC sorting', () => {
    before(() => {
      testUserJSON = swimInstance.createUserJSON({
        roles: ['Administrator'],
        displayName: displayNameUserDescSorting
      });
    });

    it('Create user for DESC sorting', () => {
      swimInstance.usersListing.clickNewUser();
      swimInstance.usersListing.userDialog.enterUserInfo(testUserJSON);
      swimInstance.usersListing.userDialog.saveUserEdit();
    });
  });

  describe('Sorting users by name', () => {
    it('Sorting by name ASC', () => {
      swimInstance.usersListing.sortingUsersByName(displayNameUserAscSorting);
      swimInstance.usersListing.removeUserInListing(displayNameUserAscSorting);
    });

    it('Sorting by name DESC', () => {
      swimInstance.usersListing.sortingUsersByName(displayNameUserDescSorting);
      swimInstance.usersListing.removeUserInListing(displayNameUserDescSorting);
    });
  });

  describe('Keyword searching Roles', () => {
    it('Keyword Searching', () => {
      swimInstance.usersListing.keywordSearchingUsers(displayName);
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const username = `QA-E2E-${faker.internet.userName()}`;
const password = 'testPassword01';
const incorrectPassword = 'thisisatest01';
const displayName = `QA-E2E-${faker.internet.userName()}`;
const loginCode = 401;
let testUserJSON: Record<string, any> = {};

describe('SPT-9860: Lockout User', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Create a test user for Lockout', () => {
    before(() => {
      testUserJSON = swimInstance.createUserJSON({
        displayName,
        username,
        password
      });
    });

    it('Create User', () => {
      swimInstance.openUsersListing();
      swimInstance.usersListing.clickNewUser();
      swimInstance.usersListing.userDialog.enterUserInfo(testUserJSON);
      swimInstance.usersListing.userDialog.saveUserEdit();
      swimInstance.logout();
    });

    it('Lockout Process', () => {
      swimInstance.setLoginState();
      swimInstance.loginPage.performLogin(username, incorrectPassword, loginCode, 'failed');
      swimInstance.loginPage.performLogin(username, incorrectPassword, loginCode, 'failed');
      swimInstance.loginPage.performLogin(username, incorrectPassword, loginCode, 'failed');
      swimInstance.loginPage.performLogin(username, incorrectPassword, loginCode, 'warning');
      swimInstance.loginPage.performLogin(username, incorrectPassword, loginCode, 'lock');
    });

    it('Unlock User', () => {
      swimInstance.setLoginState();
      swimInstance.loginPage.performLogin(Cypress.env('USERNAME'), Cypress.env('PASSWORD'));
      swimInstance.openUsersListing();
      swimInstance.usersListing.keywordSearchingUsers(displayName);
      swimInstance.usersListing.clickUserToEdit(displayName);
      swimInstance.usersListing.unlockUser(displayName);
      swimInstance.logout();
    });

    it('Validate Unlock', () => {
      swimInstance.setLoginState();
      swimInstance.loginPage.performLogin(username, password);
      swimInstance.logout();
    });

    it('Clean up and logout', () => {
      swimInstance.setLoginState();
      swimInstance.loginPage.performLogin(Cypress.env('USERNAME'), Cypress.env('PASSWORD'));
      swimInstance.openUsersListing();
      swimInstance.usersListing.removeUserInListing(displayName);
    });
  });

  after(() => {
    cy.logout();
  });
});

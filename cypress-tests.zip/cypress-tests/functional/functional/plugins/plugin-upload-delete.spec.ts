import * as swimInstance from '../../support/page-objects/swimInstance';

const carbonBlackDetails = {
  file: 'bundles/sw_vmware_carbon_black_cloud_endpoint_standard-1.0.0-linux.python36.swimbundle',
  name: 'Carbon Black Cloud Endpoint Standard',
  version: '1.0.0',
  subName: 'sw_vmware_carbon_black_cloud_endpoint_standard',
  description: 'Formerly Carbon Black Defense, this plugin integrates with Events, Processes and policies'
};
const virusTotalDetails = {
  file: 'bundles/sw_virus_total-3.1.3-linux.python36.swimbundle',
  name: 'VirusTotal',
  version: '3.1.3',
  subName: 'sw_virus_total',
  description: 'VirusTotal integration library'
};

describe('Basic verification of Plugin Upload and deletion.', () => {
  before(() => {
    cy.login();
    // TODO: SPT-12282 clean this up with the fix for the ticket.
    cy.cleanUpBundles();
    // cy.cleanUpBundles([carbonBlackDetails.subName, virusTotalDetails.subName]);

    cy.visitSwimlane('/');
  });

  describe('Upload multiple Plugins', () => {
    it('Navigate to the plugins listing.', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.openPluginsPage();
    });

    it('Upload plugins', () => {
      swimInstance.integrationsPage.uploadPlugins([
        { filePath: virusTotalDetails.file, encoding: 'base64' },
        { filePath: carbonBlackDetails.file, encoding: 'base64' }
      ]);
      swimInstance.integrationsPage.verifyPluginsUploaded([
        { ...carbonBlackDetails, ...{ status: 'New Plugin Installed' } },
        { ...virusTotalDetails, ...{ status: 'New Plugin Installed' } }
      ]);
      swimInstance.integrationsPage.closePluginUpload();
    });
  });

  describe('Verify plugins added to the list', () => {
    it('Find Plugin in list', () => {
      swimInstance.integrationsPage.findPlugin(carbonBlackDetails);
      swimInstance.integrationsPage.findPlugin(virusTotalDetails);
    });
  });

  describe('Remove uploaded plugins', () => {
    it('Delete plugins that were added.', () => {
      swimInstance.integrationsPage.deletePlugin(carbonBlackDetails);
      swimInstance.integrationsPage.deletePlugin(virusTotalDetails);
    });
  });

  after('User Logout', () => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

import * as swimInstance from '../../support/page-objects/swimInstance';

const invalidSwimlaneVersionDetails = {
  file: 'bundles/(eq99.0.0)sw_twitter-1.0.0-linux.python36.swimbundle',
  name: '(eq99.0.0)sw_twitter-1.0.0-linux.python36.swimbundle',
  subName: 'sw_twitter'
};

const virusTotalDetails = {
  file: 'bundles/sw_virus_total-3.1.3-linux.python36.swimbundle',
  name: 'VirusTotal',
  version: '3.1.3',
  subName: 'sw_virus_total',
  description: 'VirusTotal integration library'
};

describe('Basic verification of Plugin Upload and deletion.', () => {
  before(() => {
    cy.login();
    cy.cleanUpBundles();
    cy.visitSwimlane('/');
  });

  describe('Upload incompatible Plugins', () => {
    it('Navigate to the plugins listing.', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.openPluginsPage();
    });

    it('Upload bad plugin', () => {
      swimInstance.integrationsPage.uploadPlugins([
        { filePath: invalidSwimlaneVersionDetails.file, encoding: 'base64' }
      ]);
      swimInstance.integrationsPage.verifyPluginsUploaded(
        {
          name: invalidSwimlaneVersionDetails.name,
          status: 'Plugin Installation Failed'
        },
        'Swimlane supported version is not valid or incompatible with the target version.'
      );
      swimInstance.integrationsPage.closePluginUpload();
    });

    it('Upload good and bad plugin', () => {
      swimInstance.integrationsPage.uploadPlugins([
        { filePath: invalidSwimlaneVersionDetails.file, encoding: 'base64' },
        { filePath: virusTotalDetails.file, encoding: 'base64' }
      ]);
      swimInstance.integrationsPage.verifyPluginsUploaded(
        [
          { ...virusTotalDetails, ...{ status: 'New Plugin Installed' } },
          {
            ...invalidSwimlaneVersionDetails,
            ...{ status: 'Plugin Installation Failed' }
          }
        ],
        'Swimlane supported version is not valid or incompatible with the target version.'
      );
      swimInstance.integrationsPage.closePluginUpload();
    });
  });

  after('User Logout', () => {
    cy.logout();
  });
});

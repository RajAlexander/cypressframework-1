import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';
import { defaultHeaderHTML, defaultFooterHTML } from '../../support/page-objects/main-app-objects/pdfFormatting';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const newOrientation = 'Landscape';
const newHeaderCode = '<p>Hello World</p>\n<p>hi</p>';
const newFooterCode = '<p>The End</p>';

const APPLIST = [];
const WORKSPACELIST = [];

const scheduledSend = {
  shareType: 'Scheduled Send',
  disabled: false,
  Name: `QAFUNC-rep-${faker.random.words(5)}`.substring(0, 120).trim(),
  Notes: 'Some Notes',
  Recipients: { emails: [Cypress.env('EMAIL_USER')] },
  ReportControls: ['Include Link to Report in Swimlane When Email is Sent'],
  Schedule: {
    type: 'Recurring',
    frequency: 'Weekly',
    time: '12:00 AM',
    dayOfWeek: 'Sunday'
  }
};

describe('Shareable PDF Formatting Feature', () => {
  before(() => {
    cy.setExpandedMenu();

    cy.login();
    cy.visitSwimlane('/');

    cy.makeAPICall('GET', '/settings').then($response => {
      cy.log($response);
      $response.scheduledReportSettings.header = defaultHeaderHTML.replace(/{{}/g, '{');
      $response.scheduledReportSettings.footer = defaultFooterHTML.replace(/{{}/g, '{');
      $response.scheduledReportSettings.layout = 'portrait';
      cy.log(defaultHeaderHTML);
      (cy as any).makeAPICall('PUT', '/settings', $response);
    });
  });

  describe('Testing Application creation', () => {
    it('Create new App', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
      APPLIST.push(appName);
      WORKSPACELIST.push(`${appName} Workspace`);
    });

    it('Build fields into App', () => {
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.addField('Single-Line');
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('setup global pdf settings', () => {
    it('Open Email and PDF Settings', () => {
      swimInstance.openEmailSettings();
    });

    it('Change the Sharable PDF Settings', () => {
      swimInstance.emailSettings.setPageOrientation(newOrientation);
      swimInstance.emailSettings.setHeaderCode(newHeaderCode);
      swimInstance.emailSettings.setFooterCode(newFooterCode);
    });

    it('Save changes', () => {
      swimInstance.emailSettings.saveChanges();
    });
  });

  describe('Verify changes in scheduled reporting', () => {
    it('Open app default report', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.OpenAppListAll(appName);
    });

    it('Open Schedule report and verify pdf settings', () => {
      swimInstance.recordListing.clickMenuItem('Schedule');
      swimInstance.recordListing.scheduledSharingEditor.verifyPageOrientation(newOrientation);
      swimInstance.recordListing.scheduledSharingEditor.verifyHeaderCode(newHeaderCode);
      swimInstance.recordListing.scheduledSharingEditor.verifyFooterCode(newFooterCode);
    });

    it('Set up scheduled reporting so it can be saved', () => {
      swimInstance.recordListing.scheduledSharingEditor.setReportSharing({
        ...scheduledSend
      });
    });

    it('Change pdf Formatting', () => {
      swimInstance.recordListing.scheduledSharingEditor.setFooterCode(newHeaderCode);
      swimInstance.recordListing.scheduledSharingEditor.setHeaderCode(newFooterCode);
      swimInstance.recordListing.scheduledSharingEditor.setPageOrientation('Portrait');
      cy.wait(1000);
    });

    it('Save scheduled report', () => {
      swimInstance.recordListing.scheduledSharingEditor.clickSave();
      swimInstance.recordListing.scheduledSharingEditor.closeDialog();
    });
  });

  describe('Verify the changes in the scheduled reportign do not affect the global ones', () => {
    it('Open Email and PDF Settings', () => {
      swimInstance.openEmailSettings();
    });

    it('Verify the original changes were not overwritten', () => {
      swimInstance.emailSettings.verifyPageOrientation(newOrientation);
      swimInstance.emailSettings.verifyHeaderCode(newHeaderCode);
      swimInstance.emailSettings.verifyFooterCode(newFooterCode);
    });
  });

  describe('Cleanup and User Logout', () => {
    it('Remove the created application', () => {
      swimInstance.openAppAppletsList();
      APPLIST.forEach(name => swimInstance.appsAppletsListing.deleteExistingApp(name));
    });

    it('Remove the app workspace', () => {
      swimInstance.openWorkspaceList();
      WORKSPACELIST.forEach(name => swimInstance.workspacesListing.deleteWorkspace(name));
    });

    it('Reset PDF Settings', () => {
      (cy as any).makeAPICall('GET', '/settings').then($response => {
        cy.log($response);
        $response.scheduledReportSettings.header = defaultHeaderHTML.replace(/{{}/g, '{');
        $response.scheduledReportSettings.footer = defaultFooterHTML.replace(/{{}/g, '{');
        $response.scheduledReportSettings.layout = 'portrait';
        cy.log(defaultHeaderHTML);
        (cy as any).makeAPICall('PUT', '/settings', $response);
      });
    });
  });

  after(() => {
    cy.logout();
  });
});

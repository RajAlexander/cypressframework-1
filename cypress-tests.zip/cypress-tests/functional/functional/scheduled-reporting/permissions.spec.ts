import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const roleName = `QA-E2E-${faker.random.words(3)}`;
const appName = `QA-E2E- ${faker.random.words(3)}`;
const reportName = `QA-E2E-${faker.random.words(3)}`;

const bulkRecords = [
  { Text: 'on', Numeric: 123 },
  { Text: 'off', Numeric: 123 },
  { Text: 'on', Numeric: -10 },
  { Text: 'off', Numeric: -100 }
];

const scheduledSend = {
  shareType: 'Scheduled Send',
  disabled: false,
  Name: `QAFUNC-rep-${faker.random.words(3)}`,
  Notes: 'Some Notes',
  Recipients: { emails: [Cypress.env('EMAIL_USER')] },
  ReportControls: ['Include Link to Dashboard in Swimlane When Email is Sent'],
  Schedule: {
    type: 'Recurring',
    frequency: 'Weekly',
    time: '12:00 AM',
    dayOfWeek: 'Sunday'
  }
};

let appId = '';
let recordCount = 0;
const testUsersJSON: Array<Record<string, any>> = [];

describe('Scheduled Dashboard Feature', () => {
  before(() => {
    cy.setExpandedMenu();
    cy.login();

    cy.visitSwimlane('/');
  });

  describe('Create users for testing', () => {
    before(() => {
      testUsersJSON.push(swimInstance.createUserJSON({}));
      testUsersJSON.push(swimInstance.createUserJSON({}));
    });

    it('Create user to send an email to', () => {
      testUsersJSON.forEach(user => {
        cy.makeAPICall('POST', 'user', { ...user, notify: false }, 200);
      });
    });
  });

  describe('Create roles for testing', () => {
    it('Create roles', () => {
      swimInstance.openRolesListing();
      swimInstance.rolesListing.createNewRole({
        Name: roleName,
        Users: [testUsersJSON[0].displayName, testUsersJSON[1].displayName]
      });
    });
  });

  describe('Testing Application creation', () => {
    it('Create new App', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.setAppPermissions([{ name: roleName, permissions: { Read: true } }]);
      swimInstance.appsAppletsListing.appWizard.setRecordPermissions([{ name: roleName, permissions: { Read: true } }]);
      swimInstance.appsAppletsListing.appWizard.setWorkspacePermissions([
        { name: roleName, permissions: { Read: true } }
      ]);
      swimInstance.appsAppletsListing.appWizard.createApp();
    });

    it('Build fields into App', () => {
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.getAppID().then($appID => {
        appId = $appID;
      });
      swimInstance.appBuilder.addField('Single-Line');
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Reporting on record data', () => {
    before(() => {
      (cy as any).batchRecordCreateAPI(appId, bulkRecords);
      recordCount += bulkRecords.length;
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.OpenAppListAll(appName);
    });

    it('Create Report on Application', () => {
      swimInstance.recordListing.toggleShowRecordFields(['Text', 'Numeric']);
      swimInstance.recordListing.getRecordCount().then($recordCount => {
        expect($recordCount, `Verify current record count is ${recordCount}`).to.equal(recordCount);
      });
      swimInstance.recordListing.saveReport();
      swimInstance.recordListing.openCharts();
      swimInstance.recordListing.buildChart('Tracking Id', 'Text');
      swimInstance.recordListing.saveReportAs(reportName, true, [
        { name: roleName, permissions: { Read: true, Update: true } }
      ]);
    });
  });

  describe('Switch user to create scheduled reports', () => {
    it('log out/log in', () => {
      swimInstance.logout();
      swimInstance.loginPage.verifyElements();
      swimInstance.loginPage.performLogin(testUsersJSON[1].username, testUsersJSON[1].password);
    });

    it('open report', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.openReport(reportName);
      swimInstance.recordListing.clickMenuItem('Schedule');
    });

    it('Set scheduled report', () => {
      swimInstance.recordListing.scheduledSharingEditor.setReportSharing({
        ...scheduledSend
      });
      swimInstance.recordListing.scheduledSharingEditor.clickSave();
      swimInstance.recordListing.scheduledSharingEditor.closeDialog();
    });
  });

  describe('Switch to user with same role/permissions and verify scheduled reporting does not show', () => {
    it('log out/log in', () => {
      swimInstance.logout();
      swimInstance.loginPage.verifyElements();
      swimInstance.loginPage.performLogin(testUsersJSON[0].username, testUsersJSON[0].password);
    });

    it('Verify Scheduled report shows', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.verifyNoSchedReport(reportName);
    });
  });

  describe('Switch back to admin and test disabled user account.', () => {
    it('log out/log in', () => {
      swimInstance.logout();
      swimInstance.loginPage.verifyElements();
      swimInstance.loginPage.performLogin(Cypress.env('USERNAME'), Cypress.env('PASSWORD'));
    });

    it('Verify report icon shows enabled schedule', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.verifySchedReportDisabled(reportName, false);
    });

    it('Disable User', () => {
      swimInstance.openUsersListing();
      swimInstance.usersListing.clickUserToEdit(testUsersJSON[1].displayName);
      swimInstance.userEditor.disable();
      swimInstance.userEditor.save();
    });

    it('Verify report icon shows disabled schedule', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.verifySchedReportDisabled(reportName);
    });
  });

  describe('test enable user account does not enable scheduled reporting.', () => {
    it('Enable User', () => {
      swimInstance.openUsersListing();
      swimInstance.usersListing.clickUserToEdit(testUsersJSON[1].displayName);
      swimInstance.userEditor.disable(false);
      swimInstance.userEditor.save();
    });

    it('Verify report icon shows disabled schedule', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.verifySchedReportDisabled(reportName);
    });
  });

  describe('Remove user and see that scheduled report is removed.', () => {
    it('Remove User', () => {
      swimInstance.openUsersListing();
      swimInstance.usersListing.removeUserInListing(testUsersJSON[1].displayName);
      testUsersJSON.splice(1, 1);
    });

    it('Verify report icon is not shown.', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.verifyNoSchedReport(reportName);
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

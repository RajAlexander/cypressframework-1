import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const reportName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const appDescription = faker.lorem.sentence();
const bulkRecords = [
  { Text: 'on', Numeric: 123 },
  { Text: 'off', Numeric: 123 },
  { Text: 'on', Numeric: -10 },
  { Text: 'off', Numeric: -100 }
];
const scheduledSend = {
  shareType: 'Scheduled Send',
  disabled: false,
  Name: `QAFUNC-rep-${faker.random.words(30)}`.substring(0, 64).trim(),
  Notes: 'Some Notes',
  Recipients: { emails: [faker.internet.email()] },
  ReportControls: ['Include Link to Report in Swimlane When Email is Sent'],
  Schedule: {
    type: 'Recurring',
    frequency: 'Weekly',
    time: '12:00 AM',
    dayOfWeek: 'Sunday'
  }
};

let appId = '';
let recordCount = 0;

describe('Scheduled Reporting Feature', () => {
  before(() => {
    cy.setExpandedMenu();
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Testing Application creation', () => {
    it('Create new App', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.setAppDescription(appDescription);
      swimInstance.appsAppletsListing.appWizard.createApp();
    });

    it('Build fields into App', () => {
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.getAppID().then($appID => {
        appId = $appID;
      });
      swimInstance.appBuilder.addField('Single-Line');
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Reporting on record data', () => {
    before(() => {
      (cy as any).batchRecordCreateAPI(appId, bulkRecords);
      recordCount += bulkRecords.length;
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.OpenAppListAll(appName);
    });

    it('Create Report on Application', () => {
      swimInstance.recordListing.toggleShowRecordFields(['Text', 'Numeric']);
      swimInstance.recordListing.getRecordCount().then($recordCount => {
        expect($recordCount, `Verify current record count is ${recordCount}`).to.equal(recordCount);
      });
      swimInstance.recordListing.saveReport();
      swimInstance.recordListing.openCharts();
      swimInstance.recordListing.buildChart('Tracking Id', 'Text');
      swimInstance.recordListing.saveReportAs(reportName);
    });
  });

  describe('Scheduled reporting', () => {
    it('Open Schedule reporting for chart', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.openReport(reportName);
      swimInstance.recordListing.clickMenuItem('Schedule');
    });

    it('Set scheduled report', () => {
      swimInstance.recordListing.scheduledSharingEditor.setReportSharing({
        ...scheduledSend
      });
    });

    it('Save scheduled report', () => {
      swimInstance.recordListing.scheduledSharingEditor.clickSave();
      swimInstance.recordListing.scheduledSharingEditor.closeDialog();
    });
  });

  describe('Scheduled reporting', () => {
    it('remove the chart', () => {
      swimInstance.recordListing.closeCharts();
      swimInstance.recordListing.saveReport();
    });

    it('Reopen and verify scheduled report settings', () => {
      swimInstance.recordListing.editReport();
      swimInstance.recordListing.editReportDialog.editScheduledReport(scheduledSend.Name);
      swimInstance.recordListing.scheduledSharingEditor.verifySettings({
        report: reportName,
        ...scheduledSend,
        ReportControls: [...scheduledSend.ReportControls, 'Include Report Table'],
        Recipients: [].concat(scheduledSend.Recipients.emails || [], (scheduledSend.Recipients as any).userGroups || [])
      });
      swimInstance.recordListing.scheduledSharingEditor.closeDialog();
      swimInstance.recordListing.editReportDialog.close();
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

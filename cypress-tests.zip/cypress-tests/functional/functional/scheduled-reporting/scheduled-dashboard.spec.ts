import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';
import { defaultHeaderHTML, defaultFooterHTML } from '../../support/page-objects/main-app-objects/pdfFormatting';
import { verifyDoubleCheck } from '../../support/page-objects/main-app-objects/common-pieces/popupMessages';
const displayName = `QA-E2E-${faker.internet.userName()}`;
const groupName = `QA-E2E-${faker.random.words(3)}`;
const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const reportName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const appDescription = faker.lorem.sentence();
const dashboardNameValue = 'QA-E2E-' + faker.commerce.productName();
const cardName = `QA-E2E-${faker.commerce.productName()}`;
const cardName1 = `QA-E2E-${faker.commerce.productName()}`;
const cardName2 = `QA-E2E-${faker.commerce.productName()}`;
const bulkRecords = [
  { Text: 'on', Numeric: 123 },
  { Text: 'off', Numeric: 123 },
  { Text: 'on', Numeric: -10 },
  { Text: 'off', Numeric: -100 }
];
const defaultDashboard = {
  Name: '',
  Notes: ''
};
const defaultReportControls = {
  Recipients: '',
  ReportControls: ['Include Link to Dashboard in Swimlane When Email is Sent']
};
const defaultSchedule = {
  disabled: true,
  Schedule: { type: 'Recurring', frequency: 'Daily', time: '12:00 AM' }
};

const scheduledSend = {
  shareType: 'Scheduled Send',
  disabled: false,
  Name: `QAFUNC-rep-${faker.random.words(30)}`.substring(0, 200).trim(),
  Notes: 'Some Notes',
  Recipients: { emails: [Cypress.env('EMAIL_USER')] } as any,
  ReportControls: ['Include Link to Dashboard in Swimlane When Email is Sent'],
  Schedule: {
    type: 'Recurring',
    frequency: 'Weekly',
    time: '12:00 AM',
    dayOfWeek: 'Sunday'
  }
};

const oneTimeSend = {
  shareType: 'Scheduled Send',
  disabled: false,
  Name: `QAFUNC-1-${faker.random.words(5)}`.substring(0, 64).trim(),
  Notes: 'Some Notes',
  Recipients: {
    emails: [Cypress.env('EMAIL_USER')],
    userGroups: [displayName, groupName]
  },
  ReportControls: ['Include Link to Report in Swimlane When Email is Sent'],
  Schedule: { type: 'One Time', dateTime: '' }
};

const outgoingMailServerSettings = {
  Host: 'smtp.gmail.com',
  Port: '587',
  Username: Cypress.env('EMAIL_USER'),
  Password: Cypress.env('EMAIL_PASSWORD'),
  'From Email': Cypress.env('EMAIL_USER')
};

let testUserJSON: Record<string, any> = {};
let appId = '';
let recordCount = 0;
const downloadsFolder = 'functional/downloads';

describe('Scheduled Dashboard Feature', () => {
  before(() => {
    const oneTimeDate = new Date();
    oneTimeDate.setDate(oneTimeDate.getDate() + 2);
    oneTimeDate.setMinutes(oneTimeDate.getMinutes() + 3);
    oneTimeDate.setSeconds(0);
    oneTimeSend.Schedule.dateTime = oneTimeDate.toString();
    cy.task('clearDownloads');
    if (!Cypress.isBrowser('firefox')) {
      // since this call returns a promise, must tell Cypress to wait
      // for it to be resolved
      cy.log('Page.setDownloadBehavior');
      cy.wrap(
        Cypress.automation('remote:debugger:protocol', {
          command: 'Page.setDownloadBehavior',
          params: { behavior: 'allow', downloadPath: downloadsFolder }
        }),
        { log: false }
      );
    }

    cy.setExpandedMenu();
    cy.login();
    cy.visitSwimlane('/');

    // reset any header/footer PDF settings.
    cy.makeAPICall('GET', '/settings').then($response => {
      cy.log($response);
      $response.scheduledReportSettings.header = defaultHeaderHTML.replace(/{{}/g, '{');
      $response.scheduledReportSettings.footer = defaultFooterHTML.replace(/{{}/g, '{');
      $response.scheduledReportSettings.layout = 'portrait';
      cy.makeAPICall('PUT', '/settings', $response);
    });
  });

  describe('Create user for testing', () => {
    before(() => {
      testUserJSON = swimInstance.createUserJSON({
        roles: ['Administrator'],
        displayName
      });
    });

    it('Create user to send an email to', () => {
      swimInstance.openUsersListing();
      swimInstance.usersListing.clickNewUser();
      swimInstance.usersListing.userDialog.enterUserInfo(testUserJSON);
      swimInstance.usersListing.userDialog.saveUserEdit();
    });
  });

  describe('Create group for testing', () => {
    it('Create group to send an email to', () => {
      swimInstance.openGroupsListing();
      swimInstance.groupsListing.createNewGroup({
        Name: groupName,
        Users: [testUserJSON.displayName]
      });
    });
  });

  describe('Setup Outgoing Email', () => {
    it('Set Outgoing Email', () => {
      swimInstance.openEmailSettings();
      swimInstance.emailSettings.setOutgoingMailServer(outgoingMailServerSettings);
    });
  });

  describe('Testing Application creation', () => {
    it('Create new App', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.setAppDescription(appDescription);
      swimInstance.appsAppletsListing.appWizard.createApp();
    });

    it('Build fields into App', () => {
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.getAppID().then($appID => {
        appId = $appID;
      });
      swimInstance.appBuilder.addField('Single-Line');
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Reporting on record data', () => {
    before(() => {
      cy.batchRecordCreateAPI(appId, bulkRecords);
      recordCount += bulkRecords.length;
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.OpenAppListAll(appName);
    });

    it('Create Report on Application', () => {
      swimInstance.recordListing.toggleShowRecordFields(['Text', 'Numeric']);
      swimInstance.recordListing.getRecordCount().then($recordCount => {
        expect($recordCount, `Verify current record count is ${recordCount}`).to.equal(recordCount);
      });
      swimInstance.recordListing.saveReport();
      swimInstance.recordListing.openCharts();
      swimInstance.recordListing.buildChart('Tracking Id', 'Text');
      swimInstance.recordListing.saveReportAs(reportName);
    });
  });

  describe('Dashboard and Charts', () => {
    it('Create a Dashboard for Cards', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.dashboardPage.createDashboardOnEmpty();
      swimInstance.dashboardWizard.setDashboardNameAndDesc(dashboardNameValue, faker.lorem.sentence());
      swimInstance.dashboardWizard.createDashboard();
    });

    it('Add custom report as cards into dashboard', () => {
      swimInstance.dashboardPage.addCard();
      swimInstance.cardWizard.setCardDetails(cardName, 'Report', `${reportName} (${appName})`, faker.lorem.sentence());
      swimInstance.cardWizard.createCard();
      swimInstance.dashboardPage.save();
    });

    it('Add Default report as cards into dashboard', () => {
      swimInstance.dashboardPage.addCard();
      swimInstance.cardWizard.setCardDetails(cardName1, 'Report', `Default (${appName})`, faker.lorem.sentence());
      swimInstance.cardWizard.createCard();
      swimInstance.dashboardPage.save();
    });
  });

  describe('Dashboard reporting', () => {
    const continueAction = true;
    it('Open Dashboard reporting for dashboard', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.openDashboard(dashboardNameValue);
    });

    it('Adding a new card without saving', () => {
      swimInstance.dashboardPage.addCard();
      swimInstance.cardWizard.setCardDetails(cardName2, 'Report', `Default (${appName})`, faker.lorem.sentence());
      swimInstance.cardWizard.createCard();
      swimInstance.dashboardPage.clickMenuItem('Schedule');
      verifyDoubleCheck(
        'Save Confirmation',
        'You must save this dashboard before sharing. Save now?',
        continueAction,
        'Cancel'
      );
      swimInstance.dashboardPage.clickMenuItem('Schedule');
      verifyDoubleCheck(
        'Save Confirmation',
        'You must save this dashboard before sharing. Save now?',
        continueAction,
        'Ok'
      );
    });

    it('Validate default Dashboard scheduler', () => {
      swimInstance.dashboardPage.scheduledSharingEditor.verifySettings({
        report: dashboardNameValue,
        save: false,
        ...defaultDashboard,
        ...defaultReportControls,
        ...defaultSchedule
      });
    });

    it('Set scheduled Dashboard', () => {
      swimInstance.dashboardPage.scheduledSharingEditor.setReportSharing({
        ...scheduledSend
      });
    });

    it('Save scheduled Dashboard', () => {
      swimInstance.dashboardPage.scheduledSharingEditor.clickSave(true);
      swimInstance.dashboardPage.scheduledSharingEditor.closeDialog();
    });

    it('Reopen and verify scheduled Dashboard settings', () => {
      swimInstance.dashboardPage.verifyElements();
      swimInstance.dashboardPage.editDashboard();
      swimInstance.dashboardPage.editDashboardDialog.editScheduledDialogReport(
        scheduledSend.Name.substring(0, 64).trim()
      );
      swimInstance.dashboardPage.scheduledSharingEditor.verifySettings({
        report: dashboardNameValue,
        ...scheduledSend,
        Recipients: [].concat(scheduledSend.Recipients.emails || [], scheduledSend.Recipients.userGroups || [])
      });
      swimInstance.dashboardPage.scheduledSharingEditor.closeDialog();
    });

    it('Fill in one-time and save scheduled dashboard', () => {
      swimInstance.dashboardPage.clickMenuItem('Schedule');
      swimInstance.dashboardPage.scheduledSharingEditor.setReportSharing(oneTimeSend);
    });

    it('Save scheduled Dashboard', () => {
      swimInstance.dashboardPage.scheduledSharingEditor.clickSave(true);
      swimInstance.dashboardPage.scheduledSharingEditor.closeDialog();
    });

    it('Reopen and verify scheduled one-time Dashboard settings', () => {
      swimInstance.dashboardPage.editDashboard();
      swimInstance.dashboardPage.editDashboardDialog.editScheduledDialogReport(oneTimeSend.Name);
      swimInstance.dashboardPage.scheduledSharingEditor.verifySettings({
        report: dashboardNameValue,
        ...oneTimeSend,
        Recipients: [].concat(oneTimeSend.Recipients.emails || [], oneTimeSend.Recipients.userGroups || [])
      });
      swimInstance.dashboardPage.scheduledSharingEditor.closeDialog();
    });

    it('Open scheduled dashboard, set up Send Now', () => {
      swimInstance.dashboardPage.clickMenuItem('Email');
      swimInstance.dashboardPage.scheduledSharingEditor.verifySettings({
        report: dashboardNameValue,
        send: false,
        ...defaultDashboard,
        ...defaultReportControls
      });
      swimInstance.dashboardPage.scheduledSharingEditor.setReportSharing({
        shareType: 'Send Now',
        Name: 'QAFUNC Single Report',
        Notes: 'Some Notes',
        Recipients: { emails: [Cypress.env('EMAIL_USER')] },
        ReportControls: ['Include Link to Report in Swimlane When Email is Sent']
      });
    });

    it('Validate the send email', () => {
      swimInstance.dashboardPage.scheduledSharingEditor.clickSendNow(true);
      swimInstance.dashboardPage.scheduledSharingEditor.closeDialog();
    });

    it('Open Dashboard, set up download', () => {
      swimInstance.dashboardPage.clickMenuItem('Download');
      swimInstance.dashboardPage.scheduledSharingEditor.verifySettings({
        report: dashboardNameValue,
        download: false,
        ...defaultDashboard
      });
      swimInstance.dashboardPage.scheduledSharingEditor.downloadDashboard({
        Name: 'A name',
        Notes: 'Some Notes'
      });
    });

    it('Set up download with special characters', () => {
      swimInstance.dashboardPage.scheduledSharingEditor.downloadDashboard({
        Name: 'name~?.<>:|,;*"',
        Notes: 'Some Notes'
      });
    });

    // This test fails in CI/CD because the file gets named download, possible
    // that the test environment missing a library?
    xit('Set up download with special characters Non-ascii', () => {
      swimInstance.dashboardPage.scheduledSharingEditor.downloadReport({
        Name: 'reportĨ',
        Notes: 'Some Notes'
      });
    });

    it('Close scheduled report', () => {
      swimInstance.dashboardPage.scheduledSharingEditor.closeDialogNoSave();
    });

    it('Setup with a subset of cards', () => {
      const downloadData = {
        Name: 'A name',
        Notes: 'Some Notes',
        ReportCards: {}
      };
      downloadData.ReportCards[cardName1] = false;
      downloadData.ReportCards[cardName2] = false;
      swimInstance.dashboardPage.clickMenuItem('Download');
      swimInstance.dashboardPage.scheduledSharingEditor.verifyDashboardPreviewCards([cardName, cardName1, cardName2]);
      swimInstance.dashboardPage.scheduledSharingEditor.setReportSharing(downloadData);
      swimInstance.dashboardPage.scheduledSharingEditor.verifyDashboardPreviewCards([cardName]);
    });

    it('Close dashboard scheduled report', () => {
      swimInstance.dashboardPage.scheduledSharingEditor.closeDialogNoSave();
    });

    it('Verify more then one report shows in the report editor', () => {
      swimInstance.dashboardPage.editDashboard();
      swimInstance.dashboardPage.editDashboardDialog.verifySchedulesListed([
        oneTimeSend.Name,
        scheduledSend.Name.substring(0, 64).trim()
      ]);
    });

    it('Delete scheduler', () => {
      swimInstance.dashboardPage.editDashboardDialog.deleteScheduledDashboardReport(oneTimeSend.Name);
      swimInstance.dashboardPage.editDashboardDialog.close();
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

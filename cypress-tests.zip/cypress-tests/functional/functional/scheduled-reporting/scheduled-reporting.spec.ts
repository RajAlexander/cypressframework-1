import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';
import { defaultHeaderHTML, defaultFooterHTML } from '../../support/page-objects/main-app-objects/pdfFormatting';

const displayName = `QA-E2E-${faker.internet.userName()}`;
const groupName = `QA-E2E-${faker.random.words(3)}`;
const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const reportName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const appDescription = faker.lorem.sentence();
const bulkRecords = [
  { Text: 'on', Numeric: 123 },
  { Text: 'off', Numeric: 123 },
  { Text: 'on', Numeric: -10 },
  { Text: 'off', Numeric: -100 }
];
const defaultScheduledReport = {
  Name: '',
  Notes: ''
};

const defaultReportControls = {
  Recipients: '',
  ReportControls: ['Include Link to Report in Swimlane When Email is Sent']
};
const defaultSchedule = {
  disabled: true,
  Schedule: { type: 'Recurring', frequency: 'Daily', time: '12:00 AM' }
};

const scheduledSend: Record<string, any> = {
  shareType: 'Scheduled Send',
  disabled: false,
  Name: `QAFUNC-rep-${faker.random.words(30)}`.substring(0, 200).trim(),
  Notes: 'Some Notes',
  Recipients: { emails: [Cypress.env('EMAIL_USER')] },
  ReportControls: ['Include Link to Report in Swimlane When Email is Sent'],
  Schedule: {
    type: 'Recurring',
    frequency: 'Weekly',
    time: '12:00 AM',
    dayOfWeek: 'Sunday'
  }
};

const oneTimeSend = {
  shareType: 'Scheduled Send',
  disabled: false,
  Name: `QAFUNC-1-${faker.random.words(5)}`.substring(0, 64).trim(),
  Notes: 'Some Notes',
  Recipients: {
    emails: [Cypress.env('EMAIL_USER')],
    userGroups: [displayName, groupName]
  },
  ReportControls: ['Include Link to Report in Swimlane When Email is Sent'],
  Schedule: { type: 'One Time', dateTime: '' }
};

const outgoingMailServerSettings = {
  Host: 'smtp.gmail.com',
  Port: '587',
  Username: Cypress.env('EMAIL_USER'),
  Password: Cypress.env('EMAIL_PASSWORD'),
  'From Email': Cypress.env('EMAIL_USER')
};

let testUserJSON: Record<string, any> = {};
let appId = '';
let recordCount = 0;
let reportURL = '';
const downloadsFolder = 'functional/downloads';

describe('Scheduled Reporting Feature', () => {
  before(() => {
    const oneTimeDate = new Date();
    oneTimeDate.setDate(oneTimeDate.getDate() + 2);
    oneTimeDate.setMinutes(oneTimeDate.getMinutes() + 3);
    oneTimeDate.setSeconds(0);
    oneTimeSend.Schedule.dateTime = oneTimeDate.toString();
    cy.task('clearDownloads');
    if (!Cypress.isBrowser('firefox')) {
      // since this call returns a promise, must tell Cypress to wait
      // for it to be resolved
      cy.log('Page.setDownloadBehavior');
      cy.wrap(
        Cypress.automation('remote:debugger:protocol', {
          command: 'Page.setDownloadBehavior',
          params: { behavior: 'allow', downloadPath: downloadsFolder }
        }),
        { log: false }
      );
    }
    cy.setExpandedMenu();
    cy.login();
    cy.visitSwimlane('/');

    // reset any header/footer PDF settings.
    cy.makeAPICall('GET', '/settings').then($response => {
      cy.log($response);
      $response.scheduledReportSettings.header = defaultHeaderHTML.replace(/{{}/g, '{');
      $response.scheduledReportSettings.footer = defaultFooterHTML.replace(/{{}/g, '{');
      $response.scheduledReportSettings.layout = 'portrait';
      cy.makeAPICall('PUT', '/settings', $response);
    });
  });

  describe('Create user for testing', () => {
    before(() => {
      testUserJSON = swimInstance.createUserJSON({ displayName });
    });

    it('Create user to send an email to', () => {
      cy.makeAPICall('POST', 'user', { ...testUserJSON, notify: false });
    });
  });

  describe('Create group for testing', () => {
    it('Create group to send an email to', () => {
      swimInstance.openGroupsListing();
      swimInstance.groupsListing.createNewGroup({
        Name: groupName,
        Users: [testUserJSON.displayName]
      });
    });
  });

  describe('Setup Outgoing Email', { tags: ['#flaky', 'SPT-13518'] }, () => {
    it('Set Outgoing Email', () => {
      swimInstance.openEmailSettings();
      swimInstance.emailSettings.setOutgoingMailServer(outgoingMailServerSettings);
    });
  });

  describe('Testing Application creation', () => {
    it('Create new App', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.setAppDescription(appDescription);
      swimInstance.appsAppletsListing.appWizard.createApp();
    });

    it('Build fields into App', () => {
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.getAppID().then($appID => {
        appId = $appID;
      });
      swimInstance.appBuilder.addField('Single-Line');
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Reporting on record data', () => {
    before(() => {
      cy.batchRecordCreateAPI(appId, bulkRecords);
      recordCount += bulkRecords.length;
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.OpenAppListAll(appName);
    });

    it('Create Report on Application', () => {
      swimInstance.recordListing.toggleShowRecordFields(['Text', 'Numeric']);
      swimInstance.recordListing.getRecordCount().then($recordCount => {
        expect($recordCount, `Verify current record count is ${recordCount}`).to.equal(recordCount);
      });
      swimInstance.recordListing.saveReport();
      swimInstance.recordListing.openCharts();
      swimInstance.recordListing.buildChart('Tracking Id', 'Text');
      swimInstance.recordListing.saveReportAs(reportName);
    });
  });

  describe('Scheduled reporting', () => {
    it('Open Schedule reporting for chart', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.openReport(reportName);
      cy.url().then(url => {
        reportURL = url;
      });
      swimInstance.recordListing.clickMenuItem('Schedule');
    });

    it('Validate default report scheduler', () => {
      swimInstance.recordListing.scheduledSharingEditor.verifySettings({
        report: reportName,
        save: false,
        ...defaultScheduledReport,
        ...defaultReportControls,
        ...defaultSchedule
      });
    });

    it('Set scheduled report', () => {
      swimInstance.recordListing.scheduledSharingEditor.setReportSharing({
        ...scheduledSend
      });
      swimInstance.recordListing.scheduledSharingEditor.verifyReportPreview({
        Name: scheduledSend.Name.substring(0, 64),
        Notes: scheduledSend.Notes,
        reportName,
        reportURL
      });
    });

    it('Change notes and verify preview update', () => {
      swimInstance.recordListing.scheduledSharingEditor.setOptions({ Notes: 'Hello Fred' }, false);
      swimInstance.recordListing.scheduledSharingEditor.verifyReportPreview({
        Name: scheduledSend.Name.substring(0, 64),
        Notes: 'Hello Fred',
        reportName,
        reportURL
      });
      swimInstance.recordListing.scheduledSharingEditor.setOptions({ Notes: scheduledSend.Notes }, false);
    });

    it('Change the header code and verify preview update', () => {
      const tempHeader = '<p>{{}{{}Note}}</p><p>{{}{{}Name}}';
      swimInstance.recordListing.scheduledSharingEditor.setHeaderCode(tempHeader);
      swimInstance.recordListing.scheduledSharingEditor.verifyReportPreview({
        Name: scheduledSend.Notes,
        Notes: scheduledSend.Name.substring(0, 64),
        reportName,
        reportURL
      });
      swimInstance.recordListing.scheduledSharingEditor.revertHeaderCodeToSettings();
      cy.wait(1000);
    });

    it('Save scheduled report', () => {
      swimInstance.recordListing.scheduledSharingEditor.clickSave();
      swimInstance.recordListing.scheduledSharingEditor.closeDialog();
    });

    it('Reopen and verify scheduled report settings', () => {
      swimInstance.recordListing.editReport();
      swimInstance.recordListing.editReportDialog.editScheduledReport(scheduledSend.Name.substring(0, 64).trim());
      swimInstance.recordListing.scheduledSharingEditor.verifySettings({
        report: reportName,
        ...scheduledSend,
        Recipients: [].concat(scheduledSend.Recipients.emails || [], scheduledSend.Recipients.userGroups || [])
      });
      swimInstance.recordListing.scheduledSharingEditor.closeDialog();
      swimInstance.recordListing.editReportDialog.close();
    });

    it('Fill in one-time and save scheduler', () => {
      swimInstance.recordListing.clickMenuItem('Schedule');
      swimInstance.recordListing.scheduledSharingEditor.verifySettings({
        report: reportName,
        ...defaultScheduledReport,
        ...defaultReportControls
      });
      swimInstance.recordListing.scheduledSharingEditor.setReportSharing(oneTimeSend);
    });

    it('Save scheduled report', () => {
      swimInstance.recordListing.scheduledSharingEditor.clickSave();
      swimInstance.recordListing.scheduledSharingEditor.closeDialog();
    });

    it('Reopen and verify scheduled one-time report settings', () => {
      swimInstance.recordListing.editReport();
      swimInstance.recordListing.editReportDialog.editScheduledReport(oneTimeSend.Name);
      swimInstance.recordListing.scheduledSharingEditor.verifySettings({
        report: reportName,
        ...oneTimeSend,
        Recipients: [].concat(oneTimeSend.Recipients.emails || [], oneTimeSend.Recipients.userGroups || [])
      });
      swimInstance.recordListing.scheduledSharingEditor.closeDialog();
      swimInstance.recordListing.editReportDialog.close();
    });

    it('Open schedular, set up Send Now', () => {
      swimInstance.recordListing.clickMenuItem('Schedule');
      swimInstance.recordListing.scheduledSharingEditor.setReportSharing({
        shareType: 'Send Now',
        Name: 'QAFUNC Single Report',
        Notes: 'Some Notes',
        Recipients: { emails: [Cypress.env('EMAIL_USER')] },
        ReportControls: ['Include Link to Report in Swimlane When Email is Sent']
      });
    });

    it('Validate the send email', () => {
      swimInstance.recordListing.scheduledSharingEditor.clickSendNow();
      swimInstance.recordListing.scheduledSharingEditor.closeDialog('Leave');
    });

    it('Open schedular, set up download', () => {
      swimInstance.recordListing.clickMenuItem('Download');
      swimInstance.recordListing.scheduledSharingEditor.verifySettings({
        report: reportName,
        download: false,
        ...defaultScheduledReport
      });
      swimInstance.recordListing.scheduledSharingEditor.downloadReport({
        Name: 'A name is more then a name',
        Notes: 'Some Notes'
      });
    });

    it('Set up download with special characters', () => {
      swimInstance.recordListing.scheduledSharingEditor.downloadReport({
        Name: 'name~?.<>:|,;*"',
        Notes: 'Some Notes'
      });
    });

    // This test fails in CI/CD because the file gets named download, possible
    // that the test environment missing a library?
    xit('Set up download with special characters Non-ascii', () => {
      swimInstance.recordListing.scheduledSharingEditor.downloadReport({
        Name: 'reportĨ',
        Notes: 'Some Notes'
      });
    });

    it('Set up download with CSV also', () => {
      swimInstance.recordListing.scheduledSharingEditor.downloadReport({
        Name: 'Include CSV',
        Notes: 'Some Notes',
        ReportControls: ['Include Report Table as CSV File Attachment in Download']
      });
    });

    it('Close scheduled report', () => {
      swimInstance.recordListing.scheduledSharingEditor.closeDialogNoSave();
    });

    it('Verify more then one report shows in the report editor', () => {
      swimInstance.recordListing.editReport();
      swimInstance.recordListing.editReportDialog.verifySchedulesListed([
        oneTimeSend.Name,
        scheduledSend.Name.substring(0, 64).trim()
      ]);
      swimInstance.recordListing.editReportDialog.close();
    });

    it('Delete scheduler', () => {
      swimInstance.recordListing.editReport();
      swimInstance.recordListing.editReportDialog.deleteScheduledReport(oneTimeSend.Name);
      swimInstance.recordListing.editReportDialog.close();
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

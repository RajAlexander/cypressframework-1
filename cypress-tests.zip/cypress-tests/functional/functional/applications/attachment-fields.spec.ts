import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const appDescription = faker.lorem.sentence();

describe('App Builder - Attachment Fields', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('GIVEN: Add New application for Testing field parameters', () => {
    it('build base app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.setAppDescription(appDescription);
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(appName);
    });
  });

  describe('WHEN: Add Text Fields With Options', () => {
    it('Basic Attachments Field', () => {
      swimInstance.appBuilder.addField('Attachments');
      swimInstance.appBuilder.checkFieldProperties('Attachment', {
        'Read-only': false
      });
      swimInstance.appBuilder.checkFieldPermissions('Attachment');
      swimInstance.appBuilder.checkFieldAdvancedOptions('Attachment', {
        'Max Size': '100000',
        'Delete attachments': false
      });
      swimInstance.appBuilder.checkFieldSize('Attachment');
    });

    it('Read-only Attachments Field', () => {
      swimInstance.appBuilder.addField('Attachments');
      swimInstance.appBuilder.editAppComponent('Attachment (2)', {
        Name: 'Read-only Attachment',
        'Read-only': true
      });
    });

    it('Max Size 100kB Attachments Field', () => {
      swimInstance.appBuilder.addField('Attachments');
      swimInstance.appBuilder.editAppComponent('Attachment (2)', {
        Name: 'Max Size 100kB Attachment',
        'Max Size [kB]': '100'
      });
    });

    it('Help Above Attachments Field', () => {
      swimInstance.appBuilder.addField('Attachments');
      swimInstance.appBuilder.editAppComponent('Attachment (2)', {
        Name: 'Help Above Attachment',
        'Help Text': 'Above',
        'Help Text Content': 'This is HELP text above the value'
      });
    });

    it('Help Below Attachments Field', () => {
      swimInstance.appBuilder.addField('Attachments');
      swimInstance.appBuilder.editAppComponent('Attachment (2)', {
        Name: 'Help Below Attachment',
        'Help Text': 'Below',
        'Help Text Content': 'This is HELP text below the value'
      });
    });

    after(() => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('THEN: Verify the field properties in the record editor', () => {
    it('Create initial Record', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecordForApp(appName);
    });

    it('Verify Read-only property', () => {
      swimInstance.recordEditor.verifyReadOnlyFields('Read-only Attachment');
    });

    it('(SPT-5864) Verify Max Size 100kB property', () => {
      swimInstance.recordEditor.addAttachment('Max Size 100kB Attachment', 'attachments/60kb.pdf');
      swimInstance.recordEditor.verifyAttachmentsList('Max Size 100kB Attachment', ['60kb.pdf']);
      swimInstance.recordEditor.addAttachment('Max Size 100kB Attachment', 'attachments/103kb.json');
      swimInstance.recordEditor.verifyAttachmentsList('Max Size 100kB Attachment', ['60kb.pdf']);
      swimInstance.recordEditor.addAttachment('Max Size 100kB Attachment', 'attachments/44kb.png');
      swimInstance.recordEditor.verifyAttachmentsList('Max Size 100kB Attachment', ['60kb.pdf', '44kb.png']);
      swimInstance.recordEditor.addAttachment('Max Size 100kB Attachment', 'attachments/hello-world.xlsx');
      swimInstance.recordEditor.verifyAttachmentsList('Max Size 100kB Attachment', [
        '60kb.pdf',
        '44kb.png',
        'hello-world.xlsx'
      ]);
    });

    it('Verify Ability to Delete Attachment', () => {
      swimInstance.recordEditor.deleteAttachment('Max Size 100kB Attachment', '60kb.pdf');
    });

    it('Verify Help Above text', () => {
      swimInstance.recordEditor.verifyHelpText(
        { 'Help Above Attachment': 'This is HELP text above the value' },
        'above'
      );
    });

    it('Verify Help Below text', () => {
      swimInstance.recordEditor.verifyHelpText(
        { 'Help Below Attachment': 'This is HELP text below the value' },
        'below'
      );
    });

    after(() => {
      swimInstance.recordEditor.save();
    });
  });

  describe('THEN: Verify the attachment in the record editor', () => {
    it('Verify existing attachment', () => {
      swimInstance.recordEditor.getAttachment('Max Size 100kB Attachment', '44kb.png');
      swimInstance.recordEditor.closePreview();
    });

    it('Verify HTML existing attachment', () => {
      swimInstance.recordEditor.getAttachment('Max Size 100kB Attachment', 'hello-world.xlsx');
      swimInstance.recordEditor.closePreview();
    });

    after(() => {
      swimInstance.recordEditor.deleteRecord();
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const selectionValues = ['One', 'Two'];

describe('App Builder - Selection Fields', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('GIVEN: Add New application for Testing field parameters', () => {
    it('build base app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(appName);
    });
  });

  describe('WHEN: Add Selection Fields With Options', () => {
    it('Basic Selection Field', () => {
      swimInstance.appBuilder.addField('Selection');
      swimInstance.appBuilder.checkFieldProperties('Selection', {
        Required: false,
        'Read-only': false
      });
      swimInstance.appBuilder.checkFieldPermissions('Selection');
      swimInstance.appBuilder.checkFieldSize('Selection');
      swimInstance.appBuilder.editAppComponent('Selection', {
        AddEditValues: selectionValues
      });
    });

    it('Required Selection Field', () => {
      swimInstance.appBuilder.addField('Selection');
      swimInstance.appBuilder.editAppComponent('Selection (2)', {
        Name: 'Required Selection',
        AddEditValues: selectionValues,
        Required: true
      });
    });

    it('Read-only Selection Field', () => {
      swimInstance.appBuilder.addField('Selection');
      swimInstance.appBuilder.editAppComponent('Selection (2)', {
        Name: 'Read-only Selection',
        AddEditValues: selectionValues,
        'Read-only': true
      });
    });

    it('Help Above Selection Field', () => {
      swimInstance.appBuilder.addField('Selection');
      swimInstance.appBuilder.editAppComponent('Selection (2)', {
        Name: 'Help Above Selection',
        AddEditValues: selectionValues,
        'Help Text': 'Above',
        'Help Text Content': 'This is HELP Text above the value'
      });
    });

    it('Help Below Selection Field', () => {
      swimInstance.appBuilder.addField('Selection');
      swimInstance.appBuilder.editAppComponent('Selection (2)', {
        Name: 'Help Below Selection',
        AddEditValues: selectionValues,
        'Help Text': 'Below',
        'Help Text Content': 'This is HELP Text below the value'
      });
    });

    after(() => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('THEN: Verify the field properties in the record editor', () => {
    it('Create initial Record', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecordForApp(appName);
    });

    it('Verify Required property, field properties', () => {
      swimInstance.recordEditor.verifyRequiredFields('Required Selection');
    });

    it('Verify Required property, save dependency', () => {
      // Verify Save button is missing
      swimInstance.recordEditor.verifySaveButton(false);
      // Set a field that is not required.
      swimInstance.recordEditor.setFieldValue({
        Selection: { value: selectionValues[0] }
      });

      // Click save button and verify error.
      swimInstance.recordEditor.save('The record has validation error(s)!');
      swimInstance.recordEditor.verifyValueVerification({
        'Required Selection': `Error: Value must be populated before submitting`
      });

      // Set required field, can clear other field
      swimInstance.recordEditor.setFieldValue({
        Selection: { value: '' },
        'Required Selection': { value: selectionValues[1] }
      });
      // click save button and verify valid save.
      swimInstance.recordEditor.save();
    });

    it('Verify Read-only property', () => {
      swimInstance.recordEditor.verifyReadOnlyFields('Read-only Selection');
    });

    it('Verify Help Above Selection', () => {
      swimInstance.recordEditor.verifyHelpText(
        { 'Help Above Selection': 'This is HELP Text above the value' },
        'above'
      );
    });

    it('Verify Help Below Selection', () => {
      swimInstance.recordEditor.verifyHelpText(
        { 'Help Below Selection': 'This is HELP Text below the value' },
        'below'
      );
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

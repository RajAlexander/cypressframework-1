import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const minValue = faker.random.number();
const minMaxValues = [minValue, minValue + faker.random.number({ min: 5, max: 1000 })];

describe('App Builder - Numeric Fields', () => {
  before(() => {
    cy.login();

    cy.log(minMaxValues as any);
    cy.visitSwimlane('/');
  });

  describe('GIVEN: Add New application for Testing field parameters', () => {
    it('build base app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(appName);
    });
  });

  describe('WHEN: Add Numeric Fields With Options', () => {
    it('Basic Numeric Field', () => {
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.checkFieldProperties('Numeric', {
        Required: false,
        Unique: false,
        'Read-only': false,
        Calculated: false
      });
      swimInstance.appBuilder.checkFieldPermissions('Numeric');
      swimInstance.appBuilder.checkFieldAdvancedOptions('Numeric', {
        Prefix: '',
        Suffix: '',
        Min: '',
        Max: ''
      });
      swimInstance.appBuilder.checkFieldSize('Numeric');
    });

    it('Required Numeric Field', () => {
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.editAppComponent('Numeric (2)', {
        Name: 'Required Numeric',
        Required: true
      });
    });

    it('Unique Numeric Field', () => {
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.editAppComponent('Numeric (2)', {
        Name: 'Unique Numeric',
        Unique: true
      });
    });

    it('Read-only Numeric Field', () => {
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.editAppComponent('Numeric (2)', {
        Name: 'Read-only Numeric',
        'Read-only': true
      });
    });

    it('Calculated Numeric Field', () => {
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.editAppComponent('Numeric (2)', {
        Name: 'Calculated Numeric',
        Calculated: '[Numeric] + 1'
      });
    });

    it('Prefix Numeric Field', () => {
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.editAppComponent('Numeric (2)', {
        Name: 'Prefix Numeric',
        Prefix: 'Before'
      });
    });

    it('Suffix Numeric Field', () => {
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.editAppComponent('Numeric (2)', {
        Name: 'Suffix Numeric',
        Suffix: 'After'
      });
    });

    it('Min Numeric Field', () => {
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.editAppComponent('Numeric (2)', {
        Name: 'Min Numeric',
        Min: minMaxValues[0]
      });
    });

    it('Max Numeric Field', () => {
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.editAppComponent('Numeric (2)', {
        Name: 'Max Numeric',
        Max: minMaxValues[1]
      });
    });

    it('Min-Max Numeric Field', () => {
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.editAppComponent('Numeric (2)', {
        Name: 'Min-Max Numeric',
        Min: minMaxValues[0],
        Max: minMaxValues[1]
      });
    });

    it('Help Above Numeric Field', () => {
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.editAppComponent('Numeric (2)', {
        Name: 'Help Above Numeric',
        'Help Text': 'Above',
        'Help Text Content': 'This is HELP text above the value'
      });
    });

    it('Help Below Numeric Field', () => {
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.editAppComponent('Numeric (2)', {
        Name: 'Help Below Numeric',
        'Help Text': 'Below',
        'Help Text Content': 'This is HELP text below the value'
      });
    });

    after(() => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('THEN: Verify the field properties in the record editor', () => {
    it('Create initial Record', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecordForApp(appName);
    });

    it('Verify Required property, field properties', () => {
      swimInstance.recordEditor.verifyRequiredFields('Required Numeric');
    });

    it('Verify Required property, save dependency', () => {
      // Verify Save button is missing
      swimInstance.recordEditor.verifySaveButton(false);
      // Set a field that is not required.
      swimInstance.recordEditor.setFieldValue({
        Numeric: { value: minMaxValues[1] - 1 }
      });

      // Click save button and verify error.
      swimInstance.recordEditor.save('The record has validation error(s)!');
      swimInstance.recordEditor.verifyValueVerification({
        'Required Numeric': `Error: Value must be populated before submitting`
      });

      // Set required field, can clear other field
      swimInstance.recordEditor.setFieldValue({
        Numeric: { value: '' },
        'Required Numeric': { value: minMaxValues[0] - 1 }
      });
      // click save button and verify valid save.
      swimInstance.recordEditor.save();
    });

    // SPT-???? We currently do not tag a field as being unique
    it('Verify Unique Property, field properties', () => {
      swimInstance.recordEditor.setFieldValue({
        'Unique Numeric': { value: minMaxValues[1] - 1, isUnique: true }
      });
    });

    it('Verify Read-only property', () => {
      swimInstance.recordEditor.verifyReadOnlyFields('Read-only Numeric');
    });

    it('Verify Calculated Property', () => {
      swimInstance.recordEditor.verifyFieldIsCalculated(['Calculated Numeric']);
    });

    it('Verify Calculated Property', () => {
      swimInstance.recordEditor.verifyFieldValues({ Numeric: '', 'Calculated Numeric': '1' }, false);
      swimInstance.recordEditor.setFieldValue({
        Numeric: { value: minMaxValues[0], isCalculated: true }
      });
      swimInstance.recordEditor.verifyFieldValues(
        {
          Numeric: minMaxValues[0].toString(),
          'Calculated Numeric': (minMaxValues[0] + 1).toString()
        },
        false
      );
    });

    it('Verify Prefix property', () => {
      swimInstance.recordEditor.verifyPrefixFields({
        'Prefix Numeric': 'Before'
      });
    });

    it('Verify Suffix property', () => {
      swimInstance.recordEditor.verifySuffixFields({
        'Suffix Numeric': 'After'
      });
    });

    it('Verify Min value property', () => {
      swimInstance.recordEditor.setFieldValue({
        'Min Numeric': { value: minMaxValues[0] - 1 }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Min Numeric': `Error: Value must be a minimum of ${minMaxValues[0]}`
      });
      swimInstance.recordEditor.setFieldValue({
        'Min Numeric': { value: minMaxValues[0] }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Min Numeric': ''
      });
      swimInstance.recordEditor.setFieldValue({
        'Min Numeric': { value: minMaxValues[1] + 1 }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Min Numeric': ''
      });
    });

    it('Verify Max value property', () => {
      swimInstance.recordEditor.setFieldValue({
        'Max Numeric': { value: minMaxValues[1] + 1 }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Max Numeric': `Error: Value must be a maximum of ${minMaxValues[1]}`
      });
      swimInstance.recordEditor.setFieldValue({
        'Max Numeric': { value: minMaxValues[1] }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Max Numeric': ''
      });
      swimInstance.recordEditor.setFieldValue({
        'Max Numeric': { value: minMaxValues[0] - 1 }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Max Numeric': ''
      });
    });

    it('Verify Min/Max value property', () => {
      swimInstance.recordEditor.setFieldValue({
        'Min-Max Numeric': { value: minMaxValues[0] - 1 }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Min-Max Numeric': `Error: Value must be a minimum of ${minMaxValues[0]}`
      });
      swimInstance.recordEditor.setFieldValue({
        'Min-Max Numeric': { value: minMaxValues[0] }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Min-Max Numeric': ''
      });
      swimInstance.recordEditor.setFieldValue({
        'Min-Max Numeric': { value: minMaxValues[1] + 1 }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Min-Max Numeric': `Error: Value must be a maximum of ${minMaxValues[1]}`
      });
      swimInstance.recordEditor.setFieldValue({
        'Min-Max Numeric': { value: minMaxValues[1] }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Min-Max Numeric': ''
      });
    });

    it('Verify Help Above text', () => {
      swimInstance.recordEditor.verifyHelpText({ 'Help Above Numeric': 'This is HELP text above the value' }, 'above');
    });

    it('Verify Help Below text', () => {
      swimInstance.recordEditor.verifyHelpText({ 'Help Below Numeric': 'This is HELP text below the value' }, 'below');
    });

    after(() => {
      swimInstance.recordEditor.save('Record updated');
    });
  });

  describe('THEN(2): Verify unique field check on record save', () => {
    it('Create new record', () => {
      swimInstance.startNewRecordForApp(appName);
      swimInstance.recordEditor.setFieldValue({
        'Required Numeric': { value: minMaxValues[0] - 1 },
        'Unique Numeric': { value: minMaxValues[1] - 1, isUnique: true }
      });
    });

    it('Save the record to see unique value conflict.', () => {
      cy.wait(500); // giving the FE time to check field values
      swimInstance.recordEditor.save('The record has validation error(s)!', false);
      swimInstance.recordEditor.verifyValueVerification({
        'Unique Numeric': `Error: The value is not unique`
      });
    });

    it('Change unique value to not be a duplicate.', () => {
      swimInstance.recordEditor.setFieldValue({
        'Unique Numeric': { value: minMaxValues[1], isUnique: true }
      });
    });

    it('Save the record to see unique value.', () => {
      // Wait for pending validation requests to complete.
      // In new record page the save button should be disabled until the validation request complete.
      cy.get('.record-view .pending-messages', { timeout: 120000 }).should('not.be.visible');

      cy.wait(500); // giving the FE time to check field values

      swimInstance.recordEditor.save();
      swimInstance.recordEditor.verifyValueVerification({
        'Unique Numeric': ''
      });
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

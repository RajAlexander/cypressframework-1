import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const uniqueValue = faker.lorem.word();
// SPT-5958 Word count is off if there is non-alphanumeric charcters in it.
const wordCollection = faker.lorem.sentences(5).replace(/\./g, '').split(' ');
const fieldKey64Characters = 'this-lengthy-text-field-name-is-greater-than-sixty-four-characte';

describe('App Builder - Text Fields', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('GIVEN: Add New application for Testing field parameters', () => {
    it('build base app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(appName);
    });
  });

  describe('WHEN: Add Text Fields With Options', () => {
    it('Basic Text Field', () => {
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.checkFieldProperties('Text', {
        Required: false,
        Unique: false,
        'Read-only': false,
        Calculated: false,
        'Write Once': false
      });
      swimInstance.appBuilder.checkFieldPermissions('Text');
      swimInstance.appBuilder.checkFieldAdvancedOptions('Text', {
        Prefix: '',
        Suffix: '',
        Placeholder: '',
        Length: { Min: '', Max: '', Units: 'None' }
      });
      swimInstance.appBuilder.checkFieldSize('Text');
    });

    it('Required Text Field', () => {
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.editAppComponent('Text (2)', {
        Name: 'Required Text',
        Required: true
      });
    });

    it('Unique Text Field', () => {
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.editAppComponent('Text (2)', {
        Name: 'Unique Text',
        Unique: true
      });
    });

    it('Read-only Text Field', () => {
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.editAppComponent('Text (2)', {
        Name: 'Read-only Text',
        'Read-only': true
      });
    });

    it('Calculated Text Field', () => {
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.editAppComponent('Text (2)', {
        Name: 'Calculated Text',
        Calculated: 'CONCATENATE([Text],"1")'
      });
    });

    it('(SPT-3827) Calculated Text Field w/ Whitespace in Formula', () => {
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.editAppComponent('Text (2)', {
        Name: 'Calculated Text Formula with Whitespace',
        Calculated: ' =CONCATENATE ("text1", "text2") '
      });
    });

    it('Prefix Text Field', () => {
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.editAppComponent('Text (2)', {
        Name: 'Prefix Text',
        Prefix: 'Before'
      });
    });

    it('Suffix Text Field', () => {
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.editAppComponent('Text (2)', {
        Name: 'Suffix Text',
        Suffix: 'After'
      });
    });

    it('Placeholder Text Field', () => {
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.editAppComponent('Text (2)', {
        Name: 'Placeholder Text',
        Placeholder: 'Placeholder for text field'
      });
    });

    it('Min Words Text Field', () => {
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.editAppComponent('Text (2)', {
        Name: 'Min Words Text',
        Length: { Min: '2', Units: 'Words' }
      });
    });

    it('Max Words Text Field', () => {
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.editAppComponent('Text (2)', {
        Name: 'Max Words Text',
        Length: { Max: '5', Units: 'Words' }
      });
    });

    it('Min-Max Text Field', () => {
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.editAppComponent('Text (2)', {
        Name: 'Min-Max Words Text',
        Length: { Min: '2', Max: '5', Units: 'Words' }
      });
    });

    it('Min Chars Text Field', () => {
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.editAppComponent('Text (2)', {
        Name: 'Min Chars Text',
        Length: { Min: '2', Units: 'Characters' }
      });
    });

    it('Max Chars Text Field', () => {
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.editAppComponent('Text (2)', {
        Name: 'Max Chars Text',
        Length: { Max: '5', Units: 'Characters' }
      });
    });

    it('Min-Max Chars Field', () => {
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.editAppComponent('Text (2)', {
        Name: 'Min-Max Chars Text',
        Length: { Min: '2', Max: '5', Units: 'Characters' }
      });
    });

    it('Help Above Text Field', () => {
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.editAppComponent('Text (2)', {
        Name: 'Help Above Text',
        'Help Text': 'Above',
        'Help Text Content': 'This is HELP text above the value'
      });
    });

    it('Help Below Text Field', () => {
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.editAppComponent('Text (2)', {
        Name: 'Help Below Text',
        'Help Text': 'Below',
        'Help Text Content': 'This is HELP text below the value'
      });
    });

    it('Verify 64 character Field length', () => {
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.editAppComponent('Text (2)', {
        Name: 'This lengthy text field name is greater than sixty four characters long',
        Size: '75%'
      });
      swimInstance.appBuilder.verifyFieldKey(
        'This lengthy text field name is greater than sixty four characters long',
        fieldKey64Characters
      );
    });

    after(() => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('THEN: Verify the field properties in the record editor', () => {
    it('Create initial Record', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecordForApp(appName);
    });

    it('Verify Required property, field properties', () => {
      swimInstance.recordEditor.verifyRequiredFields('Required Text');
    });

    it('Verify Required property, save dependency', () => {
      // Verify Save button is missing
      swimInstance.recordEditor.verifySaveButton(false);
      // Set a field that is not required.
      swimInstance.recordEditor.setFieldValue({
        Text: { value: faker.company.catchPhrase() }
      });

      // Click save button and verify error.
      swimInstance.recordEditor.save('The record has validation error(s)!');
      swimInstance.recordEditor.verifyValueVerification({
        'Required Text': `Error: Value must be populated before submitting`
      });

      // Set required field, can clear other field
      swimInstance.recordEditor.setFieldValue({
        Text: { value: '' },
        'Required Text': { value: faker.hacker.phrase() }
      });
      // click save button and verify valid save.
      swimInstance.recordEditor.save();
    });

    // SPT-???? We currently do not tag a field as being unique
    it('Verify Unique Property, field properties', () => {
      swimInstance.recordEditor.setFieldValue({
        'Unique Text': { value: uniqueValue }
      });
    });

    it('Verify Read-only property', () => {
      swimInstance.recordEditor.verifyReadOnlyFields('Read-only Text');
    });

    it('Verify Calculated Property', () => {
      swimInstance.recordEditor.verifyFieldIsCalculated(['Calculated Text']);
      swimInstance.recordEditor.verifyFieldIsCalculated(['Calculated Text Formula with Whitespace']);
    });

    it('Verify Calculated Value', () => {
      swimInstance.recordEditor.verifyFieldValues({ Text: '', 'Calculated Text': '1' }, false);
      swimInstance.recordEditor.verifyFieldValues(
        { Text: '', 'Calculated Text Formula with Whitespace': 'text1text2' },
        false
      );
      swimInstance.recordEditor.setFieldValue({
        Text: { value: uniqueValue }
      });
      swimInstance.recordEditor.verifyFieldValues({ Text: uniqueValue, 'Calculated Text': `${uniqueValue}1` }, false);
    });

    it('Verify Prefix property', () => {
      swimInstance.recordEditor.verifyPrefixFields({ 'Prefix Text': 'Before' });
    });

    it('Verify Suffix property', () => {
      swimInstance.recordEditor.verifySuffixFields({ 'Suffix Text': 'After' });
    });

    it('Verify Placeholder property', () => {
      swimInstance.recordEditor.verifyPlaceholderFields({
        'Placeholder Text': 'Placeholder for text field'
      });
    });

    it('Verify Min Words value property', () => {
      swimInstance.recordEditor.setFieldValue({
        'Min Words Text': { value: wordCollection.slice(0, 1).join(' ') }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Min Words Text': `Error: Value must be a minimum length of 2 words`
      });
      swimInstance.recordEditor.setFieldValue({
        'Min Words Text': { value: wordCollection.slice(0, 4).join(' ') }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Min Words Text': ''
      });
      swimInstance.recordEditor.setFieldValue({
        'Min Words Text': { value: wordCollection.slice(0, 7).join(' ') }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Min Words Text': ''
      });
    });

    it('Verify Max Words value property', () => {
      swimInstance.recordEditor.setFieldValue({
        'Max Words Text': { value: wordCollection.slice(0, 6).join(' ') }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Max Words Text': `Error: Value must be a maximum length of 5 words`
      });
      swimInstance.recordEditor.setFieldValue({
        'Max Words Text': { value: wordCollection.slice(0, 5).join(' ') }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Max Words Text': ''
      });
      swimInstance.recordEditor.setFieldValue({
        'Max Words Text': { value: wordCollection.slice(0, 1).join(' ') }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Max Words Text': ''
      });
    });

    it('Verify Min-Max Words value property', () => {
      swimInstance.recordEditor.setFieldValue({
        'Min-Max Words Text': { value: wordCollection.slice(0, 1).join(' ') }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Min-Max Words Text': `Error: Value must be a minimum length of 2 words`
      });
      swimInstance.recordEditor.setFieldValue({
        'Min-Max Words Text': { value: wordCollection.slice(0, 2).join(' ') }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Min-Max Words Text': ''
      });
      swimInstance.recordEditor.setFieldValue({
        'Min-Max Words Text': { value: wordCollection.slice(0, 6).join(' ') }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Min-Max Words Text': `Error: Value must be a maximum length of 5 words`
      });
      swimInstance.recordEditor.setFieldValue({
        'Min-Max Words Text': { value: wordCollection.slice(0, 5).join(' ') }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Min-Max Words Text': ''
      });
    });

    it('Verify Min Chars value property', () => {
      swimInstance.recordEditor.setFieldValue({
        'Min Chars Text': { value: 'a' }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Min Chars Text': `Error: Value must be a minimum length of 2 characters`
      });
      swimInstance.recordEditor.setFieldValue({
        'Min Chars Text': { value: 'abcde' }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Min Chars Text': ''
      });
      swimInstance.recordEditor.setFieldValue({
        'Min Chars Text': { value: 'abcdergh' }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Min Chars Text': ''
      });
    });

    it('Verify Max Chars value property', () => {
      swimInstance.recordEditor.setFieldValue({
        'Max Chars Text': { value: 'abcdergh' }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Max Chars Text': `Error: Value must be a maximum length of 5 characters`
      });
      swimInstance.recordEditor.setFieldValue({
        'Max Chars Text': { value: 'abcde' }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Max Chars Text': ''
      });
      swimInstance.recordEditor.setFieldValue({
        'Max Chars Text': { value: 'a' }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Max Chars Text': ''
      });
    });

    it('Verify Min-Max Chars value property', () => {
      swimInstance.recordEditor.setFieldValue({
        'Min-Max Chars Text': { value: 'a' }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Min-Max Chars Text': `Error: Value must be a minimum length of 2 characters`
      });
      swimInstance.recordEditor.setFieldValue({
        'Min-Max Chars Text': { value: 'ab' }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Min-Max Chars Text': ''
      });
      swimInstance.recordEditor.setFieldValue({
        'Min-Max Chars Text': { value: 'abdftr' }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Min-Max Chars Text': `Error: Value must be a maximum length of 5 characters`
      });
      swimInstance.recordEditor.setFieldValue({
        'Min-Max Chars Text': { value: 'asdvf' }
      });
      swimInstance.recordEditor.verifyValueVerification({
        'Min-Max Chars Text': ''
      });
    });

    it('Verify Help Above text', () => {
      swimInstance.recordEditor.verifyHelpText({ 'Help Above Text': 'This is HELP text above the value' }, 'above');
    });

    it('Verify Help Below text', () => {
      swimInstance.recordEditor.verifyHelpText({ 'Help Below Text': 'This is HELP text below the value' }, 'below');
    });

    after(() => {
      swimInstance.recordEditor.save('Record updated');
    });
  });

  describe('THEN(2): Verify unique field check on record save', () => {
    it('Create new record', () => {
      swimInstance.startNewRecordForApp(appName);
      swimInstance.recordEditor.setFieldValue({
        'Required Text': { value: faker.name.jobType() },
        'Unique Text': { value: uniqueValue, isUnique: true }
      });
    });

    it('Save the record to see unique value conflict.', () => {
      cy.wait(500); // Validation requests wait..
      swimInstance.recordEditor.save('The record has validation error(s)!');
      swimInstance.recordEditor.verifyValueVerification({
        'Unique Text': `Error: The value is not unique`
      });
    });

    it('Change unique value to not be a duplicate.', () => {
      swimInstance.recordEditor.setFieldValue({
        'Unique Text': { value: `${uniqueValue}1`, isUnique: true }
      });
    });

    it('Save the record to see unique value.', () => {
      // Wait for pending validation requests to complete.
      // In new record page the save button should be disabled until the validation request complete.
      cy.get('.record-view .pending-messages', { timeout: 120000 }).should('not.be.visible');

      cy.wait(500); // Validation requests wait..

      swimInstance.recordEditor.save();
      swimInstance.recordEditor.verifyValueVerification({
        'Unique Text': ''
      });
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

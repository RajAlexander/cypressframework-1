import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const appDescription = faker.lorem.sentence();

describe('App Builder - Comments Fields', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('GIVEN: Add New application for Testing field parameters', () => {
    it('build base app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.setAppDescription(appDescription);
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(appName);
    });
  });

  describe('WHEN: Add Comments Fields With Options', () => {
    it('Basic Comments Field', () => {
      swimInstance.appBuilder.addField('Comments');
      swimInstance.appBuilder.checkFieldProperties('Comments', {});
      swimInstance.appBuilder.checkFieldPermissions('Comments');
      swimInstance.appBuilder.checkFieldAdvancedOptions('Comments');
      swimInstance.appBuilder.checkFieldSize('Comments', '50%');
    });

    it('Help Above Comments Field', () => {
      swimInstance.appBuilder.addField('Comments');
      swimInstance.appBuilder.editAppComponent('Comments (2)', {
        Name: 'Help Above Comments',
        'Help Text': 'Above',
        'Help Text Content': 'This is HELP text above the value'
      });
    });

    it('Help Below Comments Field', () => {
      swimInstance.appBuilder.addField('Comments');
      swimInstance.appBuilder.editAppComponent('Comments (2)', {
        Name: 'Help Below Comments',
        'Help Text': 'Below',
        'Help Text Content': 'This is HELP text below the value'
      });
    });

    after(() => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('THEN: Verify the field properties in the record editor', () => {
    it('Create initial Record', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecordForApp(appName);
    });

    it('Verify Help Above text', () => {
      swimInstance.recordEditor.verifyHelpText({ 'Help Above Comments': 'This is HELP text above the value' }, 'above');
    });

    it('Verify Help Below text', () => {
      swimInstance.recordEditor.verifyHelpText({ 'Help Below Comments': 'This is HELP text below the value' }, 'below');
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

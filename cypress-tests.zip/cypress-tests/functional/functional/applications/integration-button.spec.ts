import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const taskName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 64);
const pythonCode = 'import time \ntime.sleep(1)\nprint(sw_context.inputs["textIn"])';

describe('App Builder - Integration button', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Create an app to test the integration button', () => {
    it('create an app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(appName);
    });
  });

  describe('Drag and drop integration button', () => {
    it('Add an integration button in the app builder', () => {
      swimInstance.appBuilder.addLayout('Integration');
      swimInstance.appBuilder.checkFieldProperties('Integration', {});
    });
    after(() => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Create a task from the integration button', () => {
    it('Create a task from the integration button and open it', () => {
      swimInstance.appBuilder.integrationTask('create');
      swimInstance.integrationsPage.setupTask('Python 3', taskName, appName);
      swimInstance.integrationsPage.setBypassTimeout(false);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: pythonCode,
        inputs: { Variable: 'textIn', Type: 'Record', Field: 'Tracking Id' }
      });
      swimInstance.integrationsPage.saveCurrentTask(true, false);
      swimInstance.appBuilder.verifyTaskName(taskName);
    });
  });

  describe('Edit the task from the integration button', () => {
    it('Edit the task created and remove it', () => {
      swimInstance.appBuilder.integrationTask('edit', taskName);
      swimInstance.integrationsPage.removeTask();
      swimInstance.appBuilder.integrationTask('remove');
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

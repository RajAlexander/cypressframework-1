import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 64);
const defaultWhoIsOutput =
  '[\n  {\n    "status": $status$,\n    "sw_task_error_message": "",\n    "dnssec": null,\n    "sw_task_stack_trace": "",\n    "domain_name": $domain_name$,\n    "whois_server": null,\n    "address": null,\n    "name_servers": null,\n    "org": null,\n    "emails": $emails$,\n    "city": null,\n    "name": null,\n    "country": null,\n    "zipcode": null,\n    "sw_task_status": "success",\n    "state": null,\n    "registrar": null,\n    "referral_url": null,\n    "sw_task_error_type": "",\n    "stdOutput": null\n  }\n]';

let appAcronym = '';

function personalized(baseText, inserts = {}) {
  return baseText.replace(/\$(.*?)\$/g, function (placeholder) {
    return inserts[placeholder.substring(1, placeholder.length - 1)] || 'null';
  });
}

describe('Using Widget editor', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Create App', () => {
    it('build app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.getAppAcronym().then(acronym => {
        appAcronym = acronym;
      });
      swimInstance.appsAppletsListing.appWizard.createApp();
    });

    it('Add text fields & widget', () => {
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.addField('Single-Line');
      swimInstance.appBuilder.addLayout('Widget');
      swimInstance.appBuilder.saveApplication();
    });

    it('Open widget editor', () => {
      swimInstance.appBuilder.clickOnField('Widget');
      swimInstance.appBuilder.openWidgetEditor();
    });

    it('Create new record from the widget', () => {
      swimInstance.appBuilder.editRecordFromWidget(
        personalized(defaultWhoIsOutput, {
          status: '"ACTIVE"',
          domain_name: '"WHITEHOUSE.GOV"'
        }),
        {
          newRecord: { Text: { value: 'whitehouse.gov' } }
        }
      );
    });

    it('Update a record in the widget', () => {
      swimInstance.appBuilder.editRecordFromWidget(
        personalized(defaultWhoIsOutput, {
          status: '"ACTIVE"',
          domain_name: '"NASA.GOV"',
          emails: '"soc@nasa.gov"'
        }),
        {
          fromRecord: `${appAcronym}-1`,
          updateRecord: { Text: { value: 'testing' } }
        }
      );
    });

    it('Close widget editor', () => {
      swimInstance.appBuilder.closeWidgetEditor();
      swimInstance.appBuilder.saveApplication();
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

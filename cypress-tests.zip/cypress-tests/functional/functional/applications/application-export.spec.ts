import faker from 'faker/locale/en';

import * as swimInstance from '../../support/page-objects/swimInstance';
import { makeApplicationWithFields } from '../../support/data-generation';
import { verifyAppListEllipsisDropDown } from '../../support/page-objects/main-app-objects/appAppletList';
import { verifyEditEllipsisDropdownList } from '../../support/page-objects/main-app-objects/admin-pages/app-builder';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const appIssuesName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const randomInteger = faker.datatype.number({ min: -100, max: 100 });
const roleName = `QA-E2E- ${faker.random.words(3)}`;
const assetName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const testTaskName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const testAsset100Settings = {
  Username: Cypress.env('USERNAME'),
  Password: Cypress.env('PASSWORD')
};

let testUserJSON: Record<string, any> = {};

const application = makeApplicationWithFields(
  [
    {
      id: faker.random.uuid(),
      fieldType: 'numeric',
      inputType: 'numeric'
    }
  ],
  'ZZZZ',
  appName
);

describe('App Builder - Export Application', () => {
  before(() => {
    cy.login();
    cy.cleanupSwimlane();
    cy.visitSwimlane('/');

    // create a test user
    testUserJSON = swimInstance.createUserJSON({});

    cy.makeAPICall('POST', 'user', { ...testUserJSON, notify: false }).then(body => {
      testUserJSON = {
        ...body,
        ...testUserJSON
      };
    });

    cy.makeAPICall('POST', 'app', application);
  });

  describe('export app with key store removal issue', () => {
    let key = '';
    let taskName = '';

    it('Navigate to the integrations page and add new key store', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.openKeyStorePage();
      key = `qa-e2e-${faker.lorem.word()}${faker.lorem.word()}`;
      taskName = `${key}-task`;
      swimInstance.integrationsPage.addNewKeyStore(key, 'keyStoreValue');
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', taskName);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: '#',
        inputs: { Type: 'Key Store', Key: key, Variable: 'Text' }
      });
      swimInstance.integrationsPage.saveCurrentTask();
    });

    it('Create a new app and add integration', () => {
      const app = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(app);
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(app);
      swimInstance.appBuilder.addLayout('Integration');
      swimInstance.appBuilder.editAppComponent('Integration', {
        Task: taskName
      });
    });

    it('Save Application and then export', () => {
      swimInstance.appBuilder.saveApplication();
      swimInstance.appBuilder.exportApplication({ hasCredIssues: true });
    });

    it('Cleanup Key store', () => {
      if (key) {
        swimInstance.openIntegrations();
        swimInstance.integrationsPage.openKeyStorePage();
        swimInstance.integrationsPage.deleteKeystore(key);
      }
    });
  });

  describe('export app with issues', () => {
    it('Upload plugin', () => {
      swimInstance.integrationsPage.checkForExistingBundle('sw_test_plugin', '6.0.0');
    });

    it('Create Test Plugin Asset', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewAsset('Test Plugin', {
        Name: assetName,
        parameters: testAsset100Settings
      });
    });

    it('Create test Task for Asset', () => {
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Test Plugin IO changes', testTaskName);
      swimInstance.integrationsPage.editCurrentTask({
        Name: testTaskName,
        Asset: assetName
      });
      swimInstance.integrationsPage.editTaskConfiguration({
        Input2: ['Literal Value', randomInteger],
        Input4: ['Literal Value', true],
        Input1: ['Literal Value', randomInteger, true]
      });
      swimInstance.integrationsPage.saveCurrentTask();
    });

    it('Add Integration button', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appIssuesName);
      swimInstance.appsAppletsListing.appWizard.createApp();

      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.addLayout('Integration');
      swimInstance.appBuilder.editAppComponent('Integration', {
        Task: testTaskName
      });
    });

    it('Attempt to Export Application before saving', () => {
      swimInstance.appBuilder.exportApplication({ performSave: false });
    });

    it('Save Application and then export', () => {
      swimInstance.appBuilder.saveApplication();
      swimInstance.appBuilder.exportApplication({ hasCredIssues: true });
    });
  });

  describe('export app with no issues', () => {
    it('Create non-admin user for testing', () => {
      swimInstance.openRolesListing();
      swimInstance.rolesListing.createNewRole({
        Name: roleName,
        Users: [testUserJSON.displayName],
        Permissions: {
          Applications: [
            {
              name: 'Global Applications',
              settings: ['Read', 'Create', 'Export', 'Delete', 'Update']
            }
          ]
        }
      });
    });

    it('Attempt to Export Application (without issues) before saving', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.editExistingApp(appName);
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.exportApplication({ performSave: false });
    });

    it('Save Application and then export without issues', () => {
      swimInstance.appBuilder.saveApplication();
      swimInstance.appBuilder.exportApplication();
    });

    it('Log out and then log in as non-admin user', () => {
      swimInstance.logout();
      swimInstance.loginPage.performLogin(testUserJSON.username, testUserJSON.password);
    });

    it('Verify that non-admin user is unable to export applications on app page', () => {
      swimInstance.openAppAppletsList();
      verifyAppListEllipsisDropDown(
        ['Builder', 'Workflow', 'Settings', 'Copy', 'Copy URL to Clipboard', 'Delete'],
        appName
      );
    });

    it('Verify that non-admin user is unable to export applications in editor', () => {
      swimInstance.appsAppletsListing.editExistingApp(appName);
      verifyEditEllipsisDropdownList(['Validate', 'Manage Export Templates', 'History', 'Delete Application']);
    });

    after(() => {
      cy.logout(); // Log out as user
      cy.login(); // Log back in as admin
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

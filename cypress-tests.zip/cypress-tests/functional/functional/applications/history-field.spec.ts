import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);

describe('App Builder - History Fields', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('GIVEN: Add New application for Testing field parameters', () => {
    it('build base app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
    });
  });

  describe('WHEN: Add History Fields With Options', () => {
    it('Basic History Field', () => {
      swimInstance.appBuilder.addField('History');
      swimInstance.appBuilder.checkFieldProperties('History', {});
      swimInstance.appBuilder.checkFieldPermissions('History');
      swimInstance.appBuilder.checkFieldAdvancedOptions('History');
      swimInstance.appBuilder.checkFieldSize('History', '50%');
    });

    it('Help Above History Field', () => {
      swimInstance.appBuilder.addField('History');
      swimInstance.appBuilder.editAppComponent('History (2)', {
        Name: 'Help Above History',
        'Help Text': 'Above',
        'Help Text Content': 'This is HELP text above the value'
      });
    });

    it('Help Below History Field', () => {
      swimInstance.appBuilder.addField('History');
      swimInstance.appBuilder.editAppComponent('History (2)', {
        Name: 'Help Below History',
        'Help Text': 'Below',
        'Help Text Content': 'This is HELP text below the value'
      });
    });

    after(() => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('THEN: Verify the field properties in the record editor', () => {
    it('Create initial Record', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecordForApp(appName);
    });

    it('Verify Help Above text', () => {
      swimInstance.recordEditor.verifyHelpText({ 'Help Above History': 'This is HELP text above the value' }, 'above');
    });

    it('Verify Help Below text', () => {
      swimInstance.recordEditor.verifyHelpText({ 'Help Below History': 'This is HELP text below the value' }, 'below');
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

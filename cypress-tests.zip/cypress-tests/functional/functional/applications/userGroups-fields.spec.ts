import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);

describe('App Builder - Users/Groups Fields', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('GIVEN: Add New application for Testing field parameters', () => {
    it('build base app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(appName);
    });
  });

  describe('WHEN: Add Users/Groups Fields With Options', () => {
    it('Basic Users/Groups Field', () => {
      swimInstance.appBuilder.addField('Users/Groups');
      swimInstance.appBuilder.checkFieldProperties('User/Groups', {
        Required: false,
        'Read-only': false
      });
      swimInstance.appBuilder.checkFieldPermissions('User/Groups');
      swimInstance.appBuilder.checkFieldSize('User/Groups');
    });

    it('Required Users/Groups Field', () => {
      swimInstance.appBuilder.addField('Users/Groups');
      swimInstance.appBuilder.editAppComponent('User/Groups (2)', {
        Name: 'Required User/Groups',
        Required: true
      });
    });

    it('Read-only Users/Groups Field', () => {
      swimInstance.appBuilder.addField('Users/Groups');
      swimInstance.appBuilder.editAppComponent('User/Groups (2)', {
        Name: 'Read-only User/Groups',
        'Read-only': true
      });
    });

    it('Help Above Users/Groups Field', () => {
      swimInstance.appBuilder.addField('Users/Groups');
      swimInstance.appBuilder.editAppComponent('User/Groups (2)', {
        Name: 'Help Above User/Groups',
        'Help Text': 'Above',
        'Help Text Content': 'This is HELP Text above the value'
      });
    });

    it('Help Below Users/Groups Field', () => {
      swimInstance.appBuilder.addField('Users/Groups');
      swimInstance.appBuilder.editAppComponent('User/Groups (2)', {
        Name: 'Help Below User/Groups',
        'Help Text': 'Below',
        'Help Text Content': 'This is HELP Text below the value'
      });
    });

    after(() => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('THEN: Verify the field properties in the record editor', () => {
    it('Create initial Record', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecordForApp(appName);
    });

    it('Verify Required property, field properties', () => {
      swimInstance.recordEditor.verifyRequiredFields('Required User/Groups');
    });

    it('Verify Required property, save dependency', () => {
      // Verify Save button is missing
      swimInstance.recordEditor.verifySaveButton(false);
      // Set a field that is not required.
      swimInstance.recordEditor.setFieldValue({
        'User/Groups': { value: 'admin' }
      });

      // Click save button and verify error.
      swimInstance.recordEditor.save('The record has validation error(s)!');
      swimInstance.recordEditor.verifyValueVerification({
        'Required User/Groups': `Error: Value must be populated before submitting`
      });

      // Set required field, can clear other field
      swimInstance.recordEditor.setFieldValue({
        'User/Groups': { value: '' },
        'Required User/Groups': { value: 'admin' }
      });
      // click save button and verify valid save.
      swimInstance.recordEditor.save();
    });

    it('Verify Read-only property', () => {
      swimInstance.recordEditor.verifyReadOnlyFields('Read-only User/Groups');
    });

    it('Verify Help Above Users/Groups', () => {
      swimInstance.recordEditor.verifyHelpText({ 'Help Above Text': 'This is HELP Text above the value' }, 'above');
    });

    it('Verify Help Below Users/Groups', () => {
      swimInstance.recordEditor.verifyHelpText({ 'Help Below Text': 'This is HELP Text below the value' }, 'below');
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

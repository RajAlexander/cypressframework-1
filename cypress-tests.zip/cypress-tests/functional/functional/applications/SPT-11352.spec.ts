import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);

describe('Application - Duplicate field name with field key', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Add New application', () => {
    it('build base app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(appName);
    });
    it('Add two text fields', () => {
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.saveApplication();
      swimInstance.appBuilder.checkFieldProperties('Text', {
        Required: false,
        Unique: false,
        'Read-only': false,
        Calculated: false,
        'Write Once': false
      });
      swimInstance.appBuilder.checkFieldProperties('Text (2)', {
        Required: false,
        Unique: false,
        'Read-only': false,
        Calculated: false,
        'Write Once': false
      });
    });
    it('Change name of the fields', () => {
      swimInstance.appBuilder.editAppComponent('Text', {
        Name: 'text1'
      });
      swimInstance.appBuilder.saveApplication();
      swimInstance.appBuilder.editAppComponent('text1', {
        Name: 'text2'
      });
      swimInstance.appBuilder.saveApplication();
      swimInstance.appBuilder.editAppComponent('Text (2)', {
        Name: 'text1'
      });
      swimInstance.appBuilder.saveApplication();
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

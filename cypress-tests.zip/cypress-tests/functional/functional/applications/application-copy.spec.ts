import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const origAppName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const newAppName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const origAcronym = `AAAA`;
const newAcronym = 'ZZZZ';

describe('App Builder - Copy Application', () => {
  before(() => {
    cy.login();
    cy.cleanupSwimlane();
    cy.visitSwimlane('/');
  });

  describe('Copy application and give new acronym', () => {
    it('build base app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(origAppName);
      swimInstance.appsAppletsListing.appWizard.setAppAcronym(origAcronym);
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(origAppName);
    });

    it('Add Basic Numeric Field', () => {
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.saveApplication();
    });

    it('Copy then update name and acronym', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.copyApp(origAppName, newAppName, newAcronym);
      swimInstance.appsAppletsListing.editExistingApp(newAppName);
      swimInstance.appBuilder.setAppAdditionalSettings();
      swimInstance.appsAppletsListing.appWizard.setAppWorkspace(`${origAppName} Workspace`, true, true);
      swimInstance.appBuilder.applyChanges();
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Create a new record and verify that TrackingID contains the original acronym', () => {
    it(
      'Create new Record and verify that TrackingID contains the original acronym',
      { tags: ['#flaky', 'SPT-13539'] },
      () => {
        swimInstance.switchToWorkspace(`${origAppName} Workspace`);
        swimInstance.startNewRecordForApp(origAppName);
        swimInstance.recordEditor.enterRandomData();
        swimInstance.recordEditor.save();
        swimInstance.startNewRecordForApp(origAppName);
        swimInstance.recordEditor.enterRandomData();
        swimInstance.recordEditor.save();
        swimInstance.startNewRecordForApp(origAppName);
        swimInstance.recordEditor.enterRandomData();
        swimInstance.recordEditor.save();
        swimInstance.recordEditor.getRecordValues();
        swimInstance.recordEditor.getRecordTrackingID(true).then($trackingID => {
          expect($trackingID).to.equal(`${origAcronym}-3`);
        });
      }
    );
  });

  describe('Create a new record and verify that TrackingID contains the correct acronym', () => {
    it('Create new Record and verify that TrackingID contains the correct acronym', () => {
      swimInstance.switchToWorkspace(`${origAppName} Workspace`);
      swimInstance.startNewRecordForApp(newAppName);
      swimInstance.recordEditor.enterRandomData();
      swimInstance.recordEditor.save();
      swimInstance.recordEditor.getRecordValues();
      swimInstance.recordEditor.getRecordTrackingID(true).then($trackingID => {
        expect($trackingID).to.equal(`${newAcronym}-1`);
      });
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);

describe('App Builder - Reference Fields', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('GIVEN: Add New application for Testing field parameters', () => {
    it('build base app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(appName);
    });
  });

  describe('WHEN: Add Reference Fields With Options', () => {
    it('Basic Reference Field', () => {
      swimInstance.appBuilder.addField('Reference');
      swimInstance.appBuilder.editAppComponent('Reference', {
        'Reference Application': appName
      });
      swimInstance.appBuilder.checkFieldProperties('Reference', {});
      swimInstance.appBuilder.checkFieldPermissions('Reference');
      swimInstance.appBuilder.checkFieldAdvancedOptions('Reference', {
        'Ability to add new on target': true,
        'Create and maintain reciprocal reference': false
      });
      swimInstance.appBuilder.checkFieldSize('Reference', '50%');
    });

    it('No New Target Records Reference Field', () => {
      swimInstance.appBuilder.addField('Reference');
      swimInstance.appBuilder.editAppComponent('Reference (2)', {
        Name: 'No New Target Records Reference',
        'Reference Application': appName,
        'Ability to add new on target': false
      });
    });

    // This adds complexity to set up, switching back and forth settign up ref
    // fields, or if self referencing, then have to save with the ref field
    // and then turn on the option.
    xit('Create and maintain reciprocal reference Records Reference Field [SPT-7931]', () => {
      swimInstance.appBuilder.addField('Reference');
      swimInstance.appBuilder.editAppComponent('Reference (2)', {
        Name: 'Create and maintain reciprocal references Reference',
        'Reference Application': appName,
        'Create and maintain reciprocal reference': true
      });
    });

    it('Help Above Reference Field', () => {
      swimInstance.appBuilder.addField('Reference');
      swimInstance.appBuilder.editAppComponent('Reference (2)', {
        Name: 'Help Above Reference',
        'Help Text': 'Above',
        'Help Text Content': 'This is HELP text above the value',
        'Reference Application': appName
      });
    });

    it('Help Below Reference Field', () => {
      swimInstance.appBuilder.addField('Reference');
      swimInstance.appBuilder.editAppComponent('Reference (2)', {
        Name: 'Help Below Reference',
        'Help Text': 'Below',
        'Help Text Content': 'This is HELP text below the value',
        'Reference Application': appName
      });
    });

    after(() => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('THEN: Verify the field properties in the record editor', () => {
    it('Create initial Record', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecordForApp(appName);
    });

    it('Verify default reference field', () => {
      swimInstance.recordEditor.verifyRefFieldOptions('Reference', ['Add New', 'Lookup']);
    });

    it('Verify No New Target Records Reference field', () => {
      swimInstance.recordEditor.verifyRefFieldOptions('No New Target Records Reference', ['Lookup']);
    });

    it('Verify Help Above text', () => {
      swimInstance.recordEditor.verifyHelpText(
        { 'Help Above Reference': 'This is HELP text above the value' },
        'above'
      );
    });

    it('Verify Help Below text', () => {
      swimInstance.recordEditor.verifyHelpText(
        { 'Help Below Reference': 'This is HELP text below the value' },
        'below'
      );
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

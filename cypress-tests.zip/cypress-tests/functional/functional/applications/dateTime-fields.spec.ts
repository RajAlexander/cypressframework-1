import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);

describe('App Builder - Date/Time Fields', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('GIVEN: Add New application for Testing field parameters', () => {
    it('build base app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(appName);
    });
  });

  describe('WHEN: Add Date/Time Fields With Options', () => {
    it('Basic Date/Time Field', () => {
      swimInstance.appBuilder.addField('Date/Time');
      swimInstance.appBuilder.checkFieldProperties('Date & Time', {
        Required: false,
        'Read-only': false,
        Calculated: false
      });
      swimInstance.appBuilder.checkFieldPermissions('Date & Time');
      swimInstance.appBuilder.checkFieldAdvancedOptions('Date & Time', {
        'Default Value': 'None'
      });
      swimInstance.appBuilder.checkFieldSize('Date & Time');
    });

    it('Required Date/Time Field', () => {
      swimInstance.appBuilder.addField('Date/Time');
      swimInstance.appBuilder.editAppComponent('Date & Time (2)', {
        Name: 'Required Date & Time',
        Required: true
      });
    });

    it('Read-only Date/Time Field', () => {
      swimInstance.appBuilder.addField('Date/Time');
      swimInstance.appBuilder.editAppComponent('Date & Time (2)', {
        Name: 'Read-only Date & Time',
        'Read-only': true
      });
    });

    it('Help Above Date/Time Field', () => {
      swimInstance.appBuilder.addField('Date/Time');
      swimInstance.appBuilder.editAppComponent('Date & Time (2)', {
        Name: 'Help Above Date & Time',
        'Help Text': 'Above',
        'Help Text Content': 'This is HELP text above the value'
      });
    });

    it('Help Below Date/Time Field', () => {
      swimInstance.appBuilder.addField('Date/Time');
      swimInstance.appBuilder.editAppComponent('Date & Time (2)', {
        Name: 'Help Below Date & Time',
        'Help Text': 'Below',
        'Help Text Content': 'This is HELP text below the value'
      });
    });

    after(() => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('THEN: Verify the field properties in the record editor', () => {
    it('Create initial Record', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecordForApp(appName);
    });

    it('Verify Required property, field properties', () => {
      swimInstance.recordEditor.verifyRequiredFields('Required Date & Time');
    });

    it('Verify Required property, save dependency', () => {
      // Verify Save button is missing
      swimInstance.recordEditor.verifySaveButton(false);
      // Set a field that is not required.
      swimInstance.recordEditor.setFieldValue({
        'Date & Time': { value: 'Jan 1, 1999 10:00 AM' }
      });

      // Click save button and verify error.
      swimInstance.recordEditor.save('The record has validation error(s)!');
      swimInstance.recordEditor.verifyValueVerification({
        'Required Date & Time': `Error: Value must be populated before submitting`
      });

      // Set required field, can clear other field
      swimInstance.recordEditor.setFieldValue({
        'Date & Time': { value: '' },
        'Required Date & Time': { value: 'Jan 5, 1999 10:00 AM' }
      });
      cy.wait(500); // wait for validation to refresh
      // click save button and verify valid save.
      swimInstance.recordEditor.save();
    });

    it('Verify Read-only property', () => {
      swimInstance.recordEditor.verifyReadOnlyFields('Read-only Date & Time');
    });

    it('Verify Help Above text', () => {
      swimInstance.recordEditor.verifyHelpText(
        { 'Help Above Date & Time': 'This is HELP text above the value' },
        'above'
      );
    });

    it('Verify Help Below text', () => {
      swimInstance.recordEditor.verifyHelpText(
        { 'Help Below Date & Time': 'This is HELP text below the value' },
        'below'
      );
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

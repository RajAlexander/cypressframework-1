import * as swimInstance from '../../support/page-objects/swimInstance';
import { uploadPackage } from '../../support/page-objects/main-app-objects/app-applet-ssp-wizard';
import faker from 'faker/locale/en';

const noIssuesPath = 'packages/QA-E2E- Application Export.ssp';
const actionableIssuesPath = 'packages/QA-E2E- Actionable Testing.ssp';
const nonActionableIssuesPath = 'packages/QA-E2E- Issues Testing.ssp';
const actionableAndNonActionableIssuesPath = 'packages/QA-E2E- Actionable and Non-Actionable Testing.ssp';
const keyStoreRemovableIssuesPath = 'packages/QA-E2E-key-store-removal-issue.ssp';
const invalidSSPPath = 'packages/QA-E2E-Supercharged Date and Time App.ssp';
const bulkEnableScheduledAndNonScheduledSSPPath = 'packages/QA-E2E-BulkTaskEnableScheduled and Non-scheduled.ssp';
const bulkEnableScheduledOnlySSPPath = 'packages/QA-E2E-BulkTaskEnableScheduledOnly.ssp';
const bulkEnableNonScheduledOnlySSPPath = 'packages/QA-E2E-BulkEnableTasksApp.ssp';
const keyValue = faker.random.word();
const keyName = 'qa-e2e-key';
const keyName2 = 'Lohnes Bonus';

const issuesTestPluginDetails = {
  file: 'bundles/sw_cherwell_service_management-1.0.4-linux.python36.swimbundle',
  name: 'Service Management',
  version: '1.0.4',
  subName: 'sw_cherwell_service_management',
  description: 'Cherwell Ticket Management'
};

describe('Import Application SSP', { tags: ['#bug', 'SPT-12419'] }, () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Import Application SSP, success', () => {
    it('import success', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startImportPlus();
      uploadPackage(noIssuesPath);
      swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
        'Import Success',
        null,
        null,
        null,
        null,
        null,
        {
          packageContents: ['1 Application', '1 Report', '1 Workspace'],
          appName: 'QA-E2E- Application Export'
        },
        true,
        true
      );
    });
  });

  describe('Import Application SSP, fail', () => {
    it('import fail', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startImportPlus();
      uploadPackage(noIssuesPath);
      swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUploadFailure(
        'Error Detected',
        'This item already exists in this environment.'
      );
    });
  });

  // this ssp returns actionable issues. use a different ssp
  describe('Import Application SSP, non-actionable issues', () => {
    it('import non-actionable issues', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startImportPlus();
      uploadPackage(nonActionableIssuesPath);
      swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
        'Import Summary',
        'Review Potential Issues',
        'Your application has imported successfully but there are issues. This may result in an incomplete solution.',
        'Take note of or take action on the issues listed.',
        null,
        null,
        {
          packageContents: ['1 Application', '1 Report', '1 Workspace', '2 Tasks', '1 Asset'],
          appName: 'Issues Testing',
          descriptors: {
            asset: [
              {
                name: 'Service Management',
                version: '1.0.4',
                message: 'A secure credential has been removed from Password.'
              }
            ],
            workflow: [
              {
                name: 'Issues Testing',
                reason: 'Task undefined for this workflow action',
                errors: null
              }
            ]
          }
        },
        true,
        true
      );
    });
  });

  describe('Import Application SSP, actionable issues', () => {
    it('import actionable issues', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startImportPlus();
      uploadPackage(actionableIssuesPath);
      swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
        'Import Summary',
        'Review Potential Issue',
        'Your application has imported successfully but there is an issue. This may result in an incomplete solution.',
        'Take note of or take action on the issue listed.',
        null,
        0,
        {
          packageContents: ['1 Application', '1 Report', '1 Workspace', '1 Task', '1 Asset'],
          appName: 'QA-E2E- Actionable Testing',
          descriptors: {
            asset: [
              {
                name: 'Trend Micro Apex Central',
                version: '1.0.0',
                message: 'A secure credential has been removed from API Key.'
              }
            ]
          }
        },
        true,
        true
      );
    });
  });

  describe('Import Application SSP, actionable and non-actionable issues', () => {
    it('import actionable AND non-actionable issues', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startImportPlus();
      uploadPackage(actionableAndNonActionableIssuesPath);
      swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
        'Import Summary',
        'Review Potential Issues',
        'Your application has imported successfully but there are issues. This may result in an incomplete solution.',
        'Take note of or take action on the issues listed.',
        null,
        null,
        {
          packageContents: ['1 Application', '1 Report', '1 Workspace', '1 Task', '1 Asset'],
          appName: 'QA-E2E- Actionable and Non-Actionable Testing',
          descriptors: {
            asset: [
              {
                name: 'Atlassian Jira',
                version: '6.4.0',
                message: 'A secure credential has been removed from API Token.'
              }
            ],
            workflow: [
              {
                name: 'QA-E2E- Actionable and Non-Actionable Testing',
                reason: 'Task undefined for this workflow action',
                errors: null
              }
            ]
          }
        },
        true,
        true
      );
    });
  });

  describe('Import Application SSP, key store removal issues', () => {
    it('key store removal issues', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startImportPlus();
      uploadPackage(keyStoreRemovableIssuesPath);
      swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
        'Import Summary',
        'Review Potential Issue',
        'Your application has imported successfully but there is an issue. This may result in an incomplete solution.',
        'Take note of or take action on the issue listed.',
        null,
        null,
        {
          packageContents: ['1 Application', '1 Report', '1 Workspace', '1 Task'],
          appName: 'QA-E2E-Pre-emptive fresh-thinking product',
          descriptors: {
            task: [
              {
                name: 'qa-e2e-key-task',
                issues: 1,
                reason: 'Key store mapping to input "qa-e2e-key" has been cleared.'
              }
            ]
          }
        },
        true,
        false
      );
      swimInstance.appsAppletsListing.appAppletSSPWizard.resolveIssue('qa-e2e-key-task', 'Task', {
        name: 'qa-e2e-key',
        value: keyValue
      });
      swimInstance.appsAppletsListing.appAppletSSPWizard.close();
    });
  });

  describe('Import invalid Application SSP, verify error message is clear', () => {
    it('import invalid Application SSP', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startImportPlus();
      uploadPackage(invalidSSPPath);
      swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
        'Import',
        'Import Failed',
        'Something went wrong',
        null,
        null,
        null,
        {},
        true,
        true
      );
    });
  });

  describe('Cleanup Plugin, Asset and Task for the next test', () => {
    it('Remove the Plugin, Asset and Task', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.deleteAsset('Atlassian Jira');
      swimInstance.integrationsPage.openPluginsPage();
      swimInstance.integrationsPage.deletePlugin(issuesTestPluginDetails, true);
    });
  });

  describe('Import Application SSP, verify ability to bulk enable tasks, non-scheduled tasks only', () => {
    it('import Application SSP', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startImportPlus();
      uploadPackage(bulkEnableNonScheduledOnlySSPPath);
      swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
        'Import Summary',
        'Review Potential Issues',
        'Your application has imported successfully but there are issues. This may result in an incomplete solution.',
        'Take note of or take action on the issues listed.',
        'Some tasks were disabled during export. Enable them all now or later.',
        4,
        {
          packageContents: ['1 Application', '1 Report', '1 Workspace', '5 Tasks', '1 Dashboard', '3 Assets'],
          appName: 'QA-E2E-BulkEnableTasksApp',
          descriptors: {
            task: [
              {
                name: 'test',
                issues: null,
                reason: 'Key store mapping to input "Lohnes Bonus" has been cleared.'
              },
              {
                name: 'Lohnes Taskin003',
                issues: null,
                reason: 'Asset Sixgill Actionable Alerts connected to Task Lohnes Taskin003 has been modified.'
              },
              {
                name: 'Lohnes Taskin002',
                issues: null,
                reason: 'Asset Alienvault USM Anywhere connected to Task Lohnes Taskin002 has been modified.'
              },
              {
                name: 'Lohnes Taskin001',
                issues: null,
                reason: 'Asset Atlassian Jira connected to Task Lohnes Taskin001 has been modified.'
              }
            ],
            asset: [
              {
                name: 'Alienvault USM Anywhere',
                version: '2.4.0',
                message: 'A secure credential has been removed from Client Secret.'
              },
              {
                name: 'Atlassian Jira',
                version: '6.4.0',
                message: 'A secure credential has been removed from API Token.'
              },
              {
                name: 'Sixgill Actionable Alerts',
                version: '1.0.0',
                message: 'A secure credential has been removed from Client Secret.'
              }
            ]
          }
        },
        true,
        false
      );
      swimInstance.appsAppletsListing.appAppletSSPWizard.resolveIssue('test', 'Task', {
        name: 'Lohnes Bonus',
        value: keyValue
      });
      swimInstance.appsAppletsListing.appAppletSSPWizard.resolveIssue('Alienvault USM Anywhere', 'Asset', {
        parameters: { client_id: keyValue, client_secret: keyValue }
      });
      swimInstance.appsAppletsListing.appAppletSSPWizard.resolveIssue('Atlassian Jira', 'Asset', {
        parameters: { api_token: keyValue }
      });
      swimInstance.appsAppletsListing.appAppletSSPWizard.resolveIssue('Sixgill Actionable Alerts', 'Asset', {
        parameters: { client_secret: keyValue }
      });
      swimInstance.appsAppletsListing.appAppletSSPWizard.enableAllTasks(false, 4);
      swimInstance.appsAppletsListing.appAppletSSPWizard.verifyTasksEnabled([
        'test',
        'Lohnes Taskin003',
        'Lohnes Taskin002',
        'Lohnes Taskin001'
      ]);
      swimInstance.appsAppletsListing.appAppletSSPWizard.close();
    });
  });

  describe('Import Application SSP, verify ability to bulk enable tasks, scheduled AND non-scheduled tasks', () => {
    it('import Application SSP', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startImportPlus();
      uploadPackage(bulkEnableScheduledAndNonScheduledSSPPath);
      swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
        'Import Summary',
        'Review Potential Issues',
        'Your application has imported successfully but there are issues. This may result in an incomplete solution.',
        'Take note of or take action on the issues listed.',
        'Some tasks were disabled during export. Enable them all now or later.',
        2,
        {
          packageContents: ['1 Application', '1 Report', '1 Workspace', '3 Tasks', '2 Assets'],
          appName: 'QA-E2E-BulkTaskEnableScheduled and Non-scheduled',
          descriptors: {
            task: [
              {
                name: 'QA-E2E-Another Scheduled Task',
                issues: null,
                reason: 'Asset Twilio connected to Task QA-E2E-Another Scheduled Task has been modified.'
              },
              {
                name: 'QA-E2E-Non-Scheduled Task',
                issues: null,
                reason: 'Asset Sixgill Darkfeed connected to Task QA-E2E-Non-Scheduled Task has been modified.'
              }
            ],
            asset: [
              {
                name: 'Twilio',
                version: '1.0.3',
                message: 'A secure credential has been removed from Account SID.',
                message1: 'A secure credential has been removed from Authorization Token.'
              },
              {
                name: 'Sixgill Darkfeed',
                version: '1.0.0',
                message: 'A secure credential has been removed from Client Secret.',
                message1: 'A secure credential has been removed from Swimlane Access Token.'
              }
            ]
          }
        },
        true,
        false
      );
      swimInstance.appsAppletsListing.appAppletSSPWizard.resolveIssue('Twilio', 'Asset', {
        parameters: { account_sid: keyValue, auth_token: keyValue }
      });
      swimInstance.appsAppletsListing.appAppletSSPWizard.resolveIssue('Sixgill Darkfeed', 'Asset', {
        parameters: {
          client_secret: keyValue,
          swimlane_access_token: keyValue
        }
      });
      swimInstance.appsAppletsListing.appAppletSSPWizard.enableAllTasks(false, 2);
      swimInstance.appsAppletsListing.appAppletSSPWizard.verifyTasksEnabled([
        'test',
        'Lohnes Taskin003',
        'Lohnes Taskin002',
        'Lohnes Taskin001'
      ]);
      swimInstance.appsAppletsListing.appAppletSSPWizard.close();
    });
  });

  describe('Import Application SSP, verify ability to bulk enable tasks, scheduled tasks only', () => {
    it('import Application SSP', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startImportPlus();
      uploadPackage(bulkEnableScheduledOnlySSPPath);
      swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
        'Import Summary',
        'Review Potential Issues',
        'Your application has imported successfully but there are issues. This may result in an incomplete solution.',
        'Take note of or take action on the issues listed.',
        'Some tasks were disabled during export. Enable them all now or later.',
        1,
        {
          packageContents: ['1 Application', '1 Report', '1 Workspace', '2 Tasks', '1 Asset'],
          appName: 'QA-E2E-BulkTaskEnableScheduledOnly',
          descriptors: {
            task: [
              {
                name: 'QA-E2E-SecondScheduled Task',
                issues: null,
                reason: 'Asset Twitter connected to Task QA-E2E-SecondScheduled Task has been modified.'
              }
            ],
            asset: [
              {
                name: 'Twitter',
                version: '1.0.0',
                message: 'A secure credential has been removed from Consumer Key.',
                message1: 'A secure credential has been removed from Consumer Secret.',
                message2: 'A secure credential has been removed from Access Token.',
                message3: 'A secure credential has been removed from Access Token Secret.'
              }
            ]
          }
        },
        true,
        false
      );
      swimInstance.appsAppletsListing.appAppletSSPWizard.resolveIssue('Twitter', 'Asset', {
        parameters: {
          consumer_key: keyValue,
          consumer_secret: keyValue,
          access_token: keyValue,
          access_token_secret: keyValue
        }
      });
      swimInstance.appsAppletsListing.appAppletSSPWizard.enableAllTasks(true, 0);
      swimInstance.appsAppletsListing.appAppletSSPWizard.verifyTasksEnabled([
        'test',
        'Lohnes Taskin003',
        'Lohnes Taskin002',
        'Lohnes Taskin001'
      ]);
      swimInstance.appsAppletsListing.appAppletSSPWizard.close();
    });
  });

  describe('Cleanup apps', () => {
    it('Remove the created applications', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.deleteExistingApp('Issues Testing');
    });
  });

  describe('Cleanup workspaces', () => {
    it('Remove the created workspaces', () => {
      swimInstance.openWorkspaceList();
      swimInstance.workspacesListing.deleteWorkspace('Issues Testing Workspace');
    });
  });

  describe('Cleanup key stores', () => {
    it('Delete key stores that were added.', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.openKeyStorePage();
      swimInstance.integrationsPage.deleteKeystore(keyName);
      swimInstance.integrationsPage.deleteKeystore(keyName2);
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const appName2 = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
let recordTrackingIdSource = '';
let recordTrackingIdTarget = '';
let recordTrackingIdTarget2 = '';

describe('App Builder - Reference Fields', () => {
  before(() => {
    cy.login();
    cy.setFeatureFlag('RecordPage');
    cy.cleanupSwimlane();
    cy.visitSwimlane('/');
  });

  describe('Add Application for Testing Reciprocal Reference Fields', () => {
    it('build reciprocal reference app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName2);
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(appName2);
    });
  });

  describe('Add New application for Testing Reference Fields', () => {
    it('build base app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(appName);
    });
  });

  describe('Add Reference Fields With Options', () => {
    it('Basic Reference Field', () => {
      swimInstance.appBuilder.addField('Reference');
      swimInstance.appBuilder.editAppComponent('Reference', {
        'Reference Application': appName
      });
      swimInstance.appBuilder.checkFieldProperties('Reference', {});
      swimInstance.appBuilder.checkFieldPermissions('Reference');
      swimInstance.appBuilder.checkFieldAdvancedOptions('Reference', {
        'Ability to add new on target': true,
        'Create and maintain reciprocal reference': false
      });
      swimInstance.appBuilder.checkFieldSize('Reference', '50%');
    });

    it('No New Target Records Reference Field', () => {
      swimInstance.appBuilder.addField('Reference');
      swimInstance.appBuilder.editAppComponent('Reference (2)', {
        Name: 'No New Target Records Reference',
        'Reference Application': appName,
        'Ability to add new on target': false
      });
    });

    it('Single Select Reference Field', () => {
      swimInstance.appBuilder.addField('Single-select');
      swimInstance.appBuilder.editAppComponent('Reference (2)', {
        Name: 'Single-select Reference',
        'Reference Application': appName2
      });
      swimInstance.appBuilder.checkFieldProperties('Single-select Reference', {});
      swimInstance.appBuilder.checkFieldPermissions('Single-select Reference');
      swimInstance.appBuilder.checkFieldAdvancedOptions('Single-select Reference', {
        'Ability to add new on target': true,
        'Create and maintain reciprocal reference': false
      });
    });

    it('Multi Select Reference Field', () => {
      swimInstance.appBuilder.addField('Multi-select');
      swimInstance.appBuilder.editAppComponent('Reference (2)', {
        Name: 'Multi-select Reference',
        'Reference Application': appName2
      });
      swimInstance.appBuilder.checkFieldProperties('Multi-select Reference', {});
      swimInstance.appBuilder.checkFieldPermissions('Multi-select Reference');
      swimInstance.appBuilder.checkFieldAdvancedOptions('Multi-select Reference', {
        'Ability to add new on target': true,
        'Create and maintain reciprocal reference': false
      });
    });

    it('Create Reference Field on the target Application [SPT-7931]', () => {
      swimInstance.appBuilder.addField('Reference');
      swimInstance.appBuilder.editAppComponent('Reference (2)', {
        Name: 'Create and maintain reciprocal references Reference',
        'Reference Application': appName2,
        'Create and maintain reciprocal reference': true
      });
    });

    it('Add Numeric Field on the target Application', () => {
      swimInstance.appBuilder.addField('Numeric');
    });

    after(() => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Add Reference Fields With Options', () => {
    it('Create reciprocal Reference field on target application [SPT-7931]', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.editExistingApp(appName2, true);
      swimInstance.appBuilder.addField('Reference');
      swimInstance.appBuilder.editAppComponent('Reference', {
        Name: 'Target Reference Field',
        'Reference Application': appName,
        'Create and maintain reciprocal reference': true
      });
    });

    it('Add Numeric Field', () => {
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.editAppComponent('Numeric', {
        Name: 'Numeric'
      });
      swimInstance.appBuilder.saveApplication();
    });

    it('Create reciprocal Reference field on source Application', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.editExistingApp(appName, true);
      swimInstance.appBuilder.editAppComponent('Create and maintain reciprocal references Reference', {
        Name: 'Create and maintain reciprocal references Reference',
        'Reference Application': appName2,
        'Create and maintain reciprocal reference': true,
        'Fields to Display': 'Numeric'
      });
    });

    after(() => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Verify the field properties in the record editor', () => {
    it('Create initial Record on source Application', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecord2ForApp(appName);
      swimInstance.recordEditor2.setFieldValue({
        Numeric: { value: '666' }
      });
      swimInstance.recordEditor2.save();
      swimInstance.recordEditor2.getRecordTrackingID(true).then($trackingID => {
        recordTrackingIdSource = $trackingID.trim();
      });
    });

    it('Verify Single Select Reference field', () => {
      swimInstance.recordEditor2.verifyReferenceFieldOptions(
        'Single-select Reference',
        false,
        ['Add New', 'Lookup'],
        ['TrackingId']
      );
    });

    it('Verify Multi Select Reference field', () => {
      swimInstance.recordEditor2.verifyReferenceFieldOptions(
        'Multi-select Reference',
        false,
        ['Add New', 'Lookup'],
        ['TrackingId']
      );
    });

    it('Verify default Reference field', () => {
      swimInstance.recordEditor2.verifyReferenceFieldOptions('Reference', true, ['Add New', 'Lookup'], ['Tracking Id']);
    });

    it('Verify No New Target Records Reference field', () => {
      swimInstance.recordEditor2.verifyReferenceFieldOptions(
        'No New Target Records Reference',
        true,
        ['Lookup'],
        ['Tracking Id']
      );
    });

    it('Verify Grid Reference field', () => {
      swimInstance.recordEditor2.verifyReferenceFieldOptions(
        'Create and maintain reciprocal references Reference',
        true,
        ['Add New', 'Lookup'],
        ['Tracking Id', 'Numeric']
      );
    });

    it('Create initial Record on target Application', () => {
      swimInstance.switchToWorkspace(`${appName2} Workspace`);
      swimInstance.startNewRecord2ForApp(appName2);
      swimInstance.recordEditor2.setFieldValue({
        Numeric: { value: '777' }
      });
      swimInstance.recordEditor2.save();
      swimInstance.recordEditor2.getRecordTrackingID(true).then($trackingID => {
        recordTrackingIdTarget = $trackingID.trim();
      });
      swimInstance.recordEditor2.setFieldValue(
        {
          'Target Reference Field': { value: recordTrackingIdSource }
        },
        true
      );
      swimInstance.recordEditor2.save('Record saved');
    });

    it('Verify ability to open Grid Referenced Record in a tray', () => {
      swimInstance.recordEditor2.openReferencedRecord('Target Reference Field', recordTrackingIdSource, true);
      swimInstance.recordEditor2.verifyRecordOpenedInDrawer(
        recordTrackingIdSource,
        ['Delete', 'Restrict Record', 'Lock Record'],
        { 'Single-select Reference': recordTrackingIdTarget }
      );
      swimInstance.recordEditor2.closeRecordDrawer();
    });

    it('Create second Record on target Application for Multi-select Reference', () => {
      swimInstance.switchToWorkspace(`${appName2} Workspace`);
      swimInstance.startNewRecord2ForApp(appName2);
      swimInstance.recordEditor2.setFieldValue({
        Numeric: { value: '789' }
      });
      swimInstance.recordEditor2.save();
      swimInstance.recordEditor2.getRecordTrackingID(true).then($trackingID => {
        recordTrackingIdTarget2 = $trackingID.trim();
      });
    });

    it('Open Record on source Application and verify reciprocal reference', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.OpenAppListAll(appName);
      swimInstance.recordListing.openRecord(recordTrackingIdSource);
      swimInstance.recordEditor.verifyFieldValues(
        { 'CREATE AND MAINTAIN RECIPROCAL REFERENCES REFERENCE': recordTrackingIdTarget },
        false
      );
      swimInstance.recordListing.closeRecordWindow();
    });

    it('Create Single Select reference', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecord2ForApp(appName);
      swimInstance.recordEditor2.setFieldValue(
        {
          'Single-select Reference': { value: recordTrackingIdTarget }
        },
        false
      );
      swimInstance.recordEditor2.verifyFieldValues({ 'Single-select Reference': recordTrackingIdTarget }, false);
    });

    it('Verify ability to open Select Referenced Record in a tray', () => {
      swimInstance.recordEditor2.openReferencedRecord('Single-select Reference', recordTrackingIdTarget, false);
      swimInstance.recordEditor2.verifyRecordOpenedInDrawer(
        recordTrackingIdTarget,
        ['Delete', 'Restrict Record', 'Lock Record'],
        { 'Target Reference Field': [recordTrackingIdSource] }
      );
      swimInstance.recordEditor2.closeRecordDrawer();
    });

    it('Create Multi Select reference', () => {
      swimInstance.recordEditor2.setFieldValue(
        {
          'Multi-select Reference': { value: recordTrackingIdTarget }
        },
        false
      );
      swimInstance.recordEditor2.setFieldValue(
        {
          'Multi-select Reference': { value: recordTrackingIdTarget2 }
        },
        false
      );
      swimInstance.recordEditor2.verifyFieldValues(
        { 'Multi-select Reference': [recordTrackingIdTarget, recordTrackingIdTarget2] },
        false
      );
      swimInstance.recordEditor2.save('Record created');
    });
  });

  after(() => {
    cy.setFeatureFlag('RecordPage', false);
    cy.cleanupSwimlane();
    cy.logout();
  });
});

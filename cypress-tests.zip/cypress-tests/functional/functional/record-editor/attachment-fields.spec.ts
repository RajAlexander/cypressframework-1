import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const appDescription = faker.lorem.sentence();

describe('App Builder - Attachment Fields', () => {
  before(() => {
    cy.login();
    cy.setFeatureFlag('RecordPage');
    cy.cleanupSwimlane();
    cy.visitSwimlane('/');
  });

  describe('GIVEN: Add New application for Testing field parameters', () => {
    it('build base app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.setAppDescription(appDescription);
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(appName);
    });
  });

  describe('WHEN: Add Attachments Fields With Options', () => {
    it('Basic Attachments Field', () => {
      swimInstance.appBuilder.addField('Attachments');
      swimInstance.appBuilder.editAppComponent('Attachment', {
        Name: 'Attachment',
        'Max Size [kB]': '60'
      });
      swimInstance.appBuilder.checkFieldProperties('Attachment', {
        'Read-only': false
      });
      swimInstance.appBuilder.checkFieldPermissions('Attachment');
      swimInstance.appBuilder.checkFieldAdvancedOptions('Attachment', {
        'Max Size': '60',
        'Delete attachments': false
      });
      swimInstance.appBuilder.checkFieldSize('Attachment');
    });

    it('Max Size 100kB Attachments Field', () => {
      swimInstance.appBuilder.addField('Attachments');
      swimInstance.appBuilder.editAppComponent('Attachment (2)', {
        Name: 'Max Size 100kB Attachment',
        'Max Size [kB]': '100'
      });
      swimInstance.appBuilder.checkFieldAdvancedOptions('Max Size 100kB Attachment', {
        'Max Size': '100',
        'Delete attachments': false
      });
    });

    after(() => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('THEN: Verify the ability to upload attachments and verify that attachments above the size limit are not uploaded', () => {
    it('Create initial Record', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecord2ForApp(appName);
    });

    it('Verify Max Size 100kB property', () => {
      swimInstance.recordEditor2.addAttachment('Max Size 100kB Attachment', '60kb.pdf');
      swimInstance.recordEditor2.verifyAttachmentsList('Max Size 100kB Attachment', ['60kb.pdf']);
      swimInstance.recordEditor2.addAttachment(
        'Max Size 100kB Attachment',
        '103kb.json',
        true,
        'File is too large. Allowed maximum size for this field is 100 KB'
      );
      swimInstance.recordEditor2.verifyAttachmentsList('Max Size 100kB Attachment', ['60kb.pdf']);
      swimInstance.recordEditor2.addAttachment('Max Size 100kB Attachment', '44kb.png');
      swimInstance.recordEditor2.verifyAttachmentsList('Max Size 100kB Attachment', ['60kb.pdf', '44kb.png']);
      swimInstance.recordEditor2.addMSAttachment('Max Size 100kB Attachment', 'hello-world.xlsx');
      swimInstance.recordEditor2.verifyAttachmentsList('Max Size 100kB Attachment', [
        '60kb.pdf',
        '44kb.png',
        'hello-world.xlsx'
      ]);
      swimInstance.recordEditor2.addAttachment('Attachment', 'sample2.csv');
      swimInstance.recordEditor2.verifyAttachmentsList('Attachment', ['sample2.csv']);
      swimInstance.recordEditor2.addMSAttachment('Attachment', 'rms_five.xls');
      swimInstance.recordEditor2.verifyAttachmentsList('Attachment', ['sample2.csv', 'rms_five.xls']);
      swimInstance.recordEditor2.addMSAttachment('Attachment', 'Testing_PPT.pptx');
      swimInstance.recordEditor2.verifyAttachmentsList('Attachment', [
        'sample2.csv',
        'rms_five.xls',
        'Testing_PPT.pptx'
      ]);
      swimInstance.recordEditor2.addAttachment('Attachment', 'timezones.txt');
      swimInstance.recordEditor2.verifyAttachmentsList('Attachment', [
        'sample2.csv',
        'rms_five.xls',
        'Testing_PPT.pptx',
        'timezones.txt'
      ]);
      swimInstance.recordEditor2.addMSAttachment('Attachment', 'Untitled.ppt');
      swimInstance.recordEditor2.verifyAttachmentsList('Attachment', [
        'sample2.csv',
        'rms_five.xls',
        'Testing_PPT.pptx',
        'timezones.txt',
        'Untitled.ppt'
      ]);
      swimInstance.recordEditor2.addAttachment('Attachment', 'biospecimen.tsv');
      swimInstance.recordEditor2.verifyAttachmentsList('Attachment', [
        'sample2.csv',
        'rms_five.xls',
        'Testing_PPT.pptx',
        'timezones.txt',
        'Untitled.ppt',
        'biospecimen.tsv'
      ]);
      swimInstance.recordEditor2.addAttachment('Attachment', 'Mood_Poisoning.jpg');
      swimInstance.recordEditor2.verifyAttachmentsList('Attachment', [
        'sample2.csv',
        'rms_five.xls',
        'Testing_PPT.pptx',
        'timezones.txt',
        'Untitled.ppt',
        'biospecimen.tsv',
        'Mood_Poisoning.jpg'
      ]);
      swimInstance.recordEditor2.addAttachment('Attachment', 'niXbaLGiB.jpeg');
      swimInstance.recordEditor2.verifyAttachmentsList('Attachment', [
        'sample2.csv',
        'rms_five.xls',
        'Testing_PPT.pptx',
        'timezones.txt',
        'Untitled.ppt',
        'biospecimen.tsv',
        'Mood_Poisoning.jpg',
        'niXbaLGiB.jpeg'
      ]);
      swimInstance.recordEditor2.addMSAttachment('Attachment', 'E2E Coding and design patterns.doc');
      swimInstance.recordEditor2.verifyAttachmentsList('Attachment', [
        'sample2.csv',
        'rms_five.xls',
        'Testing_PPT.pptx',
        'timezones.txt',
        'Untitled.ppt',
        'biospecimen.tsv',
        'Mood_Poisoning.jpg',
        'niXbaLGiB.jpeg',
        'E2E Coding and design patterns.doc'
      ]);
      swimInstance.recordEditor2.addMSAttachment('Attachment', 'E2E Coding and design patterns.docx');
      swimInstance.recordEditor2.verifyAttachmentsList('Attachment', [
        'sample2.csv',
        'rms_five.xls',
        'Testing_PPT.pptx',
        'timezones.txt',
        'Untitled.ppt',
        'biospecimen.tsv',
        'Mood_Poisoning.jpg',
        'niXbaLGiB.jpeg',
        'E2E Coding and design patterns.doc',
        'E2E Coding and design patterns.docx'
      ]);
    });

    after(() => {
      swimInstance.recordEditor2.save();
    });
  });

  describe('THEN: Verify the ability to preview the attachments in the record editor', () => {
    it('Preview .csv attachment', () => {
      swimInstance.recordEditor2.previewAttachment('Attachment', 'sample2.csv');
    });

    it('Preview .tsv attachment', () => {
      swimInstance.recordEditor2.previewAttachment('Attachment', 'biospecimen.tsv');
    });

    it('Preview .png attachment', () => {
      swimInstance.recordEditor2.previewAttachment('Max Size 100kB Attachment', '44kb.png');
    });

    it('Preview .jpg attachment', () => {
      swimInstance.recordEditor2.previewAttachment('Attachment', 'Mood_Poisoning.jpg');
    });

    it('Preview .jpeg attachment', () => {
      swimInstance.recordEditor2.previewAttachment('Attachment', 'niXbaLGiB.jpeg');
    });

    it('Preview .pdf attachment', () => {
      swimInstance.recordEditor2.previewAttachment('Max Size 100kB Attachment', '60kb.pdf');
    });

    it('Preview .xls attachment', () => {
      swimInstance.recordEditor2.previewAttachment('Attachment', 'rms_five.xls');
    });

    it('Preview .xlsx attachment', () => {
      swimInstance.recordEditor2.previewAttachment('Max Size 100kB Attachment', 'hello-world.xlsx');
    });

    it('Preview .txt attachment', () => {
      swimInstance.recordEditor2.previewAttachment('Attachment', 'timezones.txt');
    });

    it('Preview .ppt attachment', () => {
      swimInstance.recordEditor2.previewAttachment('Attachment', 'Untitled.ppt');
    });

    it('Preview .pptx attachment', () => {
      swimInstance.recordEditor2.previewAttachment('Attachment', 'Testing_PPT.pptx');
    });

    it('Preview .doc attachment', () => {
      swimInstance.recordEditor2.previewAttachment('Attachment', 'E2E Coding and design patterns.doc');
    });

    it('Preview .docx attachment', () => {
      swimInstance.recordEditor2.previewAttachment('Attachment', 'E2E Coding and design patterns.docx');
    });

    afterEach(() => {
      swimInstance.recordEditor2.closePreview();
    });
  });

  describe('THEN: Verify the ability to download the attachments in the record editor', () => {
    it('Download .csv attachment', () => {
      swimInstance.recordEditor2.downloadAttachment('Attachment', 'sample2.csv');
    });

    it('Download .tsv attachment', () => {
      swimInstance.recordEditor2.downloadAttachment('Attachment', 'biospecimen.tsv');
    });

    it('Download .png attachment', () => {
      swimInstance.recordEditor2.downloadAttachment('Max Size 100kB Attachment', '44kb.png');
    });

    it('Download .jpg attachment', () => {
      swimInstance.recordEditor2.downloadAttachment('Attachment', 'Mood_Poisoning.jpg');
    });

    it('Download .jpeg attachment', () => {
      swimInstance.recordEditor2.downloadAttachment('Attachment', 'niXbaLGiB.jpeg');
    });

    it('Download .pdf attachment', () => {
      swimInstance.recordEditor2.downloadAttachment('Max Size 100kB Attachment', '60kb.pdf');
    });

    it('Download .xls attachment', () => {
      swimInstance.recordEditor2.downloadAttachment('Attachment', 'rms_five.xls');
    });

    it('Download .xlsx attachment', () => {
      swimInstance.recordEditor2.downloadAttachment('Max Size 100kB Attachment', 'hello-world.xlsx');
    });

    it('Download .txt attachment', () => {
      swimInstance.recordEditor2.downloadAttachment('Attachment', 'timezones.txt');
    });

    it('Download .ppt attachment', () => {
      swimInstance.recordEditor2.downloadAttachment('Attachment', 'Untitled.ppt');
    });

    it('Download .pptx attachment', () => {
      swimInstance.recordEditor2.downloadAttachment('Attachment', 'Testing_PPT.pptx');
    });

    it('Download .doc attachment', () => {
      swimInstance.recordEditor2.downloadAttachment('Attachment', 'E2E Coding and design patterns.doc');
    });

    it('Download .docx attachment', () => {
      swimInstance.recordEditor2.downloadAttachment('Attachment', 'E2E Coding and design patterns.docx');
    });
  });

  describe('THEN: Verify the ability to delete the attachments in the record editor', () => {
    it('Delete .csv attachment', () => {
      swimInstance.recordEditor2.deleteAttachment('Attachment', 'sample2.csv');
      swimInstance.recordEditor2.verifyAttachmentsList('Attachment', [
        'rms_five.xls',
        'Testing_PPT.pptx',
        'timezones.txt',
        'Untitled.ppt',
        'biospecimen.tsv',
        'Mood_Poisoning.jpg',
        'niXbaLGiB.jpeg',
        'E2E Coding and design patterns.doc',
        'E2E Coding and design patterns.docx'
      ]);
    });

    it('Delete .tsv attachment', () => {
      swimInstance.recordEditor2.deleteAttachment('Attachment', 'biospecimen.tsv');
      swimInstance.recordEditor2.verifyAttachmentsList('Attachment', [
        'rms_five.xls',
        'Testing_PPT.pptx',
        'timezones.txt',
        'Untitled.ppt',
        'Mood_Poisoning.jpg',
        'niXbaLGiB.jpeg',
        'E2E Coding and design patterns.doc',
        'E2E Coding and design patterns.docx'
      ]);
    });

    it('Delete .png attachment', () => {
      swimInstance.recordEditor2.deleteAttachment('Max Size 100kB Attachment', '44kb.png');
      swimInstance.recordEditor2.verifyAttachmentsList('Max Size 100kB Attachment', ['60kb.pdf', 'hello-world.xlsx']);
    });

    it('Delete .jpg attachment', () => {
      swimInstance.recordEditor2.deleteAttachment('Attachment', 'Mood_Poisoning.jpg');
      swimInstance.recordEditor2.verifyAttachmentsList('Attachment', [
        'rms_five.xls',
        'Testing_PPT.pptx',
        'timezones.txt',
        'Untitled.ppt',
        'niXbaLGiB.jpeg',
        'E2E Coding and design patterns.doc',
        'E2E Coding and design patterns.docx'
      ]);
    });

    it('Delete .jpeg attachment', () => {
      swimInstance.recordEditor2.deleteAttachment('Attachment', 'niXbaLGiB.jpeg');
      swimInstance.recordEditor2.verifyAttachmentsList('Attachment', [
        'rms_five.xls',
        'Testing_PPT.pptx',
        'timezones.txt',
        'Untitled.ppt',
        'E2E Coding and design patterns.doc',
        'E2E Coding and design patterns.docx'
      ]);
    });

    it('Delete .pdf attachment', () => {
      swimInstance.recordEditor2.deleteAttachment('Max Size 100kB Attachment', '60kb.pdf');
      swimInstance.recordEditor2.verifyAttachmentsList('Max Size 100kB Attachment', ['hello-world.xlsx']);
    });

    it('Delete .xls attachment', () => {
      swimInstance.recordEditor2.deleteAttachment('Attachment', 'rms_five.xls');
      swimInstance.recordEditor2.verifyAttachmentsList('Attachment', [
        'Testing_PPT.pptx',
        'timezones.txt',
        'Untitled.ppt',
        'E2E Coding and design patterns.doc',
        'E2E Coding and design patterns.docx'
      ]);
    });

    it('Delete .xlsx attachment', () => {
      swimInstance.recordEditor2.deleteAttachment('Max Size 100kB Attachment', 'hello-world.xlsx');
      swimInstance.recordEditor2.verifyAttachmentsList('Max Size 100kB Attachment', []);
    });

    it('Delete .txt attachment', () => {
      swimInstance.recordEditor2.deleteAttachment('Attachment', 'timezones.txt');
      swimInstance.recordEditor2.verifyAttachmentsList('Attachment', [
        'Testing_PPT.pptx',
        'Untitled.ppt',
        'E2E Coding and design patterns.doc',
        'E2E Coding and design patterns.docx'
      ]);
    });

    it('Delete .ppt attachment', () => {
      swimInstance.recordEditor2.deleteAttachment('Attachment', 'Untitled.ppt');
      swimInstance.recordEditor2.verifyAttachmentsList('Attachment', [
        'Testing_PPT.pptx',
        'E2E Coding and design patterns.doc',
        'E2E Coding and design patterns.docx'
      ]);
    });

    it('Delete .pptx attachment', () => {
      swimInstance.recordEditor2.deleteAttachment('Attachment', 'Testing_PPT.pptx');
      swimInstance.recordEditor2.verifyAttachmentsList('Attachment', [
        'E2E Coding and design patterns.doc',
        'E2E Coding and design patterns.docx'
      ]);
    });

    it('Delete .docx attachment', () => {
      swimInstance.recordEditor2.deleteAttachment('Attachment', 'E2E Coding and design patterns.docx');
      swimInstance.recordEditor2.verifyAttachmentsList('Attachment', ['E2E Coding and design patterns.doc']);
    });

    it('Delete .doc attachment', () => {
      swimInstance.recordEditor2.deleteAttachment('Attachment', 'E2E Coding and design patterns.doc');
      swimInstance.recordEditor2.verifyAttachmentsList('Attachment', []);
    });
  });

  after(() => {
    cy.setFeatureFlag('RecordPage', false);
    cy.cleanupSwimlane();
    cy.logout();
  });
});

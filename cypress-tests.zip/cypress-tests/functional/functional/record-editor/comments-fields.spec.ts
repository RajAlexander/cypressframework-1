import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const appDescription = faker.lorem.sentence();
const basicComment = faker.lorem.sentence();
const additionalComment = faker.lorem.sentence();
const editedComment = ' EDITED! ';

describe('App Builder - Comments Fields', () => {
  before(() => {
    cy.login();
    cy.setFeatureFlag('RecordPage');
    cy.cleanupSwimlane();
    cy.visitSwimlane('/');
  });

  describe('Add New application for Testing field parameters', () => {
    it('build base app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.setAppDescription(appDescription);
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(appName);
    });
  });

  describe('Add Comments Fields With Options', () => {
    it('Basic Comments Field', () => {
      swimInstance.appBuilder.addField('Comments');
      swimInstance.appBuilder.checkFieldProperties('Comments', {});
      swimInstance.appBuilder.checkFieldPermissions('Comments');
      swimInstance.appBuilder.checkFieldAdvancedOptions('Comments');
      swimInstance.appBuilder.checkFieldSize('Comments', '50%');
    });

    it('Second Comments Field', () => {
      swimInstance.appBuilder.addField('Comments');
      swimInstance.appBuilder.editAppComponent('Comments (2)', {
        Name: 'Additional Comments'
      });
    });

    // Adding a numeric field as the [data-cy=record-editor__form] DOM element is not part of the Record page with only a comments field
    it('Basic Numeric Field', () => {
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.editAppComponent('Numeric', {
        Name: 'Numeric'
      });
    });

    after(() => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Verify the field properties in the record editor', () => {
    before('Create initial Record', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecord2ForApp(appName);
    });

    it('Create a comment', () => {
      swimInstance.recordEditor2.setFieldValue({
        Comments: { value: basicComment }
      });
      swimInstance.recordEditor2.verifyFieldValues({ Comments: basicComment }, false, false, true);
    });

    it('Create another comment in the other Comments field', () => {
      swimInstance.recordEditor2.setFieldValue({
        'Additional Comments': { value: additionalComment }
      });
      swimInstance.recordEditor2.save();
      swimInstance.recordEditor2.verifyFieldValues({ Comments: basicComment }, false, false, true);
      swimInstance.recordEditor2.verifyFieldValues({ 'Additional Comments': additionalComment }, false, false, true);
    });

    it('Edit a comment', () => {
      swimInstance.recordEditor2.clickEditCommentButton('Comments');
      swimInstance.recordEditor2.editExistingComment(editedComment);
      swimInstance.recordEditor2.verifyFieldValues({ Comments: basicComment + editedComment }, false, false, true);
      swimInstance.recordEditor2.verifySaveButton(false);
    });

    it('Save an edited comment on a dirty, dirty Record', () => {
      swimInstance.recordEditor2.setFieldValue({
        Numeric: { value: 777 }
      });
      swimInstance.recordEditor2.save('Record saved');
    });
  });

  after(() => {
    cy.setFeatureFlag('RecordPage', false);
    cy.cleanupSwimlane();
    cy.logout();
  });
});

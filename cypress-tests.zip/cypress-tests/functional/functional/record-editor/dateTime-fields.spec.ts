import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);

describe('Record Editor 2 - Date/Time Fields', () => {
  before(() => {
    cy.login();
    cy.setFeatureFlag('RecordPage');
    cy.visitSwimlane('/');
  });

  describe('GIVEN: Add New application for Testing field parameters', () => {
    it('build base app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(appName);
    });
  });

  describe('WHEN: Add Date/Time Fields With Options', () => {
    it('Basic Date/Time Field', () => {
      swimInstance.appBuilder.addField('Date/Time');
      swimInstance.appBuilder.checkFieldProperties('Date & Time', {
        Required: false,
        'Read-only': false,
        Calculated: false
      });
      swimInstance.appBuilder.checkFieldPermissions('Date & Time');
      swimInstance.appBuilder.checkFieldAdvancedOptions('Date & Time', {
        'Default Value': 'None'
      });
      swimInstance.appBuilder.checkFieldSize('Date & Time');
    });

    it('Required Date/Time Field', () => {
      swimInstance.appBuilder.addField('Date/Time');
      swimInstance.appBuilder.editAppComponent('Date & Time (2)', {
        Name: 'Required Date & Time',
        Required: true
      });
    });

    it('Calculated Date/Time Field', () => {
      swimInstance.appBuilder.addField('Date/Time');
      swimInstance.appBuilder.editAppComponent('Date & Time (2)', {
        Name: 'Calculated Date & Time',
        Calculated: 'DATE("2009", "07", "04")'
      });
    });

    after(() => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('THEN: Verify the field properties in the record editor', () => {
    before('Create initial Record', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecord2ForApp(appName);
    });

    it('Verify Date & Time fields', () => {
      // Set non-required field so that we can see the error in the next step
      swimInstance.recordEditor2.setFieldValue({
        'Date & Time': { value: 'Jan 15, 2009 11:11 PM -06:00' }
      });

      // Click save button and verify error.
      swimInstance.recordEditor2.save('The record has validation error(s)!');
      swimInstance.recordEditor2.verifyValueVerification({
        'Required Date & Time': `Error: Required Date & Time is required.`
      });

      // Set required field, can clear other field
      swimInstance.recordEditor2.setFieldValue({
        'Date & Time': { value: '' },
        'Required Date & Time': { value: 'Jan 5, 1999 10:00 AM' }
      });

      cy.wait(300); // calculations are debounced, TODO: wait for API

      // Verify calculated field
      swimInstance.recordEditor2.verifyFieldValues(
        {
          'Calculated Date & Time': `Fri, Jul 3, 2009 6:00 PM -06:00 (MDT)`
        },
        false,
        true
      );
    });

    it('Click save button and verify valid save', () => {
      swimInstance.recordEditor2.save();
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const uniqueValue = faker.lorem.word();

describe('Record Editor 2 - Text Fields', () => {
  before(() => {
    cy.login();
    cy.cleanupSwimlane();
    cy.visitSwimlane('/');
    cy.setFeatureFlag('RecordPage');
  });

  describe('GIVEN: Add New application for Testing field parameters', () => {
    it('build base app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(appName);
    });
  });

  describe('WHEN: Add Text Fields With Options', () => {
    it('Unique Text Field', () => {
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.editAppComponent('Text', {
        Name: 'Unique Text',
        Unique: true
      });
    });

    it('Calculated Text Field', () => {
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.editAppComponent('Text', {
        Name: 'Calculated Text',
        Calculated: 'CONCATENATE ( [Unique Text], " calculated!")'
      });
    });

    it('Rich Text Field', () => {
      swimInstance.appBuilder.addField('Rich Text');
      swimInstance.appBuilder.editAppComponent('Text', {
        Name: 'Rich Text',
        Unique: false
      });
      swimInstance.appBuilder.saveApplication();
      swimInstance.appBuilder.checkFieldProperties('Rich Text', {
        Required: false,
        Unique: false,
        'Read-only': false,
        Calculated: false,
        'Write Once': false
      });
      swimInstance.appBuilder.checkFieldPermissions('Rich Text');
      swimInstance.appBuilder.checkFieldAdvancedOptions('Rich Text', {
        Prefix: '',
        Suffix: '',
        Placeholder: '',
        Length: { Min: '', Max: '', Units: 'None' }
      });
      swimInstance.appBuilder.checkFieldSize('Rich Text', '50%');
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('THEN: Verify the field properties in the record editor', () => {
    before('Create initial Record', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecord2ForApp(appName);
    });

    it('Verify Unique Property, field properties', () => {
      swimInstance.recordEditor2.setFieldValue({
        'Unique Text': { value: uniqueValue, isUnique: true, isCalculated: true }
      });
    });

    it('Verify Rich Text, set field values', () => {
      swimInstance.recordEditor2.setFieldValue({
        'Rich Text': {
          value: 'This is rich text. /n <script>alert(23)</script>!'
        }
      });
      swimInstance.recordEditor2.save();
    });

    it('Verify calculated field', () => {
      swimInstance.recordEditor2.verifyFieldValues(
        {
          'Calculated Text': `${uniqueValue} calculated!`
        },
        false
      );
    });
  });

  describe('THEN: Verify unique field check on record save', () => {
    before(() => {
      swimInstance.startNewRecord2ForApp(appName);
    });

    it('Update the record to see unique value conflict.', () => {
      swimInstance.recordEditor2.setFieldValue({
        'Unique Text': { value: uniqueValue, isUnique: true }
      });
      swimInstance.recordEditor2.verifyValueVerification({
        'Unique Text': `Error: Unique Text must be a unique value.`
      });
    });

    it('Change unique value to not be a duplicate.', () => {
      swimInstance.recordEditor2.setFieldValue({
        'Unique Text': { value: `${uniqueValue}1`, isUnique: true }
      });
    });

    it('Save the record to see unique value.', () => {
      swimInstance.recordEditor2.save();
      swimInstance.recordEditor2.verifyValueVerification({
        'Unique Text': ''
      });
    });
  });

  after('Turn New Record page off, cleanup Swimlane and log out', () => {
    cy.setFeatureFlag('RecordPage', false);
    cy.cleanupSwimlane();
    cy.logout();
  });
});

import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const numericValue = faker.random.number();
const numericValue2 = `${numericValue}1`;
const numericValue3 = `${numericValue2}12`;
const numericValue4 = `${numericValue3}1234`;

describe('Record Editor 2 - History Fields', () => {
  before(() => {
    cy.login();
    cy.setFeatureFlag('RecordPage');
    cy.visitSwimlane('/');
  });

  describe('GIVEN: Add New application for Testing field parameters', () => {
    it('build base app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(appName);
    });
  });

  describe('WHEN: Add Fields', () => {
    it('Numeric Field', () => {
      swimInstance.appBuilder.addField('Numeric');
    });

    it('Date & Time Field', () => {
      swimInstance.appBuilder.addField('Date & Time');
    });

    it('History Field', () => {
      swimInstance.appBuilder.addField('History');
    });

    after(() => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('THEN: Add values on the record editor', () => {
    before('Create initial Record', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecord2ForApp(appName);
    });

    it('Add numeric value', () => {
      swimInstance.recordEditor2.setFieldValue({
        Numeric: { value: numericValue }
      });
    });

    it('Add date value', () => {
      swimInstance.recordEditor2.setFieldValue({
        'Date & Time': { value: 'Jan 15, 2009 11:11 PM -06:00' }
      });
    });

    after(() => {
      swimInstance.recordEditor2.save();
    });
  });

  describe('THEN(2): Update the values and save the changes', () => {
    it('Add numeric value', () => {
      swimInstance.recordEditor2.setFieldValue({
        Numeric: { value: numericValue2 }
      });
    });

    it('Add date value', () => {
      swimInstance.recordEditor2.setFieldValue({
        'Date & Time': { value: 'Jan 26, 2020 12:21 PM -09:00' }
      });
      swimInstance.recordEditor2.save('Record saved');
    });
  });

  describe('THEN(3): Update the values and save the changes', () => {
    it('Add numeric value', () => {
      swimInstance.recordEditor2.setFieldValue({
        Numeric: { value: numericValue3 }
      });
    });

    it('Add date value', () => {
      swimInstance.recordEditor2.setFieldValue({
        'Date & Time': { value: 'Jan 27, 2020 12:21 PM -09:00' }
      });
      swimInstance.recordEditor2.save('Record saved');
    });
  });

  describe('THEN(4): Update the values and validate the changes', () => {
    it('Add numeric value', () => {
      swimInstance.recordEditor2.setFieldValue({
        Numeric: { value: numericValue4 }
      });
    });

    it('Add date value', () => {
      swimInstance.recordEditor2.setFieldValue({
        'Date & Time': { value: 'Jan 28, 2020 12:21 PM -09:00' }
      });
      swimInstance.recordEditor2.save('Record saved');
    });

    it('Verify history record', () => {
      // Validate that the changes are reflected on the History table
      swimInstance.recordEditor2.verifyHistoryRecord(numericValue2);
    });
  });

  after('Turn New Record page off, cleanup Swimlane and log out', () => {
    cy.setFeatureFlag('RecordPage', false);
    cy.cleanupSwimlane();
    cy.logout();
  });
});

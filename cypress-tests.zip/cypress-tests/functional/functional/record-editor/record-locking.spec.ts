import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);

describe('Record Editor 2 - Text Fields', () => {
  before(() => {
    cy.login();
    cy.cleanupSwimlane();
    cy.visitSwimlane('/');
    cy.setFeatureFlag('RecordPage');
  });

  describe('Add New application for Testing Record locking', () => {
    it('build base app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(appName);
    });
  });

  describe('Add some Fields', () => {
    it('Text Field', () => {
      swimInstance.appBuilder.addField('Text');
    });

    it('Numeric Field', () => {
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Verify Record locking in the record editor', () => {
    before('Create initial Record', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecord2ForApp(appName);
      swimInstance.recordEditor2.setFieldValue({
        Text: { value: 'Testing!' }
      });
      swimInstance.recordEditor2.setFieldValue({
        Numeric: { value: 555 }
      });
      swimInstance.recordEditor2.save();
    });

    it('Lock the Record', () => {
      swimInstance.recordEditor2.lockUnlockRecord();
      swimInstance.recordEditor2.verifyLockedRecord(true, Cypress.env('USERNAME'));
    });

    it('Unlock the Record', () => {
      swimInstance.recordEditor2.lockUnlockRecord(false);
      swimInstance.recordEditor2.verifyLockedRecord(false);
    });
  });

  after('Turn New Record page off, cleanup Swimlane and log out', () => {
    // cy.setFeatureFlag('RecordPage', false);
    // cy.cleanupSwimlane();
    cy.logout();
  });
});

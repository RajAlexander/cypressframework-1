import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const dayjs = require('dayjs');
const todaysDate = dayjs().format('MMM DD, YYYY hh:mm A');
let recordTrackingId = '';

describe('Previous X Days" filter should include the Current Day data in search results', () => {
  before(() => {
    cy.login();
    cy.setFeatureFlag('RecordPage');
    cy.visitSwimlane('/');
  });

  describe('Add New application for validating previous day filter', () => {
    it('build base app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(appName);
    });
  });

  describe('Add Date/Time Fields With Options', () => {
    it('Add Date/Time Field', () => {
      swimInstance.appBuilder.addField('Date/Time');
      swimInstance.appBuilder.checkFieldProperties('Date & Time', {
        Required: false,
        'Read-only': false,
        Calculated: false
      });
      swimInstance.appBuilder.checkFieldPermissions('Date & Time');
      swimInstance.appBuilder.checkFieldAdvancedOptions('Date & Time', {
        'Default Value': 'None'
      });
      swimInstance.appBuilder.checkFieldSize('Date & Time');
    });
    after(() => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe(' Verify previous day filter shows/include current day record', () => {
    it('Create records with current date', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecordForApp(appName);

      swimInstance.recordEditor.setFieldValue({
        'Date & Time': { value: todaysDate }
      });
      swimInstance.recordEditor.save();
      swimInstance.recordEditor.getRecordTrackingID(true).then($trackingID => {
        recordTrackingId = $trackingID;
      });
    });
    it('Apply Filter and check if previous day filter include current day record', () => {
      swimInstance.OpenAppListAll(appName);
      swimInstance.recordListing.setAddRemoveColumsValue('Date & Time');
      swimInstance.recordListing.recordFilter('Date & Time', 'Previous', '1', 'Day');
      swimInstance.recordListing.openRecord(recordTrackingId);
      swimInstance.recordEditor.getRecordTrackingID().then($trackingID => {
        expect($trackingID).to.equal(recordTrackingId);
      });
    });

    after(() => {
      cy.cleanupSwimlane();
      cy.logout();
    });
  });
});

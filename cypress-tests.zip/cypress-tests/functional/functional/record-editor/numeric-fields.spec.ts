import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const minValue = faker.random.number();
const minMaxValues = [minValue, minValue + faker.random.number({ min: 5, max: 1000 })];
let appAcronym2 = '';

describe('Record Editor 2 - Numeric Fields', () => {
  before(() => {
    cy.login();
    cy.setFeatureFlag('RecordPage');
    cy.visitSwimlane('/');
  });

  describe('GIVEN: Add New application for Testing field parameters', () => {
    it('build base app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.getAppAcronym().then(acronym => {
        appAcronym2 = acronym;
      });
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(appName);
    });
  });

  describe('WHEN: Add Numeric Fields With Options', () => {
    it('Unique Numeric Field', () => {
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.editAppComponent('Numeric', {
        Name: 'Unique Numeric',
        Unique: true
      });
    });

    it('Calculated Numeric Field', () => {
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.editAppComponent('Numeric', {
        Name: 'Calculated Numeric',
        Calculated: '[Unique Numeric] + 1'
      });
    });

    after(() => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('THEN: Verify the field properties in the record editor', () => {
    it('Create initial Record', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecord2ForApp(appName);
      swimInstance.recordEditor2.verifyRecordPageElements(true, appName, appAcronym2);
    });

    it('Verify Unique Property, field properties', () => {
      swimInstance.recordEditor2.setFieldValue({
        'Unique Numeric': { value: minMaxValues[1] - 1, isUnique: true }
      });
      swimInstance.recordEditor2.verifyRecordPageElements(true, appName, appAcronym2);
      swimInstance.recordEditor2.save();
    });

    it('Verify Calculated Field', () => {
      swimInstance.recordEditor2.verifyFieldIsCalculated('Calculated Numeric');
    });

    it('Verify Calculated Property', { tags: ['SPT-13610'] }, () => {
      swimInstance.recordEditor2.verifyFieldValues({ 'Unique Numeric': (minMaxValues[1] - 1).toString() }, false);
      swimInstance.recordEditor2.verifyFieldValues({ ' Calculated Numeric ': minMaxValues[1].toString() }, false);
      swimInstance.recordEditor2.setFieldValue({
        'Unique Numeric': { value: minMaxValues[0], isUnique: true }
      });
      swimInstance.recordEditor2.save('Record saved', false, false, false, true);
      swimInstance.recordEditor2.verifyFieldValues({ 'Unique Numeric': minMaxValues[0].toString() }, false);
      swimInstance.recordEditor2.verifyFieldValues({ ' Calculated Numeric ': (minMaxValues[0] + 1).toString() }, false);
      swimInstance.recordEditor2.verifyRecordPageElements(false, appName, appAcronym2);
    });
  });

  describe('THEN(2): Verify unique field check on record save', () => {
    before('Create new record', () => {
      swimInstance.startNewRecord2ForApp(appName);
      swimInstance.recordEditor2.setFieldValue({
        'Unique Numeric': { value: minMaxValues[0], isUnique: true }
      });
    });

    it('Save the record to see unique value conflict.', () => {
      swimInstance.recordEditor2.save('The record has validation error(s)!');
      swimInstance.recordEditor2.verifyValueVerification({
        'Unique Numeric': `Error: Unique Numeric must be a unique value.`
      });
    });

    it('Change unique value to not be a duplicate.', () => {
      swimInstance.recordEditor2.setFieldValue({
        'Unique Numeric': { value: minMaxValues[1], isUnique: true }
      });
    });

    it('Save the record to see unique value.', () => {
      swimInstance.recordEditor2.save('Record created');
      swimInstance.recordEditor2.verifyValueVerification({
        'Unique Numeric': ''
      });
    });
  });

  after('Turn New Record page off, cleanup Swimlane and log out', () => {
    cy.setFeatureFlag('RecordPage', false);
    cy.cleanupSwimlane();
    cy.logout();
  });
});

import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

function personalized(baseText: string, inserts = {}) {
  return baseText.replace(/\$(.*?)\$/g, (placeholder: string) => {
    return inserts[placeholder.substring(1, placeholder.length - 1)] || 'null';
  });
}

describe('Using task debugger', { tags: ['#bug', 'SPT-12163'] }, () => {
  const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 64);
  const taskName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 64);
  const taskName2 = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 64);
  const taskName3 = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 64);
  const taskName4 = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 64);
  const bulkRecords = [{ Text: 'nasa.gov', Numeric: -100 }];
  const pythonCode = 'import time \ntime.sleep(1)\nprint(sw_context.inputs["textIn"])';
  const pythonCode2 = 'import time \ntime.sleep(20)\nprint("hello")';
  const pythonCode3 = 'import time \ntime.sleep(20)\nprint("today")';
  const pythonCode4 = 'sw_outputs.append({\n"key_storefield":sw_context.inputs["keystore_field"]\n})';

  const defaultTaskOutputs =
    '[\n  {\n    "sw_task_status": "success",\n    "sw_task_error_type": "",\n    "sw_task_error_message": "",\n    "sw_task_stack_trace": "",\n    "stdOutput": "$output$"\n  }\n]';

  const defaultWhoIsOutput =
    '[\n  {\n    "address": null,\n    "whois_server": null,\n    "registrar": null,\n    "raw_text": "!!NO TEXT RETURNED FROM LOOKUP!!",\n    "city": null,\n    "raw_json": {\n      "domain_name": null,\n      "registrar": null,\n      "whois_server": null,\n      "referral_url": null,\n      "updated_date": null,\n      "creation_date": null,\n      "expiration_date": null,\n      "name_servers": null,\n      "status": null,\n      "emails": null,\n      "dnssec": null,\n      "name": null,\n      "org": null,\n      "address": null,\n      "city": null,\n      "state": null,\n      "zipcode": null,\n      "country": null,\n      "raw_text": "!!NO TEXT RETURNED FROM LOOKUP!!"\n    },\n    "name_servers": null,\n    "emails": null,\n    "country": null,\n    "zipcode": null,\n    "name": null,\n    "org": null,\n    "creation_date": null,\n    "status": null,\n    "state": null,\n    "referral_url": null,\n    "dnssec": null,\n    "domain_name": null,\n    "expiration_date": null,\n    "updated_date": null,\n    "sw_task_status": "success",\n    "sw_task_error_type": "",\n    "sw_task_error_message": "",\n    "sw_task_stack_trace": "",\n    "stdOutput": null\n  }\n]';

  const defaultWhoIsOutputRecord =
    '[\n  {\n    "address": null,\n    "whois_server": null,\n    "registrar": null,\n    "raw_text": "% DOTGOV WHOIS Server ready\\r\\n   Domain Name: NASA.GOV\\r\\n   Status: ACTIVE\\r\\n   Security Contact Email: soc@nasa.gov\\r\\n\\r\\n>>> Last update of whois database: %date% <<<\\r\\n\\r\\nPlease be advised that this whois server only contains information pertaining\\r\\nto the .GOV domain. For information for other domains please use the whois\\r\\nserver at RS.INTERNIC.NET. \\r\\n",\n    "city": null,\n    "raw_json": {\n      "domain_name": "NASA.GOV",\n      "registrar": null,\n      "whois_server": null,\n      "referral_url": null,\n      "updated_date": null,\n      "creation_date": null,\n      "expiration_date": null,\n      "name_servers": null,\n      "status": "ACTIVE",\n      "emails": "soc@nasa.gov",\n      "dnssec": null,\n      "name": null,\n      "org": null,\n      "address": null,\n      "city": null,\n      "state": null,\n      "zipcode": null,\n      "country": null,\n      "raw_text": "% DOTGOV WHOIS Server ready\\r\\n   Domain Name: NASA.GOV\\r\\n   Status: ACTIVE\\r\\n   Security Contact Email: soc@nasa.gov\\r\\n\\r\\n>>> Last update of whois database: %date% <<<\\r\\n\\r\\nPlease be advised that this whois server only contains information pertaining\\r\\nto the .GOV domain. For information for other domains please use the whois\\r\\nserver at RS.INTERNIC.NET. \\r\\n"\n    },\n    "name_servers": null,\n    "emails": "soc@nasa.gov",\n    "country": null,\n    "zipcode": null,\n    "name": null,\n    "org": null,\n    "creation_date": null,\n    "status": "ACTIVE",\n    "state": null,\n    "referral_url": null,\n    "dnssec": null,\n    "domain_name": "NASA.GOV",\n    "expiration_date": null,\n    "updated_date": null,\n    "sw_task_status": "success",\n    "sw_task_error_type": "",\n    "sw_task_error_message": "",\n    "sw_task_stack_trace": "",\n    "stdOutput": null\n  }\n]';

  const defaultWhoIsOutputCreate =
    '[\n  {\n    "address": null,\n    "whois_server": null,\n    "registrar": null,\n    "raw_text": "% DOTGOV WHOIS Server ready\\r\\n   Domain Name: WHITEHOUSE.GOV\\r\\n   Status: ACTIVE\\r\\n\\r\\n>>> Last update of whois database: %date% <<<\\r\\n\\r\\nPlease be advised that this whois server only contains information pertaining\\r\\nto the .GOV domain. For information for other domains please use the whois\\r\\nserver at RS.INTERNIC.NET. \\r\\n",\n    "city": null,\n    "raw_json": {\n        "domain_name": "WHITEHOUSE.GOV",\n        "registrar": null,\n        "whois_server": null,\n        "referral_url": null,\n        "updated_date": null,\n        "creation_date": null,\n        "expiration_date": null,\n        "name_servers": null,\n        "status": "ACTIVE",\n        "emails": null,\n        "dnssec": null,\n        "name": null,\n        "org": null,\n        "address": null,\n        "city": null,\n        "state": null,\n        "zipcode": null,\n        "country": null,\n        "raw_text": "% DOTGOV WHOIS Server ready\\r\\n   Domain Name: WHITEHOUSE.GOV\\r\\n   Status: ACTIVE\\r\\n\\r\\n>>> Last update of whois database: %date% <<<\\r\\n\\r\\nPlease be advised that this whois server only contains information pertaining\\r\\nto the .GOV domain. For information for other domains please use the whois\\r\\nserver at RS.INTERNIC.NET. \\r\\n"\n    },\n    "name_servers": null,\n    "emails": null,\n    "country": null,\n    "zipcode": null,\n    "name": null,\n    "org": null,\n    "creation_date": null,\n    "status": "ACTIVE",\n    "state": null,\n    "referral_url": null,\n    "dnssec": null,\n    "domain_name": "WHITEHOUSE.GOV",\n    "expiration_date": null,\n    "updated_date": null,\n    "sw_task_status": "success",\n    "sw_task_error_type": "",\n    "sw_task_error_message": "",\n    "sw_task_stack_trace": "",\n    "stdOutput": null\n  }\n]';

  const whoIsDetails = {
    file: 'bundles/sw_swimlane_parse_whois_lookup-1.1.3-linux.python36.swimbundle',
    name: 'WHOIS Parse',
    version: '1.1.3',
    subName: 'sw_swimlane_parse_whois_lookup',
    description: 'Get Whois information on IP address'
  };
  const recordData = {
    Text: 'nasa.gov',
    Numeric: '-100',
    'Domain Name': '',
    $: '',
    '$.domain_name': ''
  };
  const keyname = faker.random.word().toLowerCase();
  const defaultTaskOutputsKeyStoreRun =
    '[\n  {\n    "key_storefield": "$keyvaluerand$",\n    "sw_task_status": "success",\n    "sw_task_error_type": "",\n    "sw_task_error_message": "",\n    "sw_task_stack_trace": "",\n    "stdOutput": null\n  }\n]';

  const APPLIST = [];
  const WORKSPACELIST = [];
  let appId = '';
  let recordId = '';
  let appAcronym = '';

  before(() => {
    cy.login();
    cy.cleanUpBundles([whoIsDetails.subName]);
    cy.visitSwimlane('/');
  });

  describe('Create App', () => {
    it('build app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.getAppAcronym().then(acronym => {
        appAcronym = acronym;
      });
      swimInstance.appsAppletsListing.appWizard.createApp();
      APPLIST.push(appName);
      WORKSPACELIST.push(`${appName} Workspace`);
    });

    it('Add text fields', () => {
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.getAppID().then($appID => {
        appId = $appID;
      });
      swimInstance.appBuilder.addField('Single-Line');
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.saveApplication();
    });

    it('create some records', () => {
      (cy as any).batchRecordCreateAPI(appId, bulkRecords);
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.OpenAppListAll(appName);
    });
  });

  describe('Test debug python task', () => {
    it('Create python task to debug run 1', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', taskName, appName);
      swimInstance.integrationsPage.setBypassTimeout(false);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: pythonCode,
        inputs: { Variable: 'textIn', Type: 'Record', Field: 'Text' }
      });
      swimInstance.integrationsPage.saveCurrentTask(false);
    });

    it('Debug with manual values', () => {
      swimInstance.integrationsPage.runTaskDebugger(JSON.parse(personalized(defaultTaskOutputs, { output: 'Hello' })), {
        textIn: 'Hello'
      });
    });

    it('Debug with actual record values', () => {
      swimInstance.integrationsPage.runTaskDebugger(
        JSON.parse(personalized(defaultTaskOutputs, { output: bulkRecords[0].Text })),
        {
          fromRecord: `${appAcronym}-1`
        }
      );
    });

    it('Collect app and record ids from task debug', () => {
      swimInstance.integrationsPage.editTaskConfiguration({
        script: 'print(sw_context.config)'
      });
      swimInstance.integrationsPage.runTaskDebugger(null, { fromRecord: `${appAcronym}-1` }).then(output => {
        const cleanOutput = String(output)
          .replace(/"{'/g, '{"')
          .replace(/'}"/g, '"}')
          .replaceAll(/': '/g, '": "')
          .replaceAll(/', '/g, '", "');

        const stdout = JSON.parse(cleanOutput)[0].stdOutput;

        expect(stdout.ApplicationId).to.equal(appId);
        recordId = stdout.RecordId;
      });
    });

    it('Close the Task', () => {
      swimInstance.integrationsPage.saveCurrentTask();
    });

    it('Verify the app and record IDs from task debug are valid', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.OpenAppListAll(appName);
      swimInstance.recordListing.openRecord(`${appAcronym}-1`);
      swimInstance.recordEditor.loadRecordPage();
      cy.wait(1000);
      cy.url().then(url => {
        expect(url).to.equal(`${Cypress.config('baseUrl')}/record/${appId}/${recordId}`);
      });
    });
  });

  describe('Test debug Key Store value input', () => {
    const keyvalue = faker.random.word();

    it('Create a Key Store', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.openKeyStorePage();
      swimInstance.integrationsPage.addNewKeyStore(keyname, keyvalue);
      swimInstance.openIntegrations();
    });

    it('Create python task for Debug Key Store', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', taskName4, appName);
      swimInstance.integrationsPage.setBypassTimeout(false);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: pythonCode4,
        inputs: { Variable: 'keystore_field', Type: 'Key Store', Key: keyname }
      });
      swimInstance.integrationsPage.saveCurrentTask(false);
    });

    it('Debug with Key Store Values', () => {
      swimInstance.integrationsPage.runTaskDebugger(
        JSON.parse(
          personalized(defaultTaskOutputsKeyStoreRun, {
            keyvaluerand: keyvalue
          })
        )
      );
    });

    it('Close the Task', () => {
      swimInstance.integrationsPage.closeTask();
    });
  });

  describe('Test debug plugin task', () => {
    it('Upload bundle', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.checkForExistingBundle(whoIsDetails.subName, whoIsDetails.version);
    });

    it('create task', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('WHOIS Lookup', taskName2, appName);
      swimInstance.integrationsPage.editTaskConfiguration({
        Domain: ['Record', 'Text']
      });
      swimInstance.integrationsPage.editTaskOutputMapping({
        updateRecord: {
          newTargetMappings: {
            $: 'Single-Line',
            '$.domain_name': 'Single-Line',
            domain_name: 'Single-Line'
          },
          createOutputs: ['$', '$.domain_name']
        }
      });
    });

    it('Save the Task', () => {
      swimInstance.integrationsPage.saveCurrentTask(false);
    });

    it('Debug with manual values', () => {
      swimInstance.integrationsPage.runTaskDebugger(JSON.parse(personalized(defaultWhoIsOutput, {})), {
        domain: 'Hello'
      });
    });

    it('Debug with actual record values', () => {
      swimInstance.integrationsPage.runTaskDebugger(
        JSON.parse(
          personalized(defaultWhoIsOutputRecord, {
            status: '"ACTIVE"',
            domain_name: '"NASA.GOV"',
            emails: '"soc@nasa.gov"'
          })
        ),
        {
          fromRecord: `${appAcronym}-1`
        }
      );
    });

    it('Create new record on the fly', () => {
      swimInstance.integrationsPage.runTaskDebugger(
        JSON.parse(
          personalized(defaultWhoIsOutputCreate, {
            status: '"ACTIVE"',
            domain_name: '"WHITEHOUSE.GOV"'
          })
        ),
        {
          newRecord: { Text: { value: 'whitehouse.gov' } }
        }
      );
    });

    it('Close the Task', () => {
      swimInstance.integrationsPage.saveCurrentTask();
    });
  });

  describe('Verify the record did not update from debug run', () => {
    it('Open record and verify field values.', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.OpenAppListAll(appName);
      swimInstance.recordListing.openRecord(`${appAcronym}-1`);
      swimInstance.recordEditor.verifyFieldValues(recordData);
    });

    it('close the record', () => {
      swimInstance.recordListing.closeRecordWindow();
    });
  });

  describe('Test timeout running task debug', () => {
    before(() => {
      localStorage.setItem('debugTaskTimeoutMillis', '2500');
    });

    after(() => {
      localStorage.removeItem('debugTaskTimeoutMillis');
    });

    it('Create python task with long loop', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', taskName3, appName);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: pythonCode2
      });
      swimInstance.integrationsPage.saveCurrentTask(false);
    });

    it('Debug with timeout', () => {
      swimInstance.integrationsPage.runTaskDebugger('Timeout Error');
    });

    it('Switch pages to refresh debugger UI', () => {
      swimInstance.integrationsPage.openTaskOutputs();
    });

    it('Debug with bypass timeout', () => {
      swimInstance.integrationsPage.runTaskDebugger(
        JSON.parse(personalized(defaultTaskOutputs, { output: 'hello' })),
        null,
        {
          bypass: true
        }
      );
    });

    it('Turn back off bypass', () => {
      swimInstance.integrationsPage.setBypassTimeout(false);
    });

    it('Stop task while running in debugger', () => {
      swimInstance.integrationsPage.editTaskConfiguration({
        script: pythonCode3
      });
      swimInstance.integrationsPage.runTaskDebugger('Run task to show results.', null, { stop: true });
    });

    it('Close the Task', () => {
      swimInstance.integrationsPage.saveCurrentTask();
    });
  });

  describe('Cleanup Apps, Tasks, etc', () => {
    it('Delete key store that were added.', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.openKeyStorePage();
      swimInstance.integrationsPage.deleteKeystore(keyname);
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

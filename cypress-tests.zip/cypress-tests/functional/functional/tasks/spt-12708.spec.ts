import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const taskName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 64);
const pythonCode = 'import time \ntime.sleep(1)\nprint(sw_context.inputs["textIn"])';

describe('SPT-12708: Add helper text to Cron on Scheduled Tasks', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Create tasks from the integration action', () => {
    it('Create first python Task', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', taskName);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: pythonCode
      });
      swimInstance.integrationsPage.addTriggerToTask();
      swimInstance.integrationsPage.saveCurrentTask();
    });
    it('Remove the Tasks and Assets', () => {
      cy.cleanupSwimlane();
      cy.logout();
    });
  });
});

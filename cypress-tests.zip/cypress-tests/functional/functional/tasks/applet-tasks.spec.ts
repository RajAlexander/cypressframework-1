import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appletName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const appletName2 = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const taskName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const taskName2 = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const whoIsDetails = {
  file: 'bundles/sw_swimlane_parse_whois_lookup-1.1.3-linux.python36.swimbundle',
  name: 'WHOIS Parse',
  version: '1.1.3',
  subName: 'sw_swimlane_parse_whois_lookup',
  description: 'Get Whois information on IP address'
};

describe('SPT-5545: Deselect all fields in mapping', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Create Applet', () => {
    it('build applet', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApplet();
      swimInstance.appsAppletsListing.appWizard.setAppName(appletName, false);
      swimInstance.appsAppletsListing.appWizard.createApplet();
    });

    it('Add text fields', () => {
      swimInstance.appBuilder.verifyElements(appletName, false);
      swimInstance.appBuilder.addField('Single-Line', '', false);
      swimInstance.appBuilder.addField('Single-Line', '', false);
      swimInstance.appBuilder.saveApplet();
    });
  });

  describe('Create Python task', () => {
    it('Start New Applet Task', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', taskName, appletName);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: 'print sw_context.inputs["Text"]',
        inputs: { Type: 'Record', Field: 'Text', Variable: 'Text' }
      });
    });

    it('Save the Task', () => {
      swimInstance.integrationsPage.saveCurrentTask();
    });
  });

  describe('Upload the swimlane parse whois plugin', () => {
    it('Upload bundle', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.checkForExistingBundle('sw_swimlane_parse_whois_lookup', '1.1.3');
    });
  });

  describe('Create Applet', () => {
    it('build app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApplet();
      swimInstance.appsAppletsListing.appWizard.setAppName(appletName2, false);
      swimInstance.appsAppletsListing.appWizard.createApplet();
    });

    it('Add Fields', () => {
      swimInstance.appBuilder.verifyElements(appletName2, false);
      swimInstance.appBuilder.addField('Text', '', false);
      swimInstance.appBuilder.addField('Text', '', false);
      swimInstance.appBuilder.editAppComponent(
        'Text (2)',
        {
          Name: 'name_servers',
          Required: true
        },
        false
      );
      swimInstance.appBuilder.addField('Single-Line', '', false);
      swimInstance.appBuilder.editAppComponent(
        'Text (2)',
        {
          Name: 'registrar',
          Required: true
        },
        false
      );
      swimInstance.appBuilder.addField('Numeric', '', false);
      swimInstance.appBuilder.addLayout('Integration', false);
    });

    it('Save Applet', () => {
      swimInstance.appBuilder.saveApplet();
    });
  });

  describe('Setup task for WHOIS lookup and then verify Mapping Actions', () => {
    it('create task', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('WHOIS Lookup', taskName2, appletName2);
      swimInstance.integrationsPage.editTaskConfiguration({
        Domain: ['Record', 'Text']
      });
      swimInstance.integrationsPage.editTaskOutputMapping({
        updateRecord: {
          createOutputs: ['$', '$.domain_name', '$.марјан'],
          newTargetMappings: {
            $: 'Single-Line',
            '$.domain_name': 'Single-Line',
            domain_name: 'Single-Line',
            '$.марјан': 'Single-Line'
          }
        }
      });
      swimInstance.integrationsPage.verifyMappings({
        $: '$',
        '$.domain_name': '$.domain_name',
        '$.марјан': '$.марјан',
        domain_name: 'Domain Name',
        name_servers: 'name_servers',
        registrar: 'registrar'
      });
    });

    it('Save the Task', () => {
      swimInstance.integrationsPage.saveCurrentTask();
    });
  });

  describe('Verify that Applet Tasks are deleted when the Applet is deleted', () => {
    it('Delete an Applet, check that the associated Task has been deleted as well', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.deleteExistingApplet(appletName);
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.verifyNonExistingTask({ name: taskName });
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

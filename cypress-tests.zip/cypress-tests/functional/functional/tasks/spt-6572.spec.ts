import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const sourceAppName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const taskName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const JSONResults =
  '{  "address": null,  "whois_server": null,  "registrar": null,  "raw_text": "% DOTGOV WHOIS Server ready\\r\\n   Domain Name: WHITEHOUSE.GOV\\r\\n   Status: ACTIVE\\r\\n\\r\\n>>> Last update of whois database: <DATE> <<<\\r\\n\\r\\nPlease be advised that this whois server only contains information pertaining\\r\\nto the .GOV domain. For information for other domains please use the whois\\r\\nserver at RS.INTERNIC.NET. \\r\\n",  "city": null,  "raw_json": {    "domain_name": "WHITEHOUSE.GOV",    "registrar": null,    "whois_server": null,    "referral_url": null,    "updated_date": null,    "creation_date": null,    "expiration_date": null,    "name_servers": null,    "status": "ACTIVE",    "emails": null,    "dnssec": null,    "name": null,    "org": null,    "address": null,    "city": null,    "state": null,    "zipcode": null,    "country": null,    "raw_text": "% DOTGOV WHOIS Server ready\\r\\n   Domain Name: WHITEHOUSE.GOV\\r\\n   Status: ACTIVE\\r\\n\\r\\n>>> Last update of whois database: <DATE> <<<\\r\\n\\r\\nPlease be advised that this whois server only contains information pertaining\\r\\nto the .GOV domain. For information for other domains please use the whois\\r\\nserver at RS.INTERNIC.NET. \\r\\n"  },  "name_servers": null,  "emails": null,  "country": null,  "zipcode": null,  "name": null,  "org": null,  "creation_date": null,  "status": "ACTIVE",  "state": null,  "referral_url": null,  "dnssec": null,  "domain_name": "WHITEHOUSE.GOV",  "expiration_date": null,  "updated_date": null,  "sw_task_status": "success",  "sw_task_error_type": "",  "sw_task_error_message": "",  "sw_task_stack_trace": "",  "stdOutput": null}';

describe('SPT-6572: Global output mapping option "all" field', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Upload the swimlane parse whois plugin', () => {
    it('Upload bundle', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.checkForExistingBundle('sw_swimlane_parse_whois_lookup', '1.1.3');
    });
  });

  describe('Create Source App', () => {
    it('build Source app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(sourceAppName);
      swimInstance.appsAppletsListing.appWizard.createApp();
    });

    it('Add Text Field', () => {
      swimInstance.appBuilder.verifyElements(sourceAppName);
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.addLayout('Integration');
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Setup task for WHOIS lookup', () => {
    it('create task', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('WHOIS Lookup', taskName, sourceAppName);
      swimInstance.integrationsPage.editTaskConfiguration({
        Domain: ['Record', 'Text']
      });
      swimInstance.integrationsPage.editTaskOutputMapping({
        updateRecord: {
          newTargetMappings: {
            $: 'Single-Line',
            '$.domain_name': 'Single-Line',
            domain_name: 'Single-Line',
            '$.марјан': 'Single-Line'
          },
          createOutputs: ['$', '$.domain_name', '$.марјан']
        }
      });
      swimInstance.integrationsPage.saveCurrentTask();
    });

    it('Add task to the app via push button', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.editExistingApp(sourceAppName);
      swimInstance.appBuilder.editAppComponent('Integration', {
        Name: 'Trigger Task',
        Task: taskName
      });
    });

    it('Save the App', () => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Create record to test', () => {
    it('Create record', () => {
      cy.wait(1000);
      swimInstance.switchToWorkspace(`${sourceAppName} Workspace`);
      swimInstance.startNewRecordForApp(sourceAppName);
      swimInstance.recordEditor.setFieldValue({
        Text: { value: 'whitehouse.gov' }
      });
      swimInstance.recordEditor.save('Record saved');
    });

    it('Trigger the integration via push button', () => {
      swimInstance.recordEditor.clickIntegrationButton('Trigger Task', taskName);
    });

    it('Verify mapped results', () => {
      swimInstance.recordEditor.verifyFieldValues(
        {
          'Domain Name': 'WHITEHOUSE.GOV',
          '$.domain_name': 'WHITEHOUSE.GOV',
          $: JSONResults
        },
        false
      );
    });
  });

  describe('(SPT-7391) Verify the valid key for field with all chars not valid for key.', () => {
    it('Open App in editor to validate the field key.', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.editExistingApp(sourceAppName);
      swimInstance.appBuilder.verifyFieldKey('$', '-');
      swimInstance.appBuilder.verifyFieldKey('$.марјан', '--u1084u1072u1088u1112u1072u1085');
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

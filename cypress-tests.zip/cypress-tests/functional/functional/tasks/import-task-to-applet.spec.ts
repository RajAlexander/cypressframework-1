import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const appletName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);

const APPLIST = [];

describe('SPT-10906: Allow importing tasks to an applet', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Create Applet', () => {
    it('build applet', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApplet();
      swimInstance.appsAppletsListing.appWizard.setAppName(appletName, false);
      swimInstance.appsAppletsListing.appWizard.createApplet();
      APPLIST.push(appName);
    });

    it('Add text fields', () => {
      swimInstance.appBuilder.verifyElements(appletName, false);
      swimInstance.appBuilder.addField('Single-Line', '', false);
      swimInstance.appBuilder.addField('Single-Line', '', false);
      swimInstance.appBuilder.saveApplet();
    });
  });

  describe('Create App', () => {
    it('build app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
      APPLIST.push(appName);
    });

    it('Add Fields', () => {
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.addField('Text', '');
      swimInstance.appBuilder.addField('Text', '');
    });

    it('Save App', () => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Upload different tasks', () => {
    before(() => {
      swimInstance.openIntegrations();
    });
    describe('Common Task', () => {
      it('upload common task to applet', () => {
        swimInstance.integrationsPage.uploadTask('tasks/common task.json');
        swimInstance.integrationsPage.setTaskDetails('QA-E2E-common task', appletName);
        swimInstance.integrationsPage.clickUploadPlugin();
        swimInstance.integrationsPage.closeTaskUpload();
      });
    });
    describe('App Task', () => {
      it('upload app task to applet', () => {
        swimInstance.integrationsPage.uploadTask('tasks/app task.json');
        swimInstance.integrationsPage.setTaskDetails('QA-E2E-app task', appletName);
        swimInstance.integrationsPage.clickUploadPlugin();
        swimInstance.integrationsPage.closeTaskUpload();
      });
    });
    describe('Applet Task', () => {
      it('upload applet task to applet', () => {
        swimInstance.integrationsPage.uploadTask('tasks/applet task.json');
        swimInstance.integrationsPage.setTaskDetails('QA-E2E-applet task', appletName);
        swimInstance.integrationsPage.clickUploadPlugin();
        swimInstance.integrationsPage.closeTaskUpload();
      });
    });
  });

  describe('Upload different tasks', () => {
    before(() => {
      swimInstance.openIntegrations();
    });
    describe('Common Task to Application', () => {
      it('upload common task to application', () => {
        swimInstance.integrationsPage.uploadTask('tasks/common task.json');
        swimInstance.integrationsPage.setTaskDetails('QA-E2E-common task to application', appName);
        swimInstance.integrationsPage.clickUploadPlugin();
        swimInstance.integrationsPage.closeTaskUpload();
      });
    });
    describe('App Task to Application', () => {
      it('upload app task to application', () => {
        swimInstance.integrationsPage.uploadTask('tasks/app task.json');
        swimInstance.integrationsPage.setTaskDetails('QA-E2E-app task to application', appName);
        swimInstance.integrationsPage.clickUploadPlugin();
        swimInstance.integrationsPage.closeTaskUpload();
      });
    });
    describe('Applet Task to Application', () => {
      it('upload applet task to application', () => {
        swimInstance.integrationsPage.uploadTask('tasks/applet task.json');
        swimInstance.integrationsPage.setTaskDetails('QA-E2E-applet task to application', appName);
        swimInstance.integrationsPage.clickUploadPlugin();
        swimInstance.integrationsPage.closeTaskUpload();
      });
    });
  });

  describe('Upload different tasks', () => {
    before(() => {
      swimInstance.openIntegrations();
    });
    describe('Common Task as Common Task', () => {
      it('upload common task as Common Task', () => {
        swimInstance.integrationsPage.uploadTask('tasks/common task.json');
        swimInstance.integrationsPage.setTaskDetails('QA-E2E-common task as Common Task', 'Common Task');
        swimInstance.integrationsPage.clickUploadPlugin();
        swimInstance.integrationsPage.closeTaskUpload();
      });
    });
    describe('App Task as Common Task', () => {
      it('upload app task as Common Task', () => {
        swimInstance.integrationsPage.uploadTask('tasks/app task.json');
        swimInstance.integrationsPage.setTaskDetails('QA-E2E-app task as Common Task', 'Common Task');
        swimInstance.integrationsPage.clickUploadPlugin({
          title: 'Task Upload Error',
          subtext: 'Task must have an ApplicationId or AppletId when it contains a SetFieldValueOutput'
        });
        swimInstance.integrationsPage.closeTaskUpload();
      });
    });
    describe('Applet Task as Common Task', () => {
      it('upload applet task as Common Task', () => {
        swimInstance.integrationsPage.uploadTask('tasks/applet task.json');
        swimInstance.integrationsPage.setTaskDetails('QA-E2E-applet task as Common Task', 'Common Task');
        swimInstance.integrationsPage.clickUploadPlugin({
          title: 'Task Upload Error',
          subtext: 'Task must have an ApplicationId or AppletId when it contains a SetFieldValueOutput'
        });
        swimInstance.integrationsPage.closeTaskUpload();
      });
    });
  });

  after(() => {
    cy.cleanUpCypressApps();
    cy.cleanUpCypressApplets();
    cy.cleanUpCypressWorkspaces();
    cy.cleanUpCypressTasks();

    cy.logout();
  });
});

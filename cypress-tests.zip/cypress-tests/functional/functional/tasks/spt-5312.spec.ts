import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';
const defaultTaskOutputs =
  '[\n  {\n    "sw_task_status": "success",\n    "sw_task_error_type": "",\n    "sw_task_error_message": "",\n    "sw_task_stack_trace": "",\n    "stdOutput": "Hello world!"\n  }\n]';
const pythonCode = 'import time \ntime.sleep(1)\nprint("Hello world!")';

describe('SPT-5312: Integration button & script debugger not returning results to the UI', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Add python tasks to run in debugger mode', () => {
    it('Create python task to debug run 1', () => {
      const taskName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', taskName, null);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: pythonCode
      });
      swimInstance.integrationsPage.runTaskDebugger(defaultTaskOutputs);
      swimInstance.integrationsPage.saveCurrentTask();
    });

    it('Create python task to debug run 2', () => {
      const taskName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', taskName, null);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: pythonCode
      });
      swimInstance.integrationsPage.runTaskDebugger(defaultTaskOutputs);
      swimInstance.integrationsPage.saveCurrentTask();
    });

    it('Create python task to debug run 3', () => {
      const taskName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', taskName, null);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: pythonCode
      });
      swimInstance.integrationsPage.runTaskDebugger(defaultTaskOutputs);
      swimInstance.integrationsPage.saveCurrentTask();
    });

    it('Create python task to debug run 4', () => {
      const taskName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', taskName, null);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: pythonCode
      });
      swimInstance.integrationsPage.runTaskDebugger(defaultTaskOutputs);
      swimInstance.integrationsPage.saveCurrentTask();
    });

    it('Create python task to debug run 5', () => {
      const taskName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', taskName, null);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: pythonCode
      });
      swimInstance.integrationsPage.runTaskDebugger(defaultTaskOutputs);
      swimInstance.integrationsPage.saveCurrentTask();
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

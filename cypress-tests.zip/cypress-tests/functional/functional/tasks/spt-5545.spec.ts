import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';
// import { openPluginsPage } from '../../support/page-objects/main-app-objects/integrationsPage';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const appName2 = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const taskName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const taskName2 = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const whoIsDetails = {
  file: 'bundles/sw_swimlane_parse_whois_lookup-1.1.3-linux.python36.swimbundle',
  name: 'WHOIS Parse',
  version: '1.1.3',
  subName: 'sw_swimlane_parse_whois_lookup',
  description: 'Get Whois information on IP address'
};

const APPLIST = [];
const TASKLIST = [];
const WORKSPACELIST = [];

describe('SPT-5545: Deselect all fields in mapping', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Create App', () => {
    it('build app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
      APPLIST.push(appName);
      WORKSPACELIST.push(`${appName} Workspace`);
    });

    it('Add text fields', () => {
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.addField('Single-Line');
      swimInstance.appBuilder.addField('Single-Line');
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Create Python task', () => {
    it('Start New Task', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', taskName, appName);
      TASKLIST.push([appName, taskName]);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: 'print sw_context.inputs["Text"]',
        inputs: { Type: 'Record', Field: 'Text', Variable: 'Text' }
      });
    });

    it('Verify Mappings Actions are all unavailable', () => {
      swimInstance.integrationsPage.openTaskOutputs();
      swimInstance.integrationsPage.openCreateUpdateRecords(appName, 'Map to Existing Fields');
      swimInstance.integrationsPage.verifyMappings({
        'Standard Output': '',
        sw_task_error_message: '',
        sw_task_error_type: '',
        sw_task_stack_trace: '',
        sw_task_status: '',
        Text: ''
      });
      swimInstance.integrationsPage.verifyCreateField({
        'Standard Output': false,
        sw_task_error_message: false,
        sw_task_error_type: false,
        sw_task_stack_trace: false,
        sw_task_status: false,
        Text: false
      });
      swimInstance.integrationsPage.mappingActionsDropdown('Reset all mappings', false);
      swimInstance.integrationsPage.mappingActionsDropdown(
        'Map unmapped parameters to available existing fields',
        false
      );
      swimInstance.integrationsPage.mappingActionsDropdown('Map unmapped parameters to new fields', false);
      swimInstance.integrationsPage.verifyMappings({
        'Standard Output': '',
        sw_task_error_message: '',
        sw_task_error_type: '',
        sw_task_stack_trace: '',
        sw_task_status: '',
        Text: ''
      });
      swimInstance.integrationsPage.verifyCreateField({
        'Standard Output': false,
        sw_task_error_message: false,
        sw_task_error_type: false,
        sw_task_stack_trace: false,
        sw_task_status: false,
        Text: false
      });
      swimInstance.integrationsPage.exitCreateUpdateRecords();
    });

    it('Save the Task', () => {
      swimInstance.integrationsPage.saveCurrentTask();
    });
  });

  describe('Upload the swimlane parse whois plugin', () => {
    it('Upload bundle', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.checkForExistingBundle('sw_swimlane_parse_whois_lookup', '1.1.3');
    });
  });

  describe('Create App', () => {
    it('build app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName2);
      swimInstance.appsAppletsListing.appWizard.createApp();
      APPLIST.push(appName2);
      WORKSPACELIST.push(`${appName2} Workspace`);
    });

    it('Add Fields', () => {
      swimInstance.appBuilder.verifyElements(appName2);
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.editAppComponent('Text (2)', {
        Name: 'name_servers',
        Required: true
      });
      swimInstance.appBuilder.addField('Single-Line');
      swimInstance.appBuilder.editAppComponent('Text (2)', {
        Name: 'registrar',
        Required: true
      });
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.addLayout('Integration');
    });

    it('Save Application', () => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Setup task for WHOIS lookup and then verify Mapping Actions', () => {
    it('create task', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('WHOIS Lookup', taskName2, appName2);
      TASKLIST.push([appName2, taskName2]);
      swimInstance.integrationsPage.editTaskConfiguration({
        Domain: ['Record', 'Text']
      });
      swimInstance.integrationsPage.editTaskOutputMapping({
        updateRecord: {
          newTargetMappings: {
            $: 'Single-Line',
            '$.domain_name': 'Single-Line',
            domain_name: 'Single-Line',
            '$.марјан': 'Single-Line'
          },
          createOutputs: ['$', '$.domain_name', '$.марјан']
        }
      });
      swimInstance.integrationsPage.verifyMappings({
        $: '$',
        '$.domain_name': '$.domain_name',
        '$.марјан': '$.марјан',
        domain_name: 'Domain Name',
        name_servers: 'name_servers',
        registrar: 'registrar'
      });
    });

    it('Save the Task', () => {
      swimInstance.integrationsPage.saveCurrentTask();
    });

    it('Verify Reset all mappings', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.openTask(taskName2);
      swimInstance.integrationsPage.openTaskOutputs();
      swimInstance.integrationsPage.openCreateUpdateRecords(appName2, 'Map to Existing Fields');
      swimInstance.integrationsPage.verifyMappings({
        address: '',
        city: '',
        country: '',
        dnssec: '',
        admin_name: 'Domain Name',
        emails: '',
        name: '',
        name_servers: 'name_servers',
        org: '$',
        referral_url: '',
        registrar: 'registrar',
        state: '',
        status: '',
        whois_server: '',
        zipcode: ''
      });
      swimInstance.integrationsPage.verifyCreateField({
        address: false,
        city: false,
        country: false,
        dnssec: false,
        domain_name: false,
        emails: false,
        name: false,
        name_servers: false,
        org: false,
        referral_url: false,
        registrar: false,
        state: false,
        status: false,
        whois_server: false,
        zipcode: false
      });
      swimInstance.integrationsPage.mappingActionsDropdown('Reset all mappings');
      swimInstance.integrationsPage.verifyMappings({
        name_servers: '',
        org: '',
        domain_name: '',
        registrar: ''
      });
      swimInstance.integrationsPage.verifyCreateField({
        address: false,
        city: false,
        country: false,
        dnssec: false,
        domain_name: false,
        emails: false,
        name: false,
        name_servers: false,
        org: false,
        referral_url: false,
        registrar: false,
        state: false,
        status: false,
        whois_server: false,
        zipcode: false
      });
      swimInstance.integrationsPage.exitCreateUpdateRecords();
      swimInstance.integrationsPage.closeTask();
    });

    it('Verify Map unmapped parameters to available existing fields', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.openTask(taskName2);
      swimInstance.integrationsPage.openTaskOutputs();
      swimInstance.integrationsPage.openCreateUpdateRecords(appName2, 'Map to Existing Fields');
      swimInstance.integrationsPage.mappingActionsDropdown(
        'Map unmapped parameters to available existing fields',
        true
      );
      swimInstance.integrationsPage.verifyMappings({
        name_servers: 'name_servers',
        registrar: 'registrar'
      });
      swimInstance.integrationsPage.exitCreateUpdateRecords();
      swimInstance.integrationsPage.closeTask();
    });

    it('Verify Map unmapped parameters to new fields', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.openTask(taskName2);
      swimInstance.integrationsPage.openTaskOutputs();
      swimInstance.integrationsPage.openCreateUpdateRecords(appName2, 'Map to Existing Fields');
      swimInstance.integrationsPage.verifyMappings({
        address: '',
        city: '',
        country: '',
        dnssec: '',
        admin_name: 'Domain Name',
        domain_name: '$.domain_name',
        emails: '',
        name: '',
        name_servers: 'name_servers',
        org: '$',
        referral_url: '',
        registrar: 'registrar',
        state: '',
        status: '',
        whois_server: '',
        zipcode: ''
        // name_servers: 'name_servers',
        // registrar: 'registrar'
      });
      swimInstance.integrationsPage.verifyCreateField({
        sw_task_error_message: false,
        sw_task_error_type: false,
        sw_task_stack_trace: false,
        sw_task_status: false,
        address: false,
        city: false,
        country: false,
        dnssec: false,
        domain_name: false,
        emails: false,
        name: false,
        name_servers: false,
        org: false,
        referral_url: false,
        registrar: false,
        state: false,
        status: false,
        whois_server: false,
        zipcode: false,
        domain: false
      });
      swimInstance.integrationsPage.mappingActionsDropdown('Map unmapped parameters to new fields');
      swimInstance.integrationsPage.verifyMappings({
        address: 'Text Single-Line',
        city: 'Text Single-Line',
        country: 'Text Single-Line',
        dnssec: 'Text Single-Line',
        admin_name: 'Domain Name',
        domain_name: '$.domain_name',
        emails: 'Text List',
        name: 'Text Single-Line',
        name_servers: 'name_servers',
        org: '$',
        referral_url: 'Text Single-Line',
        registrar: 'registrar',
        state: 'Text Single-Line',
        status: 'Text Single-Line',
        whois_server: 'Text Single-Line',
        zipcode: 'Text Single-Line'
        // name_servers: 'name_servers',
        // registrar: 'registrar'
      });
      swimInstance.integrationsPage.verifyCreateField({
        sw_task_error_message: false,
        sw_task_error_type: false,
        sw_task_stack_trace: false,
        sw_task_status: false,
        address: true,
        city: true,
        country: true,
        dnssec: true,
        domain_name: false,
        emails: true,
        name: true,
        name_servers: false,
        org: false,
        referral_url: true,
        registrar: false,
        state: true,
        status: true,
        whois_server: true,
        zipcode: true,
        domain: false
      });
      swimInstance.integrationsPage.exitCreateUpdateRecords();
      swimInstance.integrationsPage.closeTask();
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

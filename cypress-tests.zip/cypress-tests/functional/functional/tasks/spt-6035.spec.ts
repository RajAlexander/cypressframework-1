import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const sourceAppName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const targetAppName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const taskName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);

describe('SPT-6035: Setting back reference when output mapping creates new record', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Create Source App', () => {
    it('build source app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(sourceAppName);
      swimInstance.appsAppletsListing.appWizard.createApp();
    });

    it('Add text field', () => {
      swimInstance.appBuilder.verifyElements(sourceAppName);
      swimInstance.appBuilder.addField('Single-Line');
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Create Dest app', () => {
    it('build dest app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(targetAppName);
      swimInstance.appsAppletsListing.appWizard.createApp();
    });

    it('Add text field', () => {
      swimInstance.appBuilder.verifyElements(targetAppName);
      swimInstance.appBuilder.addField('Single-Line');
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Add ref field to Source App', () => {
    it('Open source app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.editExistingApp(sourceAppName);
    });

    it('Add Ref field', () => {
      swimInstance.appBuilder.verifyElements(sourceAppName);
      swimInstance.appBuilder.addField('Reference');
      swimInstance.appBuilder.editAppComponent('Reference', {
        'Reference Application': targetAppName
      });
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Create Python task Taking data from record in source app and creating a new record in the target app', () => {
    it('Start New Task', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', taskName, sourceAppName);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: 'print(sw_context.inputs["Text"])',
        inputs: { Type: 'Record', Field: 'Text', Variable: 'Text' }
      });
      swimInstance.integrationsPage.editTaskOutputMapping({
        createUpdateRecord: {
          targetAppName,
          newMappings: { 'Standard Output': 'Text' }
        }
      });
      swimInstance.integrationsPage.setupCreateUpdateConfiguration(
        {
          'CREATION TYPE': 'Insert and/or Update',
          'Key Field': 'Text',
          'Source Reference Field': 'Reference'
        },
        targetAppName
      );
      swimInstance.integrationsPage.saveCurrentTask();
    });
  });

  describe('Add Workflow to trigger integration', () => {
    it('Open Source app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.editExistingApp(sourceAppName);
      swimInstance.appBuilder.verifyElements(sourceAppName);
      swimInstance.appBuilder.editWorkflow();
    });

    it('Switch to Workflow', () => {
      swimInstance.workflowEditor.verifyElements();
      swimInstance.workflowEditor.addNode(sourceAppName, 'condition');
      swimInstance.workflowEditor.editCurrentNode({
        Name: 'Text Field Not Empty',
        Field: 'Text',
        Operator: 'Does Not Equal'
      });
      swimInstance.workflowEditor.addNode('Text Field Not Empty', 'action');
      swimInstance.workflowEditor.editCurrentNode({
        Name: 'Trigger integration',
        'Action Type': 'Trigger Integration',
        Integration: taskName
      });
      swimInstance.workflowEditor.saveWorkflow();
    });
  });

  describe('Create New Record and Verify reference is populated', () => {
    it('Open App Workspace', () => {
      swimInstance.switchToWorkspace(`${sourceAppName} Workspace`);
      swimInstance.startNewRecordForApp(sourceAppName);
      swimInstance.recordEditor.setFieldValue({
        Text: { value: 'Hello World' }
      });
      swimInstance.recordEditor.save();
    });

    it('Verify added reference', () => {
      cy.intercept('GET', '/api/workflow/**').as('getWorkflow');
      cy.get('.reference-field a.ngx-eye').click();
      cy.wait('@getWorkflow');
      cy.get('.stacks-sidebar .record-view input.form-input').should('have.value', 'Hello World');
      cy.get('.stacks-backdrop').click({ force: true });
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

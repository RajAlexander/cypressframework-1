import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 64);
const taskName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 64);

const APPLIST = [];
const WORKSPACELIST = [];

describe('SPT-10724: String interpolation functionality', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Create App', () => {
    it('build app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
      APPLIST.push(appName);
      WORKSPACELIST.push(`${appName} Workspace`);
    });

    it('Add fields', () => {
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.addField('Single-Line');
      swimInstance.appBuilder.addLayout('Integration');
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Creating a application task to validate string interpolation functionality.', () => {
    it('Create python task', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', taskName, appName);
      swimInstance.integrationsPage.setBypassTimeout(false);
      swimInstance.integrationsPage.editTaskConfiguration({
        script:
          'import json\nstringInterpolation_to_text = sw_context.inputs["date"]\nsw_outputs.append({\n"stringInterpolation_to_text": stringInterpolation_to_text\n})',
        inputs: { Variable: 'date', Type: 'Literal Value', Literal: '{{ now | date_add(-3, d) }}' },
        isAppTask: true
      });
      swimInstance.integrationsPage.runTaskDebugger(null, null, null, false);
      swimInstance.integrationsPage.discoverParameters();
      swimInstance.integrationsPage.saveCurrentTask();
    });

    it('Add task to the app via push button', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.editExistingApp(appName);
      swimInstance.appBuilder.editAppComponent('Integration', {
        Name: 'Trigger Task',
        Task: taskName
      });
    });

    it('Save the App', () => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Adding mappings', () => {
    it('Adding new outputs', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.openTask(taskName);
      swimInstance.integrationsPage.openTaskOutputs();
      swimInstance.integrationsPage.editTaskOutputMapping({
        updateRecord: {
          newTargetMappings: {
            stringInterpolation_to_text: 'Single-Line'
          },
          createOutputs: ['stringInterpolation_to_text']
        }
      });
      swimInstance.integrationsPage.saveCurrentTask();
    });
  });

  describe('Create record to run integration for mappings and execute the validations', () => {
    it('Create record', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecordForApp(appName);
      swimInstance.recordEditor.setFieldValue({
        Text: { value: 'This is a string interpolation test' }
      });
      swimInstance.recordEditor.save('Record saved');
    });

    it('Trigger the integration via push button, validate that the integration have a succesful result', () => {
      swimInstance.recordEditor.clickIntegrationButton('Trigger Task', taskName, true, false, true);
    });

    // TODO: Investigation needed on validating/asserting the dates stored in text field as string.
    // The data is coming from python code using String Interpolation in Integrations -> Tasks -> Inputs -> Literal value

    it('Check date to be less or equal than today', { tags: ['#bug'] }, () => {
      cy.get(
        '.panel-body > .row > .col-md-3 > .form-group > :nth-child(2) > [ng-switch="field.fieldType"] > [ng-switch-when="text"] > [ng-if="!isReadOnly()"] > div > .form-input',
        { timeout: 15000 }
      )
        .invoke('text')
        .then(dateText => {
          // const date = new Date(dateText);
          const today = new Date();
          expect(dateText).to.be.lte(today);
        });
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

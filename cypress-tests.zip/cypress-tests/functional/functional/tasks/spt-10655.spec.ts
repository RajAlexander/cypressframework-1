import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 64);
const taskName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 64);
const pythonCode =
  'import json\nlist_to_text = [1,2,3,4,5]\nboolean_to_text = True\nint_to_text = 5468510\n\
stringNumber_to_text = "123asfdg"\nnone_to_text = None\nfloat_to_text = 3.1415128\nnegativeInt_to_text = -549864\n\
negativeFloat_to_text = -3.1415128\njson_to_text = {\n"name":"John", "age":30, "city":"New York"\n}\n\
sw_outputs.append({\n"list_to_text": list_to_text, "boolean_to_text": boolean_to_text,"int_to_text": int_to_text,\
"json_to_text": json_to_text,"stringNumber_to_text": stringNumber_to_text, "none_to_text": none_to_text,\
"float_to_text": float_to_text,"negativeInt_to_text": negativeInt_to_text,"negativeFloat_to_text": negativeFloat_to_text\n})';

const APPLIST = [];
const WORKSPACELIST = [];
let appId = '';
let appAcronym = '';

describe('SPT-10604 Mapping numeric values,. list values, strings, Json to a single line text', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
    // Commenting out to see if the network waits are really helpful
    // cy.waitForNetworkIdle(250);
  });

  describe('Create App', () => {
    it('build app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.getAppAcronym().then(acronym => {
        appAcronym = acronym;
      });
      swimInstance.appsAppletsListing.appWizard.createApp();
      APPLIST.push(appName);
      WORKSPACELIST.push(`${appName} Workspace`);
    });

    it('Add fields', () => {
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.getAppID().then($appID => {
        appId = $appID;
      });
      swimInstance.appBuilder.addField('Single-Line');
      swimInstance.appBuilder.addLayout('Integration');
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Creating a task to setup the mappings', () => {
    it('Create python task', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', taskName, appName);
      swimInstance.integrationsPage.setBypassTimeout(false);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: pythonCode
      });
      swimInstance.integrationsPage.runTaskDebugger(null, null, null, false);
      swimInstance.integrationsPage.discoverParameters();
      // Save the task and close it
      swimInstance.integrationsPage.saveCurrentTask();
    });

    it('Add task to the app via push button', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.editExistingApp(appName);
      swimInstance.appBuilder.editAppComponent('Integration', {
        Name: 'Trigger Task',
        Task: taskName
      });
    });

    it('Save the App', () => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Adding mappings', () => {
    it('Adding new outputs', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.openTask(taskName);
      swimInstance.integrationsPage.openTaskOutputs();
      swimInstance.integrationsPage.editTaskOutputMapping({
        updateRecord: {
          newTargetMappings: {
            list_to_text: 'List',
            boolean_to_text: 'Single-Line',
            int_to_text: 'Numeric',
            stringNumber_to_text: 'Single-Line',
            none_to_text: 'Single-Line',
            float_to_text: 'Numeric',
            negativeInt_to_text: 'Numeric',
            negativeFloat_to_text: 'Numeric',
            json_to_text: 'JSON'
          },
          createOutputs: [
            'list_to_text',
            'boolean_to_text',
            'int_to_text',
            'stringNumber_to_text',
            'none_to_text',
            'float_to_text',
            'negativeInt_to_text',
            'negativeFloat_to_text',
            'json_to_text'
          ]
        }
      });
      swimInstance.integrationsPage.saveCurrentTask();
    });
  });

  describe('Create record to run integration for mappings and execute the validations', () => {
    it('Create record', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecordForApp(appName);
      swimInstance.recordEditor.setFieldValue({
        Text: { value: 'This is a test' }
      });
      swimInstance.recordEditor.save('Record saved');
    });

    it('Trigger the integration via push button, validate that the integration have a successful result', () => {
      swimInstance.recordEditor.clickIntegrationButton('Trigger Task', taskName, true, false, true);
    });

    it('Verify mapped results', () => {
      swimInstance.recordEditor.verifyFieldValues(
        {
          list_to_text: '1 2 3 4 5',
          boolean_to_text: 'True',
          int_to_text: '5468510',
          stringNumber_to_text: '123asfdg',
          none_to_text: '',
          float_to_text: '3.1415128',
          negativeInt_to_text: '-549864',
          negativeFloat_to_text: '-3.1415128',
          json_to_text: '{"name":"John","age":30,"city":"NewYork"}'
        },
        false
      );
    });
  });

  after(() => {
    cy.cleanUpCypressApps();
    cy.cleanUpCypressWorkspaces();
    cy.logout();
  });
});

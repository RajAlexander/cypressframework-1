import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const groupNameKeyWordSearching = `QA-E2E-g${faker.random.words(3)}`;
const groupNameAscSorting = 'QA-E2E-aagroup testingQA';
const groupNameDescSorting = 'QA-E2E-zzgroup testingQA';
const groupDescriptionKeyWordSearching = `QA-E2E-${faker.random.words(3)}`;
const groupDescriptionAscSorting = 'QA-E2E-aagroup description QAtesting';
const groupDescriptionDescSorting = 'QA-E2E-zzgroup description QAtesting';

describe('SPT 6681:As a user, I want to be able to filter the users, groups, and roles list pages Subtask SPT-10502: Functional Test Keyword searching and sorting for groups  ', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Create group for testing', () => {
    it('Create group for keyword searching', () => {
      swimInstance.openGroupsListing();
      swimInstance.groupsListing.createNewGroup({
        Name: groupNameKeyWordSearching,
        Description: groupDescriptionKeyWordSearching
      });
    });

    it('Create groups for sorting', () => {
      swimInstance.groupsListing.createNewGroup({
        Name: groupNameAscSorting,
        Description: groupDescriptionAscSorting
      });
      swimInstance.groupsListing.createNewGroup({
        Name: groupNameDescSorting,
        Description: groupDescriptionDescSorting
      });
    });
  });

  describe('Sorting Groups by description', () => {
    it('Sorting by description ASC', () => {
      swimInstance.groupsListing.typeGroupPrefix('QA-E2E');
      swimInstance.groupsListing.sortingGroupsByDescription(groupDescriptionAscSorting);
    });

    it('Sorting by description DESC', () => {
      swimInstance.groupsListing.sortingGroupsByDescription(groupDescriptionDescSorting);
    });
  });

  describe('Sorting Groups by name', () => {
    it('Sorting by name ASC', () => {
      swimInstance.groupsListing.sortingGroupsByName(groupNameAscSorting);
      swimInstance.groupsListing.deleteGroup(groupNameAscSorting);
    });

    it('Sorting by name DESC', () => {
      swimInstance.groupsListing.sortingGroupsByName(groupNameDescSorting);
      swimInstance.groupsListing.deleteGroup(groupNameDescSorting);
    });
  });

  describe('Keyword searching Groups', () => {
    it('Keyword Searching', () => {
      swimInstance.groupsListing.keywordSearchingGroups(groupNameKeyWordSearching);
      swimInstance.groupsListing.deleteGroup(groupNameKeyWordSearching);
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appDescription = faker.lorem.sentence();
const dashboardNameValue = `QA-E2E-Dashboards ${faker.commerce.productName()}`;
const newReportName = faker.commerce.productName();
const newReportName1 = faker.commerce.productName();

const APPLIST = [];
const WORKSPACELIST = [];
const DASHBOARDLIST = [];

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const autoRefreshDropdownItems = [
  'off',
  '5 seconds',
  '10 seconds',
  '30 seconds',
  '1 minute',
  '5 minutes',
  '15 minutes',
  '30 minutes',
  '1 hour',
  '1 day'
];

describe('Dashboards', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Dashboard and Charts', () => {
    it('Create new App', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.setAppDescription(appDescription);
      swimInstance.appsAppletsListing.appWizard.createApp();
      APPLIST.push(appName);
      WORKSPACELIST.push(`${appName} Workspace`);
    });

    it('Build fields into App', () => {
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.addField('Single-Line');
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.addField('Email');
      swimInstance.appBuilder.saveApplication();
    });

    it('Create a Dashboard for Cards and verify the Auto Refresh dropdown selection options', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.dashboardPage.createDashboardOnEmpty();
      swimInstance.dashboardWizard.setDashboardNameAndDesc(dashboardNameValue, faker.lorem.sentence());
      swimInstance.dashboardWizard.createDashboard();
      DASHBOARDLIST.push(dashboardNameValue);
    });

    it('Add Default report as card into dashboard and verify the Auto Refresh dropdown selection options', () => {
      swimInstance.dashboardPage.addCard();
      swimInstance.cardWizard.setCardDetails(
        'QA-E2E-Dashboards' + faker.commerce.productName(),
        'Report',
        `Default (${appName})`,
        faker.lorem.sentence()
      );
      swimInstance.cardWizard.verifyCardAutoRefreshOptions(autoRefreshDropdownItems);
      swimInstance.cardWizard.setCardAutoRefresh('30 minutes');
      swimInstance.cardWizard.verifyCardAutoRefreshSetting('30 minutes');
      swimInstance.cardWizard.createCard();
      swimInstance.dashboardPage.save();
    });
  });

  describe('SPT-9039 New cards from report saving are added to the bottom or the dashboard', () => {
    describe('Add the first card', () => {
      it('Create a new report and auto add it to the dashboard.', () => {
        swimInstance.switchToWorkspace(`${appName} Workspace`);
        swimInstance.OpenAppListAll(appName);
        swimInstance.recordListing.saveReportAs(newReportName, true, null, dashboardNameValue);
      });

      it('verify new card added to the end of the dashboard', () => {
        swimInstance.switchToWorkspace(`${appName} Workspace`);
        swimInstance.openDashboard(dashboardNameValue);
        swimInstance.dashboardPage.verifyCard(newReportName, 'last');
      });
    });
    describe('Add the second card', () => {
      it('Create a new report and auto add it to the dashboard.', () => {
        swimInstance.switchToWorkspace(`${appName} Workspace`);
        swimInstance.OpenAppListAll(appName);
        swimInstance.recordListing.saveReportAs(newReportName1, true, null, dashboardNameValue);
      });

      it('verify new card added to the end of the dashboard', () => {
        swimInstance.switchToWorkspace(`${appName} Workspace`);
        swimInstance.openDashboard(dashboardNameValue);
        swimInstance.dashboardPage.verifyCard(newReportName1, 'last');
      });
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

import * as swimInstance from '../../support/page-objects/swimInstance';

const sspPath4 = 'packages/QA-E2E-sw_test_plugin-v5.0+sw_virus_total-3.1.3.ssp';

describe('Import Application SSP', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  it('setup for test', () => {
    swimInstance.integrationsPage.checkForExistingBundle('sw_virus_total', '3.1.0');
    swimInstance.integrationsPage.checkForExistingBundle('sw_test_plugin', '1.0.0');
  });

  it('Upgrade the ssp package again', () => {
    swimInstance.openAppAppletsList();
    swimInstance.appsAppletsListing.startImportPlus();
    swimInstance.appsAppletsListing.appAppletSSPWizard.uploadPackage(sspPath4);
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
      'Import Contains Errors',
      'Errors Detected',
      'You must address any errors in order to import successfully.',
      null,
      null,
      null,
      {
        packageContents: ['1 Application', '1 Report', '2 Tasks', '1 Asset'],
        appName: 'QA-E2E-sw_test_plugin-v5.0+sw_virus_total-3.1.3',
        descriptors: {
          package: [
            {
              version: '5.0.0',
              name: 'sw_test_plugin',
              message: 'The sw_test_plugin plugin requires an upgrade.',
              pluginversion: 'upgrade'
            },
            {
              version: '3.1.3',
              name: 'sw_virus_total',
              message: 'The sw_virus_total plugin requires an upgrade.',
              pluginversion: 'upgrade'
            }
          ]
        }
      },
      true,
      false
    );
    swimInstance.appsAppletsListing.appAppletSSPWizard.resolveIssue('sw_test_plugin', 'Plugin', 'upgrade');
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyPluginResolved('sw_test_plugin');
    swimInstance.appsAppletsListing.appAppletSSPWizard.resolveIssue('sw_virus_total', 'Plugin', 'upgrade');
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyPluginResolved('sw_virus_total');
    swimInstance.appsAppletsListing.appAppletSSPWizard.continueUpload();
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
      'Import Summary',
      'Review Potential Issues',
      'Your application has imported successfully but there are issues. This may result in an incomplete solution.',
      'Take note of or take action on the issues listed.',
      'Some tasks were disabled during export. Enable them all now or later.',
      1,
      {
        packageContents: ['1 Application', '1 Report', '2 Tasks', '1 Asset'],
        appName: 'QA-E2E-sw_test_plugin-v5.0+sw_virus_total-3.1.3',
        descriptors: {
          task: [
            {
              name: 'QA-E2E-Virus Total',
              issues: null,
              reason: 'Asset QA-E2E-VirusTotal connected to Task QA-E2E-Virus Total has been modified.'
            }
          ],
          asset: [
            {
              name: 'QA-E2E-VirusTotal',
              version: '3.1.3',
              message: 'A secure credential has been removed from API Key.'
            }
          ]
        }
      },
      true,
      true
    );
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

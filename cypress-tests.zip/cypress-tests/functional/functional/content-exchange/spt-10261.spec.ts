import * as swimInstance from '../../support/page-objects/swimInstance';
import { uploadPackage } from '../../support/page-objects/main-app-objects/app-applet-ssp-wizard';
import { editExistingApp } from '../../support/page-objects/main-app-objects/appAppletList';

const appName = 'QA-E2E-Smelly SOCs';
const APPLIST = [];
const WORKSPACELIST = [];
const origTrackingId = 'SS-315168';
const smellySOCsPath = '../fixtures/packages/QA-E2E-Smelly SOCs.ssp';
const newSSPFilePath = '../../temp/downloads/QA-E2E-Smelly SOCs.ssp';

describe('Verify max trackingid is set to 0 on ssp import', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Import application', () => {
    it('Import application from ssp', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startImportPlus();
      uploadPackage(smellySOCsPath);
      swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
        'Import Success',
        null,
        null,
        null,
        null,
        null,
        {
          packageContents: ['1 Application', '1 Report', '1 Workspace', '2 Tasks'],
          appName: 'QA-E2E-Smelly SOCs'
        },
        true,
        true
      );
      APPLIST.push(appName);
      WORKSPACELIST.push(`${appName} Workspace`);
    });
  });

  describe('Create a new record', () => {
    it('Create new Record', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecordForApp(appName);
      swimInstance.recordEditor.enterRandomData();
      cy.wait(5000);
      swimInstance.recordEditor.save();
      swimInstance.recordEditor.getRecordValues();
      swimInstance.recordEditor.getRecordTrackingID(true).then($trackingID => {
        expect($trackingID).to.equal(origTrackingId);
      });
    });
  });

  describe('Export application', () => {
    it('Export application', () => {
      swimInstance.openAppAppletsList();
      editExistingApp(appName);
      swimInstance.appBuilder.exportApplication({ hasCredIssues: false });
    });
  });

  describe('Cleanup Apps, Workspaces', () => {
    it('Remove the created application', () => {
      swimInstance.openAppAppletsList();
      APPLIST.forEach(name => swimInstance.appsAppletsListing.deleteExistingApp(name));
    });

    it('Remove the app workspace', () => {
      swimInstance.openWorkspaceList();
      WORKSPACELIST.forEach(name => swimInstance.workspacesListing.deleteWorkspace(name));
    });
  });

  describe('Import application', () => {
    it('Import application from ssp that was just exported', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startImportPlus();
      uploadPackage(newSSPFilePath);
      swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
        'Import Success',
        null,
        null,
        null,
        null,
        null,
        {
          packageContents: ['1 Application', '1 Report', '1 Workspace', '2 Tasks'],
          appName: 'QA-E2E-Smelly SOCs'
        },
        true,
        true
      );
    });
  });

  describe('Create another new record', () => {
    it('Create new Record and verify that TrackingID starts at 1', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecordForApp(appName);
      swimInstance.recordEditor.enterRandomData();
      cy.wait(5000);
      swimInstance.recordEditor.save();
      swimInstance.recordEditor.getRecordValues();
      swimInstance.recordEditor.getRecordTrackingID(true).then($trackingID => {
        expect($trackingID).to.equal('SS-1');
      });
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

import * as swimInstance from '../../support/page-objects/swimInstance';

const sspPath1 = 'packages/sw_test_plugin v1.0.ssp';
const sspPath3 = 'packages/sw_test_plugin v3.0.ssp';
const sspPath5 = 'packages/sw_test_plugin v5.0.ssp';

describe('Import Application SSP', () => {
  before(() => {
    cy.login();
    // TODO: SPT-12282 clean this up with the fix for the ticket.
    cy.cleanUpBundles();
    // cy.cleanUpBundles(['sw_test_plugin']);
    cy.visitSwimlane('/');
  });

  it('import success', () => {
    swimInstance.openAppAppletsList();
    swimInstance.appsAppletsListing.startImportPlus();
    swimInstance.appsAppletsListing.appAppletSSPWizard.uploadPackage(sspPath1);
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload('Import Success', null, null, null, null, 0, {
      packageContents: ['1 Application', '1 Report', '1 Task', '1 Asset'],
      appName: 'sw_test_plugin v1.0'
    });
  });

  it('Cleanup app, workspace, tasks for next import', () => {
    swimInstance.openIntegrations();
    swimInstance.integrationsPage.deleteTask('Test Plugin');
  });

  it('Upgrade the ssp package v3', () => {
    swimInstance.openAppAppletsList();
    swimInstance.appsAppletsListing.startImportPlus();
    swimInstance.appsAppletsListing.appAppletSSPWizard.uploadPackage(sspPath3);
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
      'Import Contains an Error',
      'Error Detected',
      'You must address any errors in order to import successfully.',
      null,
      null,
      null,
      {
        appName: 'sw_test_plugin v3.0',
        packageContents: ['1 Application', '1 Report', '1 Workspace', '1 Task'],
        descriptors: {
          package: [
            {
              version: '3.0.0',
              name: 'sw_test_plugin',
              message: 'The sw_test_plugin plugin requires an upgrade.',
              pluginversion: 'upgrade'
            }
          ]
        }
      },
      true,
      false
    );
    swimInstance.appsAppletsListing.appAppletSSPWizard.resolveIssue('sw_test_plugin', 'Plugin', 'upgrade');
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyPluginResolved('sw_test_plugin');
    swimInstance.appsAppletsListing.appAppletSSPWizard.continueUpload();
    swimInstance.appsAppletsListing.appAppletSSPWizard.close();
  });

  it('Verify expected components', () => {
    swimInstance.appsAppletsListing.verifyExistingAppApplet('sw_test_plugin v1.0');
    swimInstance.appsAppletsListing.verifyExistingAppApplet('sw_test_plugin v3.0');

    swimInstance.openIntegrations();
    swimInstance.integrationsPage.verifyExistingTask({ name: 'Test Plugin' });
    swimInstance.integrationsPage.findPlugin({
      name: 'Plugin',
      version: '3.0.0',
      subName: 'sw_test_plugin',
      description: 'tester'
    });

    swimInstance.openWorkspaceList();
    swimInstance.workspacesListing.verifyWorkspaceExists('sw_test_plugin v3.0 Workspace');
  });

  it('Upgrade the ssp package v5', () => {
    swimInstance.openAppAppletsList();
    swimInstance.appsAppletsListing.startImportPlus();
    swimInstance.appsAppletsListing.appAppletSSPWizard.uploadPackage(sspPath5);
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
      'Import Contains an Error',
      'Error Detected',
      'You must address any errors in order to import successfully.',
      null,
      null,
      null,
      {
        appName: 'sw_test_plugin v5.0',
        packageContents: ['1 Application', '1 Report', '1 Workspace', '1 Task'],
        descriptors: {
          package: [
            {
              version: '5.0.0',
              name: 'sw_test_plugin',
              message: 'The sw_test_plugin plugin requires an upgrade.',
              pluginversion: 'upgrade'
            }
          ]
        }
      },
      true,
      false
    );
    swimInstance.appsAppletsListing.appAppletSSPWizard.resolveIssue('sw_test_plugin', 'Plugin', 'upgrade');
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyPluginResolved('sw_test_plugin');
    swimInstance.appsAppletsListing.appAppletSSPWizard.continueUpload();
    swimInstance.appsAppletsListing.appAppletSSPWizard.close();
  });

  it('Verify expected components', () => {
    swimInstance.appsAppletsListing.verifyExistingAppApplet('sw_test_plugin v1.0');
    swimInstance.appsAppletsListing.verifyExistingAppApplet('sw_test_plugin v3.0');
    swimInstance.appsAppletsListing.verifyExistingAppApplet('sw_test_plugin v5.0');

    swimInstance.openIntegrations();
    swimInstance.integrationsPage.verifyExistingTask({ name: 'Test Plugin' });
    swimInstance.integrationsPage.findPlugin({
      name: 'Plugin',
      version: '5.0.0',
      subName: 'sw_test_plugin',
      description: 'tester'
    });

    swimInstance.openWorkspaceList();
    swimInstance.workspacesListing.verifyWorkspaceExists('sw_test_plugin v3.0 Workspace');
    swimInstance.workspacesListing.verifyWorkspaceExists('App with task Workspace');
  });

  it('Shows UID error before plugin error', () => {
    swimInstance.openAppAppletsList();
    swimInstance.appsAppletsListing.startImportPlus();
    swimInstance.appsAppletsListing.appAppletSSPWizard.uploadPackage(sspPath1);
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUploadFailure(
      'Error Detected',
      'This item already exists in this environment.'
    );
  });

  it('Remove the created application', () => {
    swimInstance.openAppAppletsList();
    swimInstance.appsAppletsListing.deleteExistingApp('sw_test_plugin v1.0');
    swimInstance.appsAppletsListing.deleteExistingApp('sw_test_plugin v3.0');
    swimInstance.appsAppletsListing.deleteExistingApp('sw_test_plugin v5.0');

    swimInstance.openIntegrations();
    swimInstance.integrationsPage.deleteTask('Test Plugin');

    swimInstance.openWorkspaceList();
    swimInstance.workspacesListing.deleteWorkspace('App with task Workspace');
    swimInstance.workspacesListing.deleteWorkspace('sw_test_plugin v3.0 Workspace');
  });

  it('Downgrade the ssp package v1', () => {
    swimInstance.openAppAppletsList();
    swimInstance.appsAppletsListing.startImportPlus();
    swimInstance.appsAppletsListing.appAppletSSPWizard.uploadPackage(sspPath1);
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
      'Import Contains an Error',
      'Error Detected',
      'You must address any errors in order to import successfully.',
      null,
      null,
      null,
      {
        appName: 'sw_test_plugin v1.0',
        packageContents: ['1 Application', '1 Report', '1 Task', '1 Asset'],
        descriptors: {
          package: [
            {
              version: '1.0.0',
              name: 'sw_test_plugin',
              message: 'The sw_test_plugin plugin requires a downgrade.',
              pluginversion: 'downgrade'
            }
          ]
        }
      },
      true,
      false
    );
    swimInstance.appsAppletsListing.appAppletSSPWizard.resolveIssue('sw_test_plugin', 'Plugin', 'downgrade');
    swimInstance.appsAppletsListing.appAppletSSPWizard.close();
  });

  it('Remove the imported plugins', () => {
    swimInstance.openIntegrations();
    swimInstance.integrationsPage.openPluginsPage();
    swimInstance.integrationsPage.deletePlugin({ name: 'Plugin', version: '5.0.0' }, { TASK: ['Test Plugin', 'bbbb'] });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

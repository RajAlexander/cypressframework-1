import * as swimInstance from '../../support/page-objects/swimInstance';

const sspPath1 = 'packages/QA-E2E-sw_test_plugin-v1.0+sw_virus_total-3.0.2.ssp';

describe('Import Application SSP', () => {
  before(() => {
    cy.login();
    cy.cleanUpBundles();
    cy.visitSwimlane('/');
  });

  it('import success', () => {
    swimInstance.openAppAppletsList();
    swimInstance.appsAppletsListing.startImportPlus();
    swimInstance.appsAppletsListing.appAppletSSPWizard.uploadPackage(sspPath1);
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
      'Import Summary',
      'Review Potential Issues',
      'Your application has imported successfully but there are issues. This may result in an incomplete solution.',
      'Take note of or take action on the issues listed.',
      'Some tasks were disabled during export. Enable them all now or later.',
      1,
      {
        packageContents: ['1 Application', '1 Report', '2 Tasks', '2 Assets'],
        appName: 'QA-E2E-sw_test_plugin-v1.0+sw_virus_total-3.0.2',
        descriptors: {
          task: [
            {
              name: 'QA-E2E-Virus Total',
              issues: null,
              reason: 'Asset QA-E2E-VirusTotal connected to Task QA-E2E-Virus Total has been modified.'
            }
          ],
          asset: [
            {
              name: 'QA-E2E-VirusTotal',
              version: '3.0.2',
              message: 'A secure credential has been removed from API Key.'
            }
          ]
        }
      },
      true,
      true
    );
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

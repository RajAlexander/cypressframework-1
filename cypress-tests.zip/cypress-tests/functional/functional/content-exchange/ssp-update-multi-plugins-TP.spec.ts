import * as swimInstance from '../../support/page-objects/swimInstance';

const sspPath3 = 'packages/QA-E2E-sw_test_plugin-v3.0+sw_virus_total-3.1.0.ssp';

describe('Import Application SSP', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  it('setup for test', () => {
    swimInstance.integrationsPage.checkForExistingBundle('sw_virus_total', '3.1.0');
    swimInstance.integrationsPage.checkForExistingBundle('sw_test_plugin', '1.0.0');
  });

  it('Upgrade the ssp package test_plugin to 3.0', () => {
    swimInstance.openAppAppletsList();
    swimInstance.appsAppletsListing.startImportPlus();
    swimInstance.appsAppletsListing.appAppletSSPWizard.uploadPackage(sspPath3);
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
      'Import Contains an Error',
      'Error Detected',
      'You must address any errors in order to import successfully.',
      null,
      null,
      null,
      {
        packageContents: ['1 Application', '1 Report', '2 Tasks', '1 Asset'],
        appName: 'QA-E2E-sw_test_plugin-v3.0+sw_virus_total-3.1.0',
        descriptors: {
          package: [
            {
              version: '3.0.0',
              name: 'sw_test_plugin',
              message: 'The sw_test_plugin plugin requires an upgrade.',
              pluginversion: 'upgrade'
            }
          ]
        }
      },
      true,
      false
    );
    swimInstance.appsAppletsListing.appAppletSSPWizard.resolveIssue('sw_test_plugin', 'Plugin', 'upgrade');
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyPluginResolved('sw_test_plugin');
    swimInstance.appsAppletsListing.appAppletSSPWizard.continueUpload();
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
      'Import Summary',
      'Review Potential Issues',
      'Your application has imported successfully but there are issues. This may result in an incomplete solution.',
      'Take note of or take action on the issues listed.',
      'Some tasks were disabled during export. Enable them all now or later.',
      1,
      {
        packageContents: ['1 Application', '1 Report', '2 Tasks', '1 Asset'],
        appName: 'QA-E2E-sw_test_plugin-v3.0+sw_virus_total-3.1.0',
        descriptors: {
          task: [
            {
              name: 'QA-E2E-Virus Total',
              issues: null,
              reason: 'Asset QA-E2E-VirusTotal connected to Task QA-E2E-Virus Total has been modified.'
            }
          ],
          asset: [
            {
              name: 'QA-E2E-VirusTotal',
              version: '3.1.0',
              message: 'A secure credential has been removed from API Key.'
            }
          ]
        }
      },
      true,
      true
    );
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

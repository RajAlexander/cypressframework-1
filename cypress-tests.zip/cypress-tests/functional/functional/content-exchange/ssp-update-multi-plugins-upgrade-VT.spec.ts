import * as swimInstance from '../../support/page-objects/swimInstance';

const sspPath2 = 'packages/QA-E2E-sw_test_plugin-v1.0+sw_virus_total-3.1.0.ssp';

describe('Import Application SSP', () => {
  before(() => {
    cy.login();
    cy.cleanupSwimlane();
    cy.visitSwimlane('/');
    swimInstance.integrationsPage.checkForExistingBundle('sw_virus_total', '3.0.2');
    swimInstance.integrationsPage.checkForExistingBundle('sw_test_plugin', '1.0.0');
  });

  it('Upgrade the ssp package with VT update only', () => {
    swimInstance.openAppAppletsList();
    swimInstance.appsAppletsListing.startImportPlus();
    swimInstance.appsAppletsListing.appAppletSSPWizard.uploadPackage(sspPath2);
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
      'Import Contains an Error',
      'Error Detected',
      'You must address any errors in order to import successfully.',
      null,
      null,
      null,
      {
        packageContents: ['1 Application', '1 Report', '2 Tasks', '2 Assets'],
        appName: 'QA-E2E-sw_test_plugin-v1.0+sw_virus_total-3.1.0',
        descriptors: {
          package: [
            {
              version: '3.1.0',
              name: 'sw_virus_total',
              message: 'The sw_virus_total plugin requires an upgrade.',
              pluginversion: 'upgrade'
            }
          ]
        }
      },
      true,
      false
    );
    swimInstance.appsAppletsListing.appAppletSSPWizard.resolveIssue('sw_virus_total', 'Plugin', 'upgrade');
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyPluginResolved('sw_virus_total');
    swimInstance.appsAppletsListing.appAppletSSPWizard.continueUpload();
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
      'Import Summary',
      'Review Potential Issues',
      'Your application has imported successfully but there are issues. This may result in an incomplete solution.',
      'Take note of or take action on the issues listed.',
      'Some tasks were disabled during export. Enable them all now or later.',
      1,
      {
        packageContents: ['1 Application', '1 Report', '2 Tasks', '2 Assets'],
        appName: 'QA-E2E-sw_test_plugin-v1.0+sw_virus_total-3.1.0',
        descriptors: {
          task: [
            {
              name: 'QA-E2E-Virus Total',
              issues: null,
              reason: 'Asset QA-E2E-VirusTotal connected to Task QA-E2E-Virus Total has been modified.'
            }
          ],
          asset: [
            {
              name: 'QA-E2E-VirusTotal',
              version: '3.1.0',
              message: 'A secure credential has been removed from API Key.'
            }
          ]
        }
      },
      true,
      true
    );
  });

  it('Upgrade the ssp package again, verify name/acronym conflict is hidden when UID is in conflict', () => {
    swimInstance.openAppAppletsList();
    swimInstance.appsAppletsListing.startImportPlus();
    swimInstance.appsAppletsListing.appAppletSSPWizard.uploadPackage(sspPath2);
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUploadFailure(
      'Error Detected',
      'This item already exists in this environment.'
    );
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

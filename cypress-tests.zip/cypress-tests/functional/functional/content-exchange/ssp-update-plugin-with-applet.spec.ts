import * as swimInstance from '../../support/page-objects/swimInstance';

const sspPath2 = 'packages/sw_test_plugin v2.0.ssp';
const sspPath4 = 'packages/sw_test_plugin v4.0.ssp';

describe('Import Applet SSP', () => {
  before(() => {
    cy.login();
    cy.cleanUpBundles(['sw_virus_total', 'sw_test_plugin']);
    cy.visitSwimlane('/');
  });

  it('import the ssp package', () => {
    swimInstance.openAppAppletsList();
    swimInstance.appsAppletsListing.startImportPlus();
    swimInstance.appsAppletsListing.appAppletSSPWizard.uploadPackage(sspPath2);
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
      'Import Summary',
      'Review Potential Issue',
      'Your applet has imported successfully but there is an issue. This may result in an incomplete solution. Take note of or take action on the issue listed.',
      null,
      null,
      null,
      {
        packageContents: ['1 Applet', '1 Task', '1 Asset'],
        appName: 'sw_test_plugin v2.0',
        descriptors: {
          asset: [
            {
              version: '2.0.0',
              name: 'Test Plugin',
              message: 'A secure credential has been removed from Password.',
              issues: '1'
            }
          ]
        }
      },
      false,
      false
    );
    swimInstance.appsAppletsListing.appAppletSSPWizard.resolveIssue('Test Plugin', 'Asset', {
      parameters: { Password: 'abc123' }
    });
    swimInstance.appsAppletsListing.appAppletSSPWizard.close();
  });

  it('Verify expected components', () => {
    swimInstance.appsAppletsListing.verifyExistingAppApplet('sw_test_plugin v2.0');

    swimInstance.openIntegrations();
    swimInstance.integrationsPage.verifyExistingTask({ name: 'Test Plugin' });
    swimInstance.integrationsPage.verifyExistingAsset({ name: 'Test Plugin' });
    swimInstance.integrationsPage.findPlugin({
      name: 'Plugin',
      version: '2.0.0',
      subName: 'sw_test_plugin',
      description: 'tester'
    });
  });

  it('Upgrade the ssp package to v4.0 shows errors first', () => {
    swimInstance.openAppAppletsList();
    swimInstance.appsAppletsListing.startImportPlus();
    swimInstance.appsAppletsListing.appAppletSSPWizard.uploadPackage(sspPath4);
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
      'Import Contains Errors',
      'Errors Detected',
      'You must address any errors in order to import successfully.',
      null,
      null,
      null,
      {
        packageContents: ['1 Applet', '1 Task'],
        appName: 'sw_test_plugin v4.0',
        descriptors: {
          task: [
            {
              version: '4.0.0',
              name: 'Test Plugin',
              message: 'Test Plugin IO changes.',
              errors: 1,
              reason: 'This item already exists in this environment.'
            }
          ]
        }
      },
      false,
      false
    );
    swimInstance.appsAppletsListing.appAppletSSPWizard.close();
  });

  it('Remove the conflicting task', () => {
    swimInstance.openIntegrations();
    swimInstance.integrationsPage.deleteTask('Test Plugin');
  });

  it('Upgrade the ssp package to v4.0', () => {
    swimInstance.openAppAppletsList();
    swimInstance.appsAppletsListing.startImportPlus();
    swimInstance.appsAppletsListing.appAppletSSPWizard.uploadPackage(sspPath4);
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
      'Import Contains an Error',
      'Error Detected',
      'You must address any errors in order to import successfully.',
      null,
      null,
      null,
      {
        packageContents: ['1 Applet', '1 Task'],
        appName: 'sw_test_plugin v4.0',
        descriptors: {
          package: [
            {
              version: '4.0.0',
              name: 'sw_test_plugin',
              message: 'The sw_test_plugin plugin requires an upgrade.',
              pluginversion: 'upgrade'
            }
          ]
        }
      },
      false,
      false
    );
    swimInstance.appsAppletsListing.appAppletSSPWizard.resolveIssue('sw_test_plugin', 'Plugin', 'upgrade');
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyPluginResolved('sw_test_plugin');
    swimInstance.appsAppletsListing.appAppletSSPWizard.continueUpload();
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
      'Import Summary',
      'Review Potential Issue',
      'Your applet has imported successfully but there is an issue. This may result in an incomplete solution. Take note of the issue listed.',
      null,
      null,
      null,
      {
        packageContents: ['1 Applet', '1 Task'],
        appName: 'sw_test_plugin v4.0',
        descriptors: {
          applet: [
            {
              name: 'sw_test_plugin v4.0',
              message: 'Task undefined for this integration button',
              issues: null
            }
          ]
        }
      },
      false,
      false
    );

    swimInstance.appsAppletsListing.appAppletSSPWizard.close();
  });

  it('Verify expected components', () => {
    swimInstance.appsAppletsListing.verifyExistingAppApplet('sw_test_plugin v2.0');

    swimInstance.openIntegrations();
    swimInstance.integrationsPage.verifyExistingTask({ name: 'Test Plugin' });
    swimInstance.integrationsPage.findPlugin({
      name: 'Plugin',
      version: '4.0.0',
      subName: 'sw_test_plugin',
      description: 'tester'
    });
  });

  it('Remove the created application', () => {
    swimInstance.openAppAppletsList();
    swimInstance.appsAppletsListing.deleteExistingApplet('sw_test_plugin v2.0');
    swimInstance.appsAppletsListing.deleteExistingApplet('sw_test_plugin v4.0');

    swimInstance.openIntegrations();
    swimInstance.integrationsPage.openPluginsPage();
    swimInstance.integrationsPage.deletePlugin({ name: 'Plugin', version: '4.0.0' }, { TASK: 'Test Plugin' });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

// @ts-check
/* test steps
 1. Upload HTTP Plugin to create sensor'
 2. Create URI Asset
 3. Create Web Server Sensor
 4. Create a Playbook and Add Trigger and Action
 5. Scrape the Web Server Sensor agent and update expected values'
 6. Open sensor events and capture current number of events.  If there are no events set the current events to 0
 7. Open a browser to trigger an event
 8. Open sensor events 
 9. Verify that the event count increased by 1,
 10. Verify column headers are - '', expectedEventType, expectedSensorInstance, expectedAgentHost, expectedRowDate, expectedTriggeredPlaybooks
 11. Search for the sensor instance and verify column data
 12. Open and verify sensor event details
 13. Verify the headers '', 'Event Type','Sensor Instance', 'Agent/Host', 'Time Received', 'Triggered Playbooks'];
*/

import * as swimInstance from '../../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';
import * as sensorEvents from '../../../support/page-objects/main-app-objects/do-pages/sensors/sensors-events-interface';

const postAssetName = `QAE2E_`;
const postPlaybookName = `QAE2E_`;
const postSensorName = `QA_E2E_WebServer` + Date.now();
const portNumber = '10000';
const httpUrl = Cypress.config().baseUrl.split('https').join('http') + ':' + portNumber;
const expectedEventType = 'http.webserver.request';
const expectedSensorInstance = postSensorName;
const expectedTriggeredPlaybooks = '1';
const currentDate = new Date();
const date = currentDate.toLocaleString('en-us', { day: 'numeric' });
const month = currentDate.toLocaleString('en-us', { month: 'short' });
const year = ' ' + currentDate.getFullYear();
const expectedRowDate = month + ' ' + date + ',' + year;
let expectedRowText: string[]; // = ['', '', expectedEventType, expectedSensorInstance, expectedAgentHost, expectedRowDate, expectedTriggeredPlaybooks];
let count;
let latestCount;
const numOfEvents = 1;

// SPT-13435: Hide event stream
describe.skip('Verification of Dynamic Orchestration - Create Working Playbooks', () => {
  before(() => {
    cy.cleanupTurbine();
    cy.login();
    cy.visitSwimlane('/');
  });

  it('Upload Plugin to create Asset and Sensor', () => {
    // Upload HTTP Plugin
    swimInstance.openPlugins();
    swimInstance.pluginsPage.uploadPlugin();
    swimInstance.pluginsPage.pluginUploader.uploadFile({
      filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
      encoding: 'base64'
    });
    // Verify Plugin upload is complete
    swimInstance.pluginsPage.pluginUploader.checkUploadComplete('HTTP');
    swimInstance.pluginsPage.pluginUploader.close();
  });

  it('Create Uri Asset', () => {
    // Create URI Asset
    swimInstance.openAssets();
    swimInstance.assetsPage.createAsset({
      assetType: 'Uri',
      assetName: `${postAssetName}Uri`,
      paramData: ['https://www.google.com', 'GET'],
      noAssets: true
    });
  });

  it('Create Web Server Sensor', () => {
    cy.log('sensor ' + postSensorName);
    swimInstance.openSensors();
    swimInstance.sensorsPage.createSensor({
      sensorType: 'Web Server',
      sensorName: postSensorName,
      paramData: [portNumber]
    });
  });

  it('Create a Playbook and Add Trigger and Action', () => {
    const playbookTitle = `${postPlaybookName}${faker.company.companyName()}`;
    const playbookName = `${postPlaybookName}${faker.random.word().replace('-', '')}`;
    const actionName = 'QA-E2E-' + faker.company.companyName();

    // Create a new playbook
    swimInstance.openPlaybooks();
    swimInstance.playbookPage.createPlaybook({
      playbookName,
      playbookTitle,
      playbookDescription: faker.lorem.sentence()
    });

    // Open created playbook to access visual editor
    swimInstance.openPlaybooks();
    swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookName);

    // Add triggers on the playbook
    swimInstance.playbookPage.addPlaybookTrigger(postSensorName);

    // Add actions to the playbook
    swimInstance.playbookPage.addPlaybookAction(actionName, 'Send an http payload');
    // Save Playbook changes
    swimInstance.playbookPage.savePlaybookChanges();
  });

  it('Find Web Server Sensor agent and update expected values', () => {
    // open sensors
    sensorEvents.findTheServerAgent(postSensorName).then(expectedAgentHost => {
      cy.log('expected agent host = ' + expectedAgentHost);
      expectedRowText = [
        '',
        '',
        expectedEventType,
        expectedSensorInstance,
        expectedAgentHost,
        expectedRowDate,
        expectedTriggeredPlaybooks
      ];
    });
    cy.get('.ngx-large-format-dialog-header-action__button > .ngx-icon').click();
  });

  it('Open sensor events and capture current number of events', () => {
    // open sensor event view
    swimInstance.openSensorEvents();
    cy.wrap((count = 0));
    // verify the header
    sensorEvents.verifySensorEventsHeader();
    sensorEvents.checkForNoDataToDisplay().then($found => {
      if (!$found) {
        sensorEvents.captureLegendTotalValue().then($currentCount => {
          count = $currentCount.text();
          cy.log('capture legend total value = ' + $currentCount.text());
        });
      }
    });
  });

  it('Open a browser to trigger event(s)', () => {
    sensorEvents.triggerWebEvent(httpUrl, numOfEvents);
  });

  it('Open sensor events', () => {
    swimInstance.openSensors();
    swimInstance.openSensorEvents();
    swimInstance.openSensors();
    swimInstance.openSensorEvents();
  });

  it('Verify event count increased by 1, and verify column headers', () => {
    cy.log('Number of events = ' + numOfEvents);
    sensorEvents.captureLegendTotalValue().then($currentCount => {
      latestCount = $currentCount.text();
      cy.log('capture legend total after an event ' + Number(latestCount));
      // verify that the legend total event acccount increases by x
      cy.wrap(Number(count) + numOfEvents).should('equal', Number(latestCount));
    });
    sensorEvents.verifySensorEventsHeader();
  });

  it('Open and verify sensor event details', () => {
    cy.get('.datatable-body .datatable-row-center.datatable-row-group.ng-star-inserted').each($e1 => {
      cy.wrap(sensorEvents.verifyEventDetails($e1, httpUrl));
    });
  });

  after(() => {
    cy.cleanupTurbine();
    cy.logout();
  });
});

// @ts-check
/* test steps
 1. Upload HTTP Plugin to create sensor'
 2. Create Web Server Sensor
 3. Scrape the Web Server Sensor agent and update expected values'
 4. Open sensor events and capture current number of events.  If there are no events set the current events to 0
 5. Open a browser to trigger an event or events
 6. Open sensor events 
 7. Verify that the event count increased by 20, note: the variable to set the number of events is called numOfEvents.  This will allow the test to verify multiple sensor event 
 pages 
 8. Verify column headers are - '', expectedEventType, expectedSensorInstance, expectedAgentHost, expectedRowDate, expectedTriggeredPlaybooks
 7. Search for the sensor instance and verify column data
 8. Open and verify sensor event details
 9. Verify the actual headers '', 'Event Type','Sensor Instance', 'Agent/Host', 'Time Received', 'Triggered Playbooks'];
*/

import * as swimInstance from '../../../support/page-objects/swimInstance';
import * as sensorEvents from '../../../support/page-objects/main-app-objects/do-pages/sensors/sensors-events-interface';

const postSensorName = `QA_E2E_WebServer` + Date.now();
const portNumber = '10001';
const httpUrl = Cypress.config().baseUrl.split('https').join('http') + ':' + portNumber;
const expectedEventType = 'http.webserver.request';
const expectedSensorInstance = postSensorName;
const expectedTriggeredPlaybooks = '0';
const currentDate = new Date();
const date = currentDate.toLocaleString('en-us', { day: 'numeric' });
const month = currentDate.toLocaleString('en-us', { month: 'short' });
const year = ' ' + currentDate.getFullYear();
const expectedRowDate = month + ' ' + date + ',' + year;
let expectedRowText: string[]; // = ['', '', expectedEventType, expectedSensorInstance, expectedAgentHost, expectedRowDate, expectedTriggeredPlaybooks];
let count;
let latestCount;
const numOfEvents = 20;

// SPT-13435: Hide event stream
describe.skip('Verify events view', () => {
  before(() => {
    cy.cleanupTurbine();
    cy.login();
    cy.visitSwimlane('/');
  });

  it('Upload HTTP Plugin to create sensor', () => {
    swimInstance.openPlugins();
    swimInstance.pluginsPage.uploadPlugin();
    swimInstance.pluginsPage.pluginUploader.uploadFile({
      filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
      encoding: 'base64'
    });
    // Verify Plugin upload is complete
    swimInstance.pluginsPage.pluginUploader.checkUploadComplete('HTTP');
    swimInstance.pluginsPage.pluginUploader.close();
  });

  it('Create Web Server Sensor', () => {
    cy.log('sensor ' + postSensorName);
    swimInstance.openSensors();
    swimInstance.sensorsPage.createSensor({
      sensorType: 'Web Server',
      sensorName: postSensorName,
      paramData: [portNumber]
    });
  });

  it('Find Web Server Sensor agent and update expected values', () => {
    sensorEvents.findTheServerAgent(postSensorName).then(expectedAgentHost => {
      cy.log('expected agent host = ' + expectedAgentHost);
      expectedRowText = [
        '',
        '',
        expectedEventType,
        expectedSensorInstance,
        expectedAgentHost,
        expectedRowDate,
        expectedTriggeredPlaybooks
      ];
    });
    cy.get('.ngx-large-format-dialog-header-action__button > .ngx-icon').click();
  });

  it('Open sensor events and capture current number of events', () => {
    swimInstance.openSensorEvents();
    cy.wrap((count = 0));
    sensorEvents.verifySensorEventsHeader();
    sensorEvents.checkForNoDataToDisplay().then($found => {
      if (!$found) {
        sensorEvents.captureLegendTotalValue().then($currentCount => {
          count = $currentCount.text();
          cy.log('capture legend total value = ' + $currentCount.text());
        });
      }
    });
  });

  it('Open a browser to trigger 20 events', () => {
    sensorEvents.triggerWebEvent(httpUrl, numOfEvents);
  });

  it('Open sensor events', () => {
    swimInstance.openSensorEvents();
  });

  it('verify event count increased by 20, and verify column headers', () => {
    cy.log('Number of events = ' + numOfEvents);
    sensorEvents.captureLegendTotalValue().then($currentCount => {
      latestCount = $currentCount.text();
      cy.log('capture legend total after an event' + Number(latestCount));
      // verify that the legend total event acccount increases by x
      expect(Number(count) + numOfEvents).equals(Number(latestCount));
    });
    sensorEvents.verifySensorEventsHeader();
  });

  it('Open and verify sensor event details', () => {
    sensorEvents.openEventDetailsVerify(httpUrl);
  });

  after(() => {
    cy.cleanupTurbine();
    cy.logout();
  });
});

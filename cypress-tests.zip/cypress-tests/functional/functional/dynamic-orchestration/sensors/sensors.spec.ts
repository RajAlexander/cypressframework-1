import * as swimInstance from '../../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

// SPT-13435: Hide event stream
describe.skip('Verification of dynamic Orchestration - Sensors interface', () => {
  const postSensorName = `QAE2E_`;

  before(() => {
    cy.cleanupTurbine();
    swimInstance.setLoginState();
    swimInstance.loginPage.performLogin(Cypress.env('USERNAME'), Cypress.env('PASSWORD'));
  });

  it('Verify the empty Orchestration Sensors Page', () => {
    swimInstance.openSensors();
    swimInstance.sensorsPage.verifyElements(true);
  });

  // Skipped until it's decided how to handle system level plugin (which has a sensor) always being present but filtered out of the UI: SPT-12516
  // https://swimlane.atlassian.net/browse/SPT-12516
  xit('Verify a Sensor Cannot be Created without any Plugins installed with Sensors', () => {
    swimInstance.sensorsPage.createSensorWithNoSensorsAvailable();
  });

  it('Upload a plugin to create Sensor from', () => {
    swimInstance.openPlugins();
    swimInstance.pluginsPage.uploadPlugin();
    swimInstance.pluginsPage.pluginUploader.uploadFile({
      filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
      encoding: 'base64'
    });
    swimInstance.pluginsPage.pluginUploader.checkUploadComplete('HTTP');
    swimInstance.pluginsPage.pluginUploader.doneAddingPlugins();
  });

  it('Verify Sensor creation is successful', () => {
    const portNumber = faker.datatype.number({ min: 10000, max: 20000 });

    swimInstance.openSensors();
    swimInstance.sensorsPage.createSensor({
      sensorType: 'Web Server',
      sensorName: `${postSensorName}Web Server`,
      paramData: [portNumber]
    });
  });

  it('Create another Sensor and Validate Details', () => {
    const portNumber = faker.datatype.number({ min: 10000, max: 20000 });

    swimInstance.sensorsPage.createSensor({
      sensorType: 'JSON Web Server',
      sensorName: `${postSensorName}JSON Web Server`,
      paramData: [portNumber]
    });
  });

  it('Update existing sensors and Validate Details', () => {
    swimInstance.sensorsPage.updateSensor(`${postSensorName}Web Server`);
    swimInstance.sensorsPage.updateSensor(`${postSensorName}JSON Web Server`);
  });

  it('Successfully create Sensor from Plugin, Update newly created sensor and toggle disabled/enabled', () => {
    swimInstance.openPlugins();
    swimInstance.pluginsPage.uploadPlugin('', false);
    swimInstance.pluginsPage.pluginUploader.uploadFile({
      filePath: 'dynamic-orchestration/plugins/test_plugin-2.0.0.plugin',
      encoding: 'base64'
    });
    swimInstance.pluginsPage.pluginUploader.checkUploadComplete('Test');
    swimInstance.pluginsPage.pluginUploader.doneAddingPlugins();

    swimInstance.openSensors();
    // This throws a system error: unknown format.... SPT-????
    // swimInstance.sensorsPage.createSensor({
    //   sensorName: 'Test Server',
    //   paramData: ['10032']
    // });
    // swimInstance.sensorsPage.updateSensor('Test Server', true);
  });

  it('Successfully Disable and re-enable a sensor', () => {
    swimInstance.sensorsPage.disableSensor(`${postSensorName}Web ServerTest_Sensor_Updated`);
    swimInstance.sensorsPage.enableSensor(`${postSensorName}Web ServerTest_Sensor_Updated`);
  });

  it('Visit the LOGS tab and Verify Information', { tags: ['#bug', 'SPT-12392'] }, () => {
    swimInstance.sensorsPage.verifyLogsTab(`${postSensorName}Web Server`);
  });

  it('Delete the last 2 created sensors', () => {
    swimInstance.sensorsPage.deleteSensor(`${postSensorName}Web Server`);
    swimInstance.sensorsPage.deleteSensor(`${postSensorName}JSON Web Server`);
  });

  it('Validate Sensor Details upon Sensor Creation', () => {
    const portNumber = faker.datatype.number({ min: 10000, max: 20000 });

    swimInstance.sensorsPage.createSensor({
      sensorType: 'Web Server',
      sensorName: `${postSensorName}Web Server`,
      paramData: [portNumber]
    });
  });

  it('Create a Sensor with an invalid name and correct it upon update', () => {
    const portNumber = faker.datatype.number({ min: 10000, max: 20000 });

    swimInstance.sensorsPage.createSensor({
      sensorType: 'Web Server',
      sensorName: `${postSensorName}Web Server`,
      paramData: [portNumber],
      noSensors: false,
      invalid: false,
      invalidName: true
    });
  });

  it('Update the port on an existing Sensor and Save changes', () => {
    swimInstance.sensorsPage.updateSensor(`${postSensorName}Web Server`, false, ['10037']);
  });

  it('Upload Plugins that do not have Sensors', () => {
    cy.cleanupTurbine();
    swimInstance.openPlugins();
    swimInstance.pluginsPage.uploadPlugin();
    swimInstance.pluginsPage.pluginUploader.uploadFile({
      filePath: 'dynamic-orchestration/plugins/python27-1.0.1.plugin',
      encoding: 'base64'
    });
    swimInstance.pluginsPage.pluginUploader.checkUploadComplete('Python 2.7');
    swimInstance.pluginsPage.pluginUploader.uploadMorePlugins();
    swimInstance.pluginsPage.pluginUploader.uploadFile({
      filePath: 'dynamic-orchestration/plugins/python37-1.0.0.plugin',
      encoding: 'base64'
    });
    swimInstance.pluginsPage.pluginUploader.checkUploadComplete('Python 3.7');
    swimInstance.pluginsPage.pluginUploader.doneAddingPlugins();
  });

  // Skipped until it's decided how to handle system level plugin (which has a sensor) always being present but filtered out of the UI: SPT-12516
  // https://swimlane.atlassian.net/browse/SPT-12516
  xit('Try to Create Sensors after installing plugins that do not have sensors', () => {
    swimInstance.openSensors();
    swimInstance.sensorsPage.createSensorWithNoSensorsAvailable();
  });

  after(() => {
    cy.cleanupTurbine();
    swimInstance.logout();
  });
});

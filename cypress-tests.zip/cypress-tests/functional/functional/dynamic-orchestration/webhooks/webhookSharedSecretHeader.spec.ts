// @ts-check

/* test steps
1. Create a new webhook in the playbook editor
2. Save the webhook
3. Make sure the generated url is correct
4. Make sure a saved webhook can't be modified without opening the edit webhook dialog
5. Save a playbook with a webhook associated to it
6. Load a playbook with a webhook to ensure it shows as a webhook
7. Add shared secret header auth and verify dropdowns
8. VerifyPopup for Webhook updated - The webhook has been successfully updated.
9. Create a valid web hook request and check the status code is 200
10 Create an invalid request with incorrect username and verify the status is 401
11 Create an invalid request with incorrect password and verify the status is 401
12.Verify the webhook log - only has the following events
   Changed status starting -> running','Changed status running -> stopped', 
  'Changed status starting -> running', 
   and an event such as Webhook request received -> /v1/webhook/df337f7a-8c64-4202-ac9a-d62630a7a0c8/whn1653334198490 
13.Disable the webhook and verify the log
14.Generate a valid request on the disabled webhook - verify status code is 404
15.Verify webhook log has 'Changed status running -> stopped' 
16.Enable webhook and verify Changed status starting -> running'
17.Generate invalid auth and verify no new events are logged.
18.Disable webhook and verify - changed status running -> stopped'
*/

import * as swimInstance from '../../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

describe('Create a playbook with a secret auth header webhook, generate event and verify', () => {
  before(() => {
    cy.cleanupTurbine();
    cy.login();
    cy.visitSwimlane('/');
  });

  const postPlaybookName = `QA-E2E-`;
  const postAssetName = `QAE2E_`;
  const webhookName = 'whn' + Date.now();
  const webhookTitle = 'wht' + Date.now();
  const webhookDescription = 'Description';
  const playbookTitle = `${postPlaybookName}${Date.now()}`;
  const playbookName = `${postAssetName}${Date.now()}`;
  const actionName = 'QA-E2E-' + faker.company.companyName();

  it('Upload Plugin to use it in the playbook', () => {
    // Upload HTTP Plugin
    swimInstance.openPlugins();
    swimInstance.pluginsPage.uploadPlugin();
    swimInstance.pluginsPage.pluginUploader.uploadFile({
      filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
      encoding: 'base64'
    });
    // Verify Plugin upload is complete
    swimInstance.pluginsPage.pluginUploader.checkUploadComplete('HTTP');
    swimInstance.pluginsPage.pluginUploader.close();
  });

  it('Create a Playbook and Add Trigger and Action', () => {
    // Create a new playbook
    swimInstance.openPlaybooks();
    swimInstance.playbookPage.createPlaybook({
      playbookName,
      playbookTitle,
      playbookDescription: faker.lorem.sentence()
    });
    // Open created playbook to access visual editor
    swimInstance.openPlaybooks();
    swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookTitle);
    // Add webhook on the playbook
    swimInstance.playbookWebhookPage.addPlaybookWebHookGenerateUrl(webhookTitle, webhookName, webhookDescription);
    // Add actions to the playbook
    swimInstance.playbookPage.addPlaybookAction(actionName, 'Send an http payload');
    // Save Playbook changes
    swimInstance.playbookPage.savePlaybookChanges();
  });

  it('Open Playbook and open saved webhook', () => {
    // Open created playbook to access visual editor
    swimInstance.openPlaybooks();
    swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookTitle);
    swimInstance.playbookWebhookPage.openSavedWebhookFromPlaybook(webhookTitle);
  });

  it('Verify saved webhook panel', () => {
    swimInstance.playbookWebhookPage.verifySavedWebhookPanel(webhookTitle, webhookName, webhookDescription);
  });

  it('Verify webhook settings tab', () => {
    swimInstance.playbookWebhookPage.clickEditWebhookFromPlaybook();
    swimInstance.playbookWebhookPage.verifyEditWebhookSettingsTab(webhookTitle, webhookName, webhookDescription);
  });

  it('Generate a webhook event and verify webhook log', () => {
    swimInstance.playbookWebhookPage
      .verifySavedWebhookPanel(webhookTitle, webhookName, webhookDescription)
      .then(webhookUrl => {
        const sharedSecretAuthJson = {
          location: 'Request Header',
          fieldName: 'aFieldName',
          secret: 'test',
          format: 'plaintext'
        };
        swimInstance.playbookWebhookSettings.addSharedSecretAuth(sharedSecretAuthJson);
        let reqJson = { url: webhookUrl.toString(), method: 'POST', headers: { aFieldName: 'test' } };
        const reqInvalidSecretJson = {
          url: webhookUrl.toString(),
          failOnStatusCode: false,
          method: 'POST',
          headers: { aFieldName: 'testBad' }
        };
        const reqInvalidFieldJson = {
          url: webhookUrl.toString(),
          failOnStatusCode: false,
          method: 'POST',
          headers: { aFieldNameBad: 'test' }
        };
        // verify valid request
        swimInstance.playbookWebhookPage.generateEventSharedSecretAuth(reqJson);
        // verify invalid request
        swimInstance.playbookWebhookPage.generateEventSharedSecretInvalidAuth(reqInvalidSecretJson);
        swimInstance.playbookWebhookPage.generateEventSharedSecretInvalidAuth(reqInvalidFieldJson);
        swimInstance.playbookWebhookPage.clickEditWebhookFromPlaybook();
        // verify webhook logs
        swimInstance.playbookWebhookPage.verifyWebhooksLogsTab(webhookTitle, webhookName);
        const loggedMessages = [
          'Changed status starting -> running',
          'Changed status running -> stopped',
          'Changed status starting -> running',
          'Webhook request received -> ' + webhookUrl.toString().replace(Cypress.config().baseUrl + '/webhooks', '')
        ];
        swimInstance.playbookWebhookLog.verifyLoggedEvents(loggedMessages);
        // disabled the webhook and verify the log
        swimInstance.playbookWebhookLog.setEnableDisabledWebhook(false);
        // generate a valid request on the disabled webhook
        reqJson = {
          url: webhookUrl.toString(),
          failOnStatusCode: false,
          method: 'POST',
          headers: { aFieldName: 'test' }
        };
        swimInstance.playbookWebhookPage.generateEventSharedSecretInvalidAuth(reqJson, 404);
        loggedMessages.push('Changed status running -> stopped');
        swimInstance.playbookWebhookLog.verifyLoggedEvents(loggedMessages);
        // enable the webhook and verify the log
        swimInstance.playbookWebhookLog.setEnableDisabledWebhook(true);
        loggedMessages.push('Changed status starting -> running');
        swimInstance.playbookWebhookPage.generateEventSharedSecretInvalidAuth(reqInvalidSecretJson);
        swimInstance.playbookWebhookLog.verifyLoggedEvents(loggedMessages);
        swimInstance.playbookWebhookLog.setEnableDisabledWebhook(false);
        loggedMessages.push('Changed status running -> stopped');
        swimInstance.playbookWebhookLog.verifyLoggedEvents(loggedMessages);
        swimInstance.playbookWebhookLog.clickButtonWithText('Close');
      });
  });

  after(() => {
    cy.cleanupTurbine();
    cy.logout();
  });
});

// @ts-check
/* test steps
1. Create a new webhook in the playbook editor
2. Save the webhook
3. Make sure the generated url is correct
4. Make sure a saved webhook can't be modified without opening the edit webhook dialog
5. Save a playbook with a webhook associated to it
6. Load a playbook with a webhook to ensure it shows as a webhook
7. Add shared secret body auth and verify dropdowns
8. VerifyPopup for Webhook updated - The webhook has been successfully updated.
9. Create a valid web hook request and check the status code is 200
10 Create an invalid request with incorrect field and verify the status is 401
11 Create an invalid request with incorrect secret and verify the status is 401
12.Verify the webhook log - only has the following events
   Changed status starting -> running','Changed status running -> stopped', 
  'Changed status starting -> running', 
   and an event such as Webhook request received -> /v1/webhook/df337f7a-8c64-4202-ac9a-d62630a7a0c8/whn1653334198490 
13.Open the webhook tab
14. Verify the webhook tab's count 
15. Verify the webhook tab displays - Webhook and not Webhooks
16. Verify the webhook's header info - verify playbook name - verify count - verify webhooks label
17. Verify the webhook is enabled
18. Click edit webhook
19. Verify the logged events
*/

import * as swimInstance from '../../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';
import * as JWT from 'jsonwebtoken';

describe('Create a playbook with a secret auth jwt body webhook, generate event and verify', () => {
  before(() => {
    cy.cleanupTurbine();
    cy.login();
    cy.visitSwimlane('/');
  });

  const postPlaybookName = `QA-E2E-`;
  const postAssetName = `QAE2E_`;
  const webhookName = 'whn' + Date.now();
  const webhookTitle = 'wht' + Date.now();
  const webhookDescription = 'Description';
  const playbookTitle = `${postPlaybookName}${Date.now()}`;
  const playbookName = `${postAssetName}${Date.now()}`;
  const actionName = 'QA-E2E-' + faker.company.companyName();
  const loggedMessages = [
    'Changed status starting -> running',
    'Changed status running -> stopped',
    'Changed status starting -> running'
  ];

  it('Upload Plugin to use it in the playbook', () => {
    // Upload HTTP Plugin
    swimInstance.openPlugins();
    swimInstance.pluginsPage.uploadPlugin();
    swimInstance.pluginsPage.pluginUploader.uploadFile({
      filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
      encoding: 'base64'
    });
    // Verify Plugin upload is complete
    swimInstance.pluginsPage.pluginUploader.checkUploadComplete('HTTP');
    swimInstance.pluginsPage.pluginUploader.close();
  });

  it('Create a Playbook and Add Trigger and Action', () => {
    // Create a new playbook
    swimInstance.openPlaybooks();
    swimInstance.playbookPage.createPlaybook({
      playbookName,
      playbookTitle,
      playbookDescription: faker.lorem.sentence()
    });
    // Open created playbook to access visual editor
    swimInstance.openPlaybooks();
    swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookTitle);
    // Add playbook webhook
    swimInstance.playbookWebhookPage.addPlaybookWebHookGenerateUrl(webhookTitle, webhookName, webhookDescription);
    // Add actions to the playbook
    swimInstance.playbookPage.addPlaybookAction(actionName, 'Send an http payload');
    // Save Playbook changes
    swimInstance.playbookPage.savePlaybookChanges();
  });

  it('Open Playbook and open saved webhook', () => {
    // Open created playbook to access visual editor
    swimInstance.openPlaybooks();
    swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookTitle);
    swimInstance.playbookWebhookPage.openSavedWebhookFromPlaybook(webhookTitle);
  });

  it('Verify saved webhook panel', () => {
    swimInstance.playbookWebhookPage.verifySavedWebhookPanel(webhookTitle, webhookName, webhookDescription);
  });

  it('Verify webhook settings tab', () => {
    swimInstance.playbookWebhookPage.clickEditWebhookFromPlaybook();
    swimInstance.playbookWebhookPage.verifyEditWebhookSettingsTab(webhookTitle, webhookName, webhookDescription);
  });

  it('Generate a webhook event and verify webhook log', () => {
    swimInstance.playbookWebhookPage
      .verifySavedWebhookPanel(webhookTitle, webhookName, webhookDescription)
      .then(webhookUrl => {
        const payload = JWT.sign({ sub: 'abc1234' }, 'test');
        const invalidPayload = JWT.sign({ sub: 'abc1234' }, 'invalidtest');
        const reqJson = {
          url: webhookUrl.toString(),
          method: 'POST',
          encoding: 'base64',
          body: { aFieldName: payload }
        };
        const reqInvalidSecretJson = {
          url: webhookUrl.toString(),
          encoding: 'base64',
          method: 'POST',
          failOnStatusCode: false,
          body: { aFieldName: invalidPayload }
        };
        const reqInvalidFieldJson = {
          url: webhookUrl.toString(),
          encoding: 'base64',
          method: 'POST',
          failOnStatusCode: false,
          body: { badFieldName: payload }
        };
        const sharedSecretAuthJson = {
          location: 'Request Body',
          fieldName: 'aFieldName',
          secret: 'test',
          format: 'jwt'
        };
        swimInstance.playbookWebhookSettings.addSharedSecretAuth(sharedSecretAuthJson);
        swimInstance.playbookWebhookPage.generateEventSharedSecretAuth(reqJson);
        // Verify a status of 401 occurs
        swimInstance.playbookWebhookPage.generateEventSharedSecretInvalidAuth(reqInvalidSecretJson);
        // Verify a status of 401 occurs
        swimInstance.playbookWebhookPage.generateEventSharedSecretInvalidAuth(reqInvalidFieldJson);
        // Verify webhook logs
        swimInstance.playbookWebhookPage.clickEditWebhookFromPlaybook();
        swimInstance.playbookWebhookPage.verifyWebhooksLogsTab(webhookTitle, webhookName);
        loggedMessages.push(
          'Webhook request received -> ' + webhookUrl.toString().replace(Cypress.config().baseUrl + '/webhooks', '')
        );

        swimInstance.playbookWebhookLog.verifyLoggedEvents(loggedMessages);
        swimInstance.playbookWebhookLog.clickButtonWithText('Close');
      });
  });
  it('Open webhook tab and verify webhook info', () => {
    swimInstance.openWebhooks();
    // Verify the webhook tab - label and count
    swimInstance.webhookTab.verifyWebhookTab(1);
    swimInstance.webhookTab.verifyWebhookHeaderByPlaybook(playbookTitle, 1, 'Webhook');
    // verify playbook's webhook card
    swimInstance.webhookTab.verifyWebhookGroup(webhookTitle, playbookTitle);
  });
  it('Click edit webhook and verify settings tab and logged events', () => {
    // edit the webhook and verify the settings tab
    swimInstance.webhookTab.clickEditWebhook(webhookTitle);
    swimInstance.playbookWebhookPage.verifyEditWebhookSettingsTab(webhookTitle, webhookName, webhookDescription, true);
    swimInstance.webhookTab.clickEditWebhook(webhookTitle);
    // Verify the webhooks log tab and verify the logged events
    swimInstance.playbookWebhookPage.verifyWebhooksLogsTab(webhookTitle, webhookName);
    swimInstance.playbookWebhookLog.verifyLoggedEvents(loggedMessages);
  });

  after(() => {
    cy.cleanupTurbine();
    cy.logout();
  });
});

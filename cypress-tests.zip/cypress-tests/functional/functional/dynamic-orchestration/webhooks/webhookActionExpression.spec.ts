// @ts-check

/* test steps
1. Create a new webhook in the playbook editor
2. Add Action and expression - using Add Action and expression - Body Expression $event.data.body.user
3. Verify the code editor
4. View the action -> additional configuration and verify the expression
5. Modify Webhook title, name, description and save playbook
6. Load a playbook with the webhook and verify the panel and settings
7. Verify the code editor to ensure { body: { $:ref: $event.data.body.user } is listed
8. Verify the action expression is 'Body', '$event.data.body.user'
9. Verify the code editor to ensure { body: { $:ref: $event.data.body.user } is listed

*/

import * as swimInstance from '../../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';
import _ from 'cypress/types/lodash';

describe('Create a playbook with a basic auth no username webhook, generate event and verify', () => {
  before(() => {
    cy.cleanupTurbine();
    cy.login();
    cy.visitSwimlane('/');
  });

  const postPlaybookName = `QA-E2E-`;
  const postAssetName = `QAE2E_`;
  const playbookTitle = `${postPlaybookName}${Date.now()}`;
  let webhookName = 'whn' + Date.now();
  let webhookDescription = 'Description';
  let webhookTitle = 'wht' + Date.now();
  const playbookName = `${postAssetName}${Date.now()}`;
  const playbookDescription = faker.lorem.sentence();
  const actionName = 'QA-E2E-Action';
  const actions = 'QAE2EAction';
  const expectedCodeEditorTextPage1 =
    'schema:playbook/2name:' +
    playbookName +
    'title:' +
    playbookTitle +
    'description:' +
    playbookDescription +
    'actions:{' +
    actions +
    ':{action:http.send,inputs:{body:{$:ref:$event.data.body.user}},publish:{},title:' +
    actionName +
    '}';
  let expectedCodeEditorTextPage2 =
    'inputs: { body: { $:ref: $event.data.body.user } },publish: {},title:' +
    actionName +
    '}}triggers:sensors:- ' +
    webhookName +
    'entrypoints:- ' +
    actions;
  it('Upload Plugin to use it in the playbook', () => {
    // Upload HTTP Plugin
    swimInstance.openPlugins();
    swimInstance.pluginsPage.uploadPlugin();
    swimInstance.pluginsPage.pluginUploader.uploadFile({
      filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
      encoding: 'base64'
    });
    // Verify Plugin upload is complete
    swimInstance.pluginsPage.pluginUploader.checkUploadComplete('HTTP');
    swimInstance.pluginsPage.pluginUploader.close();
  });

  it('Create a Playbook', () => {
    // Create a new playbook
    swimInstance.openPlaybooks();
    swimInstance.playbookPage.createPlaybook({
      playbookName,
      playbookTitle,
      playbookDescription
    });
    // Open created playbook to access visual editor
    swimInstance.openPlaybooks();
    swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookTitle);
  });

  it('Add Webhook', () => {
    // Add webhook to the playbook
    swimInstance.playbookWebhookPage.addPlaybookWebHookGenerateUrl(webhookTitle, webhookName, webhookDescription);
  });

  it('Add Action and expression', () => {
    // Add actions to the playbook
    swimInstance.playbookPage.addPlaybookAction(actionName, 'Send an http payload');
    // Add additional configuation
    swimInstance.playbookPage.clickAdditionalConfiguration();
    swimInstance.playbookPage.selectPlaybookActionInputOption('Body', ' Expression ');
    // Add the expression to the dialog
    swimInstance.playbookPage.expressionDialog('$event.data.body.user');
    swimInstance.playbookPage.clickApplyCloseButton('Apply');
  });

  it('Verify Code Editor changes', () => {
    // waiting for the nodes to finish moving
    cy.wait(1000);
    swimInstance.playbookPage.verifyCodeEditorByDisplayedText(expectedCodeEditorTextPage1);
    cy.get('.view-line > span').contains(new RegExp('^inputs$', 'g')).closest('div').type('{pageDown}');
    swimInstance.playbookPage.verifyCodeEditorByDisplayedText(expectedCodeEditorTextPage2);
  });

  it('Verify the action expression', () => {
    swimInstance.playbookPage.findSpecificAction(actionName);
    swimInstance.playbookPage.clickAdditionalConfiguration();
    swimInstance.playbookPage.checkExpression('Body', '$event.data.body.user');
    swimInstance.playbookPage.clickApplyCloseButton('Apply');
  });

  it('Modify Webhook title, name, description and save playbook', () => {
    cy.get('.node-label').contains(webhookTitle).click();
    swimInstance.playbookWebhookPage.clickEditWebhookFromPlaybook();
    webhookTitle = 'new' + Date.now();
    webhookName = 'newName' + Date.now();
    webhookDescription = 'newDesc' + Date.now();
    swimInstance.playbookWebhookPage.editWebhookSettingsTab(webhookTitle, webhookName, webhookDescription);
    // Save Playbook changes
    swimInstance.playbookPage.savePlaybookChanges();
  });

  it('Open Playbook and open saved webhook', () => {
    swimInstance.openPlaybooks();
    swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookTitle);
    swimInstance.playbookWebhookPage.openSavedWebhookFromPlaybook(webhookTitle);
  });

  it('Verify webhook panel and settings', () => {
    swimInstance.playbookWebhookPage.verifySavedWebhookPanel(webhookTitle, webhookName, webhookDescription);
    swimInstance.playbookWebhookPage.clickEditWebhookFromPlaybook();
    swimInstance.playbookWebhookPage.verifyEditWebhookSettingsTab(webhookTitle, webhookName, webhookDescription);
  });

  it('Verify the code editor', () => {
    swimInstance.playbookPage.verifyCodeEditorByLine('inputs', '{body:{$:ref:$event.data.body.user}},');
    swimInstance.playbookPage.verifyCodeEditorByDisplayedText(expectedCodeEditorTextPage1);
    cy.get('.view-line > span').contains(new RegExp('^inputs$', 'g')).closest('div').type('{pageDown}');
    expectedCodeEditorTextPage2 =
      'inputs: { body: { $:ref: $event.data.body.user } },publish: {},title:' +
      actionName +
      '}}triggers:sensors:- ' +
      webhookName +
      'entrypoints:- ' +
      actions;
    swimInstance.playbookPage.verifyCodeEditorByDisplayedText(expectedCodeEditorTextPage2);
  });

  it('Verify the action expression', () => {
    swimInstance.playbookPage.findSpecificAction(actionName);
    swimInstance.playbookPage.clickAdditionalConfiguration();
    swimInstance.playbookPage.checkExpression('Body', '$event.data.body.user');
    swimInstance.playbookPage.clickApplyCloseButton('Apply');
  });

  after(() => {
    cy.cleanupTurbine();
    cy.logout();
  });
});

// @ts-check

/* test steps
1. Create 2 playbooks and add 3 webhooks for each playbook
2. Save the webhook
3. Save the playbook with a webhook associated to it
4. Open the webhook tab
5. Verify the webhook tab's count is correct 
6. Verify the webhook tab displays - Webhooks and not Webhook and the correct count
7. Verify the webhook's header info - verify playbook name - verify count - verify webhooks label
8. verify the webhook is enabled
9. verify that ellipsis dropdown displays edit webhook
10.Verify the Webhook is not displayed in the plugin tab
*/

import * as swimInstance from '../../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

describe('Create a playbook with a basic auth no username webhook, generate event and verify', () => {
  before(() => {
    cy.cleanupTurbine();
    cy.login();
    cy.visitSwimlane('/');
  });

  const postPlaybookName = `QAE2E_`;
  let webhookArray = [];
  const playbookWebhookMap = new Map();
  let webhookName = '';
  const actionName = 'QA-E2E-' + faker.company.companyName();
  const webHookDescription = 'Description';
  const numOfPlaybooks = 2;
  const numOfWebhooks = 3;
  let webhookTitle;

  it('Upload Plugin to use it in the playbook', () => {
    // Upload HTTP Plugin
    swimInstance.openPlugins();
    swimInstance.pluginsPage.uploadPlugin();
    swimInstance.pluginsPage.pluginUploader.uploadFile({
      filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
      encoding: 'base64'
    });
    // Verify Plugin upload is complete
    swimInstance.pluginsPage.pluginUploader.checkUploadComplete('HTTP');
    swimInstance.pluginsPage.pluginUploader.close();
  });

  it('Create a Playbook and with a basic auth webhook and Action', () => {
    Cypress._.times(numOfPlaybooks, () => {
      webhookArray = [];
      const playbookTitle = postPlaybookName + Date.now();
      const playbookName = postPlaybookName + Date.now();
      // Create a new playbook
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.createPlaybook({
        playbookName,
        playbookTitle,
        playbookDescription: faker.lorem.sentence()
      });
      // playbookNameArray.push(playbookName);
      // Open created playbook to access visual editor
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookTitle);
      Cypress._.times(numOfWebhooks, () => {
        webhookName = 'whn' + Date.now();
        webhookTitle = webhookName;
        // Add webhook on the playbook
        swimInstance.playbookWebhookPage.addPlaybookWebHookGenerateUrl(webhookTitle, webhookName, webHookDescription);
        webhookArray.push(webhookName);
      });
      // Add actions to the playbook
      swimInstance.playbookPage.addPlaybookAction(actionName, 'Send an http payload');
      // Save Playbook changes
      swimInstance.playbookPage.savePlaybookChanges();
      cy.wrap(playbookWebhookMap.set(playbookTitle, webhookArray));
    });
  });

  it('Open webhook tab and verify', () => {
    swimInstance.openWebhooks();
    swimInstance.webhookTab.verifyWebhookTab(6);
    playbookWebhookMap.forEach(function (value, key) {
      swimInstance.webhookTab.verifyWebhookHeaderByPlaybook(
        key,
        value.length,
        value.length > 1 ? 'Webhooks' : 'Webhook'
      );
      value.forEach(currentWebhook => {
        swimInstance.webhookTab.verifyWebhookGroup(currentWebhook, key);
      });
    });
  });

  after(() => {
    cy.cleanupTurbine();
    cy.logout();
  });
});

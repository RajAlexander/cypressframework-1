// @ts-check

/* test steps
1. Upload HTTP Plugin to use it in the playbook
2. Create a Playbook and add a webhook trigger and action
3. Save a playbook with a webhook associated to it
4. Load a playbook with a webhook to ensure it shows as a webhook
5. Verify saved webhook panel - Make sure a saved webhook can't be modified without opening the edit webhook dialog
6. Make sure the generated url is correct
7. Verify copy url and verify the message 'Link was copied to the clipboard' displays
8. Verify webhook setting tab
9. Generate a web hook event and verify webhook log
10.Disable the webhook
11.Refresh the log by clicking on jump to today's date 
12.Verify the webhook log
*/

import * as swimInstance from '../../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

describe('Create a playbook with a basic auth webhook, generate event and verify', () => {
  before(() => {
    cy.cleanupTurbine();
    cy.login();
    cy.visitSwimlane('/');
  });

  const postPlaybookName = `QA-E2E-`;
  const postAssetName = `QAE2E_`;
  const webhookName = 'whn' + Date.now();
  const webhookTitle = 'wht' + Date.now();
  const webhookDescription = 'Description';
  const playbookTitle = `${postPlaybookName}${Date.now()}`;
  const playbookName = `${postAssetName}${Date.now()}`;
  const actionName = 'QA-E2E-' + faker.company.companyName();

  it('Upload Plugin to use it in the playbook', () => {
    // Upload HTTP Plugin
    swimInstance.openPlugins();
    swimInstance.pluginsPage.uploadPlugin();
    swimInstance.pluginsPage.pluginUploader.uploadFile({
      filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
      encoding: 'base64'
    });
    // Verify Plugin upload is complete
    swimInstance.pluginsPage.pluginUploader.checkUploadComplete('HTTP');
    swimInstance.pluginsPage.pluginUploader.close();
  });

  it('Create a Playbook and add a webhook trigger and action', () => {
    // Create a new playbook
    swimInstance.openPlaybooks();
    swimInstance.playbookPage.createPlaybook({
      playbookName,
      playbookTitle,
      playbookDescription: faker.lorem.sentence()
    });
    // Open created playbook to access visual editor
    swimInstance.openPlaybooks();
    swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookTitle);
    // Add webhook to the playbook
    swimInstance.playbookWebhookPage.addPlaybookWebHookGenerateUrl(webhookTitle, webhookName, webhookDescription);
    // Add actions to the playbook
    swimInstance.playbookPage.addPlaybookAction(actionName, 'Send an http payload');
    // Save Playbook changes
    swimInstance.playbookPage.savePlaybookChanges();
  });

  it('Open Playbook and open saved webhook', () => {
    // Open created playbook to access visual editor
    swimInstance.openPlaybooks();
    swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookTitle);
    swimInstance.playbookWebhookPage.openSavedWebhookFromPlaybook(webhookTitle);
  });

  it('Verify saved webhook panel', () => {
    swimInstance.playbookWebhookPage.verifySavedWebhookPanel(webhookTitle, webhookName, webhookDescription);
  });

  it('Verify edit webhook setting tab', () => {
    swimInstance.playbookWebhookPage.clickEditWebhookFromPlaybook();
    swimInstance.playbookWebhookPage.verifyEditWebhookSettingsTab(webhookTitle, webhookName, webhookDescription);
  });

  it('Generate a webhook event and verify webhook log', () => {
    swimInstance.playbookWebhookPage
      .verifySavedWebhookPanel(webhookTitle, webhookName, webhookDescription)
      .then(webhookUrl => {
        swimInstance.playbookWebhookSettings.addBasicAuth('someUser', 'somePassword');
        swimInstance.playbookWebhookPage.generateEventBasicAuth('someUser', 'somePassword');
        swimInstance.playbookWebhookPage.clickEditWebhookFromPlaybook();
        swimInstance.playbookWebhookPage.verifyWebhooksLogsTab(webhookTitle, webhookName);
        // verify status is running
        swimInstance.playbookWebhookLog.verifyWebhookLogStatusRunning();
        // verify an entry such as /Webhook request received -> /v1/webhook/df337f7a-8c64-4202-ac9a-d62630a7a0c8/whn1653334198490
        const loggedMessages = [
          'Changed status starting -> running',
          'Changed status running -> stopped',
          'Changed status starting -> running',
          'Webhook request received -> ' + webhookUrl.toString().replace(Cypress.config().baseUrl + '/webhooks', '')
        ];
        swimInstance.playbookWebhookLog.verifyLoggedEvents(loggedMessages);
      });
  });

  it('From webhook log, disable webhook, jump to todays date, and verify the log', () => {
    swimInstance.playbookWebhookLog.setEnableDisabledWebhook(false);
    swimInstance.playbookWebhookLog.verifyWebhookLogEntry('Changed status running -> stopped');
    swimInstance.playbookWebhookLog.clickButtonWithText('Close');
  });

  after(() => {
    cy.cleanupTurbine();
    cy.logout();
  });
});

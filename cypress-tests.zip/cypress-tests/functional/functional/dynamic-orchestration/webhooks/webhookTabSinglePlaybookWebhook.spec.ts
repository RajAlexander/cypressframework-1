// @ts-check

/* test steps
1. Create a new webhook in the playbook editor
2. Save the webhook
3. Save the playbook with a webhook associated to it
4. Open the webhook tab
5. Verify the webhook tab's count 
6. Verify the webhook tab displays - Webhook and not Webhooks
7. Verify the webhook's header info - verify playbook name - verify count - verify webhooks label
8. Verify the webhook is enabled
9. Verify that ellipsis dropdown displays edit webhook
10.Diabled the webhook
11.Verify the Webhook is not displayed in the plugin tab
12.Disable the webhook
13.Back to the webhook tab and enable the webhook
14.Click  edit webhook and verify the settings tab Verify the webhooks log tab and verify the logged events
*/

import * as swimInstance from '../../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

describe('Create a playbook with a basic auth no username webhook, generate event and verify', () => {
  before(() => {
    cy.cleanupTurbine();
    cy.login();
    cy.visitSwimlane('/');
  });

  const postPlaybookName = `QAE2E_`;
  const webHookDescription = 'Description';
  const numOfPlaybooks = 1;
  const numOfWebhooks = 1;
  let webhookArray = [];
  const playbookWebhookMap = new Map();
  let webhookName;
  let webhookTitle;

  it('Upload Plugin to use it in the playbook', () => {
    // Upload HTTP Plugin
    swimInstance.openPlugins();
    swimInstance.pluginsPage.uploadPlugin();
    swimInstance.pluginsPage.pluginUploader.uploadFile({
      filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
      encoding: 'base64'
    });
    // Verify Plugin upload is complete
    swimInstance.pluginsPage.pluginUploader.checkUploadComplete('HTTP');
    swimInstance.pluginsPage.pluginUploader.close();
  });

  it('Create a Playbook and with a basic auth webhook and Action', () => {
    Cypress._.times(numOfPlaybooks, () => {
      webhookArray = [];
      const playbookName = postPlaybookName + Date.now();
      const playbookTitle = postPlaybookName + Date.now();
      // Create a new playbook
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.createPlaybook({
        playbookName,
        playbookTitle,
        playbookDescription: faker.lorem.sentence()
      });
      // playbookNameArray.push(playbookName);
      // Open created playbook to access visual editor
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookTitle);
      Cypress._.times(numOfWebhooks, () => {
        webhookName = 'whn' + Date.now();
        webhookTitle = webhookName;
        // Add webhook on the playbook
        swimInstance.playbookWebhookPage.addPlaybookWebHookGenerateUrl(webhookTitle, webhookName, webHookDescription);
        webhookArray.push(webhookName);
      });
      // Add actions to the playbook
      swimInstance.playbookPage.addPlaybookAction('QA-E2E Action' + webhookName, 'Send an http payload');
      // Save Playbook changes
      swimInstance.playbookPage.savePlaybookChanges();
      playbookWebhookMap.set(playbookName, webhookArray);
    });
  });

  it('Open webhook tab and verify', () => {
    swimInstance.openWebhooks();
    // Verify the webhook tab - label and count
    swimInstance.webhookTab.verifyWebhookTab(1);
    playbookWebhookMap.forEach(function (value, key) {
      // verify webhook card header
      swimInstance.webhookTab.verifyWebhookHeaderByPlaybook(
        key,
        value.length,
        value.length > 1 ? 'Webhooks' : 'Webhook'
      );
      value.forEach(currentWebhook => {
        // verify playbook's webhook card
        swimInstance.webhookTab.verifyWebhookGroup(currentWebhook, key);
        // Disable the webhook
        swimInstance.webhookTab.setEnableDisabledWebhook(currentWebhook, false);
        swimInstance.webhookTab.verifyEllipsisDropdownEditSensor(currentWebhook);
        // verify webhook is not listed as a plugin
        swimInstance.webhookTab.verifyWebhookIsNotPlugin(currentWebhook);
        // go back to the webhook tab and enable the webhook
        swimInstance.webhookTab.setEnableDisabledWebhook(currentWebhook, true);
        // edit the webhook and verify the settings tab
        swimInstance.webhookTab.clickEditWebhook(currentWebhook);

        swimInstance.playbookWebhookPage.verifyEditWebhookSettingsTab(
          webhookTitle,
          currentWebhook,
          webHookDescription,
          true
        );
        const loggedMessages = [
          'Changed status starting -> running',
          'Changed status running -> stopped',
          'Changed status starting -> running'
        ];
        swimInstance.webhookTab.clickEditWebhook(currentWebhook);
        // Verify the webhooks log tab and verify the logged events
        swimInstance.playbookWebhookPage.verifyWebhooksLogsTab(webhookTitle, webhookName);
        swimInstance.playbookWebhookLog.verifyLoggedEvents(loggedMessages);
      });
    });
  });

  after(() => {
    cy.cleanupTurbine();
    cy.logout();
  });
});

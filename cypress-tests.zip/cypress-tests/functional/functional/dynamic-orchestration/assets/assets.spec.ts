import * as swimInstance from '../../../support/page-objects/swimInstance';

describe('Verification of dynamic Orchestration - Assets interface', () => {
  const postAssetName = `QAE2E_`;

  before(() => {
    cy.turbinelogin();
    cy.login();

    cy.cleanupTurbine();
    cy.cleanupOrchestrationTasks();

    cy.visit('/');
  });

  it('Verify the empty Orchestration Assets Page', () => {
    swimInstance.openAssets();
    swimInstance.assetsPage.verifyElements(true);
  });

  it('Attempt to create a new asset with no plugins installed', () => {
    swimInstance.assetsPage.createAssetWithNoAssetsAvailable();
  });

  // TODO: Improvement to be implemented by uploading these plugins by making API call,
  // instead of doing it through the UI, since plugin upload is already tested as part of plugins tests.
  it('Upload Plugins to Create an Asset from', () => {
    swimInstance.openPlugins();
    swimInstance.pluginsPage.uploadPlugin();
    swimInstance.pluginsPage.pluginUploader.uploadFile({
      filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
      encoding: 'base64'
    });
    swimInstance.pluginsPage.pluginUploader.checkUploadComplete('HTTP');
    swimInstance.pluginsPage.pluginUploader.uploadMorePlugins();
    swimInstance.pluginsPage.pluginUploader.uploadFile({
      filePath: 'dynamic-orchestration/plugins/github-2.0.1.plugin',
      encoding: 'base64'
    });
    swimInstance.pluginsPage.pluginUploader.checkUploadComplete('Github');
    swimInstance.pluginsPage.pluginUploader.doneAddingPlugins();
  });

  it('Create an Asset with invalid parameters and test connection', () => {
    swimInstance.openAssets();
    swimInstance.assetsPage.createAsset({
      assetType: 'Github',
      assetName: `${postAssetName}GitHub`,
      paramData: ['badkey'],
      noAssets: true,
      invalid: true
    });
  });

  it('Create a new Asset and Validates Details', () => {
    swimInstance.assetsPage.createAsset({
      assetType: 'Uri',
      assetName: `${postAssetName}Uri`,
      paramData: ['https://www.google.com', 'GET']
    });
  });

  it('Update the created assets and Validates Details', () => {
    swimInstance.assetsPage.updateAsset(`${postAssetName}Uri`);
  });

  it('Delete last 2 created assets', () => {
    swimInstance.assetsPage.deleteAsset(`${postAssetName}Uri`);
    swimInstance.assetsPage.deleteAsset(`${postAssetName}GitHub`);
  });

  it('Upload Plugins which do not have Assets', () => {
    swimInstance.openPlugins();
    swimInstance.pluginsPage.uploadPlugin('', false);
    swimInstance.pluginsPage.pluginUploader.uploadFile({
      filePath: 'dynamic-orchestration/plugins/python27-1.0.1.plugin',
      encoding: 'base64'
    });
    swimInstance.pluginsPage.pluginUploader.checkUploadComplete('Python 2.7');
    swimInstance.pluginsPage.pluginUploader.uploadMorePlugins();
    swimInstance.pluginsPage.pluginUploader.uploadFile({
      filePath: 'dynamic-orchestration/plugins/python37-1.0.0.plugin',
      encoding: 'base64'
    });
    swimInstance.pluginsPage.pluginUploader.checkUploadComplete('Python 3.7');
    swimInstance.pluginsPage.pluginUploader.doneAddingPlugins();
  });

  it('Attempt to create a new asset from plugins with no assets to choose from', () => {
    swimInstance.openAssets();
    swimInstance.assetsPage.createAssetWithNoAssetsAvailable();
  });

  it('Create an Asset with an invalid name and corrects upon update', () => {
    swimInstance.openPlugins();
    swimInstance.pluginsPage.uploadPlugin('', false);
    swimInstance.pluginsPage.pluginUploader.uploadFile({
      filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
      encoding: 'base64'
    });
    swimInstance.pluginsPage.pluginUploader.checkUploadComplete('HTTP');
    swimInstance.pluginsPage.pluginUploader.doneAddingPlugins();

    swimInstance.openAssets();
    swimInstance.assetsPage.createAsset({
      assetType: 'Uri',
      assetName: `${postAssetName}Uri`,
      paramData: ['https://www.google.com', 'GET'],
      noAssets: true,
      invalid: false,
      sourcePluginCheck: false,
      invalidName: true
    });
  });

  it('Create an Asset and Validate Plugin Details', () => {
    swimInstance.openPlugins();
    swimInstance.pluginsPage.uploadPlugin('', false);
    swimInstance.pluginsPage.pluginUploader.uploadFile({
      filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
      encoding: 'base64'
    });
    swimInstance.pluginsPage.pluginUploader.checkUploadComplete('HTTP');
    swimInstance.pluginsPage.pluginUploader.doneAddingPlugins();

    swimInstance.openAssets();
    swimInstance.assetsPage.createAsset({
      assetType: 'Uri',
      assetName: `${postAssetName}Uri`,
      paramData: ['https://www.swimlane.com', 'GET'],
      noAssets: false,
      invalid: false,
      sourcePluginCheck: true
    });
  });

  after(() => {
    cy.cleanupTurbine();
    swimInstance.logout();
  });
});

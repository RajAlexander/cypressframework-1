// @ts-check
import * as swimInstance from '../../../support/page-objects/swimInstance';

const nodeCount = {
  'Number of Agents': '',
  'Number of Pools': '',
  'Number of Engines': ''
};

describe('Verification of Dynamic Orchestration - Verify Nodes View', () => {
  before(() => {
    cy.cleanupTurbine();
    cy.login();
    cy.cleanupOrchestrationTasks();
    cy.cleanUpCypressApps();
    cy.cleanUpCypressWorkspaces();
    swimInstance.setLoginState();
    swimInstance.loginPage.performLogin(Cypress.env('USERNAME'), Cypress.env('PASSWORD'));
  });

  it('Verify Nodes Page', () => {
    cy.intercept('POST', '/orchestration/api/v1/node/rql').as('agents');
    cy.intercept('POST', '/orchestration/api/v1/pool/rql').as('pools');

    swimInstance.openNodes();

    cy.wait('@agents').then(nodes => {
      const nodeAgents = nodes.response.body.items.filter(function (agentCount) {
        return agentCount.item.node.type === 'agent' || agentCount.item.node.type === 'webhook-agent';
      });
      nodeCount['Number of Agents'] = nodeAgents.length;

      const nodeEngines = nodes.response.body.items.filter(function (engineCount) {
        return engineCount.item.node.type === 'engine';
      });
      nodeCount['Number of Engines'] = nodeEngines.length;
    });

    cy.wait('@pools').then(pools => {
      nodeCount['Number of Pools'] = pools.response.body.items.length;
    });

    swimInstance.nodesPage.verifyElements(nodeCount);
  });

  it('Verify Agent Details DataTable is Displayed', () => {
    swimInstance.nodesPage.selectViewButton('View Agents');
    swimInstance.nodesPage.verifyDataTableIsDisplayed('Agents');
  });

  it('Verify Install Agent Script Dialog is Displayed', () => {
    swimInstance.nodesPage.selectDeployAgentButton();
    swimInstance.nodesPage.verifyInstallAgentScriptDialogIsDisplayed();
    swimInstance.nodesPage.closeInstallAgentScriptDialog();
  });

  it('Verify Pools DataTable is Displayed', () => {
    swimInstance.nodesPage.selectViewButton('View Pools');
    swimInstance.nodesPage.verifyDataTableIsDisplayed('Pools');
  });

  it('Verify Engines DataTable is Displayed', () => {
    swimInstance.nodesPage.selectViewButton('View Engines');
    swimInstance.nodesPage.verifyDataTableIsDisplayed('Engines');
  });
});

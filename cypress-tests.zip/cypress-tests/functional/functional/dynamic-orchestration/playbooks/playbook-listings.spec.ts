import * as swimInstance from '../../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

let playbookCount = 0;

const basePlaybookProperties = {
  title: `QA-E2E- ${faker.company.companyName()}`,
  name: faker.internet.domainWord(),
  description: faker.lorem.sentence()
};

const playbookProperties = {
  type: 'PLAYBOOK',
  label: `QA-E2E- ${faker.company.companyName()}`,
  name: faker.internet.domainWord(),
  description: faker.lorem.sentence(),
  runsPerDay: ' -',
  avgRunTime: ' --:--'
};

describe('Verification of Dynamic Orchestration - Existing Playbook listing and details', () => {
  before(() => {
    cy.cleanupTurbine();
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Navigate to Playbooks Page', () => {
    it('Nav to Playbooks page', () => {
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.getPlaybooksCount().then($currentPlaybooks => {
        playbookCount = Number($currentPlaybooks);
      });
    });

    it('Upload playbook for testing', () => {
      swimInstance.playbookPage.uploadPlaybook(
        'dynamic-orchestration/playbooks/test_playbook_yml.yml',
        basePlaybookProperties
      );
      playbookCount += 1;
      cy.wait(500);
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.getPlaybooksCount().then($currentPlaybooks => {
        expect(Number($currentPlaybooks)).to.equal(playbookCount);
      });
    });

    /**
     * There is a change in the DOM around the `ngx-card-subtitle`
     *
     * before
     * <ngx-card-subtitle>
     *  <span class="secondary">sensor_post</span>
     * </ngx-card-subtitle>
     *
     * after
     * <ngx-card-subtitle>
     *  "sensor_post"
     * </ngx-card-subtitle>
     *
     * This is related to `$playbookDetails.name` property. Instead of `span.secondary` (which is a unique child of `ngx-card-subtitle`), it is now just a Text Node.
     * The returned value of `$playbookDetails.name` isn't just "sensor_post" anymore.
     */
    it('Check playbook icon details', () => {
      const hasRuntimeDetails = true;
      swimInstance.playbookPage
        .getPlaybookItemDetails(basePlaybookProperties.title, hasRuntimeDetails)
        .then($playbookDetails => {
          expect($playbookDetails).to.contain({
            /*name: basePlaybookProperties.name,*/
            title: basePlaybookProperties.title,
            type: playbookProperties.type,
            runsPerDay: playbookProperties.runsPerDay,
            avgRunTime: playbookProperties.avgRunTime
          });
        });
    });

    // it('Verifies the Edit Playbook button', () => {
    //   swimInstance.playbookPage.verifyEditPlaybookButton(basePlaybookProperties.title);
    //   swimInstance.playbookPage.playbookDetails.close();
    // });
  });

  describe('Check playbook finer details popup', () => {
    it('Click on playbook to open details popup', () => {
      swimInstance.playbookPage.clickOnPlaybook(basePlaybookProperties.title);
    });

    it('Verify Playbook Edit Metadata Dialog details', () => {
      swimInstance.playbookPage.playbookDetails.getPlaybookItemDetails(true).then($playbookDetails => {
        expect($playbookDetails).to.contain({
          title: basePlaybookProperties.title,
          name: basePlaybookProperties.name
        });
      });
    });

    it('Close playbook details', () => {
      swimInstance.playbookPage.playbookDetails.close();
    });
  });

  describe('Upload a plugin and related playbook to Validate Visual Editor', () => {
    it('Upload a Plugin and related Playbook for testing', () => {
      basePlaybookProperties.title = 'QA-E2E-http_test';
      basePlaybookProperties.name = 'http_test';
      // Upload HTTP Plugin
      swimInstance.openPlugins();

      //it will check for plugin exists
      swimInstance.pluginsPage.checkPlugin(
        {
          filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
          encoding: 'base64'
        },
        'HTTP',
        '1.0.2'
      );
      cy.wait(1000);
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.uploadPlaybook(
        'dynamic-orchestration/playbooks/test_playbook_yml.yml',
        basePlaybookProperties,
        false
      );
    });

    it('Verify Playbook Visual Editor', () => {
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.verifyPlaybookVisualEditor(basePlaybookProperties.title);
    });
  });

  after(() => {
    cy.cleanupTurbine();
    cy.logout();
  });
});

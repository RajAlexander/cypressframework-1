// @ts-check
import * as swimInstance from '../../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const postAssetName = `QAE2E_`;
const postPlaybookName = `QA-E2E-`;
const actionName = 'Get Users';

const playbookTitle = `${postPlaybookName}${faker.company.companyName()}`;
const playbookName = `${postAssetName}${faker.random.word().replace('-', '')}`;

describe('View all promoted playbook outputs', () => {
  before(() => {
   cy.cleanupTurbine();
    swimInstance.setLoginState();
    swimInstance.loginPage.performLogin(Cypress.env('USERNAME'), Cypress.env('PASSWORD'));
  });
  describe('Create Playbook Manually through the UI', () => {
    it('Upload Plugin to create Asset', () => {
      // Upload slack Plugin
      swimInstance.openPlugins();

      //it will check for plugin exists
      swimInstance.pluginsPage.checkPlugin(
        {
          filePath: 'dynamic-orchestration/plugins/slack-1.1.2.plugin',
          encoding: 'base64'
        },
        'Slack',
        '1.1.2'
      );
    });
  });

  describe('Create a Playbook and Add Action, map available action output configurations', () => {
    it('Create a Playbook', () => {
      // Create a new playbook
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.createPlaybook({
        playbookName,
        playbookTitle,
        playbookDescription: faker.lorem.sentence()
      });
    });

    it('Add a playbook action from plugin', () => {
      // Add actions to the playbook
      swimInstance.playbookPage.addPlaybookActionfromPlugin(actionName);
      // Save Playbook changes
      swimInstance.playbookPage.savePlaybookChanges();
    });

    it('Check all playbook labels are displayed in the UI', () => {
      swimInstance.playbookPage.clickPlaybookOutput();
      swimInstance.playbookPage.checkPlaybookOutputLables();
    });
  });

  describe('Array child properties must not be allowed to be promoted', () => {
    it('Select the parent property', () => {
      swimInstance.playbookPage.promotePlaybookOutputs('array');
      swimInstance.playbookPage.checkpromotePlaybookOutputsLables(true, actionName, 'slack');
    });

    it('Check only Parent property is displayed in promoted actions output', () => {
      swimInstance.playbookPage.checkpromotePlaybookOutput('array');
      swimInstance.playbookPage.clickApplyCloseButton('Apply');
      swimInstance.playbookPage.savePlaybookChanges();
    });

    it('Save the Playbook and check previous saved playbook is displayed', () => {
      swimInstance.playbookPage.clickPlaybookOutput();
      swimInstance.playbookPage.clickApplyCloseButton('Close');
    });
  });

  describe('Click on Remove link and check the Radio button is displayed in select promoted action outputs', () => {
    it('Click on Remove link and click on cancel button', () => {
      swimInstance.playbookPage.clickPlaybookOutput();
      swimInstance.playbookPage.removePromotedPlaybookOutputs(false);
      swimInstance.playbookPage.checkpromotePlaybookOutput('array');
    });

    it('Click on Remove link and click on OK  button', () => {
      swimInstance.playbookPage.removePromotedPlaybookOutputs(true);
      swimInstance.playbookPage.clickApplyCloseButton('Apply');
      swimInstance.playbookPage.savePlaybookChanges();
    });

    it('Check the radio button is diaplayed in select promoted action outputs', () => {
      swimInstance.playbookPage.clickPlaybookOutput();
      swimInstance.playbookPage.checkRadioButtonForRemovedPlaybookOutputs();
      swimInstance.playbookPage.clickApplyCloseButton('Close');
    });
  });

  after(() => {
    cy.cleanUpCypressApps();
    cy.cleanUpCypressWorkspaces();
    cy.cleanupOrchestrationTasks();
    cy.cleanupTurbine();
    swimInstance.logout();
  });
});

// @ts-check
import * as swimInstance from '../../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const namePrefix = `QAE2E_`;
const appName = `QA-E2E-${faker.company.catchPhrase()}`.substring(0, 128);
const appList = [];
const workSpaceList = [];

describe('Verification of Dynamic Orchestration - Validate Playbook Runs', () => {
  before(() => {
    cy.cleanupTurbine();
    cy.login();
    cy.cleanupOrchestrationTasks();
    cy.cleanUpCypressApps();
    cy.cleanUpCypressWorkspaces();
    swimInstance.setLoginState();
    swimInstance.loginPage.performLogin(Cypress.env('USERNAME'), Cypress.env('PASSWORD'));
  });

  describe('Verify the Playbook Runs page', () => {
    it('Checks empty Playbook Runs page', () => {
      swimInstance.openPlaybookRuns();
    });
  });

  describe('Verify Playbook Run from Runs Page', () => {
    let playbookName = `${namePrefix}http_test`;
    const uploadPlaybookJSON = {
      playbookFileName: '',
      invalidFile: false,
      forceClosure: false,
      closeMultiple: false
    };

    it('Upload Plugins and related Playbooks for testing', () => {
      swimInstance.openPlugins();
      swimInstance.pluginsPage.installPlugin();
      swimInstance.pluginsPage.pluginUploader.uploadFile([
        {
          filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
          encoding: 'base64'
        },
        {
          filePath: 'dynamic-orchestration/plugins/python37-1.0.0.plugin',
          encoding: 'base64'
        }
      ]);
      swimInstance.pluginsPage.pluginUploader.doneAddingPlugins();
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.uploadPlaybook('', null, false);
      uploadPlaybookJSON.playbookFileName = 'dynamic-orchestration/playbooks/retry-only-on-success.yml';
      swimInstance.playbookPage.playbookUploader.uploadFile(uploadPlaybookJSON);
      swimInstance.playbookPage.playbookUploader.setProperties(
        {
          title: `${namePrefix}retry_only_on_success`,
          name: `${namePrefix}retry_only_on_success`,
          description: faker.lorem.sentence()
        },
        true
      );

      swimInstance.openPlaybooks();
      swimInstance.playbookPage.uploadPlaybook('', null, false);
      uploadPlaybookJSON.playbookFileName = 'dynamic-orchestration/playbooks/http_test.yml';
      swimInstance.playbookPage.playbookUploader.uploadFile(uploadPlaybookJSON);
      swimInstance.playbookPage.playbookUploader.setProperties(
        {
          title: `${namePrefix}http_test`,
          name: `${namePrefix}http_test`,
          description: faker.lorem.sentence()
        },
        true
      );

      swimInstance.openPlaybooks();
      swimInstance.playbookPage.uploadPlaybook('', null, false);
      uploadPlaybookJSON.playbookFileName = 'dynamic-orchestration/playbooks/test_fail.yml';
      swimInstance.playbookPage.playbookUploader.uploadFile(uploadPlaybookJSON);
      swimInstance.playbookPage.playbookUploader.setProperties(
        {
          title: `${namePrefix}test_fail`,
          name: `${namePrefix}test_fail`,
          description: faker.lorem.sentence()
        },
        true
      );
    });

    it('Create Uri Asset', () => {
      swimInstance.openAssets();
      swimInstance.assetsPage.createAsset({
        assetType: 'Uri',
        assetName: `${namePrefix}Uri`,
        paramData: ['https://www.google.com', 'GET'],
        noAssets: true
      });
    });

    // SPT-13435: Hide event stream
    it.skip('Create Web Server Sensor', () => {
      const portNumber = faker.datatype.number({ min: 10000, max: 20000 });

      swimInstance.openSensors();
      swimInstance.sensorsPage.createSensor({
        sensorType: 'Web Server',
        sensorName: `${namePrefix}Web_Server`,
        paramData: [portNumber]
      });
    });

    // Test runner against playbooks is currently not working in Platform.
    describe('known playbook run bug', { tags: ['#bug', 'SPT-11027'] }, () => {
      it('Executes test run on the playbook', () => {
        swimInstance.openPlaybooks();
        swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookName, true);
      });

      it('Create new App', () => {
        swimInstance.openAppAppletsList();
        swimInstance.appsAppletsListing.startNewApp();
        swimInstance.appsAppletsListing.appWizard.setAppName(appName);
        swimInstance.appsAppletsListing.appWizard.createApp();
        appList.push(appName);
        workSpaceList.push(`${appName} Workspace`);
        swimInstance.appBuilder.verifyElements(appName);
        swimInstance.appBuilder.addField('Text');
        swimInstance.appBuilder.addField('Numeric');
        swimInstance.appBuilder.addLayout('Playbook Button');
        swimInstance.appBuilder.saveApplication();
      });

      it('Edit app to set a different task for "Playbook Button" button to use the http_test playbook', () => {
        swimInstance.openAppAppletsList();
        swimInstance.appsAppletsListing.editExistingApp(appName);
        swimInstance.appBuilder.verifyElements(appName);
        swimInstance.appBuilder.editAppComponent('Playbook Button', {
          Task: `${namePrefix}http_test_task`
        });
        swimInstance.appBuilder.saveApplication();
      });

      it('Create a new record and clicks the "Playbook Button" button for the http_test task', () => {
        swimInstance.switchToWorkspace(`${appName} Workspace`);
        swimInstance.startNewRecordForApp(appName);
        swimInstance.recordEditor.enterRandomData();
        swimInstance.recordEditor.save();
        swimInstance.recordEditor.getRecordValues();
        swimInstance.recordEditor.getRecordTrackingID(true).then($trackingID => {
          recordTrackingId = $trackingID;
        });
        swimInstance.recordEditor.clickIntegrationButton(
          'Playbook Button',
          `${namePrefix}http_test_task`,
          true,
          true,
          false
        );
      });

      it('Edit app to change task assigned for the retry_only_on_success playbook for "Playbook Button" button', () => {
        swimInstance.openAppAppletsList();
        swimInstance.appsAppletsListing.editExistingApp(appName);
        swimInstance.appBuilder.verifyElements(appName);
        swimInstance.appBuilder.editAppComponent('Playbook Button', {
          Task: `${namePrefix}retry_only_on_success_task`
        });
        swimInstance.appBuilder.saveApplication();
      });

      it('Create a new record and clicks the "Playbook Button" button for the retry_only_on_success playbook task', () => {
        swimInstance.switchToWorkspace(`${appName} Workspace`);
        swimInstance.startNewRecordForApp(appName);
        swimInstance.recordEditor.enterRandomData();
        swimInstance.recordEditor.save();
        swimInstance.recordEditor.getRecordValues();
        swimInstance.recordEditor.getRecordTrackingID(true).then($trackingID => {
          recordTrackingId = $trackingID;
        });
        swimInstance.recordEditor.clickIntegrationButton(
          'Playbook Button',
          `${namePrefix}retry_only_on_success_task`,
          true,
          true,
          false
        );
      });

      it('Deletes the http plugin to contribute to a playbook failure', () => {
        swimInstance.openPlugins();
        swimInstance.pluginsPage.deletePlugin('HTTP');
      });

      it('Edit app to change task assigned to "Playbook Button" button for use against test_fail playbook', () => {
        swimInstance.openAppAppletsList();
        swimInstance.appsAppletsListing.editExistingApp(appName);
        swimInstance.appBuilder.verifyElements(appName);
        swimInstance.appBuilder.editAppComponent('Playbook Button', {
          Task: `${namePrefix}test_fail_task`
        });
        swimInstance.appBuilder.saveApplication();
      });

      it('Create a new record and clicks the "Playbook Button" button for the test_fail playbook task', () => {
        swimInstance.switchToWorkspace(`${appName} Workspace`);
        swimInstance.startNewRecordForApp(appName);
        swimInstance.recordEditor.enterRandomData();
        swimInstance.recordEditor.save();
        swimInstance.recordEditor.getRecordValues();
        swimInstance.recordEditor.getRecordTrackingID(true).then($trackingID => {
          recordTrackingId = $trackingID;
        });
        swimInstance.recordEditor.clickIntegrationButton(
          'Playbook Button',
          `${namePrefix}test_fail_task`,
          true,
          true,
          false
        );
      });

      it('Checks the http_test playbook by clicking on its name to load the Visual Editor from the run', () => {
        swimInstance.openPlaybookRuns();
        swimInstance.playbookRunsPage.selectPlaybookRun(playbookName);
        swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookName, true);
      });

      it('Checks the run detail view can be accessed from the playbook run listed', () => {
        playbookName = `${namePrefix}http_test`;
        swimInstance.openPlaybookRuns();
        swimInstance.playbookRunsPage.selectPlaybookRun(playbookName, true);
        swimInstance.openPlaybookRuns();
        playbookName = `${namePrefix}retry_only_on_success`;
        swimInstance.playbookRunsPage.selectPlaybookRun(playbookName, true, 'active');
        swimInstance.openPlaybookRuns();
        playbookName = `${namePrefix}test_fail`;
        swimInstance.playbookRunsPage.selectPlaybookRun(playbookName, true, 'fail');
      });
    });
  });

  after(() => {
    cy.cleanUpCypressApps();
    cy.cleanUpCypressWorkspaces();
    cy.cleanupOrchestrationTasks();
    cy.cleanupTurbine();
    cy.logout();
  });
});

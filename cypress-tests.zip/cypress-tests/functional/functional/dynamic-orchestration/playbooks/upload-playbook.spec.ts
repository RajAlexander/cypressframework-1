import * as swimInstance from '../../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const playbookProperties = {
  title: `QA-E2E- ${faker.company.companyName()}`,
  name: faker.internet.domainWord(),
  description: faker.lorem.sentence()
};

const playbookPropertiesII = {
  title: `QA-E2E- ${faker.company.companyName()}`,
  name: faker.internet.domainWord(),
  description: faker.lorem.sentence()
};

let playbookDetails = {};

describe('Verification of Dynamic Orchestration - Playbook upload interface', () => {
  before(() => {
    cy.cleanupTurbine();
    cy.login();
    cy.visitSwimlane('/');
  });

  it('Navigate to Orchestration page and Verify Empty Orchestration Playbooks Page', () => {
    swimInstance.openPlaybooks();
    swimInstance.playbookPage.verifyNoPlaybooks();
  });

  it('Upload Plugins to be used for Playbooks', () => {
    swimInstance.openPlugins();
    swimInstance.pluginsPage.checkPlugin(
      {
        filePath: 'dynamic-orchestration/plugins/python37-1.0.0.plugin',
        encoding: 'base64'
      },
      'Python',
      '1.1.2'
    );
    swimInstance.pluginsPage.checkPlugin(
      {
        filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
        encoding: 'base64'
      },
      'HTTP',
      '1.0.2'
    );
  });

  describe('Add Dynamic Orchestration Playbooks through Swimlane', () => {
    describe('Verify Upload Playbook dialog', () => {
      it('Open Playbook upload dialog', () => {
        swimInstance.openPlaybooks();
        swimInstance.playbookPage.uploadPlaybook();
      });

      describe('Send playbook file', () => {
        const uploadPlaybookJSON = {
          playbookFileName: 'dynamic-orchestration/playbooks/test_playbook_yml.yml',
          invalidFile: false,
          forceClosure: false,
          closeMultiple: false
        };

        it('Upload Playbook File', () => {
          swimInstance.playbookPage.playbookUploader.uploadFile(uploadPlaybookJSON);
          swimInstance.playbookPage.playbookUploader.setProperties(playbookProperties, true);
        });

        it('Verify upload a Different Playbook', () => {
          swimInstance.openPlaybooks();
          swimInstance.playbookPage.uploadPlaybook('', null, false);
          swimInstance.playbookPage.playbookUploader.uploadFile(uploadPlaybookJSON);
        });
      });

      describe('Set Playbook Properties', () => {
        it('Set Playbook Properties', () => {
          swimInstance.playbookPage.playbookUploader.setProperties(playbookPropertiesII, false);
        });

        // The playbook property bar is not currently present, this should be added back in with the work in ST-1462
        it('Verify Playbook property bar', () => {
          swimInstance.playbookPage.playbookUploader.getpropertyBar().then($results => {
            expect($results).to.contain({
              label: playbookPropertiesII.title,
              /*type: 'PLAYBOOK',*/
              name: playbookPropertiesII.name
            });
            playbookDetails = $results;
          });
        });
      });

      describe('Verify the Playbook details', () => {
        it('Open Playbook details', () => {
          swimInstance.playbookPage.playbookUploader.openDetails();
        });

        it('View Playbook details', () => {
          swimInstance.playbookPage.playbookUploader.playbookDetails.getPlaybookOverview();
          swimInstance.playbookPage.playbookUploader.playbookDetails.getPluginsUsed().then($pluginsList => {
            expect($pluginsList).to.deep.equal({
              danger: [],
              good: ['HTTP']
            });
          });
        });

        it('Close Playbook details', () => {
          swimInstance.playbookPage.playbookUploader.playbookDetails.close();
        });
      });

      describe('Submit a Playbook', () => {
        it('Submit Playbook', () => {
          swimInstance.playbookPage.playbookUploader.submit();
        });
      });

      describe('Update a Playbook', () => {
        it('Verify Update Playbook Title and Description', () => {
          swimInstance.openPlaybooks();
          swimInstance.playbookPage.updatePlaybook(playbookProperties.title);
        });
      });

      describe('Upload another Playbook and Preview Playbook Details', () => {
        it('Upload a Playbook and Validate Details without Submitting', () => {
          const playbookTitle = 'chained_repeats';
          const pluginTitle = 'Python 3.7';

          swimInstance.playbookPage.uploadPlaybook('dynamic-orchestration/playbooks/chained-repeats.yml', null, false);
          swimInstance.playbookPage.verifyPlaybookDetailsUponUpload(playbookTitle, pluginTitle);
          swimInstance.playbookPage.playbookUploader.playbookDetails.close();
          swimInstance.playbookPage.playbookUploader.close();
        });
      });
    });

    describe('Upload invalid Playbook files', () => {
      const uploadInvalidFileJSON = {
        playbookFileName: 'example.json',
        invalidFile: true,
        forceClosure: true,
        closeMultiple: true
      };

      before(() => {
        swimInstance.playbookPage.uploadPlaybook('', null, false);
      });

      it('JSON file', () => {
        swimInstance.playbookPage.playbookUploader.uploadFile(uploadInvalidFileJSON);
      });

      it('PNG file', () => {
        uploadInvalidFileJSON.playbookFileName = 'img/original-icon.png';
        swimInstance.playbookPage.playbookUploader.uploadFile(uploadInvalidFileJSON);
      });

      it('swimbundle file', () => {
        uploadInvalidFileJSON.playbookFileName = 'bundles/sw_amazon_web_services-2.2.0-linux.python36.swimbundle';
        swimInstance.playbookPage.playbookUploader.uploadFile(uploadInvalidFileJSON);
      });

      it('Missing name in Playbook file', () => {
        uploadInvalidFileJSON.playbookFileName = 'dynamic-orchestration/playbooks/noname_playbook_yml.yaml';
        swimInstance.playbookPage.playbookUploader.uploadFile(uploadInvalidFileJSON);
      });

      it('Missing actions in Playbook file', () => {
        uploadInvalidFileJSON.playbookFileName = 'dynamic-orchestration/playbooks/noactions_playbook_yml.yaml';
        swimInstance.playbookPage.playbookUploader.uploadFile(uploadInvalidFileJSON);
      });

      it('Missing schema in Playbook file', () => {
        uploadInvalidFileJSON.playbookFileName = 'dynamic-orchestration/playbooks/noschema_playbook_yml.yaml';
        swimInstance.playbookPage.playbookUploader.uploadFile(uploadInvalidFileJSON);
      });

      after(() => {
        swimInstance.playbookPage.playbookUploader.close();
      });
    });

    describe('Verify duplicate name not allowed', () => {
      it('Open Playbook upload dialog', () => {
        swimInstance.playbookPage.uploadPlaybook('dynamic-orchestration/playbooks/test_playbook_yml.yml', null, false);
        swimInstance.playbookPage.playbookUploader.setProperties(playbookProperties);
        swimInstance.playbookPage.playbookUploader.validateIfDupePlaybookName(true);
      });
    });
  });

  after(() => {
    cy.cleanupTurbine();
    cy.logout();
  });
});

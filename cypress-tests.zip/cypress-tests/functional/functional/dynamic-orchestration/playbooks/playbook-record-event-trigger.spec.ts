import * as swimInstance from '../../../support/page-objects/swimInstance';

const playbookName = `QAE2E_Merlin_Use_Case`;
const playbookTitle = `QAE2E_testing`;
const playbookDesc = `QAE2E_Testing`;
const appName = `QAE2E_Merlin`;

describe('Verify Dinamic Orchestration env', () => {
  before(() => {
    cy.cleanupTurbine();
    swimInstance.setLoginState();
    swimInstance.loginPage.performLogin(Cypress.env('USERNAME'), Cypress.env('PASSWORD'));
  });

  describe('Create Application', () => {
    it('Create new App', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
    });

    it('Build fields into App', () => {
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.addField('Text');
    });

    it('Save the App', () => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Playbook creation', () => {
    it('Create a Playbook', () => {
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.createPlaybook({
        playbookName,
        playbookTitle,
        playbookDescription: playbookDesc
      });
    });

    it('Create and config a Record Event Trigger', () => {
      swimInstance.playbookPage.createRecordEventTrigger();
      swimInstance.playbookPage.recordEventTriggerConfigMenu(appName, 'Created/Updated');
      swimInstance.playbookPage.nodeValidatorRecordEventTrigger(appName, 'Created/Updated');
      swimInstance.playbookPage.inputsRecordEventTrigger('String');
      swimInstance.playbookPage.mapInputsRecordEventTrigger('String', 'Text');
      swimInstance.playbookPage.copyNodeRecordEventTrigger(appName, 'Created/Updated', 0);
      swimInstance.playbookPage.deleteNodeRecordEventTrigger(1);
      swimInstance.playbookPage.savePlaybookChanges();
      swimInstance.OpenAppListAll;
    });
  });

  describe('Cleanup outside orchestration', () => {
    it('Remove Application', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.deleteExistingApp(appName);
    });
    it('Remove workspace', () => {
      swimInstance.openWorkspaceList();
      swimInstance.workspacesListing.deleteWorkspace(`${appName} Workspace`);
    });
  });

  after(() => {
    cy.cleanupTurbine();
    swimInstance.logout();
  });
});

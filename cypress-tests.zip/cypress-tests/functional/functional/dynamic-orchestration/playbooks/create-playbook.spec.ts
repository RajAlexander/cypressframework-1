// @ts-check
import * as swimInstance from '../../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const postAssetName = `QAE2E_`;
const postSensorName = `QAE2E_`;
const postPlaybookName = `QAE2E_`;
let playbookNameForActions = '';

describe('Verification of Dynamic Orchestration - Create Working Playbooks', () => {
  before(() => {
    cy.cleanupTurbine();
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Create Playbook Manually through the UI', () => {
    it('Upload Plugin to create Asset and Sensor', () => {
      // Upload HTTP Plugin
        swimInstance.openPlugins();
  
        //it will check for plugin exists
        swimInstance.pluginsPage.checkPlugin(
          {
            filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
            encoding: 'base64'
          },
          'HTTP',
          '1.0.2'
        );
      });

    it('Create Uri Asset', () => {
      // Create URI Asset
      swimInstance.openAssets();
      swimInstance.assetsPage.createAsset({
        assetType: 'Uri',
        assetName: `${postAssetName}Uri`,
        paramData: ['https://www.google.com', 'GET'],
        noAssets: true
      });
    });

    // SPT-13435: Hide event stream
    it.skip('Create Web Server Sensor', () => {
      // Define port number for URI sensor
      const portNumber = faker.datatype.number({ min: 10000, max: 20000 });

      // Create URI Web Sensor
      swimInstance.openSensors();
      swimInstance.sensorsPage.createSensor({
        sensorType: 'Web Server',
        sensorName: `${postSensorName}Web Server`,
        paramData: [portNumber]
      });
    });

    it('Create a Playbook and Add Trigger and Action', () => {
      const playbookTitle = `${postPlaybookName}${faker.company.companyName()}`;
      const playbookName = `${postAssetName}${faker.random.word().replace('-', '')}`;
      const actionName = 'QA-E2E-' + faker.company.companyName();
      // Assign this playbook name to playbookNameForActions for use in later tests
      playbookNameForActions = playbookName;

      // Create a new playbook
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.createPlaybook({
        playbookName,
        playbookTitle,
        playbookDescription: faker.lorem.sentence()
      });

      // Open created playbook to access visual editor
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookTitle);

      // Add triggers on the playbook
      // SPT-13435: Hide event stream
      /*const sensorName = `${postSensorName}WebServer`;
      swimInstance.playbookPage.addPlaybookTrigger(sensorName);*/

      // Add actions to the playbook
      swimInstance.playbookPage.addPlaybookAction(actionName, 'Send an http payload');

      // Save Playbook changes
      swimInstance.playbookPage.savePlaybookChanges();
    });

    it('SPT-12917: Create a Playbook and an Action with specific name format', () => {
      const playbookTitle = `${postPlaybookName}${faker.company.companyName()}`;
      const playbookName = `${postAssetName}${faker.random.word().replace('-', '')}`;
      const actionName = 'QA-E2E-' + faker.company.companyName();

      // Create a new playbook
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.createPlaybook({
        playbookName,
        playbookTitle,
        playbookDescription: faker.lorem.sentence()
      });

      // Open created playbook to access visual editor
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookTitle);

      // Add actions to the playbook
      swimInstance.playbookPage.addPlaybookAction(actionName, playbookNameForActions);

      // Save Playbook changes
      swimInstance.playbookPage.savePlaybookChanges();
    });

    it('SPT-11617: Create a Playbook and verify Actions with the same name are not removed', () => {
      const playbookTitle = `${postPlaybookName}${faker.company.companyName()}`;
      const playbookName = `${postAssetName}${faker.random.word().replace('-', '')}`;

      // Create a new playbook
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.createPlaybook({
        playbookName,
        playbookTitle,
        playbookDescription: faker.lorem.sentence()
      });

      // Open created playbook to access visual editor
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookTitle);

      // Add actions with the same name to the playbook
      const actionName = faker.lorem.word();
      swimInstance.playbookPage.addPlaybookAction(actionName, playbookNameForActions);
      swimInstance.playbookPage.addPlaybookAction(actionName, playbookNameForActions);

      // Action name invalid
      swimInstance.playbookPage.verifyPlaybookFormError(true);

      // Validate there are still two nodes
      swimInstance.playbookPage.verifyNodeCount(2);

      // Change action name and verify
      swimInstance.playbookPage.editPlaybookActionName(actionName, faker.lorem.word());
      swimInstance.playbookPage.verifyPlaybookFormError(false);

      // Save Playbook changes
      swimInstance.playbookPage.savePlaybookChanges();
    });

    it('SPT-13165: Create a Playbook and verify lock icon', () => {
      const playbookTitle = `${postPlaybookName}${faker.company.companyName()}`;
      const playbookName = `${postAssetName}${faker.random.word().replace('-', '')}`;

      // Create a new playbook
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.createPlaybook({
        playbookName,
        playbookTitle,
        playbookDescription: faker.lorem.sentence()
      });

      // Open created playbook to access visual editor
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookTitle);

      // Add action #1
      const actionName1 = faker.lorem.word();
      swimInstance.playbookPage.addPlaybookAction(actionName1, playbookNameForActions);
      // Change title for action #1 and check that lock icon exists
      const newTitle1 = faker.lorem.word();
      swimInstance.playbookPage.editPlaybookActionTitle(actionName1, newTitle1);
      swimInstance.playbookPage.verifyActionNameLockIcon(true);

      // Add action #2 and check that lock icon exists
      const actionName2 = faker.lorem.word();
      swimInstance.playbookPage.addPlaybookAction(actionName2, playbookNameForActions);
      swimInstance.playbookPage.verifyActionNameLockIcon(true);

      // Rename action #1 and check that lock icon not exists
      const newName1 = faker.lorem.word();
      swimInstance.playbookPage.editPlaybookActionName(newTitle1, newName1);
      swimInstance.playbookPage.verifyActionNameLockIcon(false);

      // Select action #2 and check that icon exists
      swimInstance.playbookPage.findSpecificAction(actionName2);
      swimInstance.playbookPage.verifyActionNameLockIcon(true);
      // Select action #1 and check that icon not exists (verifies that the state per action persist)
      swimInstance.playbookPage.findSpecificAction(newName1);
      swimInstance.playbookPage.verifyActionNameLockIcon(false);

      // Add action #3
      const actionName3 = faker.lorem.word();
      swimInstance.playbookPage.addPlaybookAction(actionName3, playbookNameForActions);
      swimInstance.playbookPage.verifyActionNameLockIcon(true);

      // Check if the lock icon exists for all actions (when a new action is created or an action is deleted
      // the lock will be restored for all actions)
      swimInstance.playbookPage.findSpecificAction(newName1);
      swimInstance.playbookPage.verifyActionNameLockIcon(true);
      swimInstance.playbookPage.findSpecificAction(actionName2);
      swimInstance.playbookPage.verifyActionNameLockIcon(true);

      // Save Playbook changes
      swimInstance.playbookPage.savePlaybookChanges();
    });

    it("SPT-13643: Create a Playbook and verify that the action's name is updated automatically from title when the action is new and the lock icon was not removed", () => {
      const playbookTitle = `${postPlaybookName}${faker.company.companyName()}`;
      const playbookName = `${postAssetName}${faker.random.word().replace('-', '')}`;

      // Create a new playbook
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.createPlaybook({
        playbookName,
        playbookTitle,
        playbookDescription: faker.lorem.sentence()
      });

      // Open created playbook to access visual editor
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookTitle);

      // Add action #1
      const actionTitle1 = faker.lorem.word();
      swimInstance.playbookPage.addPlaybookAction(actionTitle1, playbookNameForActions);
      // Verify that name is equal to title because it is a new action and lock icon exists
      swimInstance.playbookPage.verifyActionTitleText(actionTitle1);
      swimInstance.playbookPage.verifyActionNameText(actionTitle1);

      // Add action #2
      const actionTitle2 = faker.lorem.word();
      swimInstance.playbookPage.addPlaybookAction(actionTitle2, playbookNameForActions);
      // Verify that name is equal to title because it is a new action and lock icon exists
      swimInstance.playbookPage.verifyActionTitleText(actionTitle2);
      swimInstance.playbookPage.verifyActionNameText(actionTitle2);

      // Change title for action #1
      const newActionTitle1 = faker.lorem.word();
      swimInstance.playbookPage.editPlaybookActionTitle(actionTitle1, newActionTitle1);
      // Verify that name is equal to title because it is a new action and lock icon exists
      swimInstance.playbookPage.verifyActionTitleText(newActionTitle1);
      swimInstance.playbookPage.verifyActionNameText(newActionTitle1);

      // Change title for action #2
      const newActionTitle2 = faker.lorem.word();
      swimInstance.playbookPage.editPlaybookActionTitle(actionTitle2, newActionTitle2);
      // Verify that name is equal to title because it is a new action and lock icon exists
      swimInstance.playbookPage.verifyActionTitleText(newActionTitle2);
      swimInstance.playbookPage.verifyActionNameText(newActionTitle2);

      // Change name for action #2
      const newActionName2 = faker.lorem.word();
      // This removes the lock icon
      swimInstance.playbookPage.editPlaybookActionName(newActionTitle2, newActionName2);
      // Verify that name is not equal to title because lock icon not exists
      swimInstance.playbookPage.verifyActionTitleText(newActionTitle2);
      swimInstance.playbookPage.verifyActionNameText(newActionName2);

      // Save Playbook changes
      swimInstance.playbookPage.savePlaybookChanges();

      // Change title for action #1 - after save
      const newActionTitle3 = faker.lorem.word();
      swimInstance.playbookPage.editPlaybookActionTitle(newActionTitle1, newActionTitle3);
      // Verify that name is not equal to title because the action is not new (saved in the above steps)
      // even the lock icon exists
      swimInstance.playbookPage.verifyActionTitleText(newActionTitle3);
      swimInstance.playbookPage.verifyActionNameText(newActionTitle1);

      // Add action #3
      const actionTitle3 = faker.lorem.word();
      swimInstance.playbookPage.addPlaybookAction(actionTitle3, playbookNameForActions);
      // Verify that name is equal to title because it is a new action and lock icon exists
      swimInstance.playbookPage.verifyActionTitleText(actionTitle3);
      swimInstance.playbookPage.verifyActionNameText(actionTitle3);

      // Save Playbook changes
      swimInstance.playbookPage.savePlaybookChanges();
    });
  });

  after(() => {
    cy.cleanupTurbine();
    cy.logout();
  });
});

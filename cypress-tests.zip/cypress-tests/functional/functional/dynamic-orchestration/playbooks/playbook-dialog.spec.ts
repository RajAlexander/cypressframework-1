import * as swimInstance from '../../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const postPlaybookName = `QAE2E_`;
const actionName = 'Send an http payload';
const action = 'Send an http pa...';
const actionInput = faker.lorem.sentence();
const close = 'Close';
const apply = 'Apply';
const cancel = 'Cancel';
const discard = 'Discard';
const outputsMenu = 'Outputs';
const expression = ' Expression ';
const actionNewTitle = 'Action New Name';
const actionNewName = 'Action_New_Name';
const expressionCheckOne = 'Send_an_http_payload.result';
const expressionText = '$event.data.body.user';
const playbookName = `${postPlaybookName}${faker.random.word().replace(/[^a-zA-Z0-9_]/g, '')}`;

describe('Verification of Dynamic Orchestration - Action Dialog working', () => {
  before(() => {
    cy.cleanupTurbine();
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Create Playbook Manually and add inputs and outputs', () => {
    it('Upload Plugin to use it in the playbook', () => {
      // Upload HTTP Plugin
      swimInstance.openPlugins();

      // it will check for plugin exists
      swimInstance.pluginsPage.checkPlugin(
        {
          filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
          encoding: 'base64'
        },
        'HTTP',
        '1.0.2'
      );
    });

    it('Create a new playbook', () => {
      const playbookTitle = `${postPlaybookName}${faker.company.companyName()}`;

      // Create a new playbook
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.createPlaybook({
        playbookName,
        playbookTitle,
        playbookDescription: faker.lorem.sentence()
      });

      // Add actions to the playbook
      swimInstance.playbookPage.addPlaybookActionfromPlugin(actionName);

      // Save Playbook changes
      swimInstance.playbookPage.savePlaybookChanges();
    });

    it('Open the action and create inputs', () => {
      // Open the playbook page
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.findSpecificPlaybook(playbookName);
      swimInstance.playbookPage.findSpecificAction(action);

      // open the dialog with the inputs
      swimInstance.playbookPage.openDialog(actionName);
      swimInstance.playbookPage.findInput(0, actionInput);

      // Checking close/cancel button
      swimInstance.playbookPage.clickApplyCloseButton(cancel);
      swimInstance.playbookPage.changesDialog(close);

      // ADding inputs to the dialog
      swimInstance.playbookPage.findInput(1, actionInput);
      swimInstance.playbookPage.selectPlaybookActionInputOption('Body', expression);

      // Adding the expression to the dialog
      swimInstance.playbookPage.expressionDialog(expressionText);
      swimInstance.playbookPage.clickApplyCloseButton(apply);

      // Save
      swimInstance.playbookPage.savePlaybookChanges();
    });

    it('Reopen the action and check that the inputs where preserved', () => {
      // Reopen the dialog
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.findSpecificPlaybook(playbookName);
      swimInstance.playbookPage.findSpecificAction(action);
      swimInstance.playbookPage.openDialog(actionName);

      // checking the inputs are saved correctly and they are still shown.
      swimInstance.playbookPage.checkInputs(0, actionInput);
      swimInstance.playbookPage.checkInputs(1, actionInput);

      // Save
      swimInstance.playbookPage.clickApplyCloseButton(close);
    });

    it('Open the action and promote outputs', () => {
      // open the playbook to promote some outputs
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.findSpecificPlaybook(playbookName);
      swimInstance.playbookPage.findSpecificAction(action);
      swimInstance.playbookPage.openDialog(actionName);
      swimInstance.playbookPage.moveintoTabs(outputsMenu);

      // Checking the outputs page
      swimInstance.playbookPage.checkPromotedMessage();
      swimInstance.playbookPage.checkRootProperty();
      swimInstance.playbookPage.promoteOutput('result');
      swimInstance.playbookPage.checkPromoted('result');
      swimInstance.playbookPage.promotedOutputs();
      swimInstance.playbookPage.clickApplyCloseButton(apply);

      // Save
      swimInstance.playbookPage.savePlaybookChanges();
    });

    it('Reopen the action, validate and remove the promoted output', () => {
      // Reopen the playbook and check that the outputs where saved successfully
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.findSpecificPlaybook(playbookName);
      swimInstance.playbookPage.findSpecificAction(action);
      swimInstance.playbookPage.openDialog(actionName);
      swimInstance.playbookPage.moveintoTabs(outputsMenu);
      swimInstance.playbookPage.promotedOutputs();

      // Checking to remove the output
      swimInstance.playbookPage.removePromoted();
      swimInstance.playbookPage.checkPromotedMessage();
      swimInstance.playbookPage.clickApplyCloseButton(cancel);
      swimInstance.playbookPage.changesDialog(discard);
      swimInstance.playbookPage.findSpecificAction(action);
      swimInstance.playbookPage.openDialog(actionName);
      swimInstance.playbookPage.moveintoTabs(outputsMenu);
      swimInstance.playbookPage.promotedOutputs();
      swimInstance.playbookPage.removePromoted();
      swimInstance.playbookPage.clickApplyCloseButton(apply);

      // Save
      swimInstance.playbookPage.savePlaybookChanges();
    });

    it('Create another action to test playbook property', () => {
      // Reopen the playbook and add another action to check the playbook property
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.findSpecificPlaybook(playbookName);
      swimInstance.playbookPage.findSpecificAction(action);
      swimInstance.playbookPage.addPlaybookAction(actionNewName, 'Send an http payload');
      swimInstance.playbookPage.selectActionType();
      swimInstance.playbookPage.changeActionName(actionNewName, actionNewTitle);

      // Save
      swimInstance.playbookPage.savePlaybookChanges();
    });

    it('Open the second action and use the playbook property input type', () => {
      // Open the playbook with the new action and check itt
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.findSpecificPlaybook(playbookName);
      swimInstance.playbookPage.findSpecificAction(actionNewTitle);
      swimInstance.playbookPage.clickAdditionalConfiguration();
      swimInstance.playbookPage.selectPlaybookActionInputOption('Headers', 'Expression');
      swimInstance.playbookPage.clickPlaybookInput('Headers');
      swimInstance.playbookPage.enterExpression(expressionCheckOne);
      swimInstance.playbookPage.clickApplyCloseButton(apply);

      // Save
      swimInstance.playbookPage.savePlaybookChanges();
    });

    it('Reopen the second action and check the playbook property input type', () => {
      // Open the playbook with the new action and check it was saved correctly
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.findSpecificPlaybook(playbookName);
      swimInstance.playbookPage.findSpecificAction(actionNewTitle);
      swimInstance.playbookPage.clickAdditionalConfiguration();
      swimInstance.playbookPage.checkExpression('Headers', expressionCheckOne);
      swimInstance.playbookPage.clickApplyCloseButton(apply);
    });

    it('Promote an output in the first action and check it is not shown in the second action', () => {
      // Open the playbook with the new action and check it was saved correctly
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.findSpecificPlaybook(playbookName);
      swimInstance.playbookPage.findSpecificAction(action);
      swimInstance.playbookPage.openDialog(actionName);
      swimInstance.playbookPage.moveintoTabs(outputsMenu);
      swimInstance.playbookPage.promoteOutput('result');
      swimInstance.playbookPage.clickApplyCloseButton(apply);
      swimInstance.playbookPage.savePlaybookChanges();
      swimInstance.playbookPage.findSpecificAction(actionNewTitle);
      swimInstance.playbookPage.clickAdditionalConfiguration();

      // Check the playbook property information was saved correctly
      swimInstance.playbookPage.selectPlaybookActionInputOption('Headers', 'Playbook property');
      swimInstance.playbookPage.clickPlaybookInput('Headers');
      swimInstance.playbookPage.checkQtyCardsOnDrawer(1);
      swimInstance.playbookPage.dismissDrawer();

      swimInstance.playbookPage.clickApplyCloseButton(apply);

      // Save
      swimInstance.playbookPage.savePlaybookChanges();
    });
  });

  after(() => {
    cy.cleanupTurbine();
    cy.logout();
  });
});

import * as swimInstance from '../../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const postPlaybookName = `QAE2E_`;
const actionName = 'Send an http payload';
const action = 'Send an http pa...';
const apply = 'Apply';
const httpMethodInput = 'https';
const URIInput = 'https://swimlane.com';
const actionNewTitle = 'Action Parent';
const actionParentNewName = 'Action_Parent';
const actionChildNewTitle = 'Action Child';
const actionChildNewName = 'Action_Child';
const playbookName = `${postPlaybookName}${faker.random.word().replace('-', '')}`;

describe('Verification of Dynamic Orchestration - Action Dialog working', () => {
  before(() => {
    cy.cleanupTurbine();
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Create Playbook Manually and use the condition buider', () => {
    it('Upload Plugin to use it in the playbook', () => {
      // Upload HTTP Plugin
      swimInstance.openPlugins();
  
      //Will ignore the plugin upload if already exists
      swimInstance.pluginsPage.checkPlugin(
        {
          filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
          encoding: 'base64'
        },
        'HTTP',
        '1.0.2'
      );
    });

    it('Create a new playbook', () => {
      const playbookTitle = `${postPlaybookName}${faker.company.companyName()}`;

      // Create a new playbook
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.createPlaybook({
        playbookName,
        playbookTitle,
        playbookDescription: faker.lorem.sentence()
      });

      // Add actions to the playbook
      swimInstance.playbookPage.addPlaybookActionfromPlugin(actionName);

      // Save Playbook changes
      swimInstance.playbookPage.savePlaybookChanges();

      swimInstance.playbookPage.findSpecificAction(action);
      swimInstance.playbookPage.openDialog(actionName);
      swimInstance.playbookPage.findInput(0, httpMethodInput);
      swimInstance.playbookPage.findInput(1, URIInput);

      swimInstance.playbookPage.clickApplyCloseButton(apply);
      swimInstance.playbookPage.savePlaybookChanges();
    });

    // SPT-13999
    xit('Create another action to test playbook property', () => {
      // Reopen the playbook and add another action to check the playbook property
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.findSpecificPlaybook(playbookName);
      swimInstance.playbookPage.findSpecificAction(action);
      swimInstance.playbookPage.recenterPlaybookView();
      swimInstance.playbookPage.addChildAction('success', 'new_action');
      swimInstance.playbookPage.findSpecificAction('new_action');
      swimInstance.playbookPage.selectActionInformation(actionName);
      swimInstance.playbookPage.changeActionName(actionChildNewName, actionChildNewTitle);

      // Save
      swimInstance.playbookPage.savePlaybookChanges();
    });

    // SPT-13999
    xit('Add a condition between the two actions', () => {
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.findSpecificPlaybook(playbookName);
      swimInstance.playbookPage.findSpecificAction(action);

      swimInstance.playbookPage.changeActionName(actionParentNewName, actionNewTitle);

      // Save
      swimInstance.playbookPage.savePlaybookChanges();

      // find the link between two actions and create the condition
      swimInstance.playbookPage.findlink(actionParentNewName, actionChildNewName);
      swimInstance.playbookPage.addConditionLine();
      swimInstance.playbookPage.checkConditionBuilder();
      swimInstance.playbookPage.addNewConditionPlus();
      swimInstance.playbookPage.selectPlaybookProperty('Action Parent', 'Status Code');
      swimInstance.playbookPage.modifycondition('200');
      swimInstance.playbookPage.clickApplyCloseButton(apply);

      // Save
      swimInstance.playbookPage.savePlaybookChanges();
    });

    // SPT-13999
    xit('Execute action to fail the execution', () => {
      // Execute the condition via test page
      swimInstance.playbookPage.openRun('fail', false);
      swimInstance.playbookPage.closeRun();
    });

    // SPT-13999
    xit('Execute action to success the execution with two actions', () => {
      swimInstance.playbookPage.findSpecificAction(actionChildNewTitle);
      swimInstance.playbookPage.openDialog(actionChildNewTitle);
      swimInstance.playbookPage.findInput(0, httpMethodInput);
      swimInstance.playbookPage.findInput(1, URIInput);
      swimInstance.playbookPage.clickApplyCloseButton(apply);
      swimInstance.playbookPage.savePlaybookChanges();
      swimInstance.playbookPage.findlink();
      swimInstance.playbookPage.clickEdtiCondition();
      swimInstance.playbookPage.modifycondition('200');
      swimInstance.playbookPage.clickApplyCloseButton(apply);
      swimInstance.playbookPage.openRun('success', true);
      swimInstance.playbookPage.closeRun();
    });

    // SPT-13999
    xit('Modify the condition to Execute action to success the execution but doesnt meet the condition', () => {
      swimInstance.playbookPage.findlink();
      swimInstance.playbookPage.clickEdtiCondition();
      swimInstance.playbookPage.modifycondition('1');
      swimInstance.playbookPage.clickApplyCloseButton(apply);
      swimInstance.playbookPage.savePlaybookChanges();
      swimInstance.playbookPage.openRun('success', false);

      swimInstance.playbookPage.closeRun();
    });
  });

  after(() => {
    cy.cleanupTurbine();
    cy.logout();
  });
});

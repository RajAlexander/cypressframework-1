// @ts-check
import * as swimInstance from '../../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const postAssetName = `QAE2E_`;
const postSensorName = `QAE2E_`;
const postPlaybookName = `QAE2E_`;
let playbookNameForActions = '';

describe('Verification of Dynamic Orchestration - Create Playbooks Actions', () => {
  before(() => {
    cy.cleanupTurbine();
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Create Playbook Manually through the UI', () => {
    it('Upload Plugin to create Asset and Event Streams', () => {
      // Upload HTTP Plugin
      swimInstance.openPlugins();
  
      //it will check for plugin exists
      swimInstance.pluginsPage.checkPlugin(
        {
          filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
          encoding: 'base64'
        },
        'HTTP',
        '1.0.2'
      );
    });

    it('Create Uri Asset', () => {
      // Create URI Asset
      swimInstance.openAssets();
      swimInstance.assetsPage.createAsset({
        assetType: 'Uri',
        assetName: `${postAssetName}Uri`,
        paramData: ['https://www.google.com', 'GET'],
        noAssets: true
      });
    });

    // SPT-13435: Hide event stream
    it.skip('Create Web Server Event Streams', () => {
      // Define port number for URI sensor
      const portNumber = faker.datatype.number({ min: 10000, max: 20000 });

      // Create URI Web Event Streams
      swimInstance.openSensors();
      swimInstance.sensorsPage.createSensor({
        sensorType: 'Web Server',
        sensorName: `${postSensorName}Web Server`,
        paramData: [portNumber]
      });
    });
  });

  describe('Create a Playbook and Add Trigger, Playbook Inputs and an Action, then map the Playbook Input to an Action Input', () => {
    const playbookTitle = `${postPlaybookName}${faker.company.companyName()}`;
    const playbookName = `${postPlaybookName}${faker.random.word().replace('-', '')}`;
    const actionName = 'QA-E2E-' + faker.company.companyName();
    // Assign this playbook name to playbookNameForActions for use in later tests
    playbookNameForActions = playbookName;

    it('Create a new Playbook', () => {
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.createPlaybook({
        playbookName,
        playbookTitle,
        playbookDescription: faker.lorem.sentence()
      });
    });

    it('Add inputs to the Playbook', () => {
      // Open created playbook to access visual editor
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookTitle);

      // Add triggers on the playbook
      // SPT-13435: Hide event stream
      /*const sensorName = `${postSensorName}WebServer`;
      swimInstance.playbookPage.addPlaybookTrigger(sensorName);*/

      // Add Inputs to the playbook
      swimInstance.playbookPage.addPlaybookInput({
        playbookInputName: 'String Input',
        playbookInputType: 'String',
        playbookInputDescription: 'QA-E2E-Playbook Input',
        min: 1,
        max: 100
      });
    });

    it('Add actions to the playbook', () => {
      swimInstance.playbookPage.addPlaybookAction(actionName, 'Send an http payload');
      swimInstance.playbookPage.clickAdditionalConfiguration();
      swimInstance.playbookPage.selectPlaybookActionInputOption('HTTP Method', 'Playbook property');
      swimInstance.playbookPage.clickPlaybookInput('HTTP Method');
      swimInstance.playbookPage.selectPlaybookProperty('Playbook Inputs', 'String Input');
      swimInstance.playbookPage.clickApplyCloseButton('Apply');

      // Save Playbook changes
      swimInstance.playbookPage.savePlaybookChanges();
    });
  });

  describe('Create a Playbook and add Trigger and an Action, then create a Playbook Input within the Action Additional Configuration', () => {
    const playbookTitle = `${postPlaybookName}${faker.company.companyName()}`;
    const playbookName = `${postPlaybookName}${faker.random.word().replace('-', '')}`;
    const actionName = 'QA-E2E-' + faker.company.companyName();

    it('Create a new Playbook', () => {
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.createPlaybook({
        playbookName,
        playbookTitle,
        playbookDescription: faker.lorem.sentence()
      });
    });

    it('Add an action to the playbook and add a Playbook input within the Action Inputs dialog', () => {
      // Open created playbook to access visual editor
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookTitle);
      swimInstance.playbookPage.addPlaybookAction(actionName, playbookNameForActions);
      swimInstance.playbookPage.clickAdditionalConfiguration();
      swimInstance.playbookPage.selectPlaybookActionInputOption('String Input', 'Playbook property');
      swimInstance.playbookPage.addPlaybookInputInline({
        playbookInputName: 'String Input 1',
        playbookInputType: 'String',
        playbookInputDescription: 'QA-E2E-Inline Playbook Input'
      });
      // SPT-13435: Hide event stream
      /*swimInstance.playbookPage.clickAdditionalConfiguration();
      swimInstance.playbookPage.selectOption(0, 'Playbook property');
      swimInstance.playbookPage.clickPlaybookInput(0);
      swimInstance.playbookPage.selectPlaybookProperty(1, 0);
      swimInstance.playbookPage.clickApplyCloseButton('Apply');*/

      // Save playbook changes
      swimInstance.playbookPage.savePlaybookChanges();
    });
  });

  describe('Modify a Playbook Input that is used as an Action Input', () => {
    it('Modify playbook input and verify warning message on playbook save', () => {
      swimInstance.playbookPage.modifyPlaybookInput('String Input', {
        playbookInputName: 'String Input Modified',
        playbookInputType: 'String',
        playbookInputDescription: 'QA-E2E-Playbook Input that has been modified'
      });
    });

    it('Remove a Playbook Input that is used as an Action Input', () => {
      // Remove playbook input and verify warning message on playbook save
      swimInstance.playbookPage.removePlaybookInput('String Input Modified');

      // Save playbook changes
      swimInstance.playbookPage.savePlaybookChanges();
    });
  });

  describe('Create a Playbook and check the Is Entry Point status', () => {
    const playbookTitle = `${postPlaybookName}${faker.company.companyName()}`;
    const playbookName = `${postPlaybookName}${faker.random.word().replace('-', '')}`;
    const actionTitle1 = 'QA-E2E-action1';
    const actionTitle2 = 'QA-E2E-action2';
    const actionName1 = 'QAE2Eaction1';
    const actionName2 = 'QAE2Eaction2';
    const duplicateActionTitle1 = 'QA-E2E-dupeaction1';
    const duplicateActionTitle2 = 'QA-E2E-dupeaction2';
    const duplicateActionName1 = 'QAE2E_dupeaction1';
    const duplicateActionName2 = 'QAE2E_dupeaction2';

    it('Create a new playbook', () => {
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.createPlaybook({
        playbookName,
        playbookTitle,
        playbookDescription: faker.lorem.sentence()
      });
    });

    it('Check if entry point is on when creating a new root action', () => {
      // Open created playbook to access visual editor
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookTitle);

      // Add actions to the playbook. Action #1
      swimInstance.playbookPage.addPlaybookAction(actionTitle1, playbookNameForActions);
      swimInstance.playbookPage.savePlaybookChanges();

      // Check if entry point is on when creating a new root action
      swimInstance.playbookPage.findSpecificAction(actionTitle1);
      swimInstance.playbookPage.openAdvancedSettings();
      swimInstance.playbookPage.checkEntryPoint(true);
    });

    it('Add a non-root action and Check if entry point is off. Action #2', () => {
      swimInstance.playbookPage.addChildAction('success', actionName2);
      swimInstance.playbookPage.changeActionName(actionName2, actionTitle2);
      swimInstance.playbookPage.selectActionType();
      swimInstance.playbookPage.recenterPlaybookView();
      swimInstance.playbookPage.savePlaybookChanges();
      swimInstance.playbookPage.openAdvancedSettings();
      swimInstance.playbookPage.checkEntryPoint(false);
    });

    it('Duplicate the Action #1 action and check if entry point is ON (inheriting value from base action)', () => {
      swimInstance.playbookPage.duplicateAction(actionName1, actionTitle1, duplicateActionName1, duplicateActionTitle1);
      swimInstance.playbookPage.savePlaybookChanges();
      swimInstance.playbookPage.openAdvancedSettings();
      swimInstance.playbookPage.checkEntryPoint(true);
    });

    it('Duplicate the Action #2 and check if entry point is OFF (inheriting value from base action)', () => {
      swimInstance.playbookPage.duplicateAction(actionName2, actionTitle2, duplicateActionName2, duplicateActionTitle2);
      swimInstance.playbookPage.savePlaybookChanges();
      swimInstance.playbookPage.openAdvancedSettings();
      swimInstance.playbookPage.checkEntryPoint(false);
    });
  });

  // Un-skip when plugins were removed
  describe.skip('Create a Playbook and check the Pool options', () => {
    const playbookTitle = `${postPlaybookName}${faker.company.companyName()}`;
    const playbookName = `${postPlaybookName}${faker.random.word().replace('-', '')}`;
    const actionName = 'QA-E2E-123';
    const defaultPool = '$default';
    const remotePool = '$remote';

    it('Create a new playbook', () => {
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.createPlaybook({
        playbookName,
        playbookTitle,
        playbookDescription: faker.lorem.sentence()
      });
    });

    it('Check if pool has the default value', () => {
      // Open created playbook to access visual editor
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookTitle);

      // Add actions to the playbook. Action #1
      swimInstance.playbookPage.addPlaybookAction(actionName, 'Falcon');

      // Check pool default value
      swimInstance.playbookPage.openAdvancedSettings();
      swimInstance.playbookPage.checkActionPoolValue(defaultPool);

      swimInstance.playbookPage.savePlaybookChanges();
    });

    it('Check if pool preserves a new value', () => {
      // Open created playbook to access visual editor
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookTitle);

      // Find Action #1
      swimInstance.playbookPage.findSpecificAction(actionName);

      // Change pool default value
      swimInstance.playbookPage.openAdvancedSettings();
      swimInstance.playbookPage.setActionPoolValue(remotePool);

      swimInstance.playbookPage.savePlaybookChanges();

      // Re-open the playbook to check latests changes
      swimInstance.openPlaybooks();
      swimInstance.playbookPage.verifyPlaybookVisualEditor(playbookTitle);

      swimInstance.playbookPage.findSpecificAction(actionName);
      swimInstance.playbookPage.openAdvancedSettings();
      swimInstance.playbookPage.checkActionPoolValue(remotePool);
    });
  });

  after(() => {
    cy.cleanupTurbine();
    cy.logout();
  });
});

import * as swimInstance from '../../../support/page-objects/swimInstance';

let pluginCount = 0;
let pluginTestDetails = { superDetails: '', baseDetails: '' };

describe('Verification of dynamic Orchestration - Plugin upload interface', () => {
  before(() => {
    cy.cleanupTurbine();
    cy.setFixture('dynamic-orchestration/plugins/http-display-details.json', 'plugin').then($pluginTestDetails => {
      pluginTestDetails = $pluginTestDetails;
    });
    swimInstance.setLoginState();
    swimInstance.loginPage.performLogin(Cypress.env('USERNAME'), Cypress.env('PASSWORD'));
  });

  it('Navigate to Orchestration Plugins page', () => {
    swimInstance.openPlugins();
    swimInstance.pluginsPage.getPluginsCount().then($count => {
      pluginCount = $count;
    });
  });

  describe('Verify plugin details', () => {
    it('Upload Plugin File', () => {
      swimInstance.pluginsPage.uploadPlugin({
        filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
        encoding: 'base64'
      });
      swimInstance.pluginsPage.pluginUploader.doneAddingPlugins();
      pluginCount += 1;
    });

    it('Verify plugin list item', () => {
      swimInstance.pluginsPage.getPluginListItemDetails('HTTP').then($pluginDetails => {
        expect($pluginDetails).to.deep.equal(pluginTestDetails.baseDetails);
      });
    });

    it('Click on plugin and view more details', () => {
      swimInstance.pluginsPage.scrollToVendorName('Swimlane', 'HTTP');
      swimInstance.pluginsPage.clickOnPluginDetails('HTTP');
      swimInstance.pluginsPage.pluginDetails.getDetails().should('deep.equal', pluginTestDetails.superDetails);
    });

    it('close plugin details dialog', () => {
      swimInstance.pluginsPage.pluginDetails.close();
    });

    it('Uploads more plugins to verify vendor names', () => {
      swimInstance.pluginsPage.uploadPlugin(
        {
          filePath: 'dynamic-orchestration/plugins/loadtest-0.1.0.plugin',
          encoding: 'base64'
        },
        false
      );
      swimInstance.pluginsPage.pluginUploader.doneAddingPlugins();
      swimInstance.pluginsPage.uploadPlugin(
        {
          filePath: 'dynamic-orchestration/plugins/python37-1.0.0.plugin',
          encoding: 'base64'
        },
        false
      );
      swimInstance.pluginsPage.pluginUploader.doneAddingPlugins();
      swimInstance.pluginsPage.scrollToVendorName('Swimlane', 'Load Test');
      swimInstance.pluginsPage.scrollToVendorName('Python Software Foundation', 'Python 3.7');
      swimInstance.pluginsPage.checkDisabledVendorNavItems('Swimlane');
      swimInstance.pluginsPage.checkDisabledVendorNavItems('Python Software Foundation');
    });

    it('Upload plugins of same vendor and verify installed plugin counts per vendor', () => {
      swimInstance.pluginsPage.uploadPlugin(
        {
          filePath: 'dynamic-orchestration/plugins/python27-1.0.1.plugin',
          encoding: 'base64'
        },
        false
      );
      swimInstance.pluginsPage.pluginUploader.doneAddingPlugins();
      swimInstance.pluginsPage.scrollToVendorName('Python Software Foundation', 'Python 3.7');
      swimInstance.pluginsPage.getPluginInstalledCountByVendor('Python Software Foundation', 2);
      swimInstance.pluginsPage.scrollToVendorName('Swimlane', 'Load Test');
      swimInstance.pluginsPage.getPluginInstalledCountByVendor('Swimlane', 2);
    });

    it('Verify plugin additional details', () => {
      let hasSensors = true;
      const hasOutputParams = false;
      cy.setFixture('dynamic-orchestration/plugins/http-display-details.json', 'plugin').then($pluginTestDetails => {
        pluginTestDetails = $pluginTestDetails;
      });
      swimInstance.pluginsPage.getPluginListItemDetails('HTTP').then($pluginDetails => {
        expect($pluginDetails).to.deep.equal(pluginTestDetails.baseDetails);
      });
      swimInstance.pluginsPage.scrollToVendorName('Swimlane', 'HTTP');
      swimInstance.pluginsPage.clickOnPluginDetails('HTTP');
      swimInstance.pluginsPage.pluginDetails.getDetails(hasSensors).then($detailsJSON => {
        cy.log(JSON.stringify($detailsJSON));
        expect($detailsJSON).to.deep.equal(pluginTestDetails.superDetails);
      });
      swimInstance.pluginsPage.pluginDetails.close();
      cy.setFixture('dynamic-orchestration/plugins/python37-display-details.json', 'plugin').then(
        $pluginTestDetails => {
          pluginTestDetails = $pluginTestDetails;
        }
      );
      swimInstance.pluginsPage.getPluginListItemDetails('Python 3.7').then($pluginDetails => {
        expect($pluginDetails).to.deep.equal(pluginTestDetails.baseDetails);
      });
      swimInstance.pluginsPage.scrollToVendorName('Python Software Foundation', 'Python 3.7');
      swimInstance.pluginsPage.clickOnPluginDetails('Python 3.7');
      swimInstance.pluginsPage.pluginDetails.getDetails((hasSensors = false)).then($detailsJSON => {
        expect($detailsJSON).to.deep.equal(pluginTestDetails.superDetails);
      });
      swimInstance.pluginsPage.pluginDetails.close();
      cy.setFixture('dynamic-orchestration/plugins/loadtest-display-details.json', 'plugin').then(
        $pluginTestDetails => {
          pluginTestDetails = $pluginTestDetails;
        }
      );
      swimInstance.pluginsPage.getPluginListItemDetails('Load Test').then($pluginDetails => {
        expect($pluginDetails).to.deep.equal(pluginTestDetails.baseDetails);
      });
      swimInstance.pluginsPage.scrollToVendorName('Swimlane', 'Load Test');
      swimInstance.pluginsPage.clickOnPluginDetails('Load Test');
      swimInstance.pluginsPage.pluginDetails.getDetails((hasSensors = true), hasOutputParams).then($detailsJSON => {
        expect($detailsJSON).to.deep.equal(pluginTestDetails.superDetails);
      });
      swimInstance.pluginsPage.pluginDetails.close();
    });

    it('Scrolls automatically to specific brand/vendor', () => {
      swimInstance.pluginsPage.scrollToVendorName('Swimlane', 'HTTP');
    });
  });

  describe('Delete installed plugins', () => {
    it('Cancels deleting existing plugin', () => {
      swimInstance.pluginsPage.deletePlugin('HTTP', true);
    });
    it('Deletes existing plugins', () => {
      swimInstance.pluginsPage.deletePlugin('Load Test');
      swimInstance.pluginsPage.deletePlugin('Python 3.7');
      swimInstance.pluginsPage.deletePlugin('Python 2.7');
      swimInstance.pluginsPage.deletePlugin('HTTP');
    });
  });

  after(() => {
    swimInstance.logout();
  });
});

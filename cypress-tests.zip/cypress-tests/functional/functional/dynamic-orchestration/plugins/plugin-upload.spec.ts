import * as swimInstance from '../../../support/page-objects/swimInstance';

describe('Verification of dynamic Orchestration - Plugin upload interface', () => {
  before(() => {
    cy.cleanupTurbine();
    swimInstance.setLoginState();
    swimInstance.loginPage.performLogin(Cypress.env('USERNAME'), Cypress.env('PASSWORD'));
  });

  it('Navigate to Orchestration page', () => {
    swimInstance.openPlugins();
  });

  describe('Add Dynamic Orchestration Plugin through Swimlane', () => {
    describe('Test Upload plugin dialog', () => {
      it('Open Plugin upload dialog', () => {
        swimInstance.pluginsPage.installPlugin();
      });

      it('Upload Plugin File', () => {
        swimInstance.pluginsPage.pluginUploader.uploadFile({
          filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
          encoding: 'base64'
        });
      });

      it('Verify upload Complete', () => {
        swimInstance.pluginsPage.pluginUploader.checkUploadComplete('HTTP');
      });
    });

    describe('Click upload more plugins', () => {
      it('Click upload more plugins', () => {
        swimInstance.pluginsPage.pluginUploader.uploadMorePlugins();
      });

      it('Uploads Multiple Plugin Files At Once', () => {
        swimInstance.pluginsPage.pluginUploader.uploadFile([
          {
            filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
            encoding: 'base64'
          },
          {
            filePath: 'dynamic-orchestration/plugins/github-2.0.1.plugin',
            encoding: 'base64'
          },
          {
            filePath: 'dynamic-orchestration/plugins/python27-1.0.1.plugin',
            encoding: 'base64'
          },
          {
            filePath: 'dynamic-orchestration/plugins/python37-1.0.0.plugin',
            encoding: 'base64'
          }
        ]);
      });
    });

    describe('Close plugin uploader', () => {
      it('close plugin upload dialog', () => {
        swimInstance.pluginsPage.pluginUploader.doneAddingPlugins();
      });
    });
  });

  /**
   * TODO: Verify when SPT-9222 is implemented that the Turbine API returns as we expect
   * due to the issue below as stated (UI tests are now passing due to work in SPT-9343).
   *
   * Skipping checking Invalid Plugins due to cypress-file-upload bubbling a CustomEvent that
   * forces @swimlane/ng2-file-upload to throw a "TypeError: files is not iterable" (because ng2-file-upload expects a File[] but receives a CustomEvent instead, this only happens in Cypress) which
   * a now-implemented GlobalErrorHandler will catch and throw this TypeError which causes the Cypress test to fail.
   *
   * Turbine team is to stop the event from bubbling on the `input[type='file']` on `(change)` event to stop the `CustomEvent` from bubbling.
   */
  describe('Upload invalid plugin files', () => {
    it('Open Plugin upload dialog', () => {
      swimInstance.pluginsPage.openUploadDialog();
    });

    it('PNG file', () => {
      swimInstance.pluginsPage.pluginUploader.uploadFile('img/original-icon.png', true);
    });

    it('JSON file', () => {
      swimInstance.pluginsPage.pluginUploader.uploadFile('example.json', true);
    });

    it('swimbundle file', () => {
      swimInstance.pluginsPage.pluginUploader.uploadFile(
        {
          filePath: 'bundles/sw_amazon_web_services-2.2.0-linux.python36.swimbundle',
          encoding: 'base64'
        },
        true
      );
    });

    it('close plugin upload dialog', () => {
      swimInstance.pluginsPage.pluginUploader.close();
    });
  });

  after(() => {
    cy.cleanupTurbine();
    swimInstance.logout();
  });
});

import * as swimInstance from '../../../support/page-objects/swimInstance';
import { verifyModalDirtyDialog } from '../../../support/page-objects/main-app-objects/common-pieces/popupMessages';
import faker from 'faker/locale/en';
import {
  openRecord,
  openRecordWorkflowResults,
  openCreatedRecordWorkflowResults,
  closeRecordWindow,
  showRecordList
} from '../../../support/page-objects/main-app-objects/app-list-all';

const appName = `QAE2E-${faker.company.catchPhrase()}`.substring(0, 128);
const namePrefix = `QAE2E_`;
const uploadPlaybookJSON = {
  playbookFileName: 'dynamic-orchestration/playbooks/chained-repeats.yml',
  invalidFile: false,
  forceClosure: false,
  closeMultiple: false
};

let recordTrackingId = '';

const appList = [];
const workSpaceList = [];

const actionTypes = [
  'Set Field Value',
  'Set Field Read/Write',
  'Set Field Required/Optional',
  'Filter Selection Options',
  'Modify Layout',
  'Toggle Time Tracking for Record'
];

describe('Verification of dynamic Orchestration - Orchestration Workflow', () => {
  before(() => {
    cy.turbinelogin();
    cy.login();

    cy.cleanupTurbine();
    cy.cleanupOrchestrationTasks();

    cy.visit('/');
  });

  it('Uploads Plugins, Playbooks, and sensor to use for creating Automation Tasks', () => {
    const portNumber = faker.datatype.number({ min: 10000, max: 20000 });

    swimInstance.openPlugins();
    swimInstance.pluginsPage.checkPlugin(
      {
        filePath: 'dynamic-orchestration/plugins/python37-1.0.0.plugin',
        encoding: 'base64'
      },
      'Python',
      '1.1.2'
    );
    swimInstance.pluginsPage.checkPlugin(
      {
        filePath: 'dynamic-orchestration/plugins/http-1.0.2.plugin',
        encoding: 'base64'
      },
      'HTTP',
      '1.0.2'
    );

    swimInstance.openPlaybooks();
    swimInstance.playbookPage.uploadPlaybook('', null, false);
    swimInstance.playbookPage.playbookUploader.uploadFile(uploadPlaybookJSON);
    swimInstance.playbookPage.playbookUploader.setProperties(
      {
        title: `${namePrefix}chained_repeats`,
        name: `${namePrefix}chained_repeats`,
        description: faker.lorem.sentence()
      },
      true
    );

    swimInstance.openPlaybooks();
    swimInstance.playbookPage.uploadPlaybook('', null, false);
    uploadPlaybookJSON.playbookFileName = 'dynamic-orchestration/playbooks/test_playbook_yml.yml';
    swimInstance.playbookPage.playbookUploader.uploadFile(uploadPlaybookJSON);
    swimInstance.playbookPage.playbookUploader.setProperties(
      {
        title: `${namePrefix}test`,
        name: `${namePrefix}test`,
        description: faker.lorem.sentence()
      },
      true
    );

    swimInstance.openPlaybooks();
    swimInstance.playbookPage.uploadPlaybook('', null, false);
    uploadPlaybookJSON.playbookFileName = 'dynamic-orchestration/playbooks/http_test.yml';
    swimInstance.playbookPage.playbookUploader.uploadFile(uploadPlaybookJSON);
    swimInstance.playbookPage.playbookUploader.setProperties(
      {
        title: `${namePrefix}http_test`,
        name: `${namePrefix}http_test`,
        description: faker.lorem.sentence()
      },
      true
    );

    // SPT-13435: Hide event stream
    /*swimInstance.openSensors();

    swimInstance.sensorsPage.createSensor({
      sensorType: 'Web Server',
      sensorName: `${namePrefix}Web_Server`,
      paramData: [portNumber]
    });*/

    swimInstance.openAssets();

    swimInstance.assetsPage.createAsset({
      assetType: 'Uri',
      assetName: `${namePrefix}Uri`,
      paramData: ['https://www.google.com', 'GET'],
      noAssets: true
    });
  });

  it('Creates a new App', () => {
    swimInstance.openAppAppletsList();
    swimInstance.appsAppletsListing.startNewApp();
    swimInstance.appsAppletsListing.appWizard.setAppName(appName);
    swimInstance.appsAppletsListing.appWizard.createApp();
    appList.push(appName);
    workSpaceList.push(`${appName} Workspace`);
    swimInstance.appBuilder.verifyElements(appName);
    swimInstance.appBuilder.addField('Text');
    swimInstance.appBuilder.addField('Numeric');
    swimInstance.appBuilder.saveApplication();
  });

  it('Does not find automation-based workflow actions', () => {
    swimInstance.appBuilder.editWorkflow();
    swimInstance.workflowEditor.verifyElements();
    swimInstance.workflowEditor.addNode('Default Action(s)', 'action');

    cy.get('[data-cy=workflow__editor]').find('[data-cy=workflow-node__editor]').as('nodeEditor');
    cy.get('@nodeEditor').find('.form-group').eq(2).as('actionType');

    cy.get('@actionType').within(() => {
      cy.get('ngx-select').as('actionTypeSelect');
      cy.get('@actionTypeSelect').ngxOpen();

      actionTypes.forEach((action, idx) => {
        cy.get('.ngx-select-option-group .vertical-list li').eq(idx).should('contain', action);
      });

      cy.get('@actionTypeSelect').ngxClose();
    });
  });

  // Skipped untill SPT-10949 is fixed
  // https://swimlane.atlassian.net/browse/SPT-10949
  xit('Opens workflow and checks default state for Trigger Tasks (with none created)', () => {
    swimInstance.appBuilder.editWorkflow();
    swimInstance.workflowEditor.verifyElements();
    swimInstance.workflowEditor.addNode('Default Action(s)', 'action');
    swimInstance.workflowEditor.editCurrentNode({
      Name: 'TestAction1',
      'Action Type': 'Playbook Button'
    });

    // Wait for workflow-action dropdown to show
    cy.get('workflow-action-trigger-task').should('exist');
    cy.get('workflow-action-trigger-task ngx-select').should('exist');

    swimInstance.workflowEditor.verifyNoOptionsAvailable('Task');

    swimInstance.orchestrationPage.switchToAppView('automation-alternate');
    verifyModalDirtyDialog('You have unsaved changes to this workflow.', 'Are you sure you want to leave?', 'Leave');
  });

  // Skipped untill SPT-10949 is fixed
  // https://swimlane.atlassian.net/browse/SPT-10949
  xit('Opens and sets up a basic workflow', () => {
    swimInstance.appBuilder.editWorkflow();
    swimInstance.workflowEditor.verifyElements();
    swimInstance.workflowEditor.addNode('Default Action(s)', 'action');
    swimInstance.workflowEditor.editCurrentNode({
      Name: 'TestAction1',
      'Action Type': 'Playbook Button',
      Task: `${namePrefix}chained_repeats_task`
    });
    swimInstance.workflowEditor.saveWorkflow();
    swimInstance.workflowEditor.addNode('Default Action(s)', 'action');
    swimInstance.workflowEditor.editCurrentNode({
      Name: 'TestAction2',
      'Action Type': 'Playbook Button',
      Task: `${namePrefix}http_test_task`
    });
    swimInstance.workflowEditor.saveWorkflow();
  });

  // Skipped untill SPT-10949 is fixed
  // https://swimlane.atlassian.net/browse/SPT-10949
  xit('Creates 2 conditions in the workflow: (1) if numeric field equals 1 (2) if text field equals "execute"', () => {
    swimInstance.workflowEditor.addNode(appName, 'condition');
    swimInstance.workflowEditor.editCurrentNode({
      Name: 'TestCondition1',
      Field: 'Numeric',
      Operator: 'Equals',
      Value: { type: 'Numeric', value: '1' }
    });
    swimInstance.workflowEditor.saveWorkflow();
    swimInstance.workflowEditor.addNode(appName, 'condition');
    swimInstance.workflowEditor.editCurrentNode({
      Name: 'TestCondition2',
      Field: 'Text',
      Operator: 'Equals',
      Value: { type: 'Text', value: 'execute' }
    });
    swimInstance.workflowEditor.saveWorkflow();
  });

  // Skipped untill SPT-10949 is fixed
  // https://swimlane.atlassian.net/browse/SPT-10949
  xit('Creates 2 actions in the workflow: (1) triggered based on numeric (2) triggered based on text', () => {
    swimInstance.workflowEditor.addNode('TestCondition1', 'action');
    swimInstance.workflowEditor.editCurrentNode({
      Name: 'TestConditionalAction1',
      'Action Type': 'Playbook Button',
      Task: `${namePrefix}chained_repeats_task`
    });
    swimInstance.workflowEditor.saveWorkflow();
    swimInstance.workflowEditor.addNode('TestCondition2', 'action');
    swimInstance.workflowEditor.editCurrentNode({
      Name: 'TestConditionalAction2',
      'Action Type': 'Playbook Button',
      Task: `${namePrefix}test_task`
    });
    swimInstance.workflowEditor.saveWorkflow();
  });

  // Skipped untill SPT-10949 is fixed
  // https://swimlane.atlassian.net/browse/SPT-10949
  xit('Creates a new Record to Trigger basic Workflow', () => {
    swimInstance.switchToWorkspace(`${appName} Workspace`);
    swimInstance.startNewRecordForApp(appName);
    swimInstance.recordEditor.enterRandomData();
    swimInstance.recordEditor.save();
    swimInstance.recordEditor.getRecordValues();
    swimInstance.recordEditor.getRecordTrackingID(true).then($trackingID => {
      recordTrackingId = $trackingID;
    });
  });

  // Skipped untill SPT-10949 is fixed
  // https://swimlane.atlassian.net/browse/SPT-10949
  xit('Opens the created Record (tied to the basic workflow) and Verifies Workflow Succeeded', () => {
    showRecordList(appName);
    openRecord(recordTrackingId);
    closeRecordWindow();
    openRecordWorkflowResults(recordTrackingId);
    openCreatedRecordWorkflowResults(appName, 'Default Action\\(s\\)', 'TestAction1');
    openCreatedRecordWorkflowResults(appName, 'Default Action\\(s\\)', 'TestAction2');
    openCreatedRecordWorkflowResults(appName, 'TestCondition1', 'TestConditionalAction1', 'run', 'no-run', 'no-run');
    openCreatedRecordWorkflowResults(appName, 'TestCondition2', 'TestConditionalAction2', 'run', 'no-run', 'no-run');
  });

  // Skipped untill SPT-10949 is fixed
  // https://swimlane.atlassian.net/browse/SPT-10949
  xit('Creates a new Record to Trigger Conditional Workflow', () => {
    swimInstance.switchToWorkspace(`${appName} Workspace`);
    swimInstance.startNewRecordForApp(appName);
    swimInstance.recordEditor.enterRandomData('execute', 1);
    swimInstance.recordEditor.save();
    swimInstance.recordEditor.getRecordValues();
    swimInstance.recordEditor.getRecordTrackingID(true).then($trackingID => {
      recordTrackingId = $trackingID;
    });
  });

  // Skipped untill SPT-10949 is fixed
  // https://swimlane.atlassian.net/browse/SPT-10949
  xit('Opens the created Record (tied to the conditional workflow) and Verifies Workflow Succeeded', () => {
    showRecordList(appName);
    openRecord(recordTrackingId);
    closeRecordWindow();
    openRecordWorkflowResults(recordTrackingId);
    openCreatedRecordWorkflowResults(appName, 'Default Action\\(s\\)', 'TestAction1');
    openCreatedRecordWorkflowResults(appName, 'Default Action\\(s\\)', 'TestAction2');
    openCreatedRecordWorkflowResults(appName, 'TestCondition1', 'TestConditionalAction1');
    openCreatedRecordWorkflowResults(appName, 'TestCondition2', 'TestConditionalAction2');
  });

  // Skipped untill SPT-10949 is fixed
  // https://swimlane.atlassian.net/browse/SPT-10949
  xit('Disables workflow nodes, Creates Record and validates active vs. inactive parts of run', () => {
    swimInstance.appBuilder.editWorkflow();
    swimInstance.workflowEditor.verifyElements(appName);
    swimInstance.workflowEditor.disableNode('stage', 'TestCondition2');
    swimInstance.workflowEditor.disableNode('stage', 'TestCondition1');
    swimInstance.workflowEditor.disableNode('action', 'TestConditionalAction1');
    swimInstance.workflowEditor.disableNode('action', 'TestConditionalAction2');
    swimInstance.workflowEditor.disableNode('action', 'TestAction1');
    swimInstance.workflowEditor.saveWorkflow();
    swimInstance.switchToWorkspace(`${appName} Workspace`);
    swimInstance.startNewRecordForApp(appName);
    swimInstance.recordEditor.enterRandomData('execute', 1);
    swimInstance.recordEditor.save();
    swimInstance.recordEditor.getRecordValues();
    swimInstance.recordEditor.getRecordTrackingID(true).then($trackingID => {
      recordTrackingId = $trackingID;
    });
    showRecordList(appName);
    openRecord(recordTrackingId);
    closeRecordWindow();
    openRecordWorkflowResults(recordTrackingId);
    openCreatedRecordWorkflowResults(appName, 'Default Action\\(s\\)', 'TestAction1', 'run', 'run', 'node-disabled');
    openCreatedRecordWorkflowResults(appName, 'Default Action\\(s\\)', 'TestAction2');
    openCreatedRecordWorkflowResults(
      appName,
      'TestCondition1',
      'TestConditionalAction1',
      'run',
      'node-disabled',
      'node-disabled'
    );
    openCreatedRecordWorkflowResults(
      appName,
      'TestCondition2',
      'TestConditionalAction2',
      'run',
      'node-disabled',
      'node-disabled'
    );
  });

  after(() => {
    cy.cleanUpCypressApps();
    cy.cleanUpCypressWorkspaces();
    cy.cleanupOrchestrationTasks();
    cy.cleanupTurbine();
    cy.logout();
  });
});

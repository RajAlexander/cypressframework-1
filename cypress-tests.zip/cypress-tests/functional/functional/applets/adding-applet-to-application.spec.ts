import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 127);
const appName2 = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 127);
const appletName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 127);
const fieldName = faker.company.catchPhrase().substring(0, 64);
const fieldName2 = fieldName + 's';
let appAcronym = '';
let appletAcronym = '';

describe('SPT-10917: Implementing task duplication when an applet is added to an app', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Create Applet', () => {
    it('build applet', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApplet();
      swimInstance.appsAppletsListing.appWizard.setAppName(appletName, false);
      swimInstance.appsAppletsListing.appWizard.getAppAcronym(false).then(acronym => {
        appletAcronym = acronym;
      });
      swimInstance.appsAppletsListing.appWizard.createApplet();
    });

    it('Add text fields', () => {
      swimInstance.appBuilder.verifyElements(appletName, false);
      swimInstance.appBuilder.addField('Single-Line', '', false);
      swimInstance.appBuilder.editAppComponent(
        'Text',
        {
          Name: fieldName
        },
        false
      );
      swimInstance.appBuilder.setFieldSize(fieldName, '100%', false);
      swimInstance.appBuilder.addField('Single-Line', '', false);
      swimInstance.appBuilder.editAppComponent(
        'Text',
        {
          Name: fieldName2
        },
        false
      );
      swimInstance.appBuilder.setFieldSize(fieldName2, '100%', false);
      swimInstance.appBuilder.saveApplet();
    });
  });

  describe('Create App', () => {
    it('build app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.getAppAcronym().then(acronym => {
        appAcronym = acronym;
      });
      swimInstance.appsAppletsListing.appWizard.createApp();
    });

    it('Add Fields', () => {
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.addField('Text', '');
      swimInstance.appBuilder.addField('Text', '');
    });

    it('Save App', () => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Create another App', () => {
    it('build another app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName2);
      swimInstance.appsAppletsListing.appWizard.getAppAcronym().then(acronym => {
        appAcronym = acronym;
      });
      swimInstance.appsAppletsListing.appWizard.createApp();
    });

    it('Add Fields', () => {
      swimInstance.appBuilder.verifyElements(appName2);
      swimInstance.appBuilder.addField('Text', '');
      swimInstance.appBuilder.addField('Text', '');
    });

    it('Save App', () => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Upload different tasks', () => {
    before(() => {
      swimInstance.openIntegrations();
    });
    describe('Common Task', () => {
      it('upload common task to applet', () => {
        swimInstance.integrationsPage.uploadTask('tasks/common task.json');
        swimInstance.integrationsPage.setTaskDetails('QA-E2E-common task', appletName);
        swimInstance.integrationsPage.clickUploadPlugin();
        swimInstance.integrationsPage.closeTaskUpload();
      });
    });
    describe('App Task', () => {
      it('upload app task to applet', () => {
        swimInstance.integrationsPage.uploadTask('tasks/app task.json');
        swimInstance.integrationsPage.setTaskDetails('QA-E2E-app task', appletName);
        swimInstance.integrationsPage.clickUploadPlugin();
        swimInstance.integrationsPage.closeTaskUpload();
      });
    });
    describe('Applet Task', () => {
      it('upload applet task to applet', () => {
        swimInstance.integrationsPage.uploadTask('tasks/applet task.json');
        swimInstance.integrationsPage.setTaskDetails('QA-E2E-applet task', appletName);
        swimInstance.integrationsPage.clickUploadPlugin();
        swimInstance.integrationsPage.closeTaskUpload();
      });
    });
  });

  describe('Add the applets (with Tasks) to the Application', () => {
    it('Add Applets to the Application', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.editExistingApp(appName);
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.addAppletToApplication(appletName, true, '3 Tasks Duplicated');
      swimInstance.appBuilder.addAppletToApplication(appletName, false);
      swimInstance.appBuilder.saveApplication({ subtext: 'Application saved' }, false, {
        title: 'You have 1 applet in your application layout',
        body: 'When you save this application, all pending applets are added to your layout.\n      \n      Application tasks are also created for each of the pending applet tasks.\n      '
      });
    });
  });

  describe('Add the applets, but leave them pending, (with Tasks) to the Application', () => {
    it('Add Applets, but leave them pending, to the Application', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.editExistingApp(appName2);
      swimInstance.appBuilder.verifyElements(appName2);
      swimInstance.appBuilder.addAppletToApplication(appletName, false);
      swimInstance.appBuilder.addAppletToApplication(appletName, false);
      swimInstance.appBuilder.saveApplication({ subtext: 'Application saved' }, false, {
        title: 'You have 2 applets in your application layout',
        body: 'When you save this application, all pending applets are added to your layout.\n      \n      Application tasks are also created for each of the pending applet tasks.\n      '
      });
    });
  });

  describe('Verify Applet Tasks are copied and associated with Application', () => {
    it('Verify Applet Tasks are copied and associated with Application', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.verifyExistingTask({
        name: `[${appAcronym}] QA-E2E-applet task`.slice(0, 64)
      });
      swimInstance.integrationsPage.verifyExistingTask({
        name: `[${appAcronym}] QA-E2E-applet task - (2)`.slice(0, 64)
      });
    });
  });

  describe('Verify Applet Field Keys are updated and still show association with originating Applet', () => {
    it('Verify Applet Field Keys are updated and still show association with originating Applet', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.editExistingApp(appName);
      swimInstance.appBuilder.verifyFieldKey(
        fieldName,
        (appletAcronym + '.' + fieldName)
          .toLowerCase()
          .replace(/[\s]+/gi, '-')
          .replace(/[^.a-z0-9_\-]+/gi, '')
          .slice(0, 64)
      );
      swimInstance.appBuilder.verifyFieldKey(
        fieldName2,
        (appletAcronym + '.' + fieldName2)
          .toLowerCase()
          .replace(/[\s]+/gi, '-')
          .replace(/[^.a-z0-9_\-]+/gi, '')
          .slice(0, 64)
      );
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const noIssuesPath = 'packages/QA-E2E- Applet Export.ssp';
const actionableIssuesPath = 'packages/QA-E2E- Applet Actionable Testing.ssp';
const nonActionableIssuesPath = 'packages/QA-E2E- Issues Testing Applet.ssp';
const actionableAndNonActionableIssuesPath = 'packages/QA-E2E- Applet Actionable and Non-Actionable Testing.ssp';
const keyStoreRemovableIssuesPath = 'packages/QA-E2E-key-store-removal-issue-applet.ssp';
const appletWithTasksPath = 'packages/QA-E2E-Applet With Tasks.ssp';
const keyValue = faker.random.word();
const keyName = 'qa-e2e-key-applet';
const issuesTestPluginDetails = {
  file: 'bundles/sw_cherwell_service_management-1.0.4-linux.python36.swimbundle',
  name: 'Service Management',
  version: '1.0.4',
  subName: 'sw_cherwell_service_management',
  description: 'Cherwell Ticket Management'
};
const actionableAndNonActionableTestPluginDetails = {
  file: 'bundles/sw_atlassian_jira-6.4.0-linux.python36.swimbundle',
  name: 'Jira',
  version: '6.4.0',
  subName: 'sw_atlassian_jira',
  description: 'Jira integration library'
};
const actionableTestPluginDetails = {
  file: 'bundles/sw_trend_micro_apex_central-1.0.0-linux.python36.swimbundle',
  name: 'Apex Central',
  version: '1.0.0',
  subName: 'sw_trend_micro_apex_central',
  description: 'Apex Central API'
};
const pwnedPluginDetails = {
  file: '',
  name: 'Have I Been Pwned',
  version: '1.0.5',
  subName: 'sw_have_i_been_pwned',
  description: 'Have I Been Pwned Integration'
};

describe('Import Applet SSP', () => {
  before(() => {
    cy.login();
    cy.cleanupSwimlane();
    cy.visitSwimlane('/');
  });

  it('import success', () => {
    swimInstance.openAppAppletsList();
    swimInstance.appsAppletsListing.startImportPlus();
    swimInstance.appsAppletsListing.appAppletSSPWizard.uploadPackage(noIssuesPath);
    swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
      'Import Success',
      null,
      null,
      null,
      null,
      null,
      {
        packageContents: ['1 Applet'],
        appName: 'QA-E2E- Applet Export'
      },
      false,
      true
    );
  });

  describe('Import Applet SSP, fail', () => {
    it('import fail', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startImportPlus();
      swimInstance.appsAppletsListing.appAppletSSPWizard.uploadPackage(noIssuesPath);
      swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUploadFailure(
        'Error Detected',
        'This item already exists in this environment.'
      );
    });
  });

  // this ssp returns actionable issues use a different ssp
  describe('Import Applet SSP, non-actionable issues', () => {
    it('import non-actionable issues', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startImportPlus();
      swimInstance.appsAppletsListing.appAppletSSPWizard.uploadPackage(nonActionableIssuesPath);
      swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
        'Import Summary',
        'Review Potential Issues',
        'Your applet has imported successfully but there are issues. This may result in an incomplete solution.',
        'Take note of or take action on the issues listed.',
        null,
        null,
        {
          packageContents: ['1 Applet', '2 Tasks', '1 Asset'],
          appName: 'Issues Testing',
          descriptors: {
            asset: [
              {
                name: 'Service Management',
                version: '1.0.4',
                message: 'A secure credential has been removed from Password.'
              }
            ],
            applet: [
              {
                name: 'Issues Testing',
                message: 'Task undefined for this integration button'
              }
            ]
          }
        },
        false,
        true
      );
    });
  });

  describe('Import Applet SSP, actionable issues', () => {
    it('import actionable issues', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startImportPlus();
      swimInstance.appsAppletsListing.appAppletSSPWizard.uploadPackage(actionableIssuesPath);
      swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
        'Import Summary',
        'Review Potential Issue',
        'Your applet has imported successfully but there is an issue. This may result in an incomplete solution.',
        'Take note of or take action on the issue listed.',
        null,
        null,
        {
          packageContents: ['1 Applet', '1 Task', '1 Asset'],
          appName: 'QA-E2E- Applet Actionable Testing',
          descriptors: {
            asset: [
              {
                name: 'Trend Micro Apex Central',
                version: '1.0.0',
                message: 'A secure credential has been removed from API Key.'
              }
            ]
          }
        },
        false,
        false
      );
      swimInstance.appsAppletsListing.appAppletSSPWizard.resolveIssue('Trend Micro Apex Central', 'Asset', {
        parameters: { api_key: 'p@ssw0rd' }
      });
      swimInstance.appsAppletsListing.appAppletSSPWizard.close();
    });
  });

  describe('Import Applet SSP, actionable and non-actionable issues', () => {
    it('import actionable AND non-actionable issues', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startImportPlus();
      swimInstance.appsAppletsListing.appAppletSSPWizard.uploadPackage(actionableAndNonActionableIssuesPath);
      swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
        'Import Summary',
        'Review Potential Issues',
        'Your applet has imported successfully but there are issues. This may result in an incomplete solution.',
        'Take note of or take action on the issues listed.',
        null,
        null,
        {
          packageContents: ['1 Applet', '1 Task', '1 Asset'],
          appName: 'QA-E2E- Applet Actionable and Non-Actionable Testing',
          descriptors: {
            asset: [
              {
                name: 'Atlassian Jira',
                version: '6.4.0',
                message: 'A secure credential has been removed from API Token.'
              }
            ],
            applet: [
              {
                name: 'QA-E2E- Applet Actionable and Non-Actionable Testing',
                message: 'Task undefined for this integration button'
              }
            ]
          }
        },
        false,
        true
      );
    });
  });

  describe('Import Applet SSP, key store removal issues', () => {
    it('key store removal issues', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startImportPlus();
      swimInstance.appsAppletsListing.appAppletSSPWizard.uploadPackage(keyStoreRemovableIssuesPath);
      swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
        'Import Summary',
        'Review Potential Issue',
        'Your applet has imported successfully but there is an issue. This may result in an incomplete solution.',
        'Take note of or take action on the issue listed.',
        null,
        null,
        {
          packageContents: ['1 Applet', '1 Task'],
          appName: 'QA-E2E-Enhanced 5th generation flexibility',
          descriptors: {
            task: [
              {
                name: 'qa-e2e-key-applet-task',
                issues: 1,
                reason: 'Key store mapping to input "qa-e2e-key-applet" has been cleared.'
              }
            ]
          }
        },
        false,
        false
      );
      swimInstance.appsAppletsListing.appAppletSSPWizard.resolveIssue('qa-e2e-key-applet-task', 'Task', {
        name: 'qa-e2e-key-applet',
        value: keyValue
      });
      swimInstance.appsAppletsListing.appAppletSSPWizard.close();
    });
  });

  describe('Import Applet SSP, with Tasks', () => {
    it('Import Applet with Tasks', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startImportPlus();
      swimInstance.appsAppletsListing.appAppletSSPWizard.uploadPackage(appletWithTasksPath);
      swimInstance.appsAppletsListing.appAppletSSPWizard.verifyUpload(
        'Import Summary',
        'Review Potential Issue',
        'Your applet has imported successfully but there is an issue. This may result in an incomplete solution.',
        'Take note of or take action on the issue listed.',
        null,
        null,
        {
          packageContents: ['1 Applet', '2 Tasks', '1 Asset'],
          appName: 'QA-E2E-Applet With Tasks',
          descriptors: {
            asset: [
              {
                name: 'Have I Been Pwned',
                version: '1.0.5',
                message: 'A secure credential has been removed from API Key.'
              }
            ]
          }
        },
        false,
        false
      );
      swimInstance.appsAppletsListing.appAppletSSPWizard.resolveIssue('Have I Been Pwned', 'Asset', {
        parameters: { api_key: keyValue }
      });
      swimInstance.appsAppletsListing.appAppletSSPWizard.close();
    });

    it('Verify Applet Tasks imported correctly', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.openTask('QA-E2E-Pwnage');
      swimInstance.integrationsPage.verifyTaskGeneralSettings({
        Name: `QA-E2E-Pwnage`,
        Description: 'This is a description?',
        'Task Parent': 'Applet: QA-E2E-Applet With Tasks',
        'Task Type': 'Vulnerability & Patch Management: Get All Breaches For An Account'
      });
      swimInstance.integrationsPage.closeTask();
      swimInstance.integrationsPage.openTask('QA-E2E-Applet Task Python');
      swimInstance.integrationsPage.verifyTaskGeneralSettings({
        Name: `QA-E2E-Applet Task Python`,
        Description: 'Testing Description!',
        'Task Parent': 'Applet: QA-E2E-Applet With Tasks',
        'Task Type': 'Scripts: Python 3'
      });
      swimInstance.integrationsPage.closeTask();
    });
  });

  describe('Cleanup applets', () => {
    it('Remove the created applets', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.deleteExistingApplet('QA-E2E- Applet Export');
      swimInstance.appsAppletsListing.deleteExistingApplet('QA-E2E- Issues Testing Applet');
      swimInstance.appsAppletsListing.deleteExistingApplet('QA-E2E- Applet Actionable Testing');
      swimInstance.appsAppletsListing.deleteExistingApplet('QA-E2E- Applet Actionable and Non-Actionable Testing');
      swimInstance.appsAppletsListing.deleteExistingApplet('QA-E2E-Enhanced 5th generation flexibility');
      swimInstance.appsAppletsListing.deleteExistingApplet('QA-E2E-Applet With Tasks');
    });
  });

  describe('Cleanup Tasks and Assets', () => {
    it('Remove the Tasks and Assets', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.deleteTask('QA-E2E- Issues Test Task');
      swimInstance.integrationsPage.deleteTask('Trend Micro Apex Central Applet Task');
      swimInstance.integrationsPage.deleteTask('QA-E2E- Jira Applet Task');
      swimInstance.integrationsPage.deleteTask('QA-E2E- SM Issues Test Task');
      swimInstance.integrationsPage.deleteTask('qa-e2e-key-applet-task');
      swimInstance.integrationsPage.deleteAsset('Cherwell Service Management');
      swimInstance.integrationsPage.deleteAsset('Atlassian Jira');
      swimInstance.integrationsPage.deleteAsset('Trend Micro Apex Central');
    });
  });

  describe('Cleanup plugins', () => {
    it('Delete plugins that were added', () => {
      swimInstance.integrationsPage.openPluginsPage();
      swimInstance.integrationsPage.deletePlugin(issuesTestPluginDetails);
      swimInstance.integrationsPage.deletePlugin(actionableTestPluginDetails);
      swimInstance.integrationsPage.deletePlugin(actionableAndNonActionableTestPluginDetails);
      swimInstance.integrationsPage.deletePlugin(pwnedPluginDetails, true);
    });
  });

  describe('Cleanup key stores', () => {
    it('Delete key stores that were added.', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.openKeyStorePage();
      swimInstance.integrationsPage.deleteKeystore(keyName);
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

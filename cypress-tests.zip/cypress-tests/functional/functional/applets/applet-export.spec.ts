import faker from 'faker/locale/en';

import * as swimInstance from '../../support/page-objects/swimInstance';
import { verifyModalConfirmDialog } from '../../support/page-objects/main-app-objects/common-pieces/popupMessages';

const appletNoIssuesName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 127);
const appletIssuesName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 127);
const appletWithTasksName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 127);
const taskName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 127);
const taskName2 = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 127);
const randomInteger = faker.random.number({ min: -100, max: 100 });
const assetName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 127);
const testTaskName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 127);
const assetDescription = faker.lorem.sentence();
const testAsset100Settings = {
  Username: Cypress.env('USERNAME'),
  Password: Cypress.env('PASSWORD')
};
const APPLETLIST = [];
const ASSETLIST = [];
const TASKLIST = [];

describe('Applet Builder - Export Applet', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('export applet with key store removal issue', () => {
    let key = '';
    let taskName = '';

    it('Navigate to the integrations page and add new key store', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.openKeyStorePage();
      key = `qa-e2e-${faker.lorem.word()}${faker.lorem.word()}`;
      taskName = `${key}-task`;
      swimInstance.integrationsPage.addNewKeyStore(key, 'keyStoreValue');
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', taskName);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: '#',
        inputs: { Type: 'Key Store', Key: key, Variable: 'Text' }
      });
      swimInstance.integrationsPage.saveCurrentTask();
      TASKLIST.push(['Common', taskName]);
    });

    it('Create a new applet and add integration', () => {
      const app = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 127);

      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApplet();
      swimInstance.appsAppletsListing.appWizard.setAppName(app, false);
      swimInstance.appsAppletsListing.appWizard.createApplet();
      APPLETLIST.push(app);
      swimInstance.appBuilder.verifyElements(app, false);
      swimInstance.appBuilder.addLayout('Integration', false);
      swimInstance.appBuilder.editAppComponent('Integration', { Task: taskName }, false);
    });

    it('Save Applet and then export', () => {
      swimInstance.appBuilder.saveApplet();
      swimInstance.appBuilder.exportApplet({ hasCredIssues: true });
    });

    after(() => {
      if (key) {
        swimInstance.openIntegrations();
        swimInstance.integrationsPage.openKeyStorePage();
        swimInstance.integrationsPage.deleteKeystore(key);
      }
    });
  });

  describe('Upload Plugin and create Asset', () => {
    it('Navigate to the plugins listing.', () => {
      swimInstance.openIntegrations();
    });

    it('Upload plugin', () => {
      swimInstance.integrationsPage.checkForExistingBundle('sw_test_plugin', '6.0.0');
    });

    it('Create Test Plugin Asset', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewAsset('Test Plugin', {
        Name: assetName,
        Description: assetDescription,
        parameters: testAsset100Settings
      });
      ASSETLIST.push(assetName);
    });

    it('Create test Task for Asset', () => {
      swimInstance.integrationsPage.createNewTask(true);
      swimInstance.integrationsPage.setupTask('Test Plugin IO changes', testTaskName);
      swimInstance.integrationsPage.editCurrentTask({
        Name: testTaskName,
        Asset: assetName
      });
      swimInstance.integrationsPage.editTaskConfiguration({
        Input2: ['Literal Value', randomInteger],
        Input4: ['Literal Value', true],
        Input1: ['Literal Value', randomInteger, true]
      });
      swimInstance.integrationsPage.saveCurrentTask();
    });
  });

  describe('Add New applet for testing applet export with issues', () => {
    it('build base applet', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApplet();
      swimInstance.appsAppletsListing.appWizard.setAppName(appletIssuesName, false);
      swimInstance.appsAppletsListing.appWizard.createApplet();
      APPLETLIST.push(appletIssuesName);
      swimInstance.appBuilder.verifyElements(appletIssuesName, false);
    });
  });

  describe('Add Fields With Options', () => {
    it('Basic Numeric Field', () => {
      swimInstance.appBuilder.addField('Numeric', '', false);
      swimInstance.appBuilder.checkFieldProperties(
        'Numeric',
        {
          Required: false,
          Unique: false,
          'Read-only': false,
          Calculated: false
        },
        false
      );
      swimInstance.appBuilder.checkFieldAdvancedOptions(
        'Numeric',
        {
          Prefix: '',
          Suffix: '',
          Min: '',
          Max: ''
        },
        false
      );
      swimInstance.appBuilder.checkFieldSize('Numeric', '25%', false);
    });

    it('Add Integration button', () => {
      swimInstance.appBuilder.addLayout('Integration', false);
      swimInstance.appBuilder.editAppComponent('Integration', { Task: testTaskName }, false);
    });

    it('Attempt to Export Applet (with issues) before saving', () => {
      swimInstance.appBuilder.exportApplet({ performSave: false });
    });

    it('Save Applet and then export (with issues)', () => {
      swimInstance.appBuilder.saveApplet();
      swimInstance.appBuilder.exportApplet({ hasCredIssues: true });
    });
  });

  describe('App Builder - Export Applet without issues', () => {
    describe('Add New applet for testing applet export', () => {
      it('build base applet', () => {
        swimInstance.openAppAppletsList();
        swimInstance.appsAppletsListing.startNewApplet();
        swimInstance.appsAppletsListing.appWizard.setAppName(appletNoIssuesName, false);
        swimInstance.appsAppletsListing.appWizard.createApplet('Applet created');
        APPLETLIST.push(appletNoIssuesName);
        swimInstance.appBuilder.verifyElements(appletNoIssuesName, false);
      });
    });

    describe('Add Fields and Tasks to Applet', () => {
      it('Basic Numeric Field', () => {
        swimInstance.appBuilder.addField('Numeric', '', false);
      });

      it('Attempt to Export Applet (without issues) before saving', () => {
        swimInstance.appBuilder.exportApplet({ performSave: false });
      });

      it('Save Applet and then export without issues', () => {
        swimInstance.appBuilder.saveApplet();
        swimInstance.appBuilder.exportApplet();
      });
    });

    describe('App Builder - Export Applet with Tasks', () => {
      describe('Add New applet for testing applet export with Tasks', () => {
        it('build base applet', () => {
          swimInstance.openAppAppletsList();
          swimInstance.appsAppletsListing.startNewApplet();
          swimInstance.appsAppletsListing.appWizard.setAppName(appletWithTasksName, false);
          swimInstance.appsAppletsListing.appWizard.createApplet('Applet created');
          APPLETLIST.push(appletWithTasksName);
          swimInstance.appBuilder.verifyElements(appletWithTasksName, false);
        });
      });

      describe('Add Fields and Tasks to Applet', () => {
        it('Basic Fields', () => {
          swimInstance.appBuilder.verifyElements(appletWithTasksName, false);
          swimInstance.appBuilder.addField('Text', '', false);
          swimInstance.appBuilder.addField('Text', '', false);
          swimInstance.appBuilder.editAppComponent(
            'Text (2)',
            {
              Name: 'name_servers',
              Required: true
            },
            false
          );
          swimInstance.appBuilder.addField('Single-Line', '', false);
          swimInstance.appBuilder.editAppComponent(
            'Text (2)',
            {
              Name: 'registrar',
              Required: true
            },
            false
          );
          swimInstance.appBuilder.addField('Numeric', '', false);
          swimInstance.appBuilder.addLayout('Integration', false);
          swimInstance.appBuilder.saveApplet();
        });

        it('Create an Applet Task', () => {
          swimInstance.openIntegrations();
          swimInstance.integrationsPage.createNewTask();
          swimInstance.integrationsPage.setupTask('Python 3', taskName, appletWithTasksName);
          swimInstance.integrationsPage.editTaskConfiguration({
            script: 'print sw_context.inputs["Text"]',
            inputs: { Type: 'Record', Field: 'Text', Variable: 'Text' }
          });
        });

        it('Save the Task', () => {
          swimInstance.integrationsPage.saveCurrentTask();
        });

        it('Upload bundle', () => {
          swimInstance.openIntegrations();
          swimInstance.integrationsPage.checkForExistingBundle('sw_swimlane_parse_whois_lookup', '1.1.3');
        });

        it('Create another Task for the Applet', () => {
          swimInstance.openIntegrations();
          swimInstance.integrationsPage.createNewTask();
          swimInstance.integrationsPage.setupTask('WHOIS Lookup', taskName2, appletWithTasksName);
          swimInstance.integrationsPage.editTaskConfiguration({
            Domain: ['Record', 'Text']
          });
          swimInstance.integrationsPage.editTaskOutputMapping({
            updateRecord: {
              createOutputs: ['$', '$.domain_name', '$.марјан'],
              newTargetMappings: {
                $: 'Single-Line',
                '$.domain_name': 'Single-Line',
                domain_name: 'Single-Line',
                '$.марјан': 'Single-Line'
              }
            }
          });
          swimInstance.integrationsPage.verifyMappings({
            $: '$',
            '$.domain_name': '$.domain_name',
            '$.марјан': '$.марјан',
            domain_name: 'Domain Name',
            name_servers: 'name_servers',
            registrar: 'registrar'
          });
        });

        it('Save the Task', () => {
          swimInstance.integrationsPage.saveCurrentTask();
        });

        it('Export the Applet, with Tasks, without issues', () => {
          swimInstance.openAppAppletsList();
          swimInstance.appsAppletsListing.editExistingApp(appletWithTasksName, false);
          swimInstance.appBuilder.exportApplet();
        });
      });
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const pyDriverTaskName = `QA-E2E- keep ${faker.company.catchPhrase()}`.substring(0, 128);
const pyTaskToDeleteName = `QA-E2E- delete ${faker.company.catchPhrase()}`.substring(0, 128);
const TASKLIST = [];
const APPLIST = [];
const WORKSPACELIST = [];
let recordTrackingId = '';

describe('SPT-5442: When Integration button is clicked, show error if no tasks assigned', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  // TODO: Speed up with API or just app upload?
  describe('Create base application', () => {
    it('Create new App', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
      APPLIST.push(appName);
      WORKSPACELIST.push(`${appName} Workspace`);
    });

    it('Build fields into App', () => {
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.addField('Single-Line');
      swimInstance.appBuilder.addLayout('Integration');
      swimInstance.appBuilder.editAppComponent('Integration', {
        Name: 'Task exists'
      });
      swimInstance.appBuilder.addLayout('Integration');
      swimInstance.appBuilder.editAppComponent('Integration', {
        Name: 'Task removed'
      });
      swimInstance.appBuilder.addLayout('Integration');
      swimInstance.appBuilder.editAppComponent('Integration', {
        Name: 'Task not set'
      });
    });

    it('Save the App', () => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Add First python task to application', () => {
    it('Create Task', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', pyDriverTaskName, appName);
      TASKLIST.push([appName, pyDriverTaskName]);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: `import time \ntime.sleep(1)\nprint("${pyDriverTaskName}")`
      });
      swimInstance.integrationsPage.editTaskOutputMapping({
        updateRecord: { newMappings: { 'Standard Output': 'Text' } }
      });
    });

    it('Save the task', () => {
      swimInstance.integrationsPage.saveCurrentTask();
    });
  });

  describe('Add Second python task to application', () => {
    it('Create Task', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', pyTaskToDeleteName, appName);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: `print("${pyTaskToDeleteName}")`
      });
      swimInstance.integrationsPage.editTaskOutputMapping({
        updateRecord: { newMappings: { 'Standard Output': 'Text' } }
      });
    });

    it('Save the task', () => {
      swimInstance.integrationsPage.saveCurrentTask();
    });
  });

  describe('Attach tasks to integration buttons', () => {
    it('Open the app editor', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.editExistingApp(appName);
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.editAppComponent('Task exists', {
        Task: pyDriverTaskName
      });
      swimInstance.appBuilder.editAppComponent('Task removed', {
        Task: pyTaskToDeleteName
      });
    });

    it('Save the App', () => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Test the integration buttons in a record', () => {
    it('Create new Record', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecordForApp(appName);
      swimInstance.recordEditor.enterRandomData();
      swimInstance.recordEditor.save();
      swimInstance.recordEditor.getRecordValues();
      swimInstance.recordEditor.getRecordTrackingID(true).then($trackingID => {
        recordTrackingId = $trackingID;
      });
    });

    it('Test Task exists button', () => {
      swimInstance.recordEditor.clickIntegrationButton('Task exists', pyDriverTaskName);
      swimInstance.recordEditor.verifyFieldValues({ Text: pyDriverTaskName });
    });

    it('Test Task removed button', () => {
      swimInstance.recordEditor.clickIntegrationButton('Task removed', pyTaskToDeleteName);
      swimInstance.recordEditor.verifyFieldValues({ Text: pyTaskToDeleteName });
    });

    it('Test Task not set button', () => {
      swimInstance.recordEditor.clickIntegrationButton('Task not set', '', false);
      swimInstance.recordEditor.verifyFieldValues({ Text: pyTaskToDeleteName });
    });
  });

  describe('Remove the second task and retest buttons.', () => {
    it('Remove the task', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.deleteTask(pyTaskToDeleteName);
    });

    it('Open the previous record', () => {
      swimInstance.OpenAppListAll(appName);
      swimInstance.recordListing.openRecord(recordTrackingId);
      swimInstance.recordEditor.verifyFieldValues({ Text: pyTaskToDeleteName });
    });

    it('Test Task exists button', () => {
      swimInstance.recordEditor.clickIntegrationButton('Task exists', pyDriverTaskName);
      swimInstance.recordEditor.verifyFieldValues({ Text: pyDriverTaskName });
    });

    it('Test Task removed button', () => {
      swimInstance.recordEditor.clickIntegrationButton('Task removed', '', false);
      swimInstance.recordEditor.verifyFieldValues({ Text: pyDriverTaskName });
    });

    it('Test Task not set button', () => {
      swimInstance.recordEditor.clickIntegrationButton('Task not set', '', false);
      swimInstance.recordEditor.verifyFieldValues({ Text: pyDriverTaskName });
    });

    it('Close the record editor', () => {
      swimInstance.recordListing.closeRecordWindow();
    });
  });

  describe('Cleanup Apps, Workspaces, etc', () => {
    it('Remove the Tasks and Assets (SPT-7330)', () => {
      swimInstance.openIntegrations();
      TASKLIST.forEach(name => swimInstance.integrationsPage.deleteTask(name[1]));
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

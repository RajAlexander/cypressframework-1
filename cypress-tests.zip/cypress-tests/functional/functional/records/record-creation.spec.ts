import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const addedText = faker.random.words(5);
const APPLIST = [];
const WORKSPACELIST = [];
let recordTrackingId = '';

describe('Functional tests for record creation', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Create base application', () => {
    it('Create new App', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
      APPLIST.push(appName);
      WORKSPACELIST.push(`${appName} Workspace`);
    });

    it('Build fields into App', () => {
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.addField('Comments');
    });

    it('Save the App', () => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Test Comment field', () => {
    it('Create new Record to create a comment', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecordForApp(appName);
      swimInstance.recordEditor.enterRandomData();
      swimInstance.recordEditor.save();
      swimInstance.recordEditor.getRecordTrackingID(true).then($trackingID => {
        recordTrackingId = $trackingID;
      });
    });

    it('Open record created and Update the comment', () => {
      swimInstance.OpenAppListAll(appName);
      swimInstance.recordListing.openRecord(recordTrackingId);
      swimInstance.recordEditor.clickEditCommentButton();
      // Trying to prevent random failure here.
      cy.wait(500);
      swimInstance.recordEditor.editExistingComment(addedText);
      swimInstance.recordEditor.getRecordValues().its('Comments.0').should('contain', addedText);
    });

    it('Cancel Update the comment', () => {
      swimInstance.recordEditor.getRecordValues().as('recordData');
      swimInstance.recordEditor.clickEditCommentButton();
      swimInstance.recordEditor.cancelUpdateButton();
      cy.get('@recordData').then(recordData => swimInstance.recordEditor.verifyFieldValues(recordData));
      swimInstance.recordListing.closeRecordWindow();
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

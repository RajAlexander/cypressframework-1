import * as swimInstance from '../../support/page-objects/swimInstance';

// const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 64);
const roleNameKeyWordSearching = `QA-E2E-ksrole testingQA`;
const roleNameAscSorting = 'QA-E2E-aarole testingQA';
const roleNameDescSorting = 'QA-E2E-zzrole testingQA';
const roleDescriptionKeyWordSearching = `QA-E2E-ksrole description testingQA`;
const roleDescriptionAscSorting = 'QA-E2E-aarole description QAtesting';
const roleDescriptionDescSorting = 'QA-E2E-zzrole description QAtesting';

describe('SPT 6681:As a user, I want to be able to filter the users, groups, and roles list pages Subtask SPT-10502: Functional Test Keyword searching and sorting for roles  ', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Create role for testing', () => {
    it('Create role for keyword searching', () => {
      swimInstance.openRolesListing();
      swimInstance.rolesListing.createNewRole({
        Name: roleNameKeyWordSearching,
        Description: roleDescriptionKeyWordSearching
      });
    });

    it('Create roles for sorting', () => {
      swimInstance.rolesListing.createNewRole({
        Name: roleNameAscSorting,
        Description: roleDescriptionAscSorting
      });
      swimInstance.rolesListing.createNewRole({
        Name: roleNameDescSorting,
        Description: roleDescriptionDescSorting
      });
    });
  });

  describe('Sorting Roles by description', () => {
    it('Sorting by description ASC', () => {
      swimInstance.rolesListing.typeRolePrefix('QA-E2E');
      swimInstance.rolesListing.sortingRolesByDescription(roleDescriptionAscSorting);
    });

    it('Sorting by description DESC', () => {
      swimInstance.rolesListing.sortingRolesByDescription(roleDescriptionDescSorting);
    });
  });

  describe('Sorting Roles by name', () => {
    it('Sorting by name ASC', () => {
      swimInstance.rolesListing.sortingRolesByName(roleNameAscSorting);
      swimInstance.rolesListing.deleteRole(roleNameAscSorting);
    });

    it('Sorting by name DESC', () => {
      swimInstance.rolesListing.sortingRolesByName(roleNameDescSorting);
      swimInstance.rolesListing.deleteRole(roleNameDescSorting);
    });
  });

  describe('Keyword searching Roles', () => {
    it('Keyword Searching', () => {
      swimInstance.rolesListing.keywordSearchingRoles(roleNameKeyWordSearching);
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const taskName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 64);
const pythonCode = `print('''<h1>Hello</h1>''')`;

describe('SPT-12719: Functional Test : Format supported by the rich text field should display in the comment section properly', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Add app with one field', () => {
    it('Add an app to test the workflow', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
    });

    it('Add some fields for the condition', () => {
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.addField('Comments');
      swimInstance.appBuilder.addLayout('Integration');
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Create tasks from the integration action', () => {
    it('Create first python Task', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', taskName, appName);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: pythonCode
      });
      swimInstance.integrationsPage.editTaskOutputMapping({
        updateRecord: { newMappings: { 'Standard Output': 'Comments' } }
      });
    });
    it('Save the task', () => {
      swimInstance.integrationsPage.saveCurrentTask();
    });

    it('configure Task', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.editExistingApp(appName);
      swimInstance.integrationsPage.configureExistingIntegrationTask(taskName);
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Create record and verify Workflow Run History modal', () => {
    it('Create new Record', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecordForApp(appName);
      swimInstance.recordEditor.clickIntegrationButton('Integration', taskName, true, false, true, false, true);
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

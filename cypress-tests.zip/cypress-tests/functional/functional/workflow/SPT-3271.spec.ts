import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const referenceAppName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const selectionValues = ['Open', 'Closed'];
const sublistOfValues = ['0', '1'];
const textConditionValue = faker.lorem.word();

describe('App Builder - Text Fields', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('GIVEN: Add reference application with text field', () => {
    it('build Reference app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(referenceAppName);
      swimInstance.appsAppletsListing.appWizard.createApp();
      swimInstance.appBuilder.verifyElements(referenceAppName);
    });

    it('Add basic text field for reference application', () => {
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('WHEN: Add one more application with selection field and reference field', () => {
    it('build regular app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
    });
    it('Add reference and selection field to the app', () => {
      swimInstance.appBuilder.addField('Reference');
      swimInstance.appBuilder.editAppComponent('Reference', {
        'Reference Application': referenceAppName
      });
      swimInstance.appBuilder.referenceFieldSelectionInTrackingField('Text');
      swimInstance.appBuilder.saveApplication();
      swimInstance.appBuilder.addField('Selection');
      swimInstance.appBuilder.editAppComponent('Selection', {
        AddEditValues: selectionValues
      });

      swimInstance.appBuilder.saveApplication();
    });
  });
});

describe('WHEN:Conditional Node with records count equal to zero', () => {
  it('Condition with Reference field as Zero', () => {
    swimInstance.appBuilder.editWorkflow();
    swimInstance.workflowEditor.verifyElements();
    swimInstance.workflowEditor.addNode(appName, 'condition');
    swimInstance.workflowEditor.editCurrentNode({
      Name: 'Zero Records',
      Field: 'Reference',
      Operator: 'Equals',
      Value: { type: 'Numeric', value: sublistOfValues[0] }
    });
    swimInstance.workflowEditor.saveWorkflow();
  });

  it('Action should be closed when records are Zero', () => {
    swimInstance.workflowEditor.addNode('Zero Records', 'action');
    swimInstance.workflowEditor.editCurrentNode({
      Name: 'Closed',
      'Action Type': 'Set Field Value',
      Field: 'Selection',
      Value: { type: 'Selection', value: selectionValues[1] }
    });
    swimInstance.workflowEditor.saveWorkflow();
  });

  describe('Conditional Node with records count greater than are equal to one', () => {
    it('Condition with Reference field as 1', () => {
      swimInstance.workflowEditor.addNode(appName, 'condition');
      swimInstance.workflowEditor.editCurrentNode({
        Name: 'Greater than or equal to one',
        Field: 'Reference',
        Operator: 'Greater Than or Equal',
        Value: { type: 'Numeric', value: sublistOfValues[1] }
      });
      swimInstance.workflowEditor.saveWorkflow();
    });

    it('Action should be Open when records are greater than or equal to one', () => {
      swimInstance.workflowEditor.addNode('Greater than or equal to one', 'action');
      swimInstance.workflowEditor.editCurrentNode({
        Name: 'Open',
        'Action Type': 'Set Field Value',
        Field: 'Selection',
        Value: { type: 'Selection', value: selectionValues[0] }
      });
      swimInstance.workflowEditor.saveWorkflow();
    });
  });
});

describe('Test The Workflow reference records add and delete', () => {
  it('Selection Should value be closed state', () => {
    swimInstance.switchToWorkspace(`${appName} Workspace`);
    swimInstance.startNewRecordForApp(appName);
    swimInstance.recordEditor.checkSelectionFieldValue(selectionValues[1]);
  });

  it('Add new record and Selection Should value be open state', () => {
    swimInstance.recordEditor.addReferenceRecord(textConditionValue);
    swimInstance.recordEditor.save();
    swimInstance.recordEditor.checkSelectionFieldValue(selectionValues[0]);
  });
  it('Delete the record Selection Should value be Closed state', () => {
    swimInstance.recordEditor.deleteRecord();
    swimInstance.recordEditor.checkSelectionFieldValue(selectionValues[1]);
  });
});

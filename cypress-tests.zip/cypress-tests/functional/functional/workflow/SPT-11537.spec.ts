import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const taskName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 64);
const pythonCode = 'import time \ntime.sleep(1)\nprint(sw_context.inputs["textIn"])';
const sublistOfValues = 1;

describe('Workflow - Integrations in workflow SPT-11537 and SPT-11373 - Edit Task link no longer visible in workflow', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Add app with one field', () => {
    it('Add an app to test the workflow', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
    });

    it('Add some fields for the condition', () => {
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Navigate to the workflow of the app', () => {
    it('Create a workflow condition and add an action', () => {
      swimInstance.appBuilder.editWorkflow();
      swimInstance.workflowEditor.verifyElements();
      swimInstance.workflowEditor.addNode(appName, 'condition');
      swimInstance.workflowEditor.editCurrentNode({
        Name: 'Numeric Field Equals',
        Field: 'Numeric',
        Operator: 'Equals',
        Value: { type: 'Numeric', value: sublistOfValues }
      });
      swimInstance.workflowEditor.saveWorkflow();
    });

    it('Add trigger integration action', () => {
      swimInstance.workflowEditor.addNode('Numeric Field Equals', 'action');
      swimInstance.workflowEditor.editCurrentNode({
        Name: 'Trigger integration',
        'Action Type': 'Trigger Integration'
      });
    });
  });

  describe('Create a task from the integration action', () => {
    it('Add a task from the integration', () => {
      swimInstance.workflowEditor.integrationWorkflow('create');
      swimInstance.integrationsPage.setupTask('Python 3', taskName, appName);
      swimInstance.integrationsPage.setBypassTimeout(false);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: pythonCode,
        inputs: { Variable: 'textIn', Type: 'Record', Field: 'Tracking Id' }
      });
      swimInstance.integrationsPage.saveCurrentTask(true, false);
      swimInstance.workflowEditor.verifyTaskName(taskName);
      swimInstance.workflowEditor.saveWorkflow();
    });

    it('Exit Application and re-enter, verify that Edit Task link is still visible', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.editExistingApp(appName);
      swimInstance.appBuilder.editWorkflow();
      swimInstance.workflowEditor.clickNode('Trigger integration');
      swimInstance.workflowEditor.verifyEditTaskLink();
    });

    it('Edit and remove the task from the integration', () => {
      swimInstance.workflowEditor.integrationWorkflow('edit', taskName);
      swimInstance.integrationsPage.removeTask();
      swimInstance.workflowEditor.integrationWorkflow('remove');
      swimInstance.workflowEditor.saveWorkflow();
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const USERLIST = [];

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const listOfValues = ['One', 'Two', 'Three', 'Four'];
const sublistOfValues = ['One', 'Three'];
let testUser1JSON = {};
let testUser2JSON = {};

describe('SPT-5679: Workflow nodes with multi-select field types', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');

    testUser1JSON = swimInstance.createUserJSON();
    testUser2JSON = swimInstance.createUserJSON();
  });

  describe('Create users for multi-select user/groups field', () => {
    it('Create users for testing', () => {
      [testUser1JSON, testUser2JSON].forEach(user => {
        (cy as any).makeAPICall('POST', 'user', { ...user, notify: false });
        USERLIST.push((user as any).displayName);
      });
    });
  });

  describe('Create app with multi-select fields for workflow testing', () => {
    it('Create app for testing', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
    });

    it('Build fields into App', () => {
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.addField('selection Multi-select');
      swimInstance.appBuilder.editAppComponent('Multi-select', {
        Name: 'Multi-select selection',
        AddEditValues: listOfValues
      });
      swimInstance.appBuilder.addField('usergroup Multi-select');
      swimInstance.appBuilder.editAppComponent('User/Groups', {
        Name: 'Multi-select usergroup'
      });

      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Test the workflow nodes for multi-value Selection field type', () => {
    describe('Conditional Node', () => {
      it('Edit node for multi-select selection to match multiple values', () => {
        swimInstance.appBuilder.editWorkflow();
        swimInstance.workflowEditor.verifyElements();
        swimInstance.workflowEditor.addNode(appName, 'condition');
        swimInstance.workflowEditor.editCurrentNode({
          Name: 'Multi-select selection Field Equals',
          Field: 'Multi-select selection',
          Operator: 'Equals',
          Value: { type: 'Selection', value: sublistOfValues }
        });
        swimInstance.workflowEditor.saveWorkflow();
      });

      it('Verify conditional node after saving', () => {
        swimInstance.workflowEditor.verifyWorkflowNodeSettings({
          Name: 'Multi-select selection Field Equals',
          Field: 'Multi-select selection',
          Operator: 'Equals',
          Value: sublistOfValues
        });
      });
    });

    describe('Action Nodes', () => {
      describe('Set Field Value Action node', () => {
        it('Edit node for set multi-select selection to multiple values', () => {
          swimInstance.workflowEditor.addNode('Multi-select selection Field Equals', 'action');
          swimInstance.workflowEditor.editCurrentNode({
            Name: 'Multi-select selection Set Field',
            'Action Type': 'Set Field Value',
            Field: 'Multi-select selection',
            Value: { type: 'Selection', value: sublistOfValues }
          });
          swimInstance.workflowEditor.saveWorkflow();
        });

        it('Verify action node after saving', () => {
          swimInstance.workflowEditor.verifyWorkflowNodeSettings({
            Name: 'Multi-select selection Set Field',
            'Action Type': 'Set Field Value',
            Field: 'Multi-select selection',
            Value: sublistOfValues
          });
        });
      });

      describe('Filter Selection Action node', () => {
        it('Edit node for Filter Field Value for multi-select selection to multiple values', () => {
          swimInstance.workflowEditor.addNode('Multi-select selection Field Equals', 'action');
          swimInstance.workflowEditor.editCurrentNode({
            Name: 'Multi-select selection filter options',
            'Action Type': 'Filter Selection Options',
            'Selection Field': 'Multi-select selection',
            'Selectable Values': { type: 'Selection', value: sublistOfValues }
          });
          swimInstance.workflowEditor.saveWorkflow();
        });

        it('Verify action node after saving', () => {
          swimInstance.workflowEditor.verifyWorkflowNodeSettings({
            Name: 'Multi-select selection filter options',
            'Action Type': 'Filter Selection Options',
            'Selection Field': 'Multi-select selection',
            'Selectable Values': sublistOfValues
          });
        });
      });
    });
  });

  describe('Test the workflow nodes for multi-value user field types', () => {
    describe('Conditional Node', () => {
      it('Edit node for multi-select user/groups to match multiple values', () => {
        swimInstance.workflowEditor.addNode(appName, 'condition');
        swimInstance.workflowEditor.editCurrentNode({
          Name: 'Multi-select user Field Equals',
          Field: 'Multi-select usergroup',
          Operator: 'Equals',
          Value: { type: 'UserGroup', value: USERLIST }
        });
        swimInstance.workflowEditor.saveWorkflow();
      });

      it('Verify conditional node after saving', () => {
        swimInstance.workflowEditor.verifyWorkflowNodeSettings({
          Name: 'Multi-select user Field Equals',
          Field: 'Multi-select usergroup',
          Operator: 'Equals',
          Value: USERLIST
        });
      });
    });

    describe('Action Node', () => {
      describe('Set Field Value', () => {
        it('Edit node for set multi-select user/group to multiple values', () => {
          swimInstance.workflowEditor.addNode('Multi-select user Field Equals', 'action');
          swimInstance.workflowEditor.editCurrentNode({
            Name: 'Multi-select user Set Field',
            'Action Type': 'Set Field Value',
            Field: 'Multi-select usergroup',
            Value: { type: 'UserGroup', value: USERLIST }
          });
          swimInstance.workflowEditor.fitWorkflowToView();
          swimInstance.workflowEditor.saveWorkflow();
        });

        it('Verify action node after saving', () => {
          swimInstance.workflowEditor.clickNode('Multi-select user Field Equals');
          cy.wait(500); // Let this node load before switching back
          swimInstance.workflowEditor.clickNode('Multi-select user Set Field');
          swimInstance.workflowEditor.verifyWorkflowNodeSettings({
            Name: 'Multi-select user Set Field',
            'Action Type': 'Set Field Value',
            Field: 'Multi-select usergroup',
            Value: USERLIST
          });
        });
      });
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

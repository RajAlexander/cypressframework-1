import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const taskName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 64);
const pythonCode = 'import time \ntime.sleep(1)\nprint(sw_context.inputs["textIn"])';
const sublistOfValues = 1;
let recordTrackingId = '';

describe('SPT-12560: Functional Test: UI Automation of "/task/hangfire/{jobId}/requeue"', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Add app with one field', () => {
    it('Add an app to test the workflow', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.createApp();
    });

    it('Add some fields for the condition', () => {
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.addField('Text');
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.saveApplication();
    });
  });
  describe('Create tasks from the integration action', () => {
    it('Create first python Task', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', taskName, appName);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: pythonCode,
        inputs: { Variable: 'textIn', Type: 'Record', Field: 'Tracking Id' }
      });
      swimInstance.integrationsPage.editTaskOutputMapping({
        updateRecord: { newMappings: { 'Standard Output': 'Text' } }
      });
    });
    it('Save the task', () => {
      swimInstance.integrationsPage.saveCurrentTask();
    });
  });

  describe('Navigate to the workflow of the app', () => {
    it('Create a workflow condition and add an action', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.editExistingApp(appName);
      swimInstance.appBuilder.editWorkflow();
      swimInstance.workflowEditor.verifyElements();
      swimInstance.workflowEditor.addNode(appName, 'condition');
      swimInstance.workflowEditor.editCurrentNode({
        Name: 'Numeric Field Equals',
        Field: 'Numeric',
        Operator: 'Equals',
        Value: { type: 'Numeric', value: sublistOfValues }
      });
    });
    it('Add trigger integration action', () => {
      swimInstance.workflowEditor.addNode('Numeric Field Equals', 'action');
      swimInstance.workflowEditor.editCurrentNode({
        Name: 'Trigger integration',
        'Action Type': 'Trigger Integration',
        Integration: taskName
      });
      swimInstance.workflowEditor.saveWorkflow();
    });
  });

  describe('Create record and verify Workflow Run History modal', () => {
    it('Create new Record', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecordForApp(appName);
      swimInstance.recordEditor.setFieldValue({
        Numeric: { value: sublistOfValues }
      });
      swimInstance.recordEditor.save();
      swimInstance.recordEditor.getRecordTrackingID(true).then($trackingID => {
        recordTrackingId = $trackingID;
      });
    });

    it('Click on View Workflow Run', () => {
      swimInstance.OpenAppListAll(appName);
      swimInstance.recordListing.openRecordWorkflowResults(recordTrackingId);
      swimInstance.workflowEditor.triggerHangfireTask();
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

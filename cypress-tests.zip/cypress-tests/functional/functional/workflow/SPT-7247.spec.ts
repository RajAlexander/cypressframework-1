import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
const appName1 = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 128);
let recordTrackingIdGTE = '';
let recordTrackingIdLT = '';
const lt5Value = faker.random.number({ max: 4 });
const gte5Value = faker.random.number({ min: 5 });

describe('SPT-7247: Workflow conditional nodes with referenced record field should all all operators.', () => {
  before(() => {
    cy.login();
    cy.visitSwimlane('/');
  });

  describe('Set up the 2 apps', () => {
    describe('Build the referenced app', () => {
      it('Start the referenced app', () => {
        swimInstance.openAppAppletsList();
        swimInstance.appsAppletsListing.startNewApp();
        swimInstance.appsAppletsListing.appWizard.setAppName(appName);
        swimInstance.appsAppletsListing.appWizard.createApp();
      });

      it('Build fields into referenced App', () => {
        swimInstance.appBuilder.verifyElements(appName);
        swimInstance.appBuilder.addField('Text');
        swimInstance.appBuilder.addField('Numeric');
        swimInstance.appBuilder.saveApplication();
      });
    });

    describe('Build the parent app', () => {
      it('Start the parent app', () => {
        swimInstance.openAppAppletsList();
        swimInstance.appsAppletsListing.startNewApp();
        swimInstance.appsAppletsListing.appWizard.setAppName(appName1);
        swimInstance.appsAppletsListing.appWizard.setAppWorkspace(`${appName} Workspace`);
        swimInstance.appsAppletsListing.appWizard.createApp();
      });

      it('Build fields into parent App', () => {
        swimInstance.appBuilder.verifyElements(appName1);
        swimInstance.appBuilder.addField('Text');
        swimInstance.appBuilder.addField('Reference');
        swimInstance.appBuilder.editAppComponent('Reference', {
          'Reference Application': appName
        });
        swimInstance.appBuilder.saveApplication();
      });
    });

    describe('Set workflow for referenced record field in conditional', () => {
      it('Open the workflow', () => {
        swimInstance.appBuilder.editWorkflow();
      });

      it('Add Conditional based on ref record field less then 5.', () => {
        swimInstance.workflowEditor.verifyElements();
        swimInstance.workflowEditor.addNode(appName1, 'condition');
        swimInstance.workflowEditor.editCurrentNode({
          Name: 'Ref Num lt 5',
          Field: 'Reference',
          'Evaluation Target': 'Target Field',
          'Select Target Field': ['Numeric'],
          Operator: 'Less Than',
          Value: { type: 'Numeric', value: '5' }
        });
        swimInstance.workflowEditor.saveWorkflow();
      });

      it('Add Conditional based on ref record field greater then or equal 5.', () => {
        swimInstance.workflowEditor.addNode(appName1, 'condition');
        swimInstance.workflowEditor.editCurrentNode({
          Name: 'Ref Num gte 5',
          Field: 'Reference',
          'Evaluation Target': 'Target Field',
          'Select Target Field': ['Numeric'],
          Operator: 'Greater Than or Equal',
          Value: { type: 'Numeric', value: '5' }
        });
        swimInstance.workflowEditor.saveWorkflow();
      });

      it('Add action off of lt conditional', () => {
        swimInstance.workflowEditor.addNode('Ref Num lt 5', 'action');
        swimInstance.workflowEditor.editCurrentNode({
          'Action Type': 'Set Field Value',
          Field: 'Text',
          Value: { type: 'Text', value: 'Referenced Numeric is less then 5' }
        });
      });

      it('Add action off of gte conditional', () => {
        swimInstance.workflowEditor.addNode('Ref Num gte 5', 'action');
        swimInstance.workflowEditor.editCurrentNode({
          'Action Type': 'Set Field Value',
          Field: 'Text',
          Value: {
            type: 'Text',
            value: 'Referenced Numeric is greater then or equal 5'
          }
        });
        swimInstance.workflowEditor.saveWorkflow();
      });
    });
  });

  describe('Test The Workflow', () => {
    it('Create target record lt 5', () => {
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecordForApp(appName);
      swimInstance.recordEditor.setFieldValue({ Numeric: { value: lt5Value } });
      swimInstance.recordEditor.save();
      swimInstance.recordEditor.getRecordTrackingID(true).then($trackingID => {
        recordTrackingIdLT = $trackingID;
      });
    });

    it('Create target record gte 5', () => {
      swimInstance.startNewRecordForApp(appName);
      swimInstance.recordEditor.setFieldValue({
        Numeric: { value: gte5Value }
      });
      swimInstance.recordEditor.save();
      swimInstance.recordEditor.getRecordTrackingID(true).then($trackingID => {
        recordTrackingIdGTE = $trackingID;
      });
    });

    it('Create main Record lt 5', () => {
      swimInstance.startNewRecordForApp(appName1);
      swimInstance.recordEditor.setFieldValue({
        Reference: [recordTrackingIdLT]
      });
      swimInstance.recordEditor.save();
      swimInstance.recordEditor.verifyFieldValues({ Text: 'Referenced Numeric is less then 5' }, false);
    });

    it('Create main record gte 5', () => {
      swimInstance.startNewRecordForApp(appName1);
      swimInstance.recordEditor.setFieldValue({
        Reference: [recordTrackingIdGTE]
      });
      swimInstance.recordEditor.save();
      swimInstance.recordEditor.verifyFieldValues({ Text: 'Referenced Numeric is greater then or equal 5' }, false);
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

import * as swimInstance from '../../support/page-objects/swimInstance';
import faker from 'faker/locale/en';

const appName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 64);
const taskName = `QA-E2E- ${faker.company.catchPhrase()}`.substring(0, 64);
const pythonCode = 'Testing';

const APPLIST = [];
const WORKSPACELIST = [];
let appId = '';

describe('SPT 891:Improve Logging & Logging Page UI Subtask SPT-3411: Implement Logs UI component ', () => {
  before(() => {
    cy.login();
    cy.cleanupSwimlane();
    cy.visitSwimlane('/');
  });

  describe('Create App', () => {
    it('build app', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.startNewApp();
      swimInstance.appsAppletsListing.appWizard.setAppName(appName);
      swimInstance.appsAppletsListing.appWizard.getAppAcronym();
      swimInstance.appsAppletsListing.appWizard.createApp();
      APPLIST.push(appName);
      WORKSPACELIST.push(`${appName} Workspace`);
    });

    it('Add fields', () => {
      swimInstance.appBuilder.verifyElements(appName);
      swimInstance.appBuilder.getAppID().then($appID => {
        appId = $appID;
      });
      swimInstance.appBuilder.addField('Single-Line');
      swimInstance.appBuilder.addField('Numeric');
      swimInstance.appBuilder.addLayout('Integration');
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Creating a task with errors', () => {
    it('Create python task to trigger error', () => {
      swimInstance.openIntegrations();
      swimInstance.integrationsPage.createNewTask();
      swimInstance.integrationsPage.setupTask('Python 3', taskName, appName);
      swimInstance.integrationsPage.setBypassTimeout(false);
      swimInstance.integrationsPage.editTaskConfiguration({
        script: pythonCode
      });
      swimInstance.integrationsPage.saveCurrentTask(false);
    });

    it('Close the Task', () => {
      swimInstance.integrationsPage.closeTask();
    });

    it('Add task to the app via push button', () => {
      swimInstance.openAppAppletsList();
      swimInstance.appsAppletsListing.editExistingApp(appName);
      swimInstance.appBuilder.editAppComponent('Integration', {
        Name: 'Trigger Task',
        Task: taskName
      });
    });

    it('Save the App', () => {
      swimInstance.appBuilder.saveApplication();
    });
  });

  describe('Create record to run failed integration and generate a new log', () => {
    it('Create record', () => {
      cy.wait(1000);
      swimInstance.switchToWorkspace(`${appName} Workspace`);
      swimInstance.startNewRecordForApp(appName);
      swimInstance.recordEditor.setFieldValue({
        Text: { value: 'swimlane.com' }
      });
      swimInstance.recordEditor.save('Record saved');
    });

    it('Trigger the integration via push button', () => {
      swimInstance.recordEditor.clickIntegrationButton('Trigger Task', taskName, true, false, true, true);
    });
  });

  describe('Validate Log instance created on logging page', () => {
    it('Open Logging page and verify for the new log added', () => {
      swimInstance.openLogging();
      cy.get('table').should('contain', pythonCode);
    });
  });

  after(() => {
    cy.cleanupSwimlane();
    cy.logout();
  });
});

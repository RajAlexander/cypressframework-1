describe('Export Dialog', () => {
  before(() => {
    cy.deleteDownloadsFolder();
    cy.login();

    cy.setupStubbedSwimlane();

    cy.navigateSwimlane(`/apps`);
  });

  beforeEach(() => {
    cy.setupStubbedSwimlane();
  });

  describe('Application Export', () => {
    it('one error', () => {
      cy.intercept('POST', '/api/content/export/try', {
        fixture: 'mocks/swimlane/content/export/try/post-error.json'
      }).as('POST:content/export/try');

      cy.get('.app-tools')
        .eq(2)
        .within(() => {
          cy.get('.ngx-dropdown-toggle button').click();
          cy.get('.vertical-list').contains('Export').click();
        });

      cy.get('.app-export--container').should('exist');

      cy.wait('@POST:content/export/try');

      cy.get('.app-export--container .ngx-dialog-header').should('contain', 'Application Export');

      cy.get('.app-export--message')
        .should('contain', 'Error Detected')
        .should('contain', 'You must resolve this error before you can continue to export this application.')
        .should('contain', 'The application aRIlkHzEA3Lou9JvS was not found.');

      cy.get('.ngx-dialog-footer').within(() => {
        cy.get('.btn').should('have.length', 2);
        cy.get('.btn').contains('Close').click();
      });

      cy.get('.app-export--container', { timeout: 1000 }).should('not.exist');
    });

    it('few issues', () => {
      cy.get('.app-tools')
        .eq(2)
        .within(() => {
          cy.get('.ngx-dropdown-toggle button').click();
          cy.get('.vertical-list').contains('Export').click();
        });

      cy.get('.app-export--container').should('exist');

      cy.wait('@POST:content/export/try');

      cy.get('.app-export--container .ngx-dialog-header').should('contain', 'Application Export');

      cy.get('.app-export--message')
        .should('contain', 'Review Potential Issues')
        .should('contain', 'You can choose to resolve these now or continue exporting.');

      cy.get('.app-export--preview').within(() => {
        cy.get('ngx-card-header').should('contain', 'Application 2');
        cy.get('ngx-card-section')
          .should('contain', '1 Application')
          .should('contain', '1 Report')
          .should('contain', '1 Workspace')
          .should('contain', '1 Task')
          .should('contain', '1 Asset');
      });

      cy.get('.app-export-content .entity-section')
        .eq(0)
        .within(() => {
          cy.get('ngx-card-header').should('contain', 'Application 2');
          cy.get('ngx-card-section').should('contain', '1 Issue');
          cy.get('.entity-issue')
            .should('contain', 'Task undefined for this integration button')
            .should('contain', 'Integration');
        });

      cy.get('.app-export-content .entity-section')
        .eq(1)
        .within(() => {
          cy.get('ngx-card-header')
            .should('contain', 'Alien')
            .should('contain', 'Alienvault OTX Get IP')
            .should('contain', '2.1.1');
          cy.get('ngx-card-section').should('contain', '2 Issues');
          cy.get('.entity-issue').first().should('contain', 'Some issue');
          cy.get('.entity-issue').eq(1).should('contain', 'Another issue');
        });

      cy.get('.app-export-content .entity-section')
        .eq(2)
        .within(() => {
          cy.get('ngx-card-header')
            .should('contain', 'AlienVault OTX')
            .should('contain', 'Alienvault Open Threat Exchange')
            .should('contain', '2.1.1');
          cy.get('ngx-card-section').should('contain', '1 Issue');
          cy.get('.entity-issue').should('contain', 'Some issue');
        });

      cy.get('.ngx-dialog-footer').within(() => {
        cy.get('.btn').should('have.length', 2);
        cy.get('.btn').contains('Continue Export').click();
      });

      cy.wait('@POST:content/export/download').then(xhr => {
        assert.isNotNull(xhr.response.body, 'Body not empty');
      });

      cy.get('.ngx-notification-container .ngx-notification-body').should('contain', 'Application exported');

      cy.get('.app-export--container', { timeout: 1000 }).should('not.exist');

      cy.findInDownloads('Application 2.ssp');
    });

    it('credential issue', () => {
      cy.intercept('POST', '/api/content/export/try', {
        fixture: 'mocks/swimlane/content/export/try/post-cred-issue.json'
      }).as('POST:content/export/try');

      cy.get('.app-tools')
        .eq(2)
        .within(() => {
          cy.get('.ngx-dropdown-toggle button').click();
          cy.get('.vertical-list').contains('Export').click();
        });

      cy.get('.app-export--container').should('exist');

      cy.wait('@POST:content/export/try');

      cy.get('.app-export--container .ngx-dialog-header').should('contain', 'Application Export');

      cy.get('.app-export--message').within(() => {
        cy.get('h4').should('contain', 'Your export is ready for download');
        cy.get('ngx-tip').should(
          'contain',
          'Secure credentials are not included in exported tasks and assets and can be configured later.'
        );
      });

      cy.get('.ngx-dialog-footer').within(() => {
        cy.get('.btn').should('have.length', 2);
        cy.get('.btn').contains('Continue Export').click();
      });

      cy.wait('@POST:content/export/download').then(xhr => {
        assert.isNotNull(xhr.response.body, 'Body not empty');
      });

      cy.get('.ngx-notification-container .ngx-notification-body').should('contain', 'Application exported');
      cy.get('.app-export--container', { timeout: 1000 }).should('not.exist');

      cy.findInDownloads('Application 1.ssp');
    });

    it('no issues', () => {
      cy.intercept('POST', '/api/content/export/try', {
        fixture: 'mocks/swimlane/content/export/try/post-clean.json'
      }).as('POST:content/export/try');

      cy.get('.app-tools')
        .eq(2)
        .within(() => {
          cy.get('.ngx-dropdown-toggle button').click();
          cy.get('.vertical-list').contains('Export').click();
        });

      cy.get('.app-export--container').should('exist');

      cy.wait('@POST:content/export/try');

      cy.get('.app-export--container .ngx-dialog-header').should('contain', 'Application Export');

      cy.get('.app-export--preview').find('ngx-card-header').should('contain', 'Application 1');
      cy.get('.app-export--message h4').should('contain', 'Your export is ready for download.');

      cy.get('.ngx-dialog-footer').within(() => {
        cy.get('.btn').should('have.length', 2);
        cy.get('.btn').contains('Continue Export').click();
      });

      cy.wait('@POST:content/export/download').then(xhr => {
        assert.isNotNull(xhr.response.body, 'Body not empty');
      });

      cy.get('.ngx-notification-container .ngx-notification-body').should('contain', 'Application exported');
      cy.get('.app-export--container', { timeout: 1000 }).should('not.exist');

      cy.findInDownloads('Application 1.ssp');
    });
  });

  describe('Applet Export', () => {
    it('few errors', () => {
      cy.intercept('POST', '/api/content/export/try', {
        fixture: 'mocks/swimlane/content/export/try/post-errors.json'
      }).as('POST:content/export/try');

      cy.get('.app-tools')
        .eq(0)
        .within(() => {
          cy.get('.ngx-dropdown-toggle button').click();
          cy.get('.vertical-list').contains('Export').click();
        });

      cy.get('.app-export--container').should('exist');

      cy.wait('@POST:content/export/try');

      cy.get('.app-export--container .ngx-dialog-header').should('contain', 'Applet Export');

      cy.get('.app-export--message')
        .should('contain', 'Errors Detected')
        .should('contain', 'You must resolve these errors before you can continue to export this applet.')
        .should('contain', 'The applet aRIlkHzEA3Lou9JvS was not found.');

      cy.get('.ngx-dialog-footer').within(() => {
        cy.get('.btn').should('have.length', 2);
        cy.get('.btn').contains('Close').click();
      });

      cy.get('.app-export--container', { timeout: 1000 }).should('not.exist');
    });

    it('one issue', () => {
      cy.intercept('POST', '/api/content/export/try', {
        fixture: 'mocks/swimlane/content/export/try/post-issue.json'
      }).as('POST:content/export/try');

      cy.get('.app-tools')
        .eq(0)
        .within(() => {
          cy.get('.ngx-dropdown-toggle button').click();
          cy.get('.vertical-list').contains('Export').click();
        });

      cy.get('.app-export--container').should('exist');

      cy.wait('@POST:content/export/try');

      cy.get('.app-export--container .ngx-dialog-header').should('contain', 'Applet Export');

      cy.get('.app-export--message')
        .should('contain', 'Review Potential Issue')
        .should('contain', 'You can choose to resolve this now or continue exporting.');

      cy.get('.app-export--preview').within(() => {
        cy.get('ngx-card-header').should('contain', 'Applet 2');
        cy.get('ngx-card-section')
          .should('contain', '1 Applet')
          .should('contain', '1 Report')
          .should('contain', '1 Workspace')
          .should('contain', '1 Task')
          .should('contain', '1 Asset');
      });

      cy.get('.app-export-content .entity-section')
        .first()
        .within(() => {
          cy.get('ngx-card-header').should('contain', 'Applet 2');
          cy.get('ngx-card-section').should('contain', '1 Issue');
          cy.get('.entity-issue')
            .should('contain', 'Task undefined for this integration button')
            .should('contain', 'Integration');
        });

      cy.get('.ngx-dialog-footer').within(() => {
        cy.get('.btn').should('have.length', 2);
        cy.get('.btn').contains('Continue Export').click();
      });

      cy.wait('@POST:content/export/download').then(xhr => {
        assert.isNotNull(xhr.response.body, 'Body not empty');
      });

      cy.get('.ngx-notification-container .ngx-notification-body').should('contain', 'Applet exported');

      cy.get('.app-export--container', { timeout: 1000 }).should('not.exist');

      cy.findInDownloads('Applet 2.ssp');
    });

    it('no issues', () => {
      cy.intercept('POST', '/api/content/export/try', {
        fixture: 'mocks/swimlane/content/export/try/post-clean-applet.json'
      }).as('POST:content/export/try');

      cy.get('.app-tools')
        .eq(0)
        .within(() => {
          cy.get('.ngx-dropdown-toggle button').click();
          cy.get('.vertical-list').contains('Export').click();
        });

      cy.get('.app-export--container').should('exist');

      cy.wait('@POST:content/export/try');

      cy.get('.app-export--container .ngx-dialog-header').should('contain', 'Applet Export');

      cy.get('.app-export--preview').find('ngx-card-header').should('contain', 'Applet 1');

      cy.get('.app-export--message h4').should('contain', 'Your export is ready for download.');

      cy.get('.ngx-dialog-footer').within(() => {
        cy.get('.btn').should('have.length', 2);
        cy.get('.btn').contains('Continue Export').click();
      });

      cy.wait('@POST:content/export/download').then(xhr => {
        assert.isNotNull(xhr.response.body, 'Body not empty');
      });

      cy.get('.ngx-notification-container .ngx-notification-body').should('contain', 'Applet exported');
      cy.get('.app-export--container', { timeout: 1000 }).should('not.exist');

      cy.findInDownloads('Applet 1.ssp');
    });
  });
});

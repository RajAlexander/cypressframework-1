describe('Navbar', () => {
  before(() => {
    cy.clearExpandedMenu();

    cy.login();

    cy.setupStubbedSwimlane();
    cy.navigateSwimlane('/');
    cy.wait('@getEnabledFlags');
  });

  beforeEach(() => {
    cy.get('navigation-bar').as('nav-bar');
    cy.get('@nav-bar').find('.nav-item-container').as('nav-items');
    cy.get('@nav-bar').find('.ngx-nav-menu').as('nav-menu');
  });

  describe('nav bar has less than 6 dashboards and application records', () => {
    const appId = 'ad2xJUGes5TNRKG4M';
    const workspaceId = 'aP6rDZMhfXU0550sc';
    const dashboardId = '5d321ea175df8a0319656f01';

    it('has items', () => {
      cy.get('@nav-items').should('have.length', 10);
    });

    it('starts expanded', () => {
      cy.get('.app-container').should('have.class', 'nav-open');
      cy.get('@nav-menu').should('have.class', 'expanded');
    });

    it('expands and collapses', () => {
      cy.get('.flyout-bar').click();
      cy.get('.app-container', { timeout: 300 }).should('not.have.class', 'nav-open');
      cy.get('@nav-menu', { timeout: 300 }).should('not.have.class', 'expanded');
      cy.get('.flyout-bar').click();
      cy.get('.app-container').should('have.class', 'nav-open');
      cy.get('@nav-menu').should('have.class', 'expanded');
    });

    describe('expanded', () => {
      it('nav bar when expanded should display nav items with correct text titles', () => {
        cy.get('.app-container').should('have.class', 'nav-open');
        cy.get('@nav-items').should('have.length', 10);
        cy.get('@nav-items').first().should('contain', 'Workspaces');
        cy.get('@nav-items').eq(1).should('contain', 'Dashboards');
        cy.get('@nav-items').eq(2).should('contain', 'Application Records');
        cy.get('@nav-items').eq(3).should('contain', 'Reports');
        cy.get('@nav-items').eq(4).should('contain', 'Administrator');
        cy.get('@nav-items').eq(5).should('contain', 'Applications & Applets');
        cy.get('@nav-items').eq(6).should('contain', 'Integrations');
        cy.get('@nav-items').eq(7).should('contain', 'Workspace Management');
        cy.get('@nav-items').eq(8).should('contain', 'Users, Groups & Roles');
        cy.get('@nav-items').eq(9).should('contain', 'Settings');
      });
    });

    describe('collapsed', () => {
      before(() => {
        cy.get('.flyout-bar').click();
      });

      it('nav bar when collapsed should display tooltips of nav items with correct text titles on mouseenter', () => {
        cy.get('@nav-items').should('have.length', 10);

        cy.get('@nav-items')
          .first()
          .whileHovering(() => {
            cy.root().closest('body').find('ngx-tooltip-content .title').should('have.text', 'Workspaces');
          });
        cy.get('ngx-tooltip-content', { timeout: 300 }).should('not.exist');

        cy.get('@nav-items')
          .eq(1)
          .whileHovering(() => {
            cy.root().closest('body').find('ngx-tooltip-content .title').should('have.text', 'Dashboards');
          });
        cy.get('ngx-tooltip-content', { timeout: 300 }).should('not.exist');

        cy.get('@nav-items')
          .eq(2)
          .whileHovering(() => {
            cy.root().closest('body').find('ngx-tooltip-content .title').should('have.text', 'Application Records');
          });
        cy.get('ngx-tooltip-content', { timeout: 300 }).should('not.exist');

        cy.get('@nav-items')
          .eq(3)
          .whileHovering(() => {
            cy.root().closest('body').find('ngx-tooltip-content .title').should('have.text', 'Reports');
          });
        cy.get('ngx-tooltip-content', { timeout: 300 }).should('not.exist');

        cy.get('@nav-items').eq(4).should('contain', 'Admin');

        cy.get('@nav-items')
          .eq(5)
          .whileHovering(() => {
            cy.root().closest('body').find('.tooltip-content').should('have.text', 'Applications & Applets');
          });
        cy.get('.tooltip-content', { timeout: 300 }).should('not.exist');

        cy.get('@nav-items')
          .eq(6)
          .whileHovering(() => {
            cy.root().closest('body').find('.tooltip-content').should('have.text', 'Integrations');
          });
        cy.get('.tooltip-content', { timeout: 300 }).should('not.exist');

        cy.get('@nav-items')
          .eq(7)
          .whileHovering(() => {
            cy.root().closest('body').find('ngx-tooltip-content .title').should('have.text', 'Workspace Management');
          });
        cy.get('ngx-tooltip-content', { timeout: 300 }).should('not.exist');

        cy.get('@nav-items')
          .eq(8)
          .whileHovering(() => {
            cy.root().closest('body').find('ngx-tooltip-content .title').should('have.text', 'Users, Groups & Roles');
          });
        cy.get('ngx-tooltip-content', { timeout: 300 }).should('not.exist');

        cy.get('@nav-items')
          .eq(9)
          .whileHovering(() => {
            cy.root().closest('body').find('ngx-tooltip-content .title').should('have.text', 'Settings');
          });
        cy.get('ngx-tooltip-content', { timeout: 300 }).should('not.exist');
      });

      it('dashboard list appears on mouseenter as links and search bar should not be visible', () => {
        cy.get('@nav-items')
          .eq(1)
          .whileHovering(() => {
            cy.root()
              .closest('body')
              .find('ngx-tooltip-content')
              .should('be.visible')
              .within(() => {
                cy.get('ngx-input', { timeout: 300 }).should('not.exist');
                cy.get('.vertical-list li a .subnav-label').should('exist');
                cy.get('.vertical-list li a .subnav-label').first().should('contain', 'Dashboard 1');
                cy.get('.vertical-list li a')
                  .first()
                  .should('have.attr', 'href', `/workspace/${workspaceId}/${dashboardId}`);
              });
          });
        cy.get('ngx-tooltip-content', { timeout: 300 }).should('not.exist');
      });

      it('workspaces and dashboards appear on mouseenter as links and search bar should not be visible', () => {
        cy.get('@nav-items')
          .eq(7)
          .whileHovering(() => {
            cy.root()
              .closest('body')
              .find('ngx-tooltip-content')
              .should('be.visible')
              .within(() => {
                cy.get('ngx-input', { timeout: 300 }).should('not.exist');
                cy.get('.vertical-list li a .subnav-label').should('exist');
                cy.get('.vertical-list li a .subnav-label').first().should('contain', 'Workspaces');
                cy.get('.vertical-list li a').first().should('have.attr', 'href', '/workspaces');
                cy.get('.vertical-list li a .subnav-label').eq(1).should('contain', 'Dashboards');
                cy.get('.vertical-list li a').eq(1).should('have.attr', 'href', '/dashboards');
              });
          });
        cy.get('ngx-tooltip-content', { timeout: 300 }).should('not.exist');
      });

      it('application records list appears on mouseenter as links and search bar should not be visible', () => {
        cy.get('@nav-items')
          .eq(2)
          .whileHovering(() => {
            cy.root()
              .closest('body')
              .find('ngx-tooltip-content')
              .should('be.visible')
              .within(() => {
                cy.get('ngx-input', { timeout: 300 }).should('not.exist');
                cy.get('.vertical-list li a .subnav-label').should('exist');
                cy.get('.vertical-list li a .subnav-label').first().should('contain', 'Application 1');
                cy.get('.vertical-list li a').first().should('have.attr', 'href', `/search/${appId}/`);
                cy.get('.vertical-list li a').eq(1).should('have.attr', 'href', `/record/${appId}/`);
              });
          });
        cy.get('ngx-tooltip-content', { timeout: 300 }).should('not.exist');
      });
    });
  });

  describe('nav bar has more than 6 dashboards and application records', () => {
    before(() => {
      cy.clearExpandedMenu();

      cy.setupStubbedSwimlane();
      cy.intercept('/api/workspaces/nav', {
        fixture: 'mocks/swimlane/workspaces/nav/get-2.json'
      }).as('GET:workspaces/nav');
      cy.navigateSwimlane('/', { forceReload: true });
    });

    it('starts expanded', () => {
      cy.get('.app-container').should('have.class', 'nav-open');
      cy.get('@nav-menu').should('have.class', 'expanded');
    });

    it('expands and collapses', () => {
      cy.get('.flyout-bar').click();
      cy.get('.app-container', { timeout: 300 }).should('not.have.class', 'nav-open');
      cy.get('@nav-menu', { timeout: 300 }).should('not.have.class', 'expanded');
      cy.get('.flyout-bar').click();
      cy.get('.app-container').should('have.class', 'nav-open');
      cy.get('@nav-menu').should('have.class', 'expanded');
    });

    describe('expanded', () => {
      it('on expanded, dashboard list should be visible along with search bar', () => {
        cy.get('.app-container').should('have.class', 'nav-open');
        cy.get('@nav-items').eq(1).should('contain', 'Dashboards');
        cy.get('ngx-input').should('be.visible');
      });

      it('on expanded, application records list should be visible along with search bar', () => {
        cy.get('@nav-items').eq(2).should('contain', 'Application Records');
        cy.get('ngx-input').should('be.visible');
      });
    });

    describe('collapsed', () => {
      before(() => {
        cy.get('.flyout-bar').click();
      });

      it('on collapsed, dashboard list should appear on mouseenter and search bar should be visible', () => {
        cy.get('@nav-items').should('have.length', 10);

        cy.get('@nav-items')
          .eq(1)
          .whileHovering(() => {
            cy.root()
              .closest('body')
              .find('ngx-tooltip-content')
              .should('be.visible')
              .within(() => {
                cy.get('.title').should('have.text', 'Dashboards');
                cy.get('ngx-input').should('be.visible');
              });
          });
        cy.get('ngx-tooltip-content', { timeout: 300 }).should('not.exist');
      });

      it('on collapsed, application records list should appear on mouseenter and search bar should be visible', () => {
        cy.get('@nav-items')
          .eq(2)
          .whileHovering(() => {
            cy.root()
              .closest('body')
              .find('ngx-tooltip-content')
              .should('be.visible')
              .within(() => {
                cy.get('.title').should('have.text', 'Application Records');
                cy.get('ngx-input').should('be.visible');
              });
          });
        cy.get('ngx-tooltip-content', { timeout: 300 }).should('not.exist');
      });
    });
  });

  describe('nav bar has no workspaces', () => {
    before(() => {
      cy.clearExpandedMenu();

      cy.setupStubbedSwimlane();
      cy.intercept('/api/workspaces/', []);
      cy.intercept('/api/workspaces/nav', []).as('GET:workspaces/nav');

      cy.navigateSwimlane('/', { forceReload: true });
    });

    it('starts expanded', () => {
      cy.get('.app-container').should('have.class', 'nav-open');
      cy.get('@nav-menu').should('have.class', 'expanded');
    });

    it('expands and collapses', () => {
      cy.get('.flyout-bar').click();
      cy.get('.app-container', { timeout: 300 }).should('not.have.class', 'nav-open');
      cy.get('@nav-menu', { timeout: 300 }).should('not.have.class', 'expanded');
      cy.get('.flyout-bar').click();
      cy.get('.app-container').should('have.class', 'nav-open');
      cy.get('@nav-menu').should('have.class', 'expanded');
    });

    // TODO: describe('expanded');

    describe('collapsed', () => {
      before(() => {
        cy.get('.flyout-bar').click();
      });

      it('workspaces list should display "No Workspaces" text', () => {
        cy.get('@nav-items')
          .first()
          .as('nav-item-1')
          .whileHovering(() => {
            cy.root().closest('body').find('ngx-tooltip-content .title').should('have.text', 'Workspaces');
            cy.root().closest('body').find('nav-filter-list .empty-message').should('contain', 'No workspaces.');
          });
        cy.get('ngx-tooltip-content', { timeout: 300 }).should('not.exist');
      });
    });
  });
});

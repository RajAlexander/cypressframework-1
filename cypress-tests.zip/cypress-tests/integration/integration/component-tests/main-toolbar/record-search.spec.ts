describe('Record Search', () => {
  const workspaceId = 'aP6rDZMhfXU0550sc';

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();

    cy.navigateSwimlane(`/workspace/${workspaceId}/`);

    cy.get('.global-search--button').click();
    cy.wait('@GET:app');
  });

  it('opens search', () => {
    cy.get('.source-name').should('contain', 'Application 1');
  });

  it('shows result counts', () => {
    cy.intercept('POST', '/api/search/keyword/count?*', {
      fixture: 'mocks/swimlane/search/keyword/count/post.json'
    }).as('POST:search/keyword/count?*');

    cy.intercept('POST', '/api/search/keyword?*', {
      fixture: 'mocks/swimlane/search/keyword/--__.post.json'
    }).as('POST:search/keyword?*');

    cy.get('.search-banner--input input').as('input');
    cy.get('@input').focus();
    cy.get('@input').type('cat{enter}');
    cy.wait('@POST:search/keyword?*');
    cy.wait('@POST:search/keyword/count?*');
    cy.get('.search-left > .results-meta > .results-meta--count').should('contain', 'Viewing 5 of 5 Total Matches');
  });

  it('shows record results', () => {
    cy.get('.search-results .app-results').first().as('first-item');
    cy.get('@first-item').find('.record-heading').should('contain', 'CA-7');
    cy.get('@first-item').find('.record-values').as('values');
    cy.get('@values').should('contain', 'Record Id');
    cy.get('@values').should('contain', 'aV4WbUU5g2OfN3Onc');
    cy.get('@values').should('contain', 'Text');
    cy.get('@values').should('contain', 'Curiosity Killed The Cat');
  });

  it('toggles apps', () => {
    cy.intercept('POST', '/api/search/keyword?*', {
      fixture: 'mocks/swimlane/search/keyword/post-2.json'
    }).as('POST:search/keyword?*');
    cy.get('.search-sidebar--app-filter').find('ngx-checkbox').eq(1).click();
    cy.wait('@POST:search/keyword?*');
    cy.get('.search-left > .results-meta > .results-meta--count').should('contain', 'Viewing 1 of 5 Total Matches');
  });
});

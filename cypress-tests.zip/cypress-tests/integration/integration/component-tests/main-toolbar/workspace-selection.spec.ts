describe('Workspace Selection', () => {
  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.navigateSwimlane(`/`);
  });

  beforeEach(() => {
    cy.get('.main-toolbar').as('main-toolbar');
  });

  it('toolbar', () => {
    cy.get('@main-toolbar').find('.main-toolbar--workspace-label').should('contain', 'Workspace');
  });
});

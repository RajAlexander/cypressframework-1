describe('Profile [SPT-3848]', () => {
  const userName = 'admin';
  const userId = 'aO_RunwkwbYwkml6X';

  before(() => {
    cy.login();
    cy.setCollapsedMenu();
    cy.setupStubbedSwimlane();
    cy.navigateSwimlane(`/`);
  });

  beforeEach(() => {
    cy.get('.main-toolbar').as('main-toolbar');
    cy.get('@main-toolbar').find('.main-toolbar--profile-dropdown').as('dropdown');
    cy.get('@dropdown').find('ngx-dropdown-toggle').as('dropdown-button');
  });

  describe('dropdown', () => {
    beforeEach(() => {
      cy.get('@dropdown-button').click();
    });

    afterEach(() => {
      cy.get('@dropdown-button').click();
    });

    it('dropdown items', () => {
      cy.get('@dropdown').should('have.class', 'open');
      cy.get('@dropdown').find('li').should('have.length', 4);
      cy.get('@dropdown').find('li').first().should('contain', 'Profile');
      cy.get('@dropdown').find('li').eq(1).should('contain', 'Documentation');
      cy.get('@dropdown').find('li').eq(2).should('contain', 'About');
      cy.get('@dropdown').find('li').last().should('contain', userName);
    });

    it('dropdown links', () => {
      cy.get('@dropdown').find('li > a').first().should('have.attr', 'href', `/user/${userId}`);
      cy.get('@dropdown')
        .find('li > a')
        .eq(1)
        .should('have.attr', 'href', 'https://swimlane.com/knowledge-center/docs/');
      cy.get('@dropdown').find('li .btn').last().should('have.attr', 'href', 'logout');
    });
  });
});

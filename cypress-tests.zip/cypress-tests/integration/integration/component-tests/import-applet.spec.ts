describe('Applet Import Dialog', { requestTimeout: 120000 }, () => {
  const trackingId = 'aKitOEZWivHGz_A7z';

  const dropSSPFile = () => {
    cy.get('.app-import__dropzone-container', { timeout: 30000 })
      .should('contain', 'Drag + Drop')
      .should('contain', 'Supports: .JSON and .SSP')
      .within(() => {
        cy.get('.ngx-dropzone--input').attachFile({
          fileContent: '{}',
          fileName: 'test.ssp',
          mimeType: 'application/json',
          encoding: 'utf-8'
        } as any);
      });
    cy.wait('@POST:content/import');
    cy.hubPublish('contentExchangeComplete', trackingId);
    cy.wait(3000); // ToDo- Remove this wait and figure out how to get test to pass without it.
    // This is added to account for the SPINNER_TIMEOUT that the import animation has
  };

  const getImportMessage = (entityType: string, status: string) => {
    switch (status) {
      case 'success':
        return `${entityType} has imported successfully.`;
      case 'error':
        return 'You must address any errors in order to import successfully.';
      case 'nonActionableIssue':
        return `Your ${entityType} has imported successfully but there is an issue. This may result in an incomplete solution. Take note of the issue listed.`;
      case 'nonActionableIssues':
        return `Your ${entityType} has imported successfully but there are issues. This may result in an incomplete solution. Take note of the issues listed.`;
      case 'actionableIssue':
        return `Your ${entityType} has imported successfully but there is an issue. This may result in an incomplete solution. Take note of or take action on the issue listed.`;
      case 'actionableIssues':
        return `Your ${entityType} has imported successfully but there are issues. This may result in an incomplete solution. Take note of or take action on the issues listed.`;
    }
  };

  before(() => {
    cy.login();

    cy.setupStubbedSwimlane();

    cy.navigateSwimlane(`/apps`);

    cy.get('.apps-ngx-toolbar').within(() => {
      cy.get('.ngx-plus-menu').click();
      cy.get('.ngx-plus-menu--icon').first().click();
    });
    cy.get('.app-import--container').should('exist');
    cy.get('.app-import__header', { timeout: 20000 }).should('contain', 'Import');
  });

  beforeEach(() => {
    cy.setupStubbedSwimlane();
  });

  describe('SSP Import', () => {
    describe('no issues', () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.intercept('GET', '/api/content/import/*/status', {
          fixture: 'mocks/swimlane/content/import/status/post-clean-applet.json'
        }).as('GET:content/import/status');
        dropSSPFile();
        cy.wait('@GET:content/import/status');
      });

      after(() => {
        cy.get('.app-import__footer').within(() => {
          cy.get('.app-import__footer__close').should('contain', 'Close');
          cy.get('.app-import__footer__goto').should('contain', 'Go to Applet').should('have.attr', 'uisref', 'applet');
          cy.get('.app-import__footer__more').should('contain', 'Import More').click();
        });

        cy.get('.app-import__header', { timeout: 20000 }).should('contain', 'Import');
      });

      it('dialog header', () => {
        cy.get('.app-import__header', { timeout: 20000 }).should('contain', 'Import').should('contain', 'Success');
      });

      it('connection preview', () => {
        cy.get('.connections-preview').within(() => {
          cy.get('.entity-card__type').should('contain', 'Applet');
          cy.get('.entity-card__title').should('contain', 'No Issues');
          cy.get('.entity-card__acronym').should('contain', 'NI');

          cy.get('.connections-preview__connections').should('contain', '1 Applet').should('contain', '1 Report');
        });
        cy.get('.app-import-messages').should('contain', getImportMessage('applet', 'success'));
        cy.get('.app-import-messages__task-enable-container').should('not.exist');
      });
    });

    describe('few non-actionable issues', () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.intercept('GET', '/api/content/import/*/status', {
          fixture: 'mocks/swimlane/content/import/status/post-issues.json'
        }).as('GET:content/import/status');
        dropSSPFile();
        cy.wait('@GET:content/import/status');
      });

      it('dialog header', () => {
        cy.get('.app-import__header', { timeout: 20000 }).should('contain', 'Import').should('contain', 'Summary');
      });

      it('connection preview', () => {
        cy.get('.connections-preview').within(() => {
          cy.get('.entity-card__type').should('contain', 'Applet');
          cy.get('.entity-card__title').should('contain', 'Issues');
          cy.get('.entity-card__acronym').should('contain', 'IS');

          cy.get('.connections-preview__connections').should('contain', '1 Applet').should('contain', '1 Report');
        });

        cy.get('.app-import-messages')
          .should('contain', 'Review Potential Issues')
          .should('contain', getImportMessage('applet', 'nonActionableIssues'));
        cy.get('.app-import-messages__task-enable-container').should('not.exist');
      });

      it('issues list', () => {
        cy.get('.entity-section--applet').within(() => {
          cy.get('.entity-card__type').should('contain', 'Applet');
          cy.get('.entity-card__name').should('contain', 'Issues');
          cy.get('.entity-card__acronym').should('contain', 'IS');

          cy.get('.entity-card__issues-section').should('contain', '2 Issues');

          cy.get('.entity-section__content .entity-issue__name').should('contain', 'Integration');
          cy.get('.entity-section__content .entity-issue__message').should('contain', 'Some issue');
        });
      });

      after(() => {
        cy.get('.app-import__footer').within(() => {
          cy.get('.app-import__footer__close').should('contain', 'Close');
          cy.get('.app-import__footer__goto').should('contain', 'Go to Applet').should('have.attr', 'uisref', 'applet');
          cy.get('.app-import__footer__more').should('contain', 'Import More').click();
        });

        cy.get('.app-import__header', { timeout: 20000 }).should('contain', 'Import');
      });
    });

    describe('few actionable issues with disabled task', () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.intercept('GET', '/api/content/import/*/status', {
          fixture: 'mocks/swimlane/content/import/status/post-actionable-issues.json'
        }).as('GET:content/import/status');
        dropSSPFile();
        cy.wait('@GET:content/import/status');
      });

      it('dialog header', () => {
        cy.get('.app-import__header', { timeout: 20000 }).should('contain', 'Import').should('contain', 'Summary');
      });

      it('connection preview', () => {
        cy.get('.connections-preview').within(() => {
          cy.get('.entity-card__type').should('contain', 'Applet');
          cy.get('.entity-card__title').should('contain', 'Issues');
          cy.get('.entity-card__acronym').should('contain', 'AI');

          cy.get('.connections-preview__connections').should('contain', '1 Applet').should('contain', '1 Report');
        });

        cy.get('.app-import-messages')
          .should('contain', 'Review Potential Issues')
          .should('contain', getImportMessage('applet', 'actionableIssues'));

        cy.get('.app-import-messages__task-enable-container').within(() => {
          cy.get('ngx-tip').should('contain', 'Some tasks were disabled during export. Enable them all now or later.');
          cy.get('button').contains('Enable 1 Task').should('exist');
          cy.get('ngx-toggle').contains('Include scheduled tasks').should('exist');
          cy.get('ngx-toggle').click();
          cy.get('ngx-toggle').contains('Exclude scheduled tasks').should('exist');
          cy.get('button').contains('Enable 0 Tasks').should('exist');
          cy.get('button').contains('Enable 0 Tasks').should('be.disabled');
          cy.get('ngx-toggle').click();
          cy.get('button').contains('Enable 1 Task').should('exist');
        });
      });

      it('task bulk enable elements disappear after click', () => {
        cy.get('.app-import-messages__task-enable-container').within(() => {
          cy.get('button').contains('Enable 1 Task').click();
        });
        cy.get('.app-import-messages__task-enable-container').should('not.exist');
      });

      it('issues list', () => {
        cy.get('.entity-section--asset').within(() => {
          cy.get('.entity-card__type').eq(0).should('contain', 'Asset');
          cy.get('.entity-card__name').eq(0).should('contain', 'Test Plugin');

          cy.get('.entity-card__type').eq(1).should('contain', 'Asset');
          cy.get('.entity-card__name').eq(1).should('contain', 'Test Plugin 2');

          cy.get('.entity-card__issues-section--edit-mode', { timeout: 20000 })
            .eq(0)
            .should('contain', 'Resolve 1 Issue');
          cy.get('.entity-card__issues-section--edit-mode', { timeout: 20000 })
            .eq(1)
            .should('contain', 'Resolve 1 Issue');
        });

        cy.get('.entity-section--task').within(() => {
          cy.get('.entity-card__type').eq(0).should('contain', 'Task');
          cy.get('.entity-card__name').eq(0).should('contain', 'int task 1');

          cy.get('.entity-card__type').eq(1).should('contain', 'Task');
          cy.get('.entity-card__name').eq(1).should('contain', 'int task 2');

          cy.get('.entity-card__issues-section--edit-mode', { timeout: 20000 })
            .eq(0)
            .should('contain', 'Resolve 1 Issue');
          cy.get('.entity-card__issues-section--edit-mode', { timeout: 20000 })
            .eq(1)
            .should('contain', 'Resolve 1 Issue');
        });
      });

      after(() => {
        cy.get('.app-import__footer').within(() => {
          cy.get('.app-import__footer__close').should('contain', 'Close');
          cy.get('.app-import__footer__goto').should('contain', 'Go to Applet').should('have.attr', 'uisref', 'applet');
          cy.get('.app-import__footer__more').should('contain', 'Import More').click();
        });

        cy.get('.app-import__header', { timeout: 20000 }).should('contain', 'Import');
      });
    });
  });

  describe('JSON Import', () => {
    it('JSON Import', () => {
      cy.get('.app-import--container').should('exist');
      cy.get('.app-import__header', { timeout: 20000 }).should('contain', 'Import');

      cy.fixture('Test Applet').then(fileContent => {
        cy.get('.app-import__dropzone-container')
          .should('contain', 'Drag + Drop')
          .should('contain', 'Supports: .JSON and .SSP')
          .within(() => {
            cy.get('.ngx-dropzone--input').attachFile({
              fileContent,
              fileName: 'test.json',
              mimeType: 'application/json',
              encoding: 'utf-8'
            });
          });
      });

      cy.get('.create-applet.ngx-dialog-content').within(() => {
        cy.get('.help-banner').should('contain', 'Upload Applet');
        cy.get('.btn-primary').should('contain', 'Upload').click();
      });

      cy.wait('@POST:applet/import');

      cy.get('.app-import__header', { timeout: 20000 }).should('contain', 'Import').should('contain', 'Success');

      cy.get('.connections-preview').within(() => {
        cy.get('.entity-card__type').should('contain', 'Applet');
        cy.get('.entity-card__title').should('contain', 'FEA Test Applet');
        cy.get('.entity-card__acronym').should('contain', 'FEAT');

        cy.get('.connections-preview__connections').should('contain', '1 Applet');
      });

      cy.get('.app-import-messages').should('contain', getImportMessage('applet', 'success'));
      cy.get('.app-import-messages__task-enable-container').should('not.exist');

      cy.get('.app-import__footer').within(() => {
        cy.get('.app-import__footer__close').should('contain', 'Close');
        cy.get('.app-import__footer__goto').should('contain', 'Go to Applet').should('have.attr', 'uisref', 'applet');
        cy.get('.app-import__footer__more').should('contain', 'Import More').click();
      });

      cy.get('.app-import__header', { timeout: 20000 }).should('contain', 'Import');
    });
  });
});

import { longPress } from '../../../../shared/interactions';

describe('List all selections', () => {
  const appId = 'adm6A9Pu_802ISkIq';
  const reportId = 'anr7B8Vi_523GHsOs';

  before(() => {
    cy.login();

    cy.setupStubbedSwimlane();

    cy.navigateSwimlane(`/search/${appId}/${reportId}/`);
    cy.wait(`@GET:reports/${reportId}`);
    cy.wait('@POST:search');
  });

  it('Header is not visible', () => {
    cy.get('.list-all-header').should('not.be.visible');
  });

  describe('Selecting a single record', () => {
    before(() => {
      cy.get('.select-box:first', { timeout: 30000 }).click({ multiple: true });
    });

    it('Selects the record', () => {
      cy.get('.dt-row').should('have.class', 'selected');
      cy.get('.list-all-header').should('be.visible');
      cy.get('.list-all-header').find('.btn').contains('Bulk Edit').should('be.visible');
      cy.get('.list-all-header').find('.btn').contains('Delete').should('be.visible');
      cy.get('.list-all-header').find('.btn').contains('Select all').should('be.visible');
      cy.get('.list-all-header').find('div').contains('Bulk update 1 record').should('be.visible');
    });

    describe('Deselecting the record', () => {
      before(() => {
        cy.get('.select-box:first').click({ multiple: true });
      });

      it('Deselects the record', () => {
        cy.get('.dt-row').should('not.have.class', 'selected');
        cy.get('.list-all-header').should('not.be.visible');
      });
    });
  });

  describe('Selecting all records via selectAll button', () => {
    before(() => {
      cy.get('.select-box:first').click({ multiple: true });
      cy.get('.list-all-header').find('.btn').contains('Select all').click();
    });

    it('Selects all records', () => {
      cy.get('.dt-row').should('have.class', 'selected');
      cy.get('.list-all-header').find('div').contains('Bulk update all records').should('be.visible');
    });

    it('Deselect first and bulk delete', () => {
      cy.get('.select-box:first').click({ multiple: true });
      cy.get('.list-all-header').find('.btn').contains('Delete').click();
      cy.get('.confirm-delete-dialog')
        .should('be.visible')
        .should('contain', `You are about to bulk delete all records except 1 record`);
      cy.get('.long-press').should('be.visible');
    });

    describe('Clicking delete', () => {
      const jobId = 'mock-tag-id-aM5iS07dU_ZD7fPaL';

      before(() => {
        cy.intercept('DELETE', `/api/app/${appId}/record/batch`, {
          body: jobId,
          statusCode: 202
        }).as('longPressRequest');
        longPress('@longPressRequest');
      });

      it('Shows a status notification on task update via signalr', () => {
        cy.setupStubbedSwimlane();

        cy.hubPublish('taskUpdate', {
          bulkModificationType: 'delete',
          jobId,
          status: 'finished',
          taskName: 'BatchRecordUpdate',
          totalRecordsSkipped: 0,
          totalRecordsUpdated: 9
        });

        cy.get('.ngx-notification').as('notification');

        cy.get('@notification').should('be.visible').find('h2').contains('Bulk delete process finished');

        cy.get('@notification').find('.ngx-notification-body').contains(`9 records were`).contains(`0 records failed`);

        cy.get('@notification').find('.icon-x').click();

        cy.wait('@POST:search');
      });

      it('Disables the button', () => {
        cy.get('.confirm-delete-dialog button').contains('Close').should('exist');
      });

      it('Closes the dialog', () => {
        cy.get('.confirm-delete-dialog button').contains('Close').click();
        cy.get('.confirm-delete-dialog').should('not.exist');
      });
    });
  });
});

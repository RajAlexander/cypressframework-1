import { longPress } from '../../../../shared/interactions';

describe('Bulk delete', () => {
  const appId = 'adm6A9Pu_802ISkIq';
  const reportId = 'anr7B8Vi_523GHsOs';

  before(() => {
    cy.login();

    cy.setupStubbedSwimlane();

    cy.navigateSwimlane(`/search/${appId}/${reportId}/`);
    cy.wait(`@GET:reports/${reportId}`);
    cy.wait(`@POST:search`);
  });

  describe('Clicking delete', () => {
    before(() => {
      cy.get('.select-box:first').click({ multiple: true });
      cy.get('.list-all-header').find('.btn').contains('Delete').click();
    });

    it('Shows the confirm dialog', () => {
      cy.get('.confirm-delete-dialog').should('be.visible');
      cy.get('.long-press').should('be.visible');
    });

    describe('Confirming delete', () => {
      const jobId = 'mock-tag-id-aM5iS07dU_ZD7fPaL';

      before(() => {
        cy.intercept('DELETE', `/api/app/${appId}/record/batch`, {
          body: jobId,
          statusCode: 202
        }).as('longPressRequest');
        longPress('@longPressRequest');
      });

      it('Shows a status notification on task update via signalr', () => {
        cy.setupStubbedSwimlane();

        cy.hubPublish('taskUpdate', {
          bulkModificationType: 'delete',
          jobId,
          status: 'finished',
          taskName: 'BatchRecordUpdate',
          totalRecordsSkipped: 0,
          totalRecordsUpdated: 1
        });

        cy.get('.ngx-notification').as('notification');

        cy.get('@notification').should('be.visible').find('h2').contains('Bulk delete process finished');

        cy.get('@notification').find('.ngx-notification-body').contains(`1 record was`).contains(`0 records failed`);

        cy.get('@notification').find('.icon-x').click();

        cy.wait('@POST:search');
      });

      it('Disables the button', () => {
        // TODO: SPT-7500
        // cy.get('.long-press').should('have.class', 'disabled-button');
        cy.get('.confirm-delete-dialog button').contains('Close').should('exist');
      });

      it('Closes the dialog', () => {
        cy.get('.confirm-delete-dialog button').contains('Close').click();
        cy.get('.confirm-delete-dialog').should('not.exist');
      });
    });
  });
});

import { validateInputPresent, setValue } from '../../../../shared/helpers/field-inputs/field';

import app from '../../../fixtures/mocks/swimlane/app/adm6A9Pu_802ISkIq/get.json';
import { ngxLongPress } from '../../../../shared/interactions';

const editableFieldTypes = ['text', 'numeric', 'valuesList', 'reference', 'userGroup', 'date'];

const availableFields = app.fields.filter(f => {
  if (f.fieldType === 'userGroup' && (f.inputType === 'lastUpdatedBy' || f.inputType === 'createdBy')) {
    return false;
  }
  if (f.fieldType === 'date' && (f.inputType === 'lastUpdated' || f.inputType === 'firstCreated')) {
    return false;
  }
  return editableFieldTypes.includes(f.fieldType) && !f.readOnly && !f.formula;
});

describe('Bulk update', () => {
  const appId = 'adm6A9Pu_802ISkIq';
  const reportId = 'anr7B8Vi_523GHsOs';

  before(() => {
    cy.login();

    cy.setupStubbedSwimlane();

    cy.navigateSwimlane(`/search/${appId}/${reportId}/`);
    cy.wait(`@GET:reports/${reportId}`);
    cy.wait('@POST:search');
  });

  describe('Selecting a single record', () => {
    describe('Clicking bulk edit', () => {
      before(() => {
        cy.get('.select-box:first').click({ multiple: true });
        cy.get('.list-all-header').find('.btn').contains('Bulk Edit').click();
      });

      beforeEach(() => {
        cy.get('.bulk-modify')
          .as('dialog')
          .find('.add-field-select')
          .as('addField')
          .find('.ngx-select-caret')
          .as('caret');
      });

      it('Shows the bulk edit dialog', () => {
        cy.get('@dialog').should('exist');
        cy.get('@dialog').find('.header').contains('Bulk Edit').should('exist');
        cy.get('@dialog').find('.add-field-select .ngx-select-caret').should('exist');
        cy.get('@dialog').find('.save-button').contains('Save Edit').should('exist').should('be.disabled');
        cy.get('@dialog').find('.content').should('contain', 'Use the search above to add fields for editing.');
      });

      it('Field select dropdown lists all valid fields', () => {
        cy.get('@addField').ngxOpen();
        cy.get('@dialog')
          .find('.ngx-select-dropdown')
          .should('exist')
          .find('.ngx-select-dropdown-option')
          .should('have.length', availableFields.length);
        cy.get('@addField').ngxClose();
      });

      describe('Adding single fields', () => {
        for (const field of availableFields) {
          describe(field.name, () => {
            before(() => {
              cy.get('.add-field-select').select(field.name);

              if (field.fieldType === 'reference') {
                cy.intercept('GET', '/api/app/?*', {
                  fixture: `mocks/swimlane/app/${field.targetId}/get.json`
                }).as('GET:app/?*');
                cy.intercept('POST', '/api/search/keyword?*', {
                  fixture: 'mocks/swimlane/search/keyword/post-4.json'
                }).as('POST:search/keyword?*');
                cy.wait(['@GET:app/?*', '@POST:search/keyword?*']);
              }
            });

            beforeEach(() => {
              cy.get('@dialog').find('.table').as('table');
              cy.get('.bulk-modify').find('.table').should('exist').find('tbody tr').last().as('row');
              cy.get('@row').find('td').eq(2).as('inputField');
            });

            it('disables field in dropdown', () => {
              cy.get('@addField').ngxOpen();
              cy.get('@dialog').find('.ngx-select-dropdown').first().should('contain', field.name);
              cy.get('@addField').ngxClose();
            });

            it('field has the correct input', () => {
              cy.get('@inputField').within(() => validateInputPresent(field));
            });

            it('Adding a value sets row as dirty', () => {
              // Note: some fields require mocking, remove this.
              cy.setupStubbedSwimlane();
              cy.get('@inputField').within(() => setValue(field));
              cy.get('@row').find('.field-icon').should('exist').should('have.class', 'active');
            });

            // TODO: verify that the field has the correct value

            it('Removes the field', () => {
              cy.get('@row').find('.remove-icon').click({ force: true });

              cy.get('@table').should('not.exist');

              cy.get('@addField').ngxOpen();
              cy.get('.bulk-modify')
                .find('.ngx-select-dropdown')
                .find('.ngx-select-dropdown-option.disabled')
                .should('have.length', 0);
              cy.get('@addField').ngxClose();
            });
          });
        }
      });

      describe('Adding multiple fields', () => {
        before(() => {
          cy.setupStubbedSwimlane();

          for (const field of availableFields) {
            cy.log(field.name);
            cy.get('.add-field-select').select(field.name);

            if (field.fieldType === 'reference') {
              cy.intercept('GET', '/api/app/?*', {
                fixture: `mocks/swimlane/app/${field.targetId}/get.json`
              }).as('GET:app/?*');
              cy.intercept('POST', '/api/search/keyword?*', {
                fixture: 'mocks/swimlane/search/keyword/post-4.json'
              }).as('POST:search/keyword?*');
              cy.wait(['@GET:app/?*', '@POST:search/keyword?*']);
            }
          }
        });

        beforeEach(() => {
          cy.get('@dialog').find('.table').as('table');
        });

        it('Adds fields', () => {
          cy.get('@table').should('exist').find('tbody tr').should('have.length', availableFields.length);
        });

        describe('Clicking save edits', () => {
          before(() => {
            cy.setupStubbedSwimlane();

            cy.get('.bulk-modify')
              .find('.table')
              .find('tbody tr td.field-value')
              .each((row, index) => {
                const field = availableFields[index];
                cy.log(field.name);
                cy.wrap(row).within(() => setValue(field));
              });
            cy.get('.bulk-modify').find('.btn').contains('Save Edits').click();
          });

          it('Shows the confirm dialog', () => {
            cy.get('.ngx-dialog-content').should('exist');
            cy.get('.long-press').should('exist');
          });

          describe('Confirming update', () => {
            const jobId = 'mock-tag-id-aM5iS07dU_ZD7fPaL';

            before(() => {
              cy.setupStubbedSwimlane();

              cy.intercept('PUT', `api/app/${appId}/record/batch`, {
                body: jobId,
                statusCode: 202
              }).as('longPressRequest');
              ngxLongPress();
              cy.wait('@longPressRequest');
            });

            it('Shows a status notification', () => {
              cy.hubPublish('taskUpdate', {
                bulkModificationType: 'update',
                jobId,
                status: 'finished',
                taskName: 'BatchRecordUpdate',
                totalRecordsSkipped: 0,
                totalRecordsUpdated: 1
              });

              cy.get('.ngx-notification', { timeout: 60000 }).as('notification');

              cy.get('@notification').should('exist').find('h2').contains('Bulk update process finished');

              cy.get('@notification')
                .find('.ngx-notification-body')
                .contains(`1 record was`)
                .contains(`0 records failed`);

              cy.get('@notification').find('.icon-x').click();
            });

            it('Disables button', () => {
              // TODO: SPT-7500
              // cy.get('.long-press').should('have.class', 'disabled-button');
              cy.get('.ngx-dialog-content').find('button').contains('Close').should('exist');
            });

            it('Closes the dialog', () => {
              cy.get('.ngx-dialog-content').find('button').contains('Close').click();
              cy.get('.ngx-dialog-content').should('not.exist');
            });
          });
        });
      });
    });
  });
});

describe('Application Import Dialog', { requestTimeout: 120000 }, () => {
  const trackingId = 'aKitOEZWivHGz_A7z';

  const dropSSPFile = () => {
    cy.get('.app-import__dropzone-container', { timeout: 30000 })
      .should('contain', 'Drag + Drop')
      .should('contain', 'Supports: .JSON and .SSP')
      .within(() => {
        cy.get('.ngx-dropzone--input').attachFile({
          fileContent: '{}',
          fileName: 'test.ssp',
          mimeType: 'application/json',
          encoding: 'utf-8'
        } as any);
      });
    cy.wait('@POST:content/import');
    cy.hubPublish('contentExchangeComplete', trackingId);
    cy.wait(3000); // ToDo- Remove this wait and figure out how to get test to pass without it.
    // This is added to account for the SPINNER_TIMEOUT that the import animation has
  };

  const importMoreOnSuccess = () => {
    cy.get('.app-import__footer').within(() => {
      cy.get('.app-import__footer__close').should('contain', 'Close');
      cy.get('.app-import__footer__goto')
        .should('contain', 'Go to Application')
        .should('have.attr', 'uisref', 'builder');
      cy.get('.app-import__footer__more').should('contain', 'Import More').click();
    });

    cy.get('.app-import__header', { timeout: 20000 }).should('contain', 'Import');
  };

  const importMoreOnFail = () => {
    cy.get('.dialog-close > .btn').should('contain', 'Close').click();

    cy.get('.apps-ngx-toolbar').within(() => {
      cy.get('.ngx-plus-menu').click();
      cy.get('.ngx-plus-menu--icon').first().click({ force: true });
    });
    cy.get('.app-import--container').should('exist');
    cy.get('.app-import__header', { timeout: 20000 }).should('contain', 'Import');
  };

  const getImportMessage = (entityType: string, status: string) => {
    switch (status) {
      case 'success':
        return `${entityType} has imported successfully.`;
      case 'error':
        return 'You must address any errors in order to import successfully.';
      case 'nonActionableIssue':
        return `Your ${entityType} has imported successfully but there is an issue. This may result in an incomplete solution. Take note of the issue listed.`;
      case 'nonActionableIssues':
        return `Your ${entityType} has imported successfully but there are issues. This may result in an incomplete solution. Take note of the issues listed.`;
      case 'actionableIssue':
        return `Your ${entityType} has imported successfully but there is an issue. This may result in an incomplete solution. Take note of or take action on the issue listed.`;
      case 'actionableIssues':
        return `Your ${entityType} has imported successfully but there are issues. This may result in an incomplete solution. Take note of or take action on the issues listed.`;
    }
  };

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.navigateSwimlane(`/apps`);

    cy.get('.apps-ngx-toolbar').within(() => {
      cy.get('.ngx-plus-menu').click();
      cy.get('.ngx-plus-menu--icon').first().click();
    });
    cy.get('.app-import--container').should('exist');
    cy.get('.app-import__header', { timeout: 20000 }).should('contain', 'Import');
  });

  describe('SSP Import - Polling', () => {
    it('stops polling when signalR notification returns', () => {
      cy.setupStubbedSwimlane();
      cy.intercept('GET', '/api/content/import/*/status', {
        fixture: 'mocks/swimlane/content/import/status/incomplete.json'
      }).as('status');

      cy.get('.app-import__dropzone-container')
        .should('contain', 'Drag + Drop')
        .should('contain', 'Supports: .JSON and .SSP')
        .within(() => {
          cy.get('.ngx-dropzone--input').attachFile({
            fileContent: '{}',
            fileName: 'test.ssp',
            mimeType: 'application/json',
            encoding: 'utf-8'
          } as any);
        });
      cy.wait('@POST:content/import');

      cy.wait('@status');
      cy.wait('@status');
      cy.wait('@status');
      cy.wait('@status');

      cy.intercept('GET', '/api/content/import/*/status', {
        fixture: 'mocks/swimlane/content/import/status/post.json'
      }).as('status');
      cy.hubPublish('contentExchangeComplete', trackingId);

      cy.wait('@status');
    });

    after(() => {
      importMoreOnFail();
    });
  });

  describe('SSP Import - success', () => {
    describe('no issues', () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.intercept('GET', '/api/content/import/*/status', {
          fixture: 'mocks/swimlane/content/import/status/post.json'
        }).as('GET:content/import/status');
        dropSSPFile();
        cy.wait('@GET:content/import/status');
      });

      it('dialog header', () => {
        cy.get('.app-import__header', { timeout: 20000 }).should('contain', 'Import').should('contain', 'Success');
      });

      it('connection preview', () => {
        cy.get('.connections-preview').within(() => {
          cy.get('.entity-card__type').should('contain', 'Application');
          cy.get('.entity-card__title').should('contain', 'No Issues');
          cy.get('.entity-card__acronym').should('contain', 'NI');

          cy.get('.connections-preview__connections').should('contain', '1 Application').should('contain', '1 Report');
        });
        cy.get('.app-import-messages').should('contain', getImportMessage('application', 'success'));
        cy.get('.app-import-messages__task-enable-container').should('not.exist');
      });

      after(() => {
        importMoreOnSuccess();
      });
    });

    describe('single non-actionable issue', () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.intercept('GET', '/api/content/import/*/status', {
          fixture: 'mocks/swimlane/content/import/status/post-issue.json'
        }).as('GET:content/import/status');
        dropSSPFile();
        cy.wait('@GET:content/import/status');
      });

      it('dialog header', () => {
        cy.get('.app-import__header', { timeout: 20000 }).should('contain', 'Import').should('contain', 'Summary');
      });

      it('connection preview', () => {
        cy.get('.connections-preview').within(() => {
          cy.get('.entity-card__type').should('contain', 'Application');
          cy.get('.entity-card__title').should('contain', 'Issues');
          cy.get('.entity-card__acronym').should('contain', 'IS');

          cy.get('.connections-preview__connections').should('contain', '1 Application').should('contain', '1 Report');
        });

        cy.get('.app-import-messages')
          .should('contain', 'Review Potential Issue')
          .should('contain', getImportMessage('application', 'nonActionableIssue'));
        cy.get('.app-import-messages__task-enable-container').should('not.exist');
      });

      it('issues list', () => {
        cy.get('.entity-section--application').within(() => {
          cy.get('.entity-card__type').should('contain', 'Application');
          cy.get('.entity-card__name').should('contain', 'Issues');
          cy.get('.entity-card__acronym').should('contain', 'IS');

          cy.get('.entity-card__issues-section').should('contain', '1 Issue');

          cy.get('.entity-section__content .entity-issue__name').should('contain', 'Integration');
          cy.get('.entity-section__content .entity-issue__message').should('contain', 'Some issue');
        });
      });

      after(() => {
        importMoreOnSuccess();
      });
    });

    describe('single actionable issue - asset', () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.intercept('GET', '/api/content/import/*/status', {
          fixture: 'mocks/swimlane/content/import/status/post-actionable-issue-asset.json'
        }).as('GET:content/import/status');
        dropSSPFile();
        cy.wait('@GET:content/import/status');
      });

      it('dialog header', () => {
        cy.get('.app-import__header', { timeout: 20000 }).should('contain', 'Import').should('contain', 'Summary');
      });

      it('connection preview', () => {
        cy.get('.connections-preview').within(() => {
          cy.get('.entity-card__type').should('contain', 'Application');
          cy.get('.entity-card__title').should('contain', 'Actionable Issues');
          cy.get('.entity-card__acronym').should('contain', 'AI');

          cy.get('.connections-preview__connections')
            .should('contain', '1 Application')
            .should('contain', '1 Report')
            .should('contain', '1 Workspace')
            .should('contain', '1 Task')
            .should('contain', '1 Asset');
        });

        cy.get('.app-import-messages')
          .should('contain', 'Review Potential Issue')
          .should('contain', getImportMessage('application', 'actionableIssue'));
        cy.get('.app-import-messages__task-enable-container').should('not.exist');
      });

      it('asset config', () => {
        cy.setupStubbedSwimlane();

        cy.get('.entity-section--asset').within(() => {
          cy.get('.entity-card__type').should('contain', 'Asset');
          cy.get('.entity-card__name').should('contain', 'Test Plugin');

          cy.get('.entity-card__issues-section--edit-mode', {
            timeout: 20000
          }).should('contain', 'Resolve 1 Issue');

          cy.get('.entity-section__content .entity-issue__name').eq(0).should('contain', 'Test Plugin');
          cy.get('.entity-section__content .entity-issue__message')
            .eq(0)
            .should('contain', 'A secure credential has been removed from password.');
          cy.get('.entity-card__issues-section--edit-mode .manage-button').click({ force: true });
        });

        cy.wait('@GET:asset/*');
        cy.wait('@GET:asset/list');

        cy.get('int-edit-asset-dialog', { timeout: 20000 })
          .should('exist')
          .within(() => {
            cy.get('.ngx-input').eq(0).ngxFill('IMAP Dirty');
            cy.get('state-save-button').click();
            cy.wait('@PUT:asset/*');
            cy.get('.edit-asset-footer__close')
              .should('contain', 'Close') // NOTE: SPT-12401
              .click();
          });

        cy.get('.entity-card__issues-section--edit-mode', {
          timeout: 20000
        }).should('contain', '1 Issue Resolved');
      });

      after(() => {
        importMoreOnSuccess();
      });
    });

    describe('single actionable issue - task', () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.intercept('GET', '/api/content/import/*/status', {
          fixture: 'mocks/swimlane/content/import/status/post-actionable-issue-task.json'
        }).as('GET:content/import/status');
        dropSSPFile();
        cy.wait('@GET:content/import/status');
      });

      it('dialog header', () => {
        cy.get('.app-import__header', { timeout: 20000 }).should('contain', 'Import').should('contain', 'Summary');
      });

      it('connection preview', () => {
        cy.get('.connections-preview').within(() => {
          cy.get('.entity-card__type').should('contain', 'Application');
          cy.get('.entity-card__title').should('contain', 'Task Actionable Issue');
          cy.get('.entity-card__acronym').should('contain', 'TAI');

          cy.get('.connections-preview__connections')
            .should('contain', '1 Application')
            .should('contain', '1 Report')
            .should('contain', '1 Workspace')
            .should('contain', '1 Task');
        });

        cy.get('.app-import-messages')
          .should('contain', 'Review Potential Issue')
          .should('contain', getImportMessage('application', 'actionableIssue'));
        cy.get('.app-import-messages__task-enable-container').should('exist');
      });

      it('task config', () => {
        cy.setupStubbedSwimlane();

        const taskId = 'a45DXpJHynWB2jVCp';
        cy.intercept('GET', '/api/credentials', { 'new-key': '' }).as('getCredentials');
        cy.get('.entity-section--task').within(() => {
          cy.get('.entity-card__type').should('contain', 'Task');
          cy.get('.entity-card__name').should('contain', 'int task 1');

          cy.get('.entity-card__issues-section--edit-mode', {
            timeout: 20000
          }).should('contain', 'Resolve 1 Issue');

          cy.get('.entity-section__content .entity-issue__name').eq(0).should('contain', 'int task 1');
          cy.get('.entity-section__content .entity-issue__message')
            .eq(0)
            .should('contain', 'Key store mapping to input "_key_" has been removed');
          cy.get('.entity-card .ngx-card--status.inactive').should('exist');
          cy.get('.entity-card__issues-section--edit-mode .manage-button', {
            timeout: 20000
          }).click();
        });

        cy.wait(`@GET:task/${taskId}`);
        cy.wait('@getCredentials');

        cy.get('.stacks-sidebar.task-page').as('dialog').should('exist');
        cy.get('@dialog').within(() => {
          cy.get('.stack-tabs ul.nav-tabs li a').contains('Configuration').click();
          cy.get('.split-pane2').as('inputParams').should('exist');
          cy.get('@inputParams')
            .find('li.list-group-item')
            .eq(0)
            .within(() => {
              cy.get('.form-group label')
                .contains('Key')
                .next('div')
                .find('.ui-select-container')
                .as('dropdown')
                .click();
              cy.get('@dropdown').contains('new-key').click();
            });
          cy.get('toolbar .save-button').first().click();
          cy.wait(`@PUT:task/${taskId}`); // task enabled here
          cy.get('.back-btn').click();
        });
        cy.get('.entity-card__issues-section--edit-mode', {
          timeout: 20000
        }).should('contain', '1 Issue Resolved');
        cy.get('.entity-card .ngx-card--status.success').should('exist');
      });

      after(() => {
        importMoreOnSuccess();
      });
    });

    describe('actionable and non-actionable issues', () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.intercept('GET', '/api/content/import/*/status', {
          fixture: 'mocks/swimlane/content/import/status/post-combined-issues.json'
        }).as('GET:content/import/status');
        dropSSPFile();
        cy.wait('@GET:content/import/status');
      });

      it('dialog header', () => {
        cy.get('.app-import__header', { timeout: 20000 }).should('contain', 'Import').should('contain', 'Summary');
      });

      it('connection preview', () => {
        cy.get('.connections-preview').within(() => {
          cy.get('.entity-card__type').should('contain', 'Application');
          cy.get('.entity-card__title').should('contain', 'Actionable Issues');
          cy.get('.entity-card__acronym').should('contain', 'AI');

          cy.get('.connections-preview__connections')
            .should('contain', '1 Application')
            .should('contain', '1 Report')
            .should('contain', '1 Workspace')
            .should('contain', '1 Task')
            .should('contain', '1 Asset');
        });

        cy.get('.app-import-messages')
          .should('contain', 'Review Potential Issues')
          .should('contain', getImportMessage('application', 'actionableIssues'));
        cy.get('.app-import-messages__task-enable-container').should('not.exist');
      });

      it('tabs', { tags: ['SPT-11115'] }, () => {
        cy.setupStubbedSwimlane();

        cy.get('.content-action-results-container ngx-tabs').within(() => {
          cy.get('.ngx-tab .title').eq(0).should('contain', 'TAKE ACTION').should('contain', '1');
          cy.get('.ngx-tab .title').eq(1).should('contain', 'TAKE NOTE').should('contain', '1');

          cy.get('.ngx-tab-content').within(() => {
            cy.get('.entity-card__type').should('contain', 'Asset');
            cy.get('.entity-card__name').should('contain', 'Test Plugin');
            cy.get('.entity-card__issues-section--edit-mode', {
              timeout: 20000
            }).should('contain', 'Resolve 1 Issue');
            cy.get('.entity-section__content .entity-issue__message').should(
              'contain',
              'A secure credential has been removed from password.'
            );
            cy.get('.entity-card .ngx-card--status.error').should('exist');
            cy.get('.entity-card__issues-section--edit-mode .manage-button', {
              timeout: 20000
            }).click();
          });

          cy.wait('@GET:asset/*');

          cy.get('int-edit-asset-dialog').as('dialog').should('exist');
          cy.get('@dialog').find('.ngx-input').eq(0).find('input').clear().type('IMAP Dirty');
          cy.get('state-save-button').click();
          cy.wait('@PUT:asset/*');
          cy.get('.edit-asset-footer__close').click();
          cy.get('.entity-card__issues-section--edit-mode', {
            timeout: 20000
          }).should('contain', '1 Issue Resolved');
          cy.get('.entity-card .ngx-card--status.success').should('exist');
          cy.get('.ngx-tab .title').eq(0).should('not.contain', '1');
          cy.get('.ngx-tab .title').eq(1).should('contain', '1');

          cy.get('.ngx-tab .title').eq(1).click();

          cy.get('.ngx-tab-content').within(() => {
            cy.get('.entity-card__type').should('contain', 'Asset');
            cy.get('.entity-card__name').should('contain', 'Test Plugin');
            cy.get('.entity-card__issues-section--edit-mode', {
              timeout: 20000
            }).should('contain', '1 Issue');
            cy.get('.entity-section__content .entity-issue__message').should('contain', 'Some Issue');
          });
        });
      });

      after(() => {
        importMoreOnSuccess();
      });
    });

    describe('at least 1 disabled tasks', () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.intercept('GET', '/api/content/import/*/status', {
          fixture: 'mocks/swimlane/content/import/status/disabled-tasks-success.json'
        }).as('GET:content/import/status');
        dropSSPFile();
        cy.wait('@GET:content/import/status');
      });

      it('connection preview should display task bulk enable button and toggle', () => {
        cy.setupStubbedSwimlane();

        cy.get('connections-preview').within(() => {
          cy.get('.entity-card__type').should('contain', 'Application');
          cy.get('.entity-card__title').should('contain', 'disabled tasks');
          cy.get('.entity-card__acronym').should('contain', 'DT');
          cy.get('.connections-preview__connections').should('contain', '1 Application').should('contain', '2 Tasks');
        });

        cy.get('.app-import-messages').should('contain', getImportMessage('application', 'actionableIssues'));

        cy.get('.app-import-messages__task-enable-container').within(() => {
          cy.get('ngx-tip').should('contain', 'Some tasks were disabled during export. Enable them all now or later.');
          cy.get('button').contains('Enable 2 Tasks').should('exist');
          cy.get('ngx-toggle').contains('Include scheduled tasks').should('exist');
          cy.get('ngx-toggle').click();
          cy.get('ngx-toggle').contains('Exclude scheduled tasks').should('exist');
          cy.get('button').contains('Enable 1 Task').should('exist');
          cy.get('ngx-toggle').click();
        });
      });

      it('task bulk enable elements disappear after click', () => {
        cy.setupStubbedSwimlane();

        cy.get('.app-import-messages__task-enable-container').within(() => {
          cy.get('button').contains('Enable 2 Tasks').click();
        });
        cy.get('.app-import-messages__task-enable-container').should('not.exist');
      });

      after(() => {
        importMoreOnSuccess();
      });
    });

    describe('no disabled tasks', () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.intercept('GET', '/api/content/import/*/status', {
          fixture: 'mocks/swimlane/content/import/status/enabled-tasks-success.json'
        }).as('GET:content/import/status');
        dropSSPFile();
        cy.wait('@GET:content/import/status');
      });

      it('connection preview should not display task bulk enable button and toggle', () => {
        cy.get('connections-preview').within(() => {
          cy.get('.entity-card__type').should('contain', 'Application');
          cy.get('.entity-card__title').should('contain', 'no disabled tasks');
          cy.get('.entity-card__acronym').should('contain', 'NDT');
          cy.get('.connections-preview__connections').should('contain', '1 Application').should('contain', '2 Tasks');
        });

        cy.get('.app-import-messages').should('contain', getImportMessage('application', 'success'));
        cy.get('.app-import-messages__task-enable-container').should('not.exist');
      });

      after(() => {
        importMoreOnSuccess();
      });
    });
  });

  describe('SSP Import - fail', () => {
    describe('global error', () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.intercept('GET', '/api/content/import/*/status', {
          fixture: 'mocks/swimlane/content/import/status/post-error.json'
        }).as('GET:content/import/status');
        dropSSPFile();
        cy.wait('@GET:content/import/status');
      });

      it('dialog header', () => {
        cy.get('.app-import__header', { timeout: 20000 })
          .should('contain', 'Import')
          .should('contain', 'Contains an Error');
      });

      it('connection preview', () => {
        cy.get('.connections-preview').within(() => {
          cy.get('.entity-card__type').should('contain', 'Application');
          cy.get('.entity-card__title').should('contain', 'Errors');
          cy.get('.entity-card__acronym').should('contain', 'ERR');

          cy.get('.connections-preview__connections').should('contain', '1 Application').should('contain', '1 Report');
        });

        cy.get('.app-import-messages')
          .should('contain', 'Error Detected')
          .should('contain', getImportMessage('application', 'error'))
          .find('.tip-content')
          .should('contain', 'Something global');
        cy.get('.app-import-messages__task-enable-container').should('not.exist');
      });

      after(() => {
        importMoreOnFail();
      });
    });

    describe('server error', () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.intercept('GET', '/api/content/import/*/status', {
          statusCode: 400,
          body: '{"ErrorCode": 5019,"Argument": "Empty request."}'
        }).as('GET:content/import/status');
        dropSSPFile();
        cy.wait('@GET:content/import/status');
      });

      it('shows error message', () => {
        cy.get('.app-import__progress-container').within(() => {
          cy.get('.ngx-progress-spinner--label').should('contain', 'Import Failed');
          cy.get('.error-message').should('contain', 'Server Error: Empty request.');
        });
      });

      after(() => {
        importMoreOnFail();
      });
    });

    describe('bad server response error', () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.intercept('GET', '/api/content/import/*/status', {
          statusCode: 200,
          body: 'Hey... what!'
        }).as('GET:content/import/status');
        dropSSPFile();
        cy.wait('@GET:content/import/status');
      });

      it('shows error message', () => {
        cy.get('.app-import__progress-container').within(() => {
          cy.get('.ngx-progress-spinner--label').should('contain', 'Import Failed');
          cy.get('.error-message').should('contain', 'Unknown Server Error');
        });
      });

      after(() => {
        importMoreOnFail();
      });
    });

    describe('entity errors', () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.intercept('GET', '/api/content/import/*/status', {
          fixture: 'mocks/swimlane/content/import/status/post-errors.json'
        }).as('GET:content/import/status');
        dropSSPFile();
        cy.wait('@GET:content/import/status');
      });

      it('dialog header', () => {
        cy.get('.app-import__header', { timeout: 20000 })
          .should('contain', 'Import')
          .should('contain', 'Contains Errors');
      });

      it('connection preview', () => {
        cy.get('.connections-preview').within(() => {
          cy.get('.entity-card__type').should('contain', 'Application');
          cy.get('.entity-card__title').should('contain', 'Errors');
          cy.get('.entity-card__acronym').should('contain', 'ERR');

          cy.get('.connections-preview__connections').should('contain', '1 Application').should('contain', '1 Report');
        });

        cy.get('.app-import-messages')
          .should('contain', 'Errors Detected')
          .should('contain', getImportMessage('application', 'error'));
        cy.get('.app-import-messages__task-enable-container').should('not.exist');
      });

      it('errors list', () => {
        cy.get('.entity-section--application').within(() => {
          cy.get('.entity-card__type').should('contain', 'Application');
          cy.get('.entity-card__name').should('contain', 'Errors');
          cy.get('.entity-card__acronym').should('contain', 'ERR');

          cy.get('.entity-card__errors-section').should('contain', '2 Errors');

          cy.get('.entity-section__content .entity-error')
            .first()
            .within(() => {
              cy.get('.entity-error__name').first().should('contain', 'Integration');
              cy.get('.entity-error__message').first().should('contain', 'Some error');
            });

          cy.get('.entity-section__content .entity-error')
            .eq(1)
            .within(() => {
              cy.get('.entity-error__name').first().should('contain', 'Button');
              cy.get('.entity-error__message').first().should('contain', 'Some other error');
            });
        });
      });

      after(() => {
        importMoreOnFail();
      });
    });

    describe('If an entity has a UID error, hide duplicate name/acronym error', () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.intercept('GET', '/api/content/import/*/status', {
          fixture: 'mocks/swimlane/content/import/status/post-uid-errors.json'
        }).as('GET:content/import/status');
        dropSSPFile();
        cy.wait('@GET:content/import/status');
      });

      it('dialog header', () => {
        cy.get('.app-import__header', { timeout: 20000 })
          .should('contain', 'Import')
          .should('contain', 'Contains Errors');
      });

      it('connection preview', () => {
        cy.get('.connections-preview').within(() => {
          cy.get('.entity-card__type').should('contain', 'Application');
          cy.get('.entity-card__title').should('contain', 'Issues');
          cy.get('.entity-card__acronym').should('contain', 'IS');

          cy.get('.connections-preview__connections').should('contain', '1 Application').should('contain', '1 Report');
        });

        cy.get('.app-import-messages')
          .should('contain', 'Errors Detected')
          .should('contain', getImportMessage('application', 'error'));
        cy.get('.app-import-messages__task-enable-container').should('not.exist');
      });

      it('should only show one UID error for entities', () => {
        cy.get('.content-action-results-container').within(() => {
          cy.get('.entity-section').should('have.length', 2);
          cy.get('.entity-section')
            .eq(1)
            .within(() => {
              cy.get('.entity-error').should('have.length', 1);
              cy.get('.entity-error').eq(0).should('contain.text', 'This item already exists in this environment.');
            });
        });
      });

      after(() => {
        importMoreOnFail();
      });
    });

    describe(`If the main entity has a UID error, don't show UID error for each entity.`, () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.intercept('GET', '/api/content/import/*/status', {
          fixture: 'mocks/swimlane/content/import/status/post-uid-error.json'
        }).as('GET:content/import/status');
        dropSSPFile();
        cy.wait('@GET:content/import/status');
      });

      it('dialog header', () => {
        cy.get('.app-import__header', { timeout: 20000 })
          .should('contain', 'Import')
          .should('contain', 'Contains an Error');
      });

      it('connection preview', () => {
        cy.get('.connections-preview').within(() => {
          cy.get('.entity-card__type').should('contain', 'Application');
          cy.get('.entity-card__title').should('contain', 'Issues');
          cy.get('.entity-card__acronym').should('contain', 'IS');

          cy.get('.connections-preview__connections').should('contain', '1 Application').should('contain', '1 Report');
        });

        cy.get('.app-import-messages')
          .should('contain', 'Error Detected')
          .should('contain', getImportMessage('application', 'error'));
        cy.get('.app-import-messages__task-enable-container').should('not.exist');
      });

      it('should only show one global error', () => {
        cy.get('.tip-container').should('contain', `This item already exists in this environment.`);
        cy.get('content-action-results .entity-section').should('have.length', 0);
      });

      after(() => {
        importMoreOnFail();
      });
    });

    describe('plugin upgrade errors', () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.intercept('GET', '/api/content/import/*/status', {
          fixture: 'mocks/swimlane/content/import/status/post-plugin-upgrade-errors.json'
        }).as('GET:content/import/status');

        dropSSPFile();
        cy.wait('@GET:content/import/status');
      });

      it('dialog header', () => {
        cy.get('.app-import__header', { timeout: 20000 })
          .should('contain', 'Import')
          .should('contain', 'Contains Errors');
      });

      it('connection preview', () => {
        cy.get('.app-import-messages')
          .should('contain', 'Errors Detected')
          .should('contain', getImportMessage('application', 'error'));
        cy.get('.app-import-messages__task-enable-container').should('not.exist');
      });

      describe('plugin upgrade flow', () => {
        beforeEach(() => {
          cy.get('.content-action-results-container').within(() => {
            cy.get('int-plugin-upload-status').should('have.length', 2);
            cy.get('int-plugin-upload-status').eq(0).as('plugin1');
            cy.get('int-plugin-upload-status').eq(1).as('plugin2');
          });
        });

        it('plugin list with status', () => {
          cy.get('.content-action-results-container').within(() => {
            cy.get('@plugin1')
              .find('.plugin-upload-status--status-text')
              .should('contain', 'New Plugin Version Detected:')
              .should('contain', 'Upgrade Now');
            cy.get('@plugin2')
              .find('.plugin-upload-status--status-text')
              .should('contain', 'New Plugin Version Detected:')
              .should('contain', 'Upgrade Now');
          });
        });

        it('breaking issues - plugin upgrade drawer', () => {
          cy.setupStubbedSwimlane();

          cy.intercept('POST', '/api/task/packages/upload/ssp?pluginId=sw_test_plugin', {
            fixture: 'mocks/swimlane/task/packages/upload/post.json'
          }).as('POST:task/packages/upload/ssp');
          cy.intercept('POST', '/api/task/packages/upgrade/ssp?pluginId=sw_test_plugin', {
            fixture: 'mocks/swimlane/task/packages/upgrade/post.json'
          }).as('POST:task/packages/upgrade/ssp');
          cy.get('@plugin1').find('.plugin-upload-status--status-text ngx-button').click();
          cy.wait('@POST:task/packages/upload/ssp');
          cy.wait(1000); // wait to allow plugin drawer to fully open
          cy.get('int-plugin-upgrade-drawer').should('exist').as('drawer');
          cy.get('@drawer').find('.ngx-toolbar-title-col').should('contain', 'Upgrade Plugin');
          cy.get('.plugin-upgrade-drawer--content--footer .btn-primary').click();
          cy.wait(1000); // wait to allow confirm dialog to fully instantiate
          cy.get('.ngx-dialog.ngx-alert-dialog.confirm').should('be.visible').as('confirm');
          cy.get('@confirm').should('contain', 'You are about to upgrade a plugin. This will create breaking issues.');
          cy.get('.ngx-dialog.ngx-alert-dialog.confirm .btn-primary').click();
          cy.wait('@POST:task/packages/upgrade/ssp');
          cy.wait(1000); // wait to allow confirm dialog to close
          cy.get('int-plugin-upgrade-issues-container').should('exist');
          cy.get('.plugin-upgrade-drawer--content--footer .btn-primary .content').click({ force: true });
          cy.get('.ngx-dialog.ngx-alert-dialog.confirm').should('be.visible').as('confirm');
          cy.get('@confirm').should('contain', 'Are you sure you want to leave?');
          cy.get('.ngx-dialog.ngx-alert-dialog.confirm .btn-primary').click();
          cy.get('@plugin1').find('.plugin-upload-status--status-text').should('contain', 'Plugin Upgraded');
        });

        it('no breaking issues', () => {
          cy.setupStubbedSwimlane();

          cy.intercept('POST', '/api/task/packages/upload/ssp?pluginId=virus-total', {
            fixture: 'mocks/swimlane/task/packages/upload/post-no-breaking-issues.json'
          }).as('POST:task/packages/upload/ssp');
          cy.get('@plugin2').find('.plugin-upload-status--status-text ngx-button').click();
          cy.wait('@POST:task/packages/upload/ssp');
          cy.get('@plugin2').find('.plugin-upload-status--status-text').should('contain', 'Plugin Upgraded');
        });

        it('continue - import successful', () => {
          cy.setupStubbedSwimlane();

          cy.intercept('GET', '/api/content/import/*/status', {
            fixture: 'mocks/swimlane/content/import/status/post.json'
          }).as('GET:content/import/status');
          cy.get('.app-import__header', { timeout: 20000 }).should('not.contain', 'Import Contains Errors');
          cy.get('.app-import-messages').should(
            'contain',
            'You have upgraded the necessary plugins. You can now continue to import your application.'
          );
          cy.get('.app-import-messages__task-enable-container').should('not.exist');

          cy.get('.app-import__footer').within(() => {
            cy.get('.app-import__footer__continue').should('contain', 'Continue').click();
            cy.hubPublish('contentExchangeComplete', trackingId);
            cy.wait('@GET:content/import/status');
          });
          cy.get('.app-import__header', { timeout: 20000 }).should('contain', 'Import').should('contain', 'Success');
        });
      });

      after(() => {
        importMoreOnFail();
      });
    });

    describe('plugin downgrade error', () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.intercept('GET', '/api/content/import/*/status', {
          fixture: 'mocks/swimlane/content/import/status/post-plugin-downgrade-error.json'
        }).as('GET:content/import/status');

        dropSSPFile();
        cy.wait('@GET:content/import/status');
      });

      it('dialog header', () => {
        cy.get('.app-import__header', { timeout: 20000 })
          .should('contain', 'Import')
          .should('contain', 'Contains an Error');
        cy.get('.app-import-messages')
          .should('contain', 'Error Detected')
          .should('contain', getImportMessage('application', 'error'));
      });

      it('plugin list with status', () => {
        cy.get('.app-import-messages__task-enable-container').should('not.exist');
        cy.get('.content-action-results-container').within(() => {
          cy.get('int-plugin-upload-status').should('have.length', 1);
          cy.get('int-plugin-upload-status')
            .eq(0)
            .find('.plugin-upload-status--status-text')
            .should('contain', 'Plugin Requires Downgrade');
        });
      });

      after(() => {
        importMoreOnFail();
      });
    });

    describe('plugin incompatible swimlane version error', () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.intercept('GET', '/api/content/import/*/status', {
          fixture: 'mocks/swimlane/content/import/status/post-plugin-incomptabile-swimlane-version-error.json'
        }).as('GET:content/import/status');

        dropSSPFile();
        cy.wait('@GET:content/import/status');
      });

      it('dialog header', () => {
        cy.get('.app-import__header', { timeout: 20000 })
          .should('contain', 'Import')
          .should('contain', 'Contains an Error');
        cy.get('.app-import-messages')
          .should('contain', 'Error Detected')
          .should('contain', getImportMessage('application', 'error'));
      });

      it('plugin list with status', () => {
        cy.get('.app-import-messages__task-enable-container').should('not.exist');
        cy.get('.content-action-results-container').within(() => {
          cy.get('int-plugin-upload-status').should('have.length', 1);
          cy.get('int-plugin-upload-status')
            .eq(0)
            .find('.plugin-upload-status--status-text')
            .should('contain', 'Incompatible Swimlane Version');
        });
      });

      after(() => {
        importMoreOnFail();
      });
    });
  });

  describe('JSON Import', () => {
    it('JSON Import', () => {
      cy.setupStubbedSwimlane();

      cy.get('.app-import--container').should('exist');
      cy.get('.app-import__header', { timeout: 20000 }).should('contain', 'Import');

      cy.fixture('Test Application').then(fileContent => {
        cy.get('.app-import__dropzone-container')
          .should('contain', 'Drag + Drop')
          .should('contain', 'Supports: .JSON and .SSP')
          .within(() => {
            cy.get('.ngx-dropzone--input').attachFile({
              fileContent,
              fileName: 'test.json',
              mimeType: 'application/json',
              encoding: 'utf-8'
            });
          });
      });

      cy.get('.create-app.ngx-dialog-content').within(() => {
        cy.get('.help-banner').should('contain', 'Upload Application');
        cy.get('.btn-primary').should('contain', 'Upload').click();
      });

      cy.wait('@POST:app/import');

      cy.get('.app-import__header', { timeout: 20000 }).should('contain', 'Import').should('contain', 'Success');

      cy.get('.connections-preview').within(() => {
        cy.get('.entity-card__type').should('contain', 'Application');
        cy.get('.entity-card__title').should('contain', 'FEA Test Application');
        cy.get('.entity-card__acronym').should('contain', 'FTA');

        cy.get('.connections-preview__connections').should('contain', '1 Application');
      });

      cy.get('.app-import-messages').should('contain', getImportMessage('application', 'success'));
      cy.get('.app-import-messages__task-enable-container').should('not.exist');

      cy.get('.app-import__footer').within(() => {
        cy.get('.app-import__footer__close').should('contain', 'Close');
        cy.get('.app-import__footer__goto')
          .should('contain', 'Go to Application')
          .should('have.attr', 'uisref', 'builder');
        cy.get('.app-import__footer__more').should('contain', 'Import More').click();
      });

      cy.get('.app-import__header', { timeout: 20000 }).should('contain', 'Import');
    });
  });
});

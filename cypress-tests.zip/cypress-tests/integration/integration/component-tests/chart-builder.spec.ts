import app from '../../fixtures/mocks/swimlane/app/adm6A9Pu_802ISkIq/get.json';

const dimensionableFieldTypes = ['valuesList', 'text', 'userGroup', 'numeric', 'date', 'list'];
const measurableFieldTypes = [...dimensionableFieldTypes, 'tracking'];

const chartControlTabs = ['Query', 'Options', 'Colors', 'Sorting'];
const numericMeasureQuery = ['Count of', 'Sum of', 'Average of', 'Min of'];
const dateDimensionQuery = [
  'Group By',
  'Group by Hour',
  'Group by Day of Week',
  'Group by Week',
  'Group by Month',
  'Group by Quarter',
  'Group by Year'
];

describe('Chart builder', () => {
  const appId = 'adm6A9Pu_802ISkIq';
  const reportId = 'aAG2BwDs3che_NZPW';

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.navigateSwimlane(`/search/${appId}/${reportId}/stats`);
    cy.wait('@POST:search');
    cy.wait(`@GET:reports/${reportId}`);

    cy.get('.mini-chart').should('exist').click();
  });

  beforeEach(() => {
    cy.get('.stats-bar').scrollIntoView();
    cy.get('.sidebar').as('sideBar').should('exist');
    cy.get('.main-area .viz-container').as('chartContainer').should('exist');
    cy.get('.sidebar .query-options').as('chartControls');
  });

  describe('chart controls', () => {
    after(() => {
      cy.get('@sideBar').find('.nav-tabs li').eq(0).click();
    });

    it('tabs', () => {
      cy.get('@sideBar').within(() => {
        cy.get('.nav-tabs li').eq(0).should('have.class', 'active');
        chartControlTabs.forEach((tab, i) => {
          cy.get('.nav-tabs li').eq(i).should('contain', tab);
        });
      });
    });

    it('measures', () => {
      const measurableFields = app.fields.filter(f => measurableFieldTypes.includes(f.fieldType));
      cy.get('@chartControls')
        .find('.measure-list .scrollbar-content')
        .within(() => {
          cy.get('li').should('have.length', measurableFields.length);
          measurableFields.forEach((field, i) => {
            cy.get('.field-name').eq(i).should('contain', field.name);
          });
        });
    });

    it('dimensions', () => {
      const dimensionableFields = app.fields.filter(f => dimensionableFieldTypes.includes(f.fieldType));
      cy.get('@chartControls')
        .find('.dimension-list .scrollbar-content')
        .within(() => {
          cy.get('li').should('have.length', dimensionableFields.length);
          dimensionableFields.forEach((field, i) => {
            cy.get('.field-name').eq(i).should('contain', field.name);
          });
        });
    });

    it('filter search bar', () => {
      cy.get('@chartControls').find('.measure-list .measure-field').as('measuresList');
      cy.get('@chartControls').find('.dimension-list .dimension-field').as('dimensionsList');
      cy.get('@chartControls').find('.form-input').as('searchBar').should('exist');
      cy.get('@searchBar').clear().focus().type('Email');
      cy.get('@measuresList').should('have.length', 1);
      cy.get('@dimensionsList').should('have.length', 1);
      cy.get('@searchBar').clear().focus().type('tracking');
      cy.get('@measuresList').should('have.length', 1);
      cy.get('@dimensionsList').should('not.exist');
      cy.get('@searchBar').clear();
    });

    it('options tab', () => {
      cy.get('@sideBar').find('.nav-tabs li').eq(1).click();
      cy.get('@sideBar').find('.nav-tabs li').eq(1).should('have.class', 'active');
      cy.get('@sideBar').find('.options-tab .toggle').should('have.length', 7);
    });

    it('colors tab', () => {
      cy.get('@sideBar').find('.nav-tabs li').eq(2).click();
      cy.get('@sideBar').find('.nav-tabs li').eq(2).should('have.class', 'active');
      cy.get('@sideBar')
        .find('.color-options')
        .within(() => {
          cy.get('.selected-name').should('contain', 'Swimlane');
          cy.get('.ui-select-toggle').as('arrow').click();
          cy.get('.ui-select-choices').should('exist');
          cy.get('.ui-select-choices-row').should('have.length', 10);
          cy.get('.ui-select-toggle').as('arrow').click();
        });
    });

    it('sorting tab', () => {
      cy.get('@sideBar').find('.nav-tabs li').eq(3).click();
      cy.get('@sideBar').find('.nav-tabs li').eq(3).should('have.class', 'active');
    });
  });

  describe('charts', () => {
    beforeEach(() => {
      cy.get('.main-area .chart-types').as('chartTypes').should('exist');
      cy.get('@chartTypes').find('ul.group-list').children().as('mainChartTypes');
      cy.get('@chartControls').find('.measure-list').as('measuresList');
      cy.get('@chartControls').find('.dimension-list').as('dimensionsList');
      cy.get('.sidebar .query').as('chartQuery');
      cy.get('@chartQuery').find('.measures').as('editMeasures');
      cy.get('@chartQuery').find('.dimension').as('editDimensions');
      cy.get('@measuresList').find('li.measure-field .add-button').eq(19).as('textMeasure');
      cy.get('@measuresList').find('li.measure-field .add-button').eq(13).as('numericMeasure');
      cy.get('@dimensionsList').find('li.dimension-field .add-button').eq(19).as('textDimension');
      cy.get('@dimensionsList').find('li.dimension-field .add-button').eq(13).as('numericDimension');
    });

    it('chart types total count', () => {
      cy.get('@chartTypes').find('ul.group-list li').should('have.length', 27);
    });

    it('default: has status message', () => {
      cy.get('@chartContainer')
        .find('.chart-status-message')
        .should('contain', 'Select 1 dimension and select 1 measure or select another chart type.');
    });

    it('default: should be bar chart', () => {
      cy.get('@mainChartTypes').first().should('have.class', 'selected');
    });

    describe('edit query', () => {
      beforeEach(() => {
        cy.intercept('POST', '/api/search/stats', {
          fixture: 'mocks/swimlane/search/stats/post.json'
        }).as('stats');
        cy.get('@mainChartTypes').first().click();
        cy.get('@mainChartTypes').first().should('have.class', 'selected');
      });

      it('remove all', () => {
        cy.get('@measuresList').find('li.measure-field .add-button').eq(0).click();
        cy.get('@dimensionsList').find('li.dimension-field .add-button').eq(1).click();
        cy.wait('@stats');
        cy.get('@editMeasures').children().should('have.length', 1);
        cy.get('@editDimensions').children().should('have.length', 1);
        cy.get('@chartQuery').find('.delete-icon').click();
        cy.get('@editMeasures').children().should('not.exist');
        cy.get('@editDimensions').children().should('not.exist');
      });

      it('add and remove measure', () => {
        cy.get('@textMeasure').click();
        cy.get('@editMeasures').within(() => {
          cy.get('li.builder-dropdown').should('contain', 'Text');
          cy.get('.subtext').should('contain', 'Count of');
          cy.get('.caret').click();
          cy.get('.builder-dropdown-menu').should('exist');
          cy.get('.builder-dropdown-menu .measure-query').should('have.length', 1);
          cy.get('.caret').click();
          cy.get('a.remove-button').click();
          cy.get('li.builder-dropdown').should('not.exist');
        });
      });

      it('add and remove dimension', () => {
        cy.get('@textDimension').click();
        cy.get('@editDimensions').within(() => {
          cy.get('li.builder-dropdown').should('contain', 'Text');
          cy.get('.subtext').should('contain', 'Group By');
          cy.get('.caret').click();
        });
        cy.get('.builder-dropdown-menu').should('exist');
        cy.get('.builder-dropdown-menu .dimension-query').should('have.length', 1);
        cy.get('@editDimensions').within(() => {
          cy.get('.caret').click();
          cy.get('a.remove-button').click();
        });
      });

      it('add and remove measure: numeric', () => {
        cy.get('@numericMeasure').click();
        cy.get('@editMeasures').within(() => {
          cy.get('li.builder-dropdown').should('contain', 'Numeric');
          cy.get('.subtext').should('contain', 'Count of');
          cy.get('.caret').click();
          cy.get('.builder-dropdown-menu').should('exist');
          cy.get('.builder-dropdown-menu .measure-query').should('have.length', numericMeasureQuery.length);
          numericMeasureQuery.forEach((query, i) => {
            cy.get('.builder-dropdown-menu .measure-query').eq(i).should('contain', query);
          });
          cy.get('.caret').click();
          cy.get('a.remove-button').click();
          cy.get('li.builder-dropdown').should('not.exist');
        });
      });

      it('add and remove dimension: date', () => {
        cy.get('@dimensionsList').find('li.dimension-field .add-button').eq(8).click();
        cy.get('@editDimensions').within(() => {
          cy.get('li.builder-dropdown').should('contain', 'Last Updated');
          cy.get('.subtext').should('contain', 'Group By');
          cy.get('.caret').click();
        });
        cy.get('.builder-dropdown-menu').should('exist');
        cy.get('.builder-dropdown-menu .dimension-query').should('have.length', dateDimensionQuery.length);
        dateDimensionQuery.forEach((query, i) => {
          cy.get('.builder-dropdown-menu .dimension-query').eq(i).should('contain', query);
        });
        cy.get('@editDimensions').within(() => {
          cy.get('.caret').click();
          cy.get('a.remove-button').click();
        });
      });
    });

    describe('widget', () => {
      it('displays widget', () => {
        cy.get('@mainChartTypes').last().click();
        cy.get('@chartContainer').find('widget-element').should('exist');
      });

      it('displays widget editor but not record select', () => {
        cy.get('.main-area').find('[data-cy=edit_widget__btn]').click();
        cy.get('widget-editor').as('editor').should('be.visible');
        cy.get('@editor').within($editor => {
          cy.get('.panel-header ngx-tabs').contains('button', 'preview report data').click();
          cy.get('[data-cy=record_select__input]').should('not.exist');
          cy.get('[data-cy=editor_cancel__btn]').click();
        });
      });
    });

    describe('chart types: no dimension', () => {
      beforeEach(() => {
        cy.intercept('POST', '/api/search/stats', {
          fixture: 'mocks/swimlane/search/stats/post.json'
        }).as('stats');
      });

      afterEach(() => {
        cy.get('@editMeasures').find('a.remove-button').click();
      });

      it('linear gauge chart', () => {
        cy.get('@mainChartTypes').eq(3).click();
        cy.get('@mainChartTypes').eq(3).find('ul.sub-list li').eq(1).click();
        cy.get('@textMeasure').click();
        cy.wait('@stats');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-linear-gauge')
          .within(() => {
            cy.get('g.linear-gauge').should('exist');
            cy.get('g.background-bar').should('exist');
            cy.get('g[ngx-charts-bar]').should('exist');
          });
      });
    });

    describe('chart types: single dimension', () => {
      beforeEach(() => {
        cy.intercept('POST', '/api/search/stats', {
          fixture: 'mocks/swimlane/search/stats/post.json'
        }).as('stats');
      });

      afterEach(() => {
        cy.get('@editMeasures').find('a.remove-button').click();
        cy.get('@editDimensions').find('a.remove-button').click();
      });

      it('bar chart - vertical', () => {
        cy.get('@mainChartTypes').eq(0).click();
        cy.get('@mainChartTypes').eq(0).find('ul.sub-list li').eq(0).click();
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.wait('@stats');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-bar-vertical')
          .within(() => {
            cy.get('g.bar-chart').should('exist');
            cy.get('ngx-charts-legend').should('exist');
            cy.get('g[ngx-charts-bar]').should('have.length', 4);
          });
      });
      it('bar chart - horizontal', () => {
        cy.get('@mainChartTypes').eq(0).click();
        cy.get('@mainChartTypes').eq(0).find('ul.sub-list li').eq(4).click();
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.wait('@stats');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-bar-horizontal')
          .within(() => {
            cy.get('g.bar-chart').should('exist');
            cy.get('ngx-charts-legend').should('exist');
            cy.get('g[ngx-charts-bar]').should('have.length', 4);
          });
      });

      it('line chart', () => {
        cy.get('@mainChartTypes').eq(1).click();
        cy.get('@mainChartTypes').eq(1).find('ul.sub-list li').eq(0).click();
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.wait('@stats');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-line-chart')
          .within(() => {
            cy.get('g.line-chart').should('exist');
            cy.get('ngx-charts-legend').should('exist');
            cy.get('g[ngx-charts-line-series]').should('exist');
          });
      });

      it('area chart', () => {
        cy.get('@mainChartTypes').eq(1).click();
        cy.get('@mainChartTypes').eq(1).find('ul.sub-list li').eq(1).click();
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.wait('@stats');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-area-chart')
          .within(() => {
            cy.get('g.area-chart').should('exist');
            cy.get('ngx-charts-legend').should('exist');
            cy.get('g[ngx-charts-area-series]').should('exist');
          });
      });

      it('radar chart', () => {
        cy.get('@mainChartTypes').eq(1).click();
        cy.get('@mainChartTypes').eq(1).find('ul.sub-list li').eq(4).click();
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.wait('@stats');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-polar-chart')
          .within(() => {
            cy.get('g.polar-chart').should('exist');
            cy.get('ngx-charts-legend').should('exist');
            cy.get('g[ngx-charts-polar-series]').should('exist');
          });
      });

      it('pie chart', () => {
        cy.get('@mainChartTypes').eq(2).click();
        cy.get('@mainChartTypes').eq(2).find('ul.sub-list li').eq(0).click();
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.wait('@stats');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-pie-chart')
          .within(() => {
            cy.get('g.pie-chart').should('exist');
            cy.get('ngx-charts-legend').should('exist');
            cy.get('g[ngx-charts-pie-series]').should('exist');
            cy.get('g[ngx-charts-pie-arc]').should('exist').should('have.length', 4);
          });
      });

      it('donut chart', () => {
        cy.get('@mainChartTypes').eq(2).click();
        cy.get('@mainChartTypes').eq(2).find('ul.sub-list li').eq(1).click();
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.wait('@stats');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-pie-chart')
          .within(() => {
            cy.get('g.pie-chart').should('exist');
            cy.get('ngx-charts-legend').should('exist');
            cy.get('g[ngx-charts-pie-series]').should('exist');
            cy.get('g[ngx-charts-pie-arc]').should('exist').should('have.length', 4);
          });
      });

      it('pie grid', () => {
        cy.get('@mainChartTypes').eq(2).click();
        cy.get('@mainChartTypes').eq(2).find('ul.sub-list li').eq(2).click();
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.wait('@stats');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-pie-grid')
          .within(() => {
            cy.get('g.pie-grid').should('exist');
            cy.get('g.pie-grid-item').should('have.length', 4);
          });
      });

      it('pie advanced', () => {
        cy.get('@mainChartTypes').eq(2).click();
        cy.get('@mainChartTypes').eq(2).find('ul.sub-list li').eq(3).click();
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.wait('@stats');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-advanced-pie-chart')
          .within(() => {
            cy.get('g.pie').should('exist');
            cy.get('g[ngx-charts-pie-series]').should('exist');
            cy.get('ngx-charts-advanced-legend').should('exist');
            cy.get('.legend-items-container .legend-item').should('have.length', 4);
          });
      });

      it('gauge chart', () => {
        cy.get('@mainChartTypes').eq(3).click();
        cy.get('@mainChartTypes').eq(3).find('ul.sub-list li').eq(0).click();
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.wait('@stats');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-gauge')
          .within(() => {
            cy.get('g.gauge').should('exist');
            cy.get('g[ngx-charts-gauge-axis]').should('exist');
            cy.get('ngx-charts-legend').should('exist');
          });
      });

      it('number chart', () => {
        cy.get('@mainChartTypes').eq(4).click();
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.wait('@stats');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-number-card')
          .within(() => {
            cy.get('g[ngx-charts-card]').should('have.length', 4);
            cy.get('rect.card').should('have.length', 4);
          });
      });
    });

    describe('chart types: multi dimension', () => {
      beforeEach(() => {
        cy.intercept('POST', '/api/search/stats', {
          fixture: 'mocks/swimlane/search/stats/post-multi.json'
        }).as('statsMulti');
      });

      afterEach(() => {
        cy.get('@editMeasures').find('a.remove-button').click();
        cy.get('@editDimensions').find('a.remove-button').eq(0).click();
        cy.get('@editDimensions').find('a.remove-button').eq(0).click();
      });

      it('bar-chart - grouped vertical', () => {
        cy.get('@mainChartTypes').eq(0).click();
        cy.get('@mainChartTypes').eq(0).find('ul.sub-list li').eq(1).click();
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.get('@chartContainer')
          .find('.chart-status-message')
          .should('contain', 'Select 1 dimension or another chart type.');
        cy.get('@numericDimension').click();
        cy.wait('@statsMulti');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-bar-vertical-2d')
          .within(() => {
            cy.get('g.bar-chart').should('exist');
            cy.get('ngx-charts-legend').should('exist');
            cy.get('g[ngx-charts-series-vertical]').should('exist');
            cy.get('g[ngx-charts-grid-panel]').should('exist').should('have.length', 4);
            cy.get('g[ngx-charts-bar]').should('have.length', 16);
          });
      });

      it('bar-chart - stacked vertical', () => {
        cy.get('@mainChartTypes').eq(0).click();
        cy.get('@mainChartTypes').eq(0).find('ul.sub-list li').eq(2).click();
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.get('@chartContainer')
          .find('.chart-status-message')
          .should('contain', 'Select 1 dimension or another chart type.');
        cy.get('@numericDimension').click();
        cy.wait('@statsMulti');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-bar-vertical-stacked')
          .within(() => {
            cy.get('g.bar-chart').should('exist');
            cy.get('ngx-charts-legend').should('exist');
            cy.get('g[ngx-charts-series-vertical]').should('exist');
            cy.get('g[ngx-charts-bar]').should('have.length', 16);
          });
      });

      it('bar-chart - normalized vertical', () => {
        cy.get('@mainChartTypes').eq(0).click();
        cy.get('@mainChartTypes').eq(0).find('ul.sub-list li').eq(3).click();
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.get('@chartContainer')
          .find('.chart-status-message')
          .should('contain', 'Select 1 dimension or another chart type.');
        cy.get('@numericDimension').click();
        cy.wait('@statsMulti');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-bar-vertical-normalized')
          .within(() => {
            cy.get('g.bar-chart').should('exist');
            cy.get('ngx-charts-legend').should('exist');
            cy.get('g[ngx-charts-series-vertical]').should('exist');
            cy.get('g[ngx-charts-bar]').should('have.length', 16);
          });
      });

      it('bar-chart - grouped horizontal', () => {
        cy.get('@mainChartTypes').eq(0).click();
        cy.get('@mainChartTypes').eq(0).find('ul.sub-list li').eq(5).click();
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.get('@chartContainer')
          .find('.chart-status-message')
          .should('contain', 'Select 1 dimension or another chart type.');
        cy.get('@numericDimension').click();
        cy.wait('@statsMulti');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-bar-horizontal-2d')
          .within(() => {
            cy.get('g.bar-chart').should('exist');
            cy.get('ngx-charts-legend').should('exist');
            cy.get('g[ngx-charts-series-horizontal]').should('exist');
            cy.get('g[ngx-charts-grid-panel]').should('exist').should('have.length', 4);
            cy.get('g[ngx-charts-bar]').should('have.length', 16);
          });
      });

      it('bar-chart - stacked horizontal', () => {
        cy.get('@mainChartTypes').eq(0).click();
        cy.get('@mainChartTypes').eq(0).find('ul.sub-list li').eq(6).click();
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.get('@chartContainer')
          .find('.chart-status-message')
          .should('contain', 'Select 1 dimension or another chart type.');
        cy.get('@numericDimension').click();
        cy.wait('@statsMulti');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-bar-horizontal-stacked')
          .within(() => {
            cy.get('g.bar-chart').should('exist');
            cy.get('ngx-charts-legend').should('exist');
            cy.get('g[ngx-charts-series-horizontal]').should('exist');
            cy.get('g[ngx-charts-bar]').should('have.length', 16);
          });
      });

      it('bar-chart - normalized horizontal', () => {
        cy.get('@mainChartTypes').eq(0).click();
        cy.get('@mainChartTypes').eq(0).find('ul.sub-list li').eq(7).click();
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.get('@chartContainer')
          .find('.chart-status-message')
          .should('contain', 'Select 1 dimension or another chart type.');
        cy.get('@numericDimension').click();
        cy.wait('@statsMulti');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-bar-horizontal-normalized')
          .within(() => {
            cy.get('g.bar-chart').should('exist');
            cy.get('ngx-charts-legend').should('exist');
            cy.get('g[ngx-charts-series-horizontal]').should('exist');
            cy.get('g[ngx-charts-bar]').should('have.length', 16);
          });
      });

      it('line chart', () => {
        cy.get('@mainChartTypes').eq(1).click();
        cy.get('@mainChartTypes').eq(1).find('ul.sub-list li').eq(0).click();
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.get('@numericDimension').click();
        cy.wait('@statsMulti');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-line-chart')
          .within(() => {
            cy.get('g.line-chart').should('exist');
            cy.get('ngx-charts-legend').should('exist');
            cy.get('g[ngx-charts-line-series]').should('exist').should('have.length', 4);
          });
      });

      it('area chart', () => {
        cy.get('@mainChartTypes').eq(1).click();
        cy.get('@mainChartTypes').eq(1).find('ul.sub-list li').eq(1).click();
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.get('@numericDimension').click();
        cy.wait('@statsMulti');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-area-chart')
          .within(() => {
            cy.get('g.area-chart').should('exist');
            cy.get('ngx-charts-legend').should('exist');
            cy.get('g[ngx-charts-area-series]').should('exist').should('have.length', 4);
          });
      });

      it('stacked area chart', () => {
        cy.get('@mainChartTypes').eq(1).click();
        cy.get('@mainChartTypes').eq(1).find('ul.sub-list li').eq(2).click();
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.get('@chartContainer')
          .find('.chart-status-message')
          .should('contain', 'Select 1 dimension or another chart type.');
        cy.get('@numericDimension').click();
        cy.wait('@statsMulti');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-area-chart-stacked')
          .within(() => {
            cy.get('g.area-chart').should('exist');
            cy.get('ngx-charts-legend').should('exist');
            cy.get('g[ngx-charts-area-series]').should('exist').should('have.length', 4);
          });
      });

      it('stacked area normalized chart', () => {
        cy.get('@mainChartTypes').eq(1).click();
        cy.get('@mainChartTypes').eq(1).find('ul.sub-list li').eq(3).click();
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.get('@chartContainer')
          .find('.chart-status-message')
          .should('contain', 'Select 1 dimension or another chart type.');
        cy.get('@numericDimension').click();
        cy.wait('@statsMulti');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-area-chart-normalized')
          .within(() => {
            cy.get('g.area-chart').should('exist');
            cy.get('ngx-charts-legend').should('exist');
            cy.get('g[ngx-charts-area-series]').should('exist').should('have.length', 4);
          });
      });

      it('radar chart', () => {
        cy.get('@mainChartTypes').eq(1).click();
        cy.get('@mainChartTypes').eq(1).find('ul.sub-list li').eq(4).click();
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.get('@numericDimension').click();
        cy.wait('@statsMulti');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-polar-chart')
          .within(() => {
            cy.get('g.polar-chart').should('exist');
            cy.get('ngx-charts-legend').should('exist');
            cy.get('g.polar-charts-series').should('exist').should('have.length', 4);
          });
      });

      it('heat map', () => {
        cy.get('@mainChartTypes').eq(5).click();
        cy.get('@mainChartTypes').eq(5).should('have.class', 'selected');
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.get('@chartContainer')
          .find('.chart-status-message')
          .should('contain', 'Select 1 dimension or another chart type.');
        cy.get('@numericDimension').click();
        cy.wait('@statsMulti');

        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-heat-map')
          .within(() => {
            cy.get('g.heat-map').should('exist');
            cy.get('ngx-charts-scale-legend').should('exist');
            cy.get('g[ngx-charts-heat-map-cell]').should('exist').should('have.length', 16);
          });
      });

      it('bubble chart', () => {
        cy.get('@mainChartTypes').eq(6).click();
        cy.get('@mainChartTypes').eq(6).should('have.class', 'selected');
        cy.get('@textMeasure').click();
        cy.get('@textDimension').click();
        cy.get('@chartContainer')
          .find('.chart-status-message')
          .should('contain', 'Select 1 dimension or another chart type.');
        cy.get('@numericDimension').click();
        cy.wait('@statsMulti');
        cy.get('.stats-bar').scrollIntoView();
        cy.get('@chartContainer')
          .find('ngx-charts-bubble-chart')
          .within(() => {
            cy.get('g.bubble-chart').should('exist');
            cy.get('ngx-charts-scale-legend').should('exist');
            cy.get('g.circle').should('exist').should('have.length', 4);
          });
      });
    });
  });
});

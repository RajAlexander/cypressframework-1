describe('Feature Flags', () => {
  describe('Orchestration', () => {
    describe('Orchestration flag is enabled', () => {
      before(() => {
        cy.login();
        cy.setupStubbedSwimlane();
        cy.setMockFeatureFlag('DynamicOrchestration');
        cy.navigateSwimlane('/');
        cy.wait('@getEnabledFlags');
      });

      it('Shows the orchestration item in the main menu', () => {
        cy.get('.nav-items').as('nav-bar');
        cy.get('@nav-bar').find('.nav-item').contains('Orchestration').click();
        cy.get('@nav-bar').find('.sub-nav-item').contains('Playbooks').click();
        cy.location('pathname').should('eq', '/orchestration/playbooks');
      });

      it('Does not show the old integration item in the main menu', () => {
        cy.get('.nav-items').as('nav-bar');
        cy.get('@nav-bar').find('.nav-item').should('not.contain', 'Integration');
      });

      it('Navigating to integration results in a 404 ', () => {
        cy.navigateSwimlane('/integration');
        cy.location('pathname').should('eq', '/error');
      });

      it('Refers to itself as "Turbine"', () => {
        cy.navigateSwimlane('/welcome');
        cy.get('.content-area h1').should('contain', 'Welcome to Turbine');
      });
    });

    describe('Orchestration flag is disabled', () => {
      before(() => {
        cy.login();
        cy.setupStubbedSwimlane();
        cy.navigateSwimlane('/', { forceReload: true });
        cy.wait('@getEnabledFlags');
      });

      it('Shows the integration item in the main menu', () => {
        cy.get('.nav-items').as('nav-bar');
        cy.get('@nav-bar').find('.nav-item').contains('Integration').closest('.nav-item').as('button');

        cy.get('@button').click();
        cy.location('pathname').should('eq', '/integration');
      });

      it('Does not show orchestration item in the main menu', () => {
        cy.get('.nav-items').as('nav-bar');
        cy.get('@nav-bar').find('.nav-item').should('not.contain', 'Orchestration');
      });

      it('Navigating to orchestration results in a 404 ', () => {
        cy.navigateSwimlane('/orchestration');
        cy.location('pathname').should('eq', '/error');
      });

      it('Refers to itself as "Swimlane"', () => {
        cy.navigateSwimlane('/welcome');
        cy.get('.content-area h1').should('contain', 'Welcome to Swimlane');
      });
    });
  });
});

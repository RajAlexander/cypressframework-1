import { getLoremText } from '../../support/helpers/faker-helper';
import app from '../../fixtures/mocks/swimlane/app/ad2xJUGes5TNRKG4M/get.json';
import { dom } from '@swimlane/cy-dom-diff';
import { longPress } from '../../../shared/interactions';

function clickBackButton() {
  cy.get('.back-button').click();
}

const fields = [
  {
    name: 'Text',
    types: ['Single-Line', 'Multi-Line', 'Email', 'Telephone', 'URL', 'IP', 'Rich Text', 'JSON', 'List']
  },
  {
    name: 'Numeric',
    types: ['Numeric', 'List']
  },
  {
    name: 'Date/Time',
    types: ['Date & Time', 'Timespan', 'Date', 'Time', 'First Created', 'Last Updated']
  },
  {
    name: 'Selection',
    types: ['Single-select', 'Multi-select', 'Radio buttons', 'Checkboxes']
  },
  {
    name: 'Users/Groups',
    types: ['Single-select', 'Multi-select', 'Created By', 'Last Updated By']
  },
  {
    name: 'Attachments'
  },
  {
    name: 'Reference',
    types: ['Single-select', 'Multi-select', 'Grid']
  },
  {
    name: 'Comments'
  }
];

const layouts = ['Section', 'Tabs', 'HTML', 'Widget', 'Integration', 'History'];

describe('App Builder', () => {
  const appId = 'ad2xJUGes5TNRKG4M';

  describe('existing app', () => {
    before(() => {
      cy.login();

      cy.setupStubbedSwimlane();

      cy.navigateSwimlane(`/app-builder/${appId}`);
      cy.wait('@GET:applet');
    });

    beforeEach(() => {
      cy.get('.content-area').as('contentArea');
    });

    describe('tool bar', () => {
      it('header', () => {
        cy.get('@contentArea')
          .find('.app-builder-toolbar .ngx-toolbar-title > span')
          .should('contain', 'Application 1');
      });

      describe('content', () => {
        beforeEach(() => {
          cy.get('@contentArea').find('.app-builder-toolbar ngx-toolbar-content').as('toolBar');
          cy.get('@toolBar').find('.app-nav').as('nav');
          cy.get('@toolBar').find('.toolbar li').eq(0).as('saveButton');
          cy.get('@toolBar').find('.toolbar li').eq(1).as('ellipsis');
        });

        it('has nav bar', () => {
          cy.get('@nav').find('.ngx-navbar .ngx-navbar--nav-items').as('navItems');
          cy.get('@navItems').within(() => {
            cy.get('.ngx-navbar-item').eq(0).as('builderMode');
            cy.get('.ngx-navbar-item').eq(1).as('workflowMode');
            cy.get('.ngx-navbar-item').eq(2).as('reportMode');
            cy.get('@builderMode').should('have.class', 'active');
            cy.get('@builderMode').find('.ngx-icon').should('have.class', 'ngx-builder');
            cy.get('@workflowMode').should('not.have.class', 'active');
            cy.get('@workflowMode').find('.ngx-icon').should('have.class', 'ngx-workflow');
            cy.get('@reportMode').should('not.have.class', 'active');
            cy.get('@reportMode').find('.ngx-icon').should('have.class', 'ngx-reports');
          });
        });

        it('has save button', () => {
          cy.get('@saveButton').find('ngx-button').should('have.class', 'disabled-button');
        });

        it('has ellipsis', () => {
          cy.get('@ellipsis').within(() => {
            cy.get('ngx-dropdown-toggle').click();
            cy.get('ngx-dropdown-menu').should('exist');
            cy.get('ngx-dropdown-menu')
              .should('contain', 'Validate')
              .should('contain', 'Manage Export Templates')
              .should('contain', 'Export Application')
              .should('contain', 'History')
              .should('contain', 'Delete Records')
              .should('contain', 'Delete Application');
            cy.get('ngx-dropdown-toggle').click();
          });
        });

        describe('Export Application', () => {
          it('opens dialog', () => {
            cy.setupStubbedSwimlane();

            cy.get('@ellipsis').within(() => {
              cy.get('ngx-dropdown-toggle').click();
              cy.get('ngx-dropdown-menu').should('contain', 'Export Application');
              cy.get('.ngx-dropdown-menu .vertical-list li').contains('Export Application').click();
            });

            cy.get('.app-export--container .ngx-dialog-header').should('contain', 'Application Export');

            cy.get('.ngx-dialog-footer').within(() => {
              cy.get('.btn').should('have.length', 2);
              cy.get('.btn').contains('Cancel').click();
            });
          });
        });

        describe('Delete Records', () => {
          it('displays confirm delete records dialog after clicking delete records', () => {
            cy.get('@ellipsis').within(() => {
              cy.get('ngx-dropdown-toggle').click();
              cy.get('ngx-dropdown-menu').should('contain', 'Delete Records');
              cy.get('.ngx-dropdown-menu .vertical-list li').contains('Delete Records').click();
            });
            cy.get('.confirm-delete-records-dialog').should('be.visible');
            cy.get('.long-press').should('be.visible');
          });

          describe('confirming delete records', () => {
            const jobId = 'mock-tag-id-aM5iS07dU_ZD7fPaL';

            before(() => {
              cy.intercept('DELETE', `/api/app/${appId}/record/batch`, {
                body: jobId,
                statusCode: 202
              }).as('longPressRequest');
              longPress('@longPressRequest');
            });

            it('shows a status notification on task update via signalr', () => {
              cy.setupStubbedSwimlane();

              cy.hubPublish('taskUpdate', {
                bulkModificationType: 'delete',
                jobId,
                status: 'finished',
                taskName: 'BatchRecordUpdate',
                totalRecordsSkipped: 0,
                totalRecordsUpdated: 10
              });

              cy.get('.ngx-notification')
                .should('be.visible')
                .within(() => {
                  cy.get('h2').contains('Bulk delete process finished');
                  cy.get('.ngx-notification-body').contains(`10 records were`).contains(`0 records failed`);
                  cy.get('.icon-x').click();
                });
            });

            it('closes the delete records dialog', () => {
              cy.get('.confirm-delete-records-dialog button').contains('Close').click();
              cy.get('.confirm-delete-records-dialog').should('not.exist');
            });
          });
        });
      });
    });

    describe('builder source', () => {
      beforeEach(() => {
        cy.get('@contentArea').find('.builder-source').find('.ngx-section').eq(0).as('fields');
        cy.get('@contentArea').find('.builder-source').find('.ngx-section').eq(1).as('layouts');
        cy.get('@contentArea').find('applets-container').find('.ngx-section').as('applets');
      });

      describe('field types', () => {
        it('header', () => {
          cy.get('@fields').find('header').should('contain', 'Field Types');
        });

        fields.forEach((field, idx) => {
          const fieldName = field.name;
          it(fieldName, () => {
            cy.get('@fields').find('.builder-source-item').eq(idx).as(fieldName).should('contain', fieldName);
            if (field.types) {
              cy.get(`@${fieldName}`).find('.corner').click();
              cy.get('@fields').within(() => {
                cy.get('.builder-source-item').should('have.length', field.types.length);
                field.types.forEach((t, i) => {
                  cy.get('.builder-source-item').eq(i).should('contain', t);
                });
                clickBackButton();
              });
            }
          });
        });
      });

      describe('layout', () => {
        it('header', () => {
          cy.get('@layouts').find('header').should('contain', 'Layout');
        });
        layouts.forEach((layout, idx) => {
          it(layout, () => {
            cy.get('@layouts').find('.builder-source-item').eq(idx).should('contain', layout);
          });
        });
      });

      describe('applets', () => {
        it('header', () => {
          cy.get('@applets').find('header').should('contain', 'Applets');
        });

        it('search bar', () => {
          cy.get('@applets').within(() => {
            cy.get('.search-box').should('exist');
            cy.get('.builder-source-applet').as('applets').should('have.length', 2);
            cy.get('.ngx-input-box').focus().type('1');
            cy.get('@applets').should('have.length', 1);
            cy.get('@applets').eq(0).should('contain', 'Applet 1');
            cy.get('.ngx-input-box').focus().clear();
          });
        });
      });
    });

    describe('settings panel', () => {
      beforeEach('', () => {
        cy.get('@contentArea').find('.settings-panel').as('settingsPanel');
      });

      it('has controls', () => {
        cy.get('@settingsPanel').find('ngx-tabs button.ngx-tab').first().should('contain', 'App Settings');
        cy.get('@settingsPanel').find('ngx-tabs .ngx-tab').first().should('have.class', 'active');
        cy.get('@settingsPanel').find('ngx-tabs button.ngx-tab').eq(1).should('contain', 'Field Properties');
      });

      describe('app settings', () => {
        describe('name input', () => {
          const loremText = getLoremText(130);

          beforeEach(() => {
            cy.get('@settingsPanel').find('input#name').as('name').should('be.visible');
          });

          after(() => {
            cy.get('@settingsPanel').find('input#name').invoke('prop', 'value', 'Application 1').trigger('input');
          });

          it('limits input to 128 characters', () => {
            cy.get('@name').clear().type(loremText, { delay: 1 });
            cy.get('@name').should('have.value', loremText.slice(0, 128));
          });

          it('shows errors on inputs larger than 128 characters', () => {
            cy.get('@name').should('have.class', 'ng-valid');
            cy.get('@name').invoke('prop', 'value', loremText).trigger('input');
            cy.get('@name').should('have.class', 'ng-invalid');
          });
        });

        it('acronym input', () => {
          cy.get('@settingsPanel').find('input').eq(1).as('acInput').should('be.visible');
          cy.get('@acInput').should('have.attr', 'disabled');
        });

        it('description input', () => {
          cy.get('@settingsPanel').find('#input-description').should('be.visible');
        });

        it('tracking time toggle', () => {
          cy.get('@settingsPanel').within(() => {
            cy.get('.ngx-toggle').should('be.visible');
            cy.get('.ngx-toggle-text').should('contain', 'Enable tracking time');
          });
        });

        describe('additional settings', () => {
          beforeEach(() => {
            cy.get('@settingsPanel').find('button').contains('Additional Settings').as('settingsButton');
          });

          after(() => {
            cy.get('ngx-dialog').find('button.close').click();
            cy.get('ngx-dialog').should('not.exist');
          });

          it('dialog opens', () => {
            cy.get('@settingsButton').should('be.visible');
            cy.get('@settingsButton').should('contain', 'Additional Settings');
            cy.get('@settingsButton').click();
            cy.get('ngx-dialog').should('be.visible');
            cy.get('ngx-dialog').within(() => {
              cy.get('.application-id').should('contain', appId);
            });
          });
        });
      });
    });

    describe('builder target', () => {
      beforeEach(() => {
        cy.get('@contentArea').find('.builder-target').find('fieldset').eq(0).as('formLayout');
        cy.get('@contentArea').find('.builder-target').find('fieldset').eq(1).as('hiddenFields');
      });

      describe('form layout', () => {
        beforeEach(() => {
          cy.get('@formLayout').find('.layout').as('layouts');
        });

        it('header', () => {
          cy.get('@formLayout').find('legend').should('contain', 'Form Layout');
        });

        it('layouts', () => {
          cy.get('@layouts').should('have.length', 10);
          app.layout.forEach((l, idx) => {
            cy.get('@layouts')
              .eq(idx)
              .within(() => {
                cy.get('app-editable-name-label').should('contain', l.name);
                cy.get('app-layout-container').find('app-field').should('have.length', l.children.length);
              });
          });
        });
      });

      describe('hidden form layout', () => {
        it('header', () => {
          cy.get('@hiddenFields').find('legend').should('contain', 'Hidden Fields');
        });

        it('has tracking field', () => {
          cy.get('@hiddenFields').find('.builder-target-item').as('hiddenFieldItems');
          cy.get('@hiddenFieldItems').should('have.length', 1);
          cy.get('@hiddenFieldItems').eq(0).should('contain', 'Tracking Id');
        });
      });
    });

    describe('nag', () => {
      beforeEach(() => {
        cy.get('@contentArea').find('.ngx-nag-content').as('nag');
      });

      after(() => {
        cy.get('@nag').find('ngx-icon[fontIcon="arrow-down"]').click({ force: true });
        cy.get('.ngx-nag-body').should('not.be.visible');
      });

      it('shows nag', () => {
        cy.get('@nag').within(() => {
          cy.get('ngx-toolbar-title > h2').should('contain', 'One error found in this application');
          cy.get('ngx-icon[fontIcon="arrow-down"]').click({ force: true });
          cy.get('.ngx-nag-body').should('be.visible');
        });
      });
    });
  });

  describe('clean builder', () => {
    const cleanAppId = 'aWHd_B_cbJiD8ldb0';
    before(() => {
      cy.login();

      cy.setupStubbedSwimlane();
      cy.navigateSwimlane(`/app-builder/${cleanAppId}`);
      cy.wait('@GET:applet');
    });

    beforeEach(() => {
      cy.get('.content-area').as('contentArea');
    });

    describe('form layout', () => {
      beforeEach(() => {
        cy.get('@contentArea').find('.builder-target').find('fieldset').eq(0).as('formLayout');
        cy.get('@formLayout').find('.builder-target').as('builderTarget');
        cy.get('@contentArea').find('.builder-source').find('.ngx-section').eq(0).as('fieldItems');
        cy.get('@contentArea').find('.builder-source').find('.ngx-section').eq(1).as('layoutItems');
        cy.get('@contentArea').find('applets-container').find('.ngx-section').as('appletItems');
        cy.get('@contentArea').find('.settings-panel').as('settingsPanel');
        cy.get('@settingsPanel').find('ngx-tabs .ngx-tab').eq(1).as('fieldPropertySettings');
        cy.get('@settingsPanel').find('ngx-tabs ngx-tab').eq(1).as('fieldPropertySettingsContent');
        cy.get('@contentArea')
          .find('.app-builder-toolbar ngx-toolbar-content')
          .find('.toolbar li ngx-button')
          .eq(0)
          .as('saveButton');
      });

      it('clean form', () => {
        const PNG = /[a-z0-9]+\.png/;
        cy.get('@formLayout').find('.bg-message').domMatch(dom`
          <h1>
            Start building your application
          </h1>
          <br />
          <div>
            Simply drag and drop from the components on the left.
          </div>
          <br />
          <img src="/dist/${PNG}" />
        `);
        cy.get('@saveButton').should('have.class', 'disabled-button');
      });

      describe('fields', () => {
        it('drags and drops fields', () => {
          fields.forEach((field, idx) => {
            const fieldName = field.name;
            cy.get('@fieldItems').find('.builder-source-item').eq(idx).as(fieldName);
            if (field.types) {
              cy.get(`@${fieldName}`).find('.corner').click();
              cy.get('@fieldItems').within(() => {
                cy.get('.builder-source-item').should('have.length', field.types.length);
                field.types.forEach((t, i) => {
                  cy.get('.builder-source-item')
                    .eq(i)
                    .as(fieldName + i);
                  cy.dragAndDrop(`@${fieldName}${i}`, '@builderTarget');
                });
                clickBackButton();
              });
            } else {
              cy.dragAndDrop(`@${fieldName}`, '@builderTarget');
            }
          });
          cy.get('@formLayout').find('.builder-target-item').should('have.length', 30);
          cy.get('@saveButton').should('not.have.class', 'disabled-button');
        });

        it('field properties settings', () => {
          cy.get('@formLayout')
            .find('.builder-target-item')
            .each($targetItem => {
              cy.wrap($targetItem).click();
              cy.wrap($targetItem).should('have.class', 'active');
              cy.get('@fieldPropertySettings').should('have.class', 'active');
              cy.get('@fieldPropertySettingsContent').find('.delete-field-wrapper > ngx-icon').should('be.visible');
            });
        });

        it('removes fields', () => {
          cy.get('@formLayout')
            .find('.builder-target-item')
            .each(($targetItem, index) => {
              if (index % 2 === 0) {
                // Removing item with field action buttons
                cy.wrap($targetItem).trigger('mouseover');
                cy.wrap($targetItem).find('.drop-in').should('be.visible');
                cy.wrap($targetItem)
                  .find('.drop-in')
                  .within(() => {
                    cy.get('.ngx-icon').first().click({ force: true });
                  });
              } else {
                // Removing item with trash icon in field property settings panel
                cy.wrap($targetItem).click();
                cy.get('@fieldPropertySettingsContent').find('.delete-field-wrapper > ngx-icon').click({ force: true });
              }
            });
          cy.get('@formLayout').find('.builder-target-item').should('have.length', 0);
          cy.get('@saveButton').should('have.class', 'disabled-button');
        });
      });

      describe('layouts', () => {
        it('drags and drops layouts', () => {
          layouts.forEach((layout, idx) => {
            cy.get('@layoutItems').find('.builder-source-item').eq(idx).as(layout);
            cy.dragAndDrop(`@${layout}`, '@builderTarget');
          });
          cy.get('@formLayout').find('.builder-target-item').should('have.length', 6);
        });

        it('layout properties settings', () => {
          cy.get('@formLayout')
            .find('.builder-target-item')
            .each($targetItem => {
              cy.wrap($targetItem).click();
              cy.wrap($targetItem).should('have.class', 'active');
              cy.get('@fieldPropertySettings').should('have.class', 'active');
            });
        });

        it('shows confirmations on edit an existing task', () => {
          cy.get('@formLayout').find('.builder-target-item.integration').click();
          cy.get('@fieldPropertySettings').should('have.class', 'active');
          cy.get('app-properties-container').within(() => {
            cy.getByLabel('Task').select('GitLab PR');
            cy.get('a').contains('Edit Task').click();
          });
          cy.get('.ngx-alert-dialog.confirm')
            .should('exist')
            .within(() => {
              cy.get('.ngx-dialog-header').should('contain', 'Save Confirmation');
              cy.get('.ngx-dialog-body').should(
                'contain',
                'You must save this application before creating or editing a task. Save now?'
              );
              cy.get('button').contains('Cancel').click();
            });
        });

        it('shows confirmations on create a task', () => {
          cy.setupStubbedSwimlane();

          cy.get('@formLayout').find('.builder-target-item.integration').click();
          cy.get('@fieldPropertySettings').should('have.class', 'active');
          cy.get('app-properties-container').within(() => {
            cy.getByLabel('Task').select('Create a Task');
          });
          cy.get('.ngx-alert-dialog.confirm')
            .should('exist')
            .within(() => {
              cy.get('.ngx-dialog-header').should('contain', 'Save Confirmation');
              cy.get('.ngx-dialog-body').should(
                'contain',
                'You must save this application before creating or editing a task. Save now?'
              );
              cy.get('button').contains('Cancel').click();
            });
        });

        it('removes layouts', () => {
          cy.get('@formLayout')
            .find('.builder-target-item')
            .each(($targetItem, index) => {
              if (index % 2 === 0) {
                // Removing item with trash icon in layout property settings panel
                cy.wrap($targetItem).click();
                cy.get('@fieldPropertySettingsContent').find('.delete-field-wrapper > ngx-icon').click();
              } else {
                cy.wrap($targetItem).trigger('mouseover');
                cy.wrap($targetItem).find('.drop-in').should('be.visible');
                cy.wrap($targetItem)
                  .find('.drop-in')
                  .within(() => {
                    cy.get('.ngx-icon').first().click({ force: true });
                  });
              }
            });
          cy.get('@formLayout').find('.builder-target-item').should('have.length', 0);
          cy.get('@saveButton').should('have.class', 'disabled-button');
        });
      });

      describe('applets', () => {
        describe('pending applets', () => {
          it('displays applet placeholder and removes it', () => {
            cy.get('@appletItems').find('.builder-source-applet').eq(1).as('applet');
            cy.dragAndDrop('@applet', '@builderTarget');
            cy.get('@formLayout').find('.builder-target-item').should('have.length', 1);

            cy.get('@formLayout').find('.builder-target-item').eq(0).find('ngx-progress-spinner').should('exist');
            cy.get('@contentArea')
              .find('.app-builder-toolbar ngx-toolbar-content')
              .find('.toolbar li ngx-button')
              .eq(0)
              .as('saveButton');
            cy.get('@saveButton').should('have.class', 'disabled-button');

            cy.get('@formLayout')
              .find('.builder-target-item')
              .eq(0)
              .within(() => {
                cy.get('.applet-icon').should('contain', 'TA');
                cy.get('.confirmation-message').should('contain', 'Add Applet 1 Here?');
                cy.get('ngx-button').should('have.length', 2);
                cy.get('@saveButton').should('not.have.class', 'disabled-button');
                cy.get('ngx-button').contains('Cancel').click();
              });
            cy.get('@formLayout').find('.builder-target-item').should('have.length', 0);
          });

          it('adds an applet - no workflow, no task', () => {
            cy.get('@appletItems').find('.builder-source-applet').eq(0).as('applet');
            cy.dragAndDrop('@applet', '@builderTarget');
            cy.get('@formLayout').find('.builder-target-item').should('have.length', 1);
            cy.get('@formLayout')
              .find('.builder-target-item')
              .eq(0)
              .within(() => {
                cy.get('.applet-icon').should('contain', 'QA');
                cy.get('.confirmation-message').should('contain', 'Add Applet 2 Here?');
                cy.get('ngx-button').should('have.length', 2);
                cy.get('ngx-button').contains('Add').click();
              });
            cy.get('@formLayout')
              .find('.builder-target-item')
              .eq(0)
              .as('applet')
              .within(() => {
                cy.get('app-editable-name-label').should('contain', 'Applet 2');
                cy.get('app-field').as('fieldItem').should('have.length', 2);
                cy.get('app-field').as('fieldItem').eq(0).find('app-editable-name-label').should('contain', 'Text');
                cy.get('app-field')
                  .as('fieldItem')
                  .eq(1)
                  .find('app-editable-name-label')
                  .should('contain', 'Integration');
              });

            cy.get('@applet').trigger('mouseover');
            cy.get('@applet').find('.drop-in').should('be.visible');
            cy.get('@applet')
              .find('.drop-in')
              .within(() => {
                cy.get('.ngx-icon').first().click({ force: true });
              });
            cy.get('.ngx-dialog').should('be.visible');
            cy.get('.ngx-dialog').within(() => {
              cy.get('.ngx-dialog-header').should('contain', 'Remove Section');
              cy.get('button').first().click();
            });
            cy.get('@formLayout').find('.builder-target-item').should('have.length', 0);
          });

          describe('adds an applet - has workflow', () => {
            const cleanAppId = 'a8k1c3QLv5u8kFHLM';
            const workflowId = 'ab3n5rtOKQ7PuYKzk';
            before(() => {
              cy.setupStubbedSwimlane();
              cy.intercept('GET', '/api/applet', {
                fixture: 'mocks/swimlane/applet/applet-has-workflow.json'
              }).as('GET:applet');
              cy.intercept('GET', `/api/workflow/${cleanAppId}`, {
                fixture: `mocks/swimlane/workflow/${cleanAppId}/get.json`
              }).as('GET:workflow');
              cy.navigateSwimlane(`/app-builder/${cleanAppId}`);
              cy.wait('@GET:workflow');
              cy.wait('@GET:applet');
            });

            it('accept pending applets', () => {
              cy.intercept('PUT', `/api/workflow/${workflowId}`, {
                fixture: `mocks/swimlane/workflow/${cleanAppId}/put.json`
              }).as('PUT:workflow');
              cy.get('@appletItems').find('.builder-source-applet').eq(0).as('applet');
              cy.dragAndDrop('@applet', '@builderTarget');
              cy.get('@formLayout').find('.builder-target-item').should('have.length', 1);
              cy.get('@formLayout')
                .find('.builder-target-item')
                .eq(0)
                .within(() => {
                  cy.get('.applet-icon').should('contain', 'TA');
                  cy.get('.confirmation-message')
                    .should('contain', 'Add Test Applet Here?')
                    .should('contain', `This action also adds the applet's workflow (in a disabled state).`);
                  cy.get('ngx-button').should('have.length', 2);
                  cy.get('ngx-button').contains('Add').click();
                  cy.wait('@PUT:workflow');
                });
              cy.get('@formLayout')
                .find('.section.builder-target-item')
                .eq(0)
                .within(() => {
                  cy.get('app-editable-name-label').should('contain', 'Test Applet');
                  cy.get('app-field').as('fieldItem').should('have.length', 2);
                  cy.get('@fieldItem').eq(0).find('app-editable-name-label').should('contain', 'Text');
                  cy.get('@fieldItem').eq(1).find('app-editable-name-label').should('contain', 'Numeric');
                });

              cy.get('@formLayout').find('.section.builder-target-item').eq(0).as('section');
              cy.get('@section').trigger('mouseover');
              cy.get('@section').find('.drop-in').should('be.visible');
              cy.get('@section')
                .find('.drop-in')
                .within(() => {
                  cy.get('.ngx-icon').first().click({ force: true });
                });
              cy.get('.ngx-dialog').should('be.visible');
              cy.get('.ngx-dialog').within(() => {
                cy.get('.ngx-dialog-header').should('contain', 'Remove Section');
                cy.get('button').first().click();
              });
              cy.get('@formLayout').find('.builder-target-item').should('have.length', 0);
            });
          });
        });

        describe('new applet', () => {
          before(() => {
            cy.setupStubbedSwimlane();
            cy.navigateSwimlane(`/app-builder/${cleanAppId}`);
          });

          after(() => {
            cy.get('@formLayout').find('.builder-target-item').eq(0).as('applet');
            cy.get('@applet').within(() => {
              cy.get('ngx-section').trigger('mouseover');
              cy.get('ngx-section .drop-in').as('controls').should('be.visible');
              cy.get('@controls').find('.ngx-icon').eq(0).click({ force: true });
            });
            cy.get('.ngx-dialog').should('be.visible');
            cy.get('.ngx-dialog').within(() => {
              cy.get('.ngx-dialog-header').should('contain', 'Remove Section');
              cy.get('button').first().click();
            });
            cy.get('@formLayout').find('.builder-target-item').should('have.length', 0);
          });

          it('section', () => {
            cy.get('@layoutItems').find('.builder-source-item').eq(0).as('section');
            cy.dragAndDrop('@section', '@builderTarget');
            cy.get('@formLayout').find('.builder-target-item').should('have.length', 1);
            cy.get('@formLayout').find('.builder-target-item').eq(0).as('applet');
            cy.get('@applet').find('app-layout-container .builder-target').as('appletTarget');
            cy.get('@fieldItems').find('.builder-source-item').eq(0).as('textField');
            cy.dragAndDrop('@textField', '@appletTarget');
            cy.get('@applet').find('app-field').as('fieldItem').should('have.length', 1);
          });

          it('section settings', () => {
            cy.get('@formLayout').find('.builder-target-item').eq(0).as('applet');
            cy.get('@applet').click();
            cy.get('@fieldPropertySettings').should('have.class', 'active');
            cy.get('@settingsPanel').within(() => {
              cy.get('ngx-input[label="Section Name"] input').as('nameField').should('be.visible');
              cy.get('@nameField').focus().clear().type('New Section');
            });
          });

          it('opens dialog', () => {
            cy.setupStubbedSwimlane();
            cy.get('@formLayout').find('.builder-target-item').eq(0).as('applet');
            cy.get('@applet').within(() => {
              cy.get('app-field').as('fieldItem').eq(0).find('app-editable-name-label').should('contain', 'Text');
              cy.get('ngx-section').trigger('mouseover');
              cy.get('ngx-section .drop-in').as('controls').should('be.visible');
              cy.get('@controls').find('.ngx-icon').eq(1).click({ force: true });
            });
            cy.get('ngx-dialog').should('be.visible');
            cy.get('ngx-dialog').within(() => {
              cy.get('ngx-icon.submit-link').click();
            });
            cy.get('ngx-dialog').find('create-applet').as('createAppletDlg').should('be.visible');
            cy.get('@createAppletDlg').within(() => {
              cy.get('.help-banner').contains('Create Applet');
              cy.get('ngx-button.create-applet--btn-submit').click();
              cy.wait('@POST:applet');
            });
            cy.get('@appletItems').find('.builder-source-applet').should('have.length', 3);
          });
        });
      });

      describe('save', () => {
        before(() => {
          cy.login();
          cy.setupStubbedSwimlane();
          cy.navigateSwimlane(`/app-builder/${cleanAppId}`);
        });

        beforeEach(() => {
          cy.get('@contentArea')
            .find('.app-builder-toolbar ngx-toolbar-content')
            .find('.toolbar li ngx-button')
            .eq(0)
            .as('saveButton');
          cy.get('@contentArea').find('.builder-target').find('fieldset').eq(0).as('formLayout');
          cy.get('@formLayout').find('.builder-target').as('builderTarget');
          cy.get('@contentArea').find('.builder-source').find('.ngx-section').eq(0).as('fieldItems');
          cy.get('@fieldItems').find('.builder-source-item').eq(0).as('textField');
        });

        afterEach(() => {
          cy.get('@formLayout').find('.builder-target-item').eq(0).as('field');
          cy.get('@field').trigger('mouseover');
          cy.get('@field').find('.drop-in').should('be.visible');
          cy.get('@field')
            .find('.drop-in')
            .within(() => {
              cy.get('.ngx-icon').first().click({ force: true });
            });
        });

        it('invalid state', () => {
          cy.dragAndDrop('@textField', '@builderTarget');
          cy.get('@formLayout').find('.builder-target-item').eq(0).click();
          cy.get('@fieldPropertySettings').should('have.class', 'active');
          cy.get('@settingsPanel').within(() => {
            cy.get('ngx-input[label="Name"] input').as('nameField').should('be.visible');
            cy.get('@nameField').last().focus().clear();
            cy.get('ngx-input').should('have.class', 'ng-invalid');
          });
          cy.get('@saveButton').click();
          cy.get('.ngx-nag-content').should('be.visible');
          cy.get('ngx-notification').should('have.class', 'ngx-notification-error');
          cy.get('ngx-notification').find('.ngx-notification-close').eq(0).click({ force: true });
          cy.get('ngx-notification').should('not.exist');
          cy.get('@saveButton').should('not.have.class', 'disabled-button');
        });

        it('save and leave', () => {
          cy.dragAndDrop('@textField', '@builderTarget');
          cy.navigateSwimlane(`/app-builder/${appId}`);
          cy.get('ngx-dialog').as('saveLeaveDlg').should('be.visible');
          cy.get('@saveLeaveDlg').within(() => {
            cy.get('h2').should('contain', 'You have unsaved changes to this application.');
            cy.get('p').should('contain', 'Are you sure you want to leave?');
            cy.get('.ngx-dialog-footer button').should('have.length', 3);
            cy.get('.ngx-dialog-footer button').eq(0).should('contain', 'Leave');
            cy.get('.ngx-dialog-footer button').eq(1).should('contain', 'Save and Leave');
            cy.get('.ngx-dialog-footer button').eq(2).should('contain', 'Cancel');
            cy.get('.ngx-dialog-footer button').eq(2).click();
          });
          cy.get('@saveButton').should('not.have.class', 'disabled-button');
        });

        it('valid state', () => {
          cy.setupStubbedSwimlane();
          cy.dragAndDrop('@textField', '@builderTarget');
          cy.get('@formLayout').find('.builder-target-item').eq(0).as('validField');
          cy.get('@saveButton').click();
          cy.wait(`@PUT:app/${cleanAppId}`);
          cy.get('ngx-notification').should('have.class', 'ngx-notification-success');
          cy.get('ngx-notification').find('.ngx-notification-close').eq(0).click({ force: true });
          cy.get('ngx-notification').should('not.exist');
          cy.get('@saveButton').should('have.class', 'disabled-button');
        });

        it('has pending applets', () => {
          cy.setupStubbedSwimlane();
          cy.get('@appletItems').find('.builder-source-applet').eq(0).as('applet');
          cy.dragAndDrop('@applet', '@builderTarget');
          cy.get('@formLayout').find('.builder-target-item').eq(0).as('pendingApplet').should('exist');
          cy.get('@pendingApplet').should('contain', 'Add Applet 2 Here?');
          cy.get('@saveButton').click();
          cy.get('.ngx-alert-dialog .ngx-dialog-content').within(() => {
            cy.get('.ngx-dialog-header').should('contain', 'You have 1 applet in your application layout');
            cy.get('.ngx-dialog-body').should(
              'contain',
              'When you save this application, all pending applets are added to your layout'
            );
            cy.get('button').contains('Ok').click();
          });
          cy.wait(`@PUT:app/${cleanAppId}`);
          cy.get('ngx-notification').should('have.class', 'ngx-notification-success');
          cy.get('ngx-notification').find('.ngx-notification-close').eq(0).click({ force: true });
          cy.get('ngx-notification').should('not.exist');
          cy.get('@saveButton').should('have.class', 'disabled-button');
        });
      });
    });
  });

  describe('widget', () => {
    const cleanAppId = 'a8k1c3QLv5u8kFHLM';
    before(() => {
      cy.login();

      cy.setupStubbedSwimlane();
      cy.navigateSwimlane(`/app-builder/${cleanAppId}`);
      cy.get('ngx-dialog').as('saveLeaveDlg').should('be.visible');
      cy.get('@saveLeaveDlg').within(() => {
        cy.get('.ngx-dialog-footer button').eq(0).click();
      });
    });

    beforeEach(() => {
      cy.get('.content-area').as('contentArea');
    });

    describe('widget editor', () => {
      beforeEach(() => {
        cy.get('@contentArea').find('.builder-target').find('fieldset').eq(0).as('formLayout');
        cy.get('@formLayout').find('.builder-target').as('builderTarget');
        cy.get('@contentArea').find('.builder-source').find('.ngx-section').eq(1).as('layoutItems');
        cy.get('@contentArea').find('.settings-panel').as('settingsPanel');
        cy.get('@settingsPanel').find('ngx-tabs .ngx-tab').eq(1).as('fieldPropertySettings');
        cy.get('@contentArea')
          .find('.app-builder-toolbar ngx-toolbar-content')
          .find('.toolbar li ngx-button')
          .eq(0)
          .as('saveButton');
      });

      it('drags and drops widget field', () => {
        cy.setupStubbedSwimlane();
        cy.get('@layoutItems').find('.builder-source-item').eq(3).as('widgetField');
        cy.dragAndDrop('@widgetField', '@builderTarget');
        cy.get('@saveButton').click();
        cy.wait(`@PUT:app/${cleanAppId}`);
      });

      it('opens widget field settings', () => {
        cy.get('@formLayout')
          .find('.builder-target-item')
          .each($targetItem => {
            cy.wrap($targetItem).click();
            cy.wrap($targetItem).should('have.class', 'active');
            cy.get('@fieldPropertySettings').should('have.class', 'active');
          });
      });

      it('opens widget editor', () => {
        cy.setupStubbedSwimlane();
        cy.get('@settingsPanel')
          .find('[data-cy=edit_widget__btn]')
          .contains(/^\s*Edit Widget\s*$/)
          .click();
        cy.get('widget-editor').as('editor').should('be.visible');
        cy.get('@editor').within(() => {
          cy.get('.panel-header ngx-tabs').contains('button', 'preview record data').click();
          cy.get('[data-cy=record_select__input]').should('exist');
          cy.get('[data-cy=editor_cancel__btn]').click();
        });
      });

      it('removes widget field', () => {
        cy.get('@formLayout')
          .find('.builder-target-item')
          .each($targetItem => {
            cy.wrap($targetItem).trigger('mouseover');
            cy.wrap($targetItem).find('.drop-in').should('be.visible');
            cy.wrap($targetItem)
              .find('.drop-in')
              .within(() => {
                cy.get('.ngx-icon').first().click({ force: true });
              });
          });
        cy.get('@formLayout').find('.builder-target-item').should('have.length', 0);
      });
    });
  });
});

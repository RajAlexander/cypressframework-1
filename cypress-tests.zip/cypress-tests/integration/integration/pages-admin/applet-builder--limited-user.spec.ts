describe('Applet Builder - as non admin', () => {
  const appletId = 'ae7XaH2STB6KM28t';

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();

    // Reset login to a limited user
    cy.intercept('GET', '/api/user/authorize', {
      fixture: 'mocks/swimlane/user/authorize/get-user.json'
    }).as('GET:user/authorize');
    cy.navigateSwimlane(`/applet-builder/${appletId}`);
  });

  beforeEach(() => {
    cy.get('.content-area').find('.applet-builder-toolbar ngx-toolbar-content').as('toolBar');
    cy.get('@toolBar').find('.applet-nav').as('nav');
    cy.get('@toolBar').find('.toolbar li').eq(0).as('saveButton');
    cy.get('@toolBar').find('.toolbar li').eq(1).as('ellipsis');
  });

  describe('tool bar', () => {
    it('header', () => {
      cy.get('.content-area')
        .find('.applet-builder-toolbar .ngx-toolbar-title > span')
        .should('contain', 'Test Applet');
    });

    it('has ellipsis', () => {
      cy.get('@ellipsis').within(() => {
        cy.get('ngx-dropdown-toggle').click();
        cy.get('ngx-dropdown-menu').should('exist');
        cy.get('ngx-dropdown-menu')
          .should('contain', 'Validate')
          .should('not.contain', 'Export Applet')
          .should('contain', 'History')
          .should('contain', 'Delete Applet');
        cy.get('ngx-dropdown-toggle').click();
      });
    });
  });
});

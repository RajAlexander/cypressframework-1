describe('Admin Users Page', () => {
  before(() => {
    cy.login();

    cy.setupStubbedSwimlane();
    cy.navigateSwimlane('/users');
    cy.wait('@GET:user?*');
    cy.wait('@GET:user?*');
  });

  it('toolbar', () => {
    cy.get('ngx-toolbar-content > button').as('toolbarButtons');
    cy.get('@toolbarButtons').first().should('have.text', 'New User');
    cy.get('[data-cy=users__filter-input]')
      .should('exist')
      .should('have.attr', 'placeholder', 'Filter by user name...');
  });

  it('first column is Name column', () => {
    cy.get('.datatable-header-cell-wrapper').first().should('have.text', 'Name');
  });

  it('second column is Groups column', () => {
    cy.get('.datatable-header-cell-wrapper').eq(1).should('have.text', 'Groups');
  });

  it('third column is Roles column', () => {
    cy.get('.datatable-header-cell-wrapper').eq(2).should('have.text', 'Roles');
  });

  it('fourth column is Created column', () => {
    cy.get('.datatable-header-cell-wrapper').eq(3).should('have.text', 'Created');
  });

  it('fifth column is Modified column', () => {
    cy.get('.datatable-header-cell-wrapper').eq(4).should('have.text', 'Modified');
  });

  it('sixth column is Authentication column', () => {
    cy.get('.datatable-header-cell-wrapper').eq(5).should('have.text', 'Authentication');
  });

  describe('Populated with users', () => {
    it('table footer shows 21 total', () => {
      cy.get('div.page-count').should('have.text', ' 21 total ');
    });

    it('"admin" user is not deletable', () => {
      cy.get('datatable-body-row').first().find('datatable-body-cell').last().as('deleteCell');
      cy.get('@deleteCell').find('.datatable-body-cell-label').should('not.contain', 'i.ngx-trash');
    });

    it('other users are deletable', () => {
      cy.get('datatable-body-row').eq(1).find('datatable-body-cell').last().as('deleteCell2');
      cy.get('@deleteCell2').find('.datatable-body-cell-label i.ngx-trash').should('exist');
    });

    it('locked user has tag', () => {
      cy.get('datatable-body-row').eq(1).find('datatable-body-cell').first().as('userNameCell');
      cy.get('@userNameCell').within(() => {
        cy.get('[data-cy=users__locked-tag]').should('exist').should('contain', 'Locked');
      });
    });

    it('clicking on name column changes sort direction to desc', () => {
      cy.get('datatable-header-cell').first().find('span.datatable-header-cell-wrapper').dblclick();
      cy.get('datatable-header-cell .sort-desc').should('exist');
    });
  });

  describe('No users', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.intercept('/api/user?**', { items: [], totalCount: 0 }).as('getEmptyUsers');
      cy.navigateSwimlane('/users');
      cy.wait('@getEmptyUsers');
    });

    it('table footer shows 0 total', () => {
      cy.get('div.page-count').should('have.text', ' 0 total ');
    });
  });

  describe('New user modal', () => {
    before(() => {
      cy.get('ngx-toolbar-content > button').first().click();
    });

    it('new user form contains first name field and is required', () => {
      cy.get('ngx-input[formcontrolname="firstName"]').should('exist').should('have.attr', 'required');
    });

    it('new user form contains middle initial field', () => {
      cy.get('ngx-input[formcontrolname="middleInitial"]').should('exist');
    });

    it('new user form contains last name field and is required', () => {
      cy.get('ngx-input[formcontrolname="lastName"]').should('exist').should('have.attr', 'required');
    });

    it('new user form contains display name field and is required', () => {
      cy.get('ngx-input[formcontrolname="displayName"]').should('exist').should('have.attr', 'required');
    });

    it('new user form contains email field and is required', () => {
      cy.get('ngx-input[formcontrolname="email"]').should('exist').should('have.attr', 'required');
    });

    it('new user form contains username field and is required', () => {
      cy.get('ngx-input[formcontrolname="username"]').should('exist').should('have.attr', 'required');
    });

    it('new user form contains password field', () => {
      cy.get('ngx-input[formcontrolname="password"]').should('exist');
    });

    it('new user form contains groups field', () => {
      cy.get('ngx-select[formcontrolname="groups"]').should('exist');
    });

    it('new user form contains roles field', () => {
      cy.get('ngx-select[formcontrolname="roles"]').should('exist');
    });

    it('new user form contains notify by email checkbox and is disabled by default', () => {
      cy.get('ngx-checkbox[formcontrolname="notify"]').should('exist').should('have.class', 'disabled');
    });

    describe('Auto generated password', () => {
      it('should allow to save if all required fields are complete and no password added', () => {
        cy.get('ngx-input[formcontrolname="firstName"]').type('John');
        cy.get('ngx-input[formcontrolname="lastName"]').type('Doe');
        cy.get('ngx-input[formcontrolname="displayName"]').type('Johnny');
        cy.get('ngx-input[formcontrolname="email"]').type('john@email.com');
        cy.get('ngx-input[formcontrolname="username"]').type('john');
        cy.get('.ngx-dialog-footer > button').should('exist').not('have.attr', 'disabled');
      });

      it('should not allow to save if password does not meet requirements', () => {
        cy.get('ngx-input[formcontrolname="password"]').type('123');
        cy.get('.ngx-dialog-footer > button').should('exist').should('have.attr', 'disabled');
      });

      it('should set notify via email to true if no password was added', () => {
        cy.get('.ngx-checkbox--box').as('notifyViaEmailCheckbox').click();
        cy.get('ngx-input[formcontrolname="password"]').clear();
        cy.get('@notifyViaEmailCheckbox').should('have.class', 'checked');
        cy.get('.ngx-dialog-footer > button').should('exist').not('have.attr', 'disabled');
      });
    });
  });
});

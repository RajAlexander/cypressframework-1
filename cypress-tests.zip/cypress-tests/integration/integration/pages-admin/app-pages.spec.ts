describe('App Pages', () => {
  const appId = 'ad2xJUGes5TNRKG4M';
  const reportId = 'aAG2BwDs3che_NZPW';

  before(() => {
    cy.login();

    cy.setupStubbedSwimlane();
    cy.navigateSwimlane(`/app-builder/${appId}`);
  });

  describe('reports', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.navigateSwimlane(`/reports/${appId}`);
      cy.wait('@GET:reports/app/*');
    });

    it('content', () => {
      cy.get('.content-area .ngx-toolbar-title > span').should('contain', 'Application 1');
      cy.get('.content-area datatable-body-row').should('have.length', 4);
      cy.get('.content-area datatable-body-row')
        .first()
        .find('.datatable-body-cell')
        .first()
        .should('contain', 'Default');
      cy.get('.content-area datatable-body-row')
        .eq(1)
        .find('.datatable-body-cell')
        .first()
        .should('contain', 'Report 2');
    });
  });

  describe('report page', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.navigateSwimlane(`/search/${appId}/${reportId}/stats`);
      cy.wait(`@GET:reports/${reportId}`);
    });

    it('popover displaying metadata should appear when mouseenter on report name', () => {
      cy.get('.search-toolbar h4 span').should('contain', 'Default Report');
      cy.get('.search-toolbar h4 span').trigger('mouseover');
      cy.get('.sw-popover-text').should('be.visible');
      cy.get('.sw-popover-text')
        .should('contain', 'Application')
        .should('contain', 'Report')
        .should('contain', 'Created')
        .should('contain', 'Updated')
        .should('contain', 'admin');
    });
  });
});

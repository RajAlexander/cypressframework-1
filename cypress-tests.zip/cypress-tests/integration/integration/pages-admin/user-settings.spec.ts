describe('User settings', () => {
  const userId = '5cd9d2a225cea00014bf1d79';
  before(() => {
    cy.login();

    cy.setupStubbedSwimlane();
    cy.navigateSwimlane(`/user/${userId}`);

    cy.wait(`@GET:user/${userId}`);
  });

  context('Session', () => {
    before(() => {
      cy.get('.ngx-tabs button.ngx-tab').contains('Session').as('sessionTab');
      cy.get('@sessionTab').click();
    });

    it('shows session timeout override toggle', () => {
      cy.get('.ngx-toggle').should('be.visible');
    });

    it('session timeout override toggle is off', () => {
      cy.get('.ngx-toggle').find('.ngx-toggle-input').should('not.be.checked');
    });

    context('Toggle on', () => {
      before(() => {
        cy.get('.ngx-toggle').find('.ngx-toggle-input').click({ force: true, multiple: true });
      });

      it('shows user inputs', () => {
        cy.get('.flexbox-container ngx-input').should('be.visible');
        cy.get('.flexbox-container ngx-select').should('be.visible');
      });

      it('defaults to global session timeout', () => {
        cy.get('.flexbox-container ngx-input input').should('have.value', '4');
      });
    });

    context('Toggle off', () => {
      before(() => {
        cy.get('.ngx-toggle').find('.ngx-toggle-input').click({ force: true, multiple: true });
      });
      it('hides user inputs', () => {
        cy.get('.flexbox-container ngx-input').should('not.exist');
        cy.get('.flexbox-container ngx-select').should('not.exist');
      });
    });
  });

  context('General', () => {
    before(() => {
      const userLockedId = '5cd9d2a225cea00014bfes25';
      cy.setupStubbedSwimlane();
      cy.navigateSwimlane(`/user/${userLockedId}`);
      cy.wait(`@GET:user/${userLockedId}`);
      cy.get('.ngx-tabs button.ngx-tab').contains('General').as('generalTab');
      cy.get('@generalTab').click({ force: true });
    });

    it('display unlock user tip', () => {
      cy.get('[data-cy=user-details__locked-user-tip]')
        .should('exist')
        .within(() => {
          cy.get('[data-cy=user-details__locked-user-tip-text]').should(
            'contain.text',
            `This user's profile is locked.`
          );
          cy.get('[data-cy=user-details__locked-user-tip-unlock-button]')
            .should('contain.text', `Unlock`)
            .should('have.class', 'btn-warning');
        });
    });
  });
});

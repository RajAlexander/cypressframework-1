describe('Applet Builder', () => {
  const appletId = 'ae7XaH2STB6KM28t';
  const layouts = ['Section', 'Tabs', 'HTML', 'Widget', 'Integration'];

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.navigateSwimlane(`/applet-builder/${appletId}`);
  });

  beforeEach(() => {
    cy.get('.content-area')
      .as('contentArea')
      .within(() => {
        cy.get('.builder-target').find('fieldset').eq(0).as('formLayout').find('.builder-target').as('builderTarget');
        cy.get('.builder-target').find('fieldset').eq(1).as('hiddenFields');

        cy.get('.builder-source').find('.ngx-section').eq(1).as('layoutItems');

        cy.get('.settings-panel').as('settingsPanel').find('ngx-tabs .ngx-tab').eq(1).as('fieldPropertySettings');

        cy.get('.applet-builder-toolbar ngx-toolbar-content')
          .as('toolBar')
          .within(() => {
            cy.get('.applet-nav').as('nav');
            cy.get('.toolbar li').eq(0).as('saveButton');
            cy.get('.toolbar li').eq(1).as('ellipsis');
          });
      });
  });

  describe('tool bar', () => {
    it('header', () => {
      cy.get('@contentArea').find('.applet-builder-toolbar .ngx-toolbar-title > span').should('contain', 'Test Applet');
    });

    describe('content', () => {
      it('has nav bar', () => {
        cy.get('@nav').within(() => {
          cy.get('li a').eq(0).as('builderMode');
          cy.get('li a').eq(1).as('workflowMode');
          cy.get('@builderMode').should('have.class', 'active');
          cy.get('@builderMode').find('.ngx-icon').should('have.class', 'ngx-builder');
          cy.get('@workflowMode').should('not.have.class', 'active');
          cy.get('@workflowMode').find('.ngx-icon').should('have.class', 'ngx-workflow');
        });
      });

      it('has save button', () => {
        cy.get('@saveButton').find('ngx-button').should('have.class', 'disabled-button');
      });

      it('has ellipsis', () => {
        cy.get('@ellipsis').within(() => {
          cy.get('ngx-dropdown-toggle').click();
          cy.get('ngx-dropdown-menu').should('exist');
          cy.get('ngx-dropdown-menu')
            .should('contain', 'Validate')
            .should('contain', 'Export Applet')
            .should('contain', 'History')
            .should('contain', 'Delete Applet');
          cy.get('ngx-dropdown-toggle').click();
        });
      });

      describe('Export Applet', () => {
        it('opens dialog', () => {
          cy.setupStubbedSwimlane();

          cy.get('@ellipsis').within(() => {
            cy.get('ngx-dropdown-toggle').click();
            cy.get('ngx-dropdown-menu').should('contain', 'Export Applet');
            cy.get('.ngx-dropdown-menu .vertical-list li').contains('Export Applet').click();
          });

          cy.get('.app-export--container .ngx-dialog-header').should('contain', 'Applet Export');

          cy.get('.ngx-dialog-footer').within(() => {
            cy.get('.btn').should('have.length', 2);
            cy.get('.btn').contains('Cancel').click();
          });
        });
      });
    });
  });

  describe('layouts', () => {
    it('drags and drops layouts', () => {
      layouts.forEach((layout, idx) => {
        cy.get('@layoutItems').find('.builder-source-item').eq(idx).as(layout);
        cy.dragAndDrop(`@${layout}`, '@builderTarget');
      });
      cy.get('@formLayout').find('.builder-target-item').should('have.length', 5);
    });

    it('layout properties settings', () => {
      cy.get('@formLayout')
        .find('.builder-target-item')
        .each($targetItem => {
          cy.wrap($targetItem).click();
          cy.wrap($targetItem).should('have.class', 'active');
          cy.get('@fieldPropertySettings').should('have.class', 'active');
        });
    });

    it('shows confirmation on edit an existing task', () => {
      cy.setupStubbedSwimlane();

      cy.get('@formLayout').find('.builder-target-item.integration').click();
      cy.get('@fieldPropertySettings').should('have.class', 'active');
      cy.get('app-properties-container').within(() => {
        cy.getByLabel('Task').select('GitLab PR');
        cy.get('a').contains('Edit Task').click();
      });
      cy.get('.ngx-alert-dialog.confirm')
        .should('exist')
        .within(() => {
          cy.get('.ngx-dialog-header').should('contain', 'Save Confirmation');
          cy.get('.ngx-dialog-body').should(
            'contain',
            'You must save this applet before creating or editing a task. Save now?'
          );
          cy.get('button').contains('Cancel').click();
        });
    });

    it('shows confirmations on create a task', () => {
      cy.setupStubbedSwimlane();

      cy.get('@formLayout').find('.builder-target-item.integration').click();
      cy.get('@fieldPropertySettings').should('have.class', 'active');
      cy.get('app-properties-container').within(() => {
        cy.getByLabel('Task').select('Create a Task');
      });
      cy.get('.ngx-alert-dialog.confirm')
        .should('exist')
        .within(() => {
          cy.get('.ngx-dialog-header').should('contain', 'Save Confirmation');
          cy.get('.ngx-dialog-body').should(
            'contain',
            'You must save this applet before creating or editing a task. Save now?'
          );
          cy.get('button').contains('Cancel').click();
        });
    });

    it('shows save and leave dialog', () => {
      cy.navigateSwimlane(`/applet-builder/${appletId}`);
      cy.get('ngx-dialog').as('saveLeaveDlg').should('be.visible');
      cy.get('@saveLeaveDlg').within(() => {
        cy.get('h2').should('contain', 'You have unsaved changes to this applet.');
        cy.get('p').should('contain', 'Are you sure you want to leave?');
        cy.get('.ngx-dialog-footer button').should('have.length', 3);
        cy.get('.ngx-dialog-footer button').eq(0).should('contain', 'Leave');
        cy.get('.ngx-dialog-footer button').eq(1).should('contain', 'Save and Leave');
        cy.get('.ngx-dialog-footer button').eq(2).should('contain', 'Cancel');
        cy.get('.ngx-dialog-footer button').contains('Leave').click();
      });
    });
  });

  describe('widget', () => {
    before(() => {
      cy.login();

      cy.setupStubbedSwimlane();
      cy.navigateSwimlane(`/applet-builder/${appletId}`);
    });

    describe('widget editor', () => {
      beforeEach(() => {
        cy.get('.content-area').as('contentArea');
        cy.get('@contentArea').find('.builder-target').find('fieldset').eq(0).as('formLayout');
        cy.get('@formLayout').find('.builder-target').as('builderTarget');
        cy.get('@contentArea').find('.builder-source').find('.ngx-section').eq(1).as('layoutItems');
        cy.get('@contentArea').find('.settings-panel').as('settingsPanel');
        cy.get('@settingsPanel').find('ngx-tabs .ngx-tab').eq(1).as('fieldPropertySettings');
        cy.get('@contentArea')
          .find('.applet-builder-toolbar ngx-toolbar-content')
          .find('.toolbar li ngx-button')
          .eq(0)
          .as('saveButton');
      });

      it('drags and drops widget field', () => {
        cy.setupStubbedSwimlane();
        cy.get('@layoutItems').find('.builder-source-item').eq(3).as('widgetField');
        cy.dragAndDrop('@widgetField', '@builderTarget');
        cy.get('@saveButton').click();
        cy.wait(`@PUT:applet/${appletId}`);
      });

      it('opens widget field settings', () => {
        cy.get('@formLayout')
          .find('.builder-target-item')
          .each($targetItem => {
            cy.wrap($targetItem).click();
            cy.wrap($targetItem).should('have.class', 'active');
            cy.get('@fieldPropertySettings').should('have.class', 'active');
          });
      });

      it('opens widget editor', () => {
        cy.setupStubbedSwimlane();
        cy.get('@settingsPanel')
          .find('[data-cy=edit_widget__btn]')
          .contains(/^\s*Edit Widget\s*$/)
          .click();
        cy.get('widget-editor').as('editor').should('be.visible');
        cy.get('@editor').within(() => {
          cy.get('.panel-header ngx-tabs').contains('button', 'preview record data').click();
          cy.get('[data-cy=record_select__input]').should('not.exist');
          cy.get('[data-cy=editor_cancel__btn]').click();
        });
      });

      it('removes widget field', () => {
        cy.get('@formLayout')
          .find('.builder-target-item')
          .each($targetItem => {
            cy.wrap($targetItem).trigger('mouseover');
            cy.wrap($targetItem).find('.drop-in').should('be.visible');
            cy.wrap($targetItem)
              .find('.drop-in')
              .within(() => {
                cy.get('.ngx-icon').first().click({ force: true });
              });
          });
        cy.get('@formLayout').find('.builder-target-item').should('have.length', 0);
      });
    });
  });
});

import app from '../../fixtures/mocks/swimlane/app/aIitXvMZ8ptg2tN0T/get.json';

const fields = app.fields.filter(f => f.key !== 'tracking-id');
const numericOperators = [
  'Equals',
  'Does Not Equal',
  'Less Than',
  'Less Than or Equal',
  'Greater Than',
  'Greater Than or Equal',
  'Has Been Modified'
];
const textOperators = ['Equals', 'Does Not Equal', 'Matches Regex', 'Has Been Modified'];
const actionTypes = [
  'Set Field Value',
  'Set Field Read/Write',
  'Set Field Required/Optional',
  'Filter Selection Options',
  'Modify Layout',
  'Trigger Notification',
  'Trigger Integration',
  'Export and Email Record',
  'Toggle Time Tracking for Record'
];

describe('workflow', () => {
  const appId = 'aIitXvMZ8ptg2tN0T';
  const workflowId = 'ab3n5rtOKQ7PuYKzk';

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.navigateSwimlane(`/workflow/${appId}`);
    cy.wait(`@GET:app/${appId}`);
    cy.wait(`@GET:workflow/${appId}`);
  });

  beforeEach(() => {
    cy.get('.content-area').as('contentArea');
    cy.get('[tooltiptitle="Center graph"] > ngx-icon > .ngx-icon').as('centerGraph');
  });

  describe('tool bar', () => {
    it('header', () => {
      cy.get('@contentArea')
        .find('.app-builder-toolbar .ngx-toolbar-title > span')
        .should('contain', 'Workflow Test App');
    });

    describe('content', () => {
      beforeEach(() => {
        cy.get('@contentArea').find('.app-builder-toolbar ngx-toolbar-content').as('toolBar');
        cy.get('@toolBar').find('.app-nav').as('nav');
        cy.get('@toolBar').find('.toolbar li').eq(0).as('saveButton');
        cy.get('@toolBar').find('.toolbar li').eq(1).as('ellipsis');
      });

      it('has nav bar', () => {
        cy.get('@nav').find('.ngx-navbar .ngx-navbar--nav-items').as('navItems');
        cy.get('@navItems').within(() => {
          cy.get('.ngx-navbar-item').eq(0).as('builderMode');
          cy.get('.ngx-navbar-item').eq(1).as('workflowMode');
          cy.get('.ngx-navbar-item').eq(2).as('reportMode');
          cy.get('@builderMode').should('not.have.class', 'active');
          cy.get('@builderMode').find('.ngx-icon').should('have.class', 'ngx-builder');
          cy.get('@workflowMode').should('have.class', 'active');
          cy.get('@workflowMode').find('.ngx-icon').should('have.class', 'ngx-workflow');
          cy.get('@reportMode').should('not.have.class', 'active');
          cy.get('@reportMode').find('.ngx-icon').should('have.class', 'ngx-reports');
        });
      });

      it('has save button', () => {
        cy.get('@saveButton').find('ngx-button').should('have.class', 'disabled-button');
      });

      it('has ellipsis', () => {
        cy.get('@ellipsis').within(() => {
          cy.get('ngx-dropdown-toggle').click();
          cy.get('ngx-dropdown-menu').should('exist');
          cy.get('ngx-dropdown-menu').should('contain', 'Export to Image');
          cy.get('ngx-dropdown-toggle').click();
        });
      });
    });
  });

  describe('graph menu', () => {
    beforeEach(() => {
      cy.get('@contentArea').find('.graph-menu').as('graphMenu');
      cy.get('@contentArea').find('.graph-search').as('graphSearch');
      cy.get('@graphMenu').find('.menu-item').as('menuItems');
      cy.get('@contentArea').find('ngx-graph .nodes .node-group').as('nodeGroups');
    });

    it('has buttons and search bar', () => {
      cy.get('@menuItems').should('have.length', 6);
      cy.get('@graphSearch').should('be.visible');
    });

    it('collapse and expand nodes', () => {
      cy.get('@nodeGroups').should('have.length', 5);
      cy.get('@menuItems').eq(4).click();
      cy.get('@nodeGroups').should('have.length', 1);
      cy.get('@menuItems').eq(5).click();
      cy.get('@nodeGroups').should('have.length', 5);
    });

    describe('search', () => {
      beforeEach(() => {
        cy.get('@graphSearch').find('input').as('searchBar');
        cy.get('@contentArea').find('.right-panel').as('nodeEditor');
      });

      afterEach(() => {
        cy.get('@graphSearch').find('.search-option ngx-icon').last().click();
      });

      it('default action', () => {
        cy.get('@searchBar').focus().clear().type('default');
        cy.get('@nodeGroups').eq(1).find('.stage').should('have.class', 'active');
        cy.get('@graphSearch').find('.result-count').should('contain', '1 / 1');
        cy.get('@nodeEditor').should('have.attr', 'hidden');
      });

      it('single search result', () => {
        cy.get('@searchBar').focus().clear().type('condition 1');
        cy.get('@nodeGroups').eq(4).find('.stage').should('have.class', 'active');
        cy.get('@graphSearch').find('.result-count').should('contain', '1 / 1');
        cy.get('@nodeEditor').should('not.have.attr', 'hidden');
      });

      it('multiple search result', () => {
        cy.get('@searchBar').focus().clear().type('action');
        cy.get('@nodeGroups').eq(1).find('.stage').should('have.class', 'active');
        cy.get('@graphSearch').find('.result-count').should('contain', '1 / 3');
        cy.get('@nodeEditor').should('have.attr', 'hidden');
        cy.get('@graphSearch').within(() => {
          cy.get('.search-option').eq(0).as('prevResult');
          cy.get('.search-option').eq(1).as('nextResult');
        });
        cy.get('@nextResult').click();
        cy.get('@graphSearch').find('.result-count').should('contain', '2 / 3');
        cy.get('@nodeGroups').eq(2).find('.action').should('have.class', 'active');
        cy.get('@nodeEditor').should('not.have.attr', 'hidden');
        cy.get('@prevResult').click();
        cy.get('@graphSearch').find('.result-count').should('contain', '1 / 3');
        cy.get('@nodeGroups').eq(1).find('.stage').should('have.class', 'active');
        cy.get('@nodeEditor').should('have.attr', 'hidden');
      });
    });
  });

  describe('conditions', () => {
    beforeEach(() => {
      cy.get('@contentArea').find('ngx-graph .nodes .node-group').as('nodeGroups');
      cy.get('@contentArea').find('.right-panel').as('nodeEditor');
    });

    it('root node has single control', () => {
      cy.get('@nodeGroups').eq(0).as('rootNode').click();
      cy.get('@centerGraph').click();
      cy.get('@nodeEditor').should('have.attr', 'hidden');
      cy.get('@rootNode').find('.workflow-context-menu-group ngx-icon').should('have.length', 1);
    });

    it('default condition has single control', () => {
      cy.get('@nodeGroups').eq(1).as('defaultCondition').click();
      cy.get('@centerGraph').click();
      cy.get('@nodeEditor').should('have.attr', 'hidden');
      cy.get('@defaultCondition').find('.workflow-context-menu-group ngx-icon').should('have.length', 1);
    });

    describe('condition', () => {
      it('has controls', () => {
        cy.get('@nodeGroups').eq(4).as('conditionNode').click();
        cy.get('@centerGraph').click();
        cy.get('@conditionNode').find('.workflow-context-menu-group ngx-icon').should('have.length', 5);
      });

      it('editor', () => {
        cy.get('@nodeGroups').eq(4).as('conditionNode').click();
        cy.get('@centerGraph').click();
        cy.get('@nodeEditor').should('not.have.attr', 'hidden');
        cy.get('@nodeEditor').within(() => {
          cy.get('.form-group').first().find('ngx-input input').should('have.value', 'condition 1');
          cy.get('.form-group').eq(1).find('.ngx-toggle-text').should('contain', 'Disable');
          cy.get('.conditions').should('be.visible');
        });
      });

      describe('controls', () => {
        it('adds a new condition', () => {
          cy.get('@nodeGroups').eq(4).as('conditionNode').click();
          cy.get('@centerGraph').click();
          cy.get('@conditionNode').find('.workflow-context-menu-group ngx-icon').first().click();
          cy.wait(300); // wait for node animation

          cy.get('@conditionNode').find('.stage').should('not.have.class', 'active');
          cy.get('@nodeEditor').within($editor => {
            cy.get($editor).should('not.have.attr', 'hidden');
            cy.get('.form-group').first().find('ngx-input input').should('have.value', 'New condition');
          });
        });

        it('has correct number of nodes', () => {
          cy.get('@nodeGroups').should('have.length', 6);
          cy.get('@nodeGroups').eq(5).find('.stage').should('have.class', 'active');
        });

        it('removes condition', () => {
          cy.get('@nodeGroups').eq(5).as('newConditionNode').click();
          cy.get('@centerGraph').click();
          cy.get('@newConditionNode').find('.workflow-context-menu-group ngx-icon').last().click();
          cy.wait(300); // wait for node animation

          cy.get('@nodeGroups').should('have.length', 5);
        });

        it('adds a new action', () => {
          cy.get('@nodeGroups').eq(4).as('conditionNode').click();
          cy.get('@centerGraph').click();
          cy.get('@conditionNode').find('.workflow-context-menu-group ngx-icon').eq(1).click();
          cy.wait(500);
          cy.get('@conditionNode').find('.stage').should('not.have.class', 'active');
          cy.get('@nodeEditor').within($editor => {
            cy.wrap($editor).should('not.have.attr', 'hidden');
            cy.get('.form-group').first().find('ngx-input input').should('have.value', 'New action');
          });
        });

        it('has correct number of nodes', () => {
          cy.get('@nodeGroups').should('have.length', 6);
          cy.get('@nodeGroups').eq(5).find('.action').should('have.class', 'active');
        });

        it('removes action', () => {
          cy.get('@nodeGroups').eq(5).as('newActionNode').click();
          cy.get('@centerGraph').click();
          cy.get('@newActionNode').find('.workflow-context-menu-group ngx-icon').last().click();
          cy.wait(500); // wait for node animation
          cy.get('@nodeGroups').should('have.length', 5);
          cy.get('ngx-notification').should('not.exist'); // make sure errors aren't getting thrown.
        });

        it('adds a new repeat', () => {
          cy.get('@nodeGroups').eq(4).as('conditionNode').click();
          cy.get('@centerGraph').click();
          cy.get('@conditionNode').find('.workflow-context-menu-group ngx-icon').eq(2).click();
          cy.wait(500); // wait for node animation

          cy.get('@conditionNode').find('.stage').should('not.have.class', 'active');
          cy.get('@nodeEditor').within($editor => {
            cy.wrap($editor).should('not.have.attr', 'hidden');
            cy.get('.form-group').first().find('ngx-input input').should('have.value', 'New repeat');
          });
        });

        // has to break up into another it block to check the newly added node for some reason
        it('has correct number of nodes', () => {
          cy.get('@nodeGroups').should('have.length', 6);
          cy.get('@nodeGroups').eq(5).find('.repeat').should('have.class', 'active');
        });

        it('removes repeat', () => {
          cy.get('@nodeGroups').eq(5).as('newRepeatNode').click();
          cy.get('@centerGraph').click();
          cy.get('@newRepeatNode').find('.workflow-context-menu-group ngx-icon').last().click();
          cy.wait(300); // wait for node animation
          cy.get('workflow-graph .graph-container', { timeout: 300 }).should('not.have.class', 'is-dragging');

          cy.get('@nodeGroups').should('have.length', 5);
        });

        it('disables node', () => {
          cy.get('@nodeGroups').eq(4).as('conditionNode').click();
          cy.get('@centerGraph').click();
          cy.get('@conditionNode').find('.workflow-context-menu-group ngx-icon').eq(3).click();
          cy.get('@conditionNode').find('.stage').should('have.class', 'node-disabled');
        });
      });

      describe('evaluations', () => {
        beforeEach(() => {
          cy.get('@nodeGroups').eq(4).as('conditionNode').click();
          cy.get('@centerGraph').click();
          cy.get('@nodeEditor').find('.conditions').as('evaluations');
          cy.get('@evaluations').find('.form-group').eq(0).as('fields');
          cy.get('@evaluations').find('.form-group').eq(1).as('operators');
          cy.get('@evaluations').find('.form-group').eq(2).as('values');
        });

        it('has fields', () => {
          cy.get('@fields').within(() => {
            cy.get('ngx-select').as('fieldSelect');
            cy.get('@fieldSelect').ngxGetValue().should('contain', 'Numeric');
            cy.get('@fieldSelect').ngxOpen();
            fields.forEach((field, idx) => {
              cy.get('.ngx-select-option-group .vertical-list li').eq(idx).should('contain', field.name);
            });
            cy.get('@fieldSelect').ngxClose();
          });
        });

        it('numeric field', () => {
          cy.get('@operators').within(() => {
            cy.get('ngx-select').as('operatorSelect');
            cy.get('@operatorSelect').ngxOpen();
            cy.get('.ngx-select-option-group .vertical-list li').should('have.length', numericOperators.length);
            numericOperators.forEach((op, idx) => {
              cy.get('.ngx-select-option-group .vertical-list li').eq(idx).should('contain', op);
            });
            cy.get('@operatorSelect').ngxClose();
          });
          cy.get('@values').find('ngx-input').should('be.visible');
        });

        it('text field', () => {
          cy.get('@fields').within(() => {
            cy.get('ngx-select').as('fieldSelect');
            cy.get('@fieldSelect').select('Text');
            cy.get('@fieldSelect').should('contain', 'Text');
          });

          cy.get('@operators').within(() => {
            cy.get('ngx-select').as('operatorSelect');
            cy.get('@operatorSelect').ngxOpen();
            cy.get('.ngx-select-option-group .vertical-list li').should('have.length', textOperators.length);
            textOperators.forEach((op, idx) => {
              cy.get('.ngx-select-option-group .vertical-list li').eq(idx).should('contain', op);
            });
            cy.get('@operatorSelect').ngxClose();
          });
          cy.get('@values').find('ngx-input').should('be.visible');
        });

        it('select field', () => {
          cy.get('@fields').within(() => {
            cy.get('ngx-select').as('fieldSelect');
            cy.get('@fieldSelect').select('Selection');
            cy.get('@fieldSelect').ngxGetValue().should('contain', 'Selection');
          });

          cy.get('@operators').within(() => {
            cy.get('ngx-select').as('operatorSelect');
            cy.get('@operatorSelect').ngxOpen();
            cy.get('.ngx-select-option-group .vertical-list li').should('have.length', textOperators.length);
            textOperators.forEach((op, idx) => {
              cy.get('.ngx-select-option-group .vertical-list li').eq(idx).should('contain', op);
            });
            cy.get('@operatorSelect').ngxClose();
          });
          cy.get('@values').within(() => {
            cy.get('ngx-select').as('valuesSelect');
            cy.get('@valuesSelect').ngxOpen();
            cy.get('.ngx-select-option-group .vertical-list li').should('have.length', 3);
            ['one', 'two', 'three'].forEach((op, idx) => {
              cy.get('.ngx-select-option-group .vertical-list li').eq(idx).should('contain', op);
            });
            cy.get('@valuesSelect').ngxClose();
          });
        });

        it('new set of evaluations', () => {
          cy.get('@nodeEditor')
            .find('ngx-button')
            .within($btn => {
              cy.get('button').should('contain', 'Add evaluation');
              cy.wrap($btn).click();
            });
          cy.get('@evaluations').find('.well').as('evalList');
          cy.get('@evalList').should('have.length', 2);
          cy.get('@nodeEditor').find('.form-group').eq(2).as('evalType').should('be.visible');
          cy.get('@evalType').within(() => {
            cy.get('label').should('contain', 'Evaluation Type');
            cy.get('.ngx-radiobutton .radio-label').eq(0).should('contain', 'AND');
            cy.get('.ngx-radiobutton .radio-label').eq(1).should('contain', 'OR');
          });
          cy.get('@evalList').last().find('ngx-icon.delete-condition').click();
          cy.get('@evalList').should('have.length', 1);
        });
      });
    });
  });

  describe('actions', () => {
    beforeEach(() => {
      cy.get('@contentArea').find('ngx-graph .nodes .node-group').as('nodeGroups');
      cy.get('@contentArea').find('.right-panel').as('nodeEditor');
    });

    it('has controls', () => {
      cy.get('@nodeGroups').eq(2).as('actionNode').click();
      cy.get('@centerGraph').click();
      cy.get('@actionNode').find('.workflow-context-menu-group ngx-icon').should('have.length', 2);
    });

    describe('action switching', () => {
      beforeEach(() => {
        cy.get('@nodeGroups').eq(2).as('actionNodeOne').click();
        cy.get('@nodeGroups').eq(3).as('actionNodeTwo').click();
        cy.get('@centerGraph').click();
      });

      it('should update fields when switching between actions', () => {
        cy.get('@actionNodeOne').click();
        cy.get('@nodeEditor').find('.form-group').eq(3).as('actionFieldOne');
        cy.get('@actionFieldOne').within(() => {
          cy.get('ngx-select').select('Selection');
          cy.get('@nodeEditor').find('.form-group').eq(4).as('actionFieldValueOne');

          cy.get('@actionFieldValueOne').within(() => {
            cy.get('ngx-select').select('one');
          });
        });

        // set a select value for other action
        cy.get('@actionNodeTwo').click();
        cy.get('@nodeEditor').find('.form-group').eq(3).as('actionFieldTwo');
        cy.get('@actionFieldTwo').within(() => {
          cy.get('ngx-select').select('Selection');

          cy.get('@nodeEditor').find('.form-group').eq(4).as('actionFieldValueTwo');
          cy.get('@actionFieldValueTwo').within(() => {
            cy.get('ngx-select').select('two');
          });
        });

        // make sure it's the same value
        cy.get('@actionNodeOne').click();
        cy.get('@actionFieldValueOne').within(() => {
          cy.get('ngx-select').ngxGetValue().should('eq', 'one');
        });

        // reset actions to text default
        cy.get('@actionFieldOne').within(() => {
          cy.get('ngx-select').select('Text');
        });

        cy.get('@actionNodeTwo').click();
        cy.get('@actionFieldTwo').within(() => {
          cy.get('ngx-select').select('Text');
        });
      });
    });

    describe('controls', () => {
      beforeEach(() => {
        cy.get('@nodeGroups').eq(2).as('actionNode').click();
        cy.get('@centerGraph').click();
      });
      it('disables node', () => {
        cy.get('@actionNode').find('.workflow-context-menu-group ngx-icon').first().click();
        cy.wait(500);
        cy.get('@actionNode').find('.action').should('have.class', 'node-disabled');
        cy.wait(500);
      });
      it('removes action', () => {
        cy.get('@actionNode').find('.workflow-context-menu-group ngx-icon').last().debug().click();
        cy.wait(500);
        cy.get('@nodeGroups').should('have.length', 4);
        cy.get('ngx-notification').should('not.exist');
      });
    });

    describe('editor', () => {
      beforeEach(() => {
        cy.get('@nodeGroups').eq(2).as('actionNode').click();
        cy.get('@centerGraph').click();
        cy.get('@nodeEditor').should('not.have.attr', 'hidden');
        cy.get('@nodeEditor').find('.form-group').eq(0).as('actionName');
        cy.get('@nodeEditor').find('.form-group').eq(2).as('actionType');
      });

      it('action name', () => {
        cy.get('@actionName').find('input').should('have.value', 'New action');
        cy.get('@actionName').find('input').focus().clear().type('New action name');
        cy.get('@actionName').find('input').should('have.value', 'New action name');
      });

      it('has action types', () => {
        cy.get('@actionType').within(() => {
          cy.get('ngx-select').as('actionTypeSelect');
          cy.get('@actionTypeSelect').ngxGetValue().should('contain', 'Set Field Value');
          cy.get('@actionTypeSelect').ngxOpen();

          actionTypes.forEach((action, idx) => {
            cy.get('.ngx-select-option-group .vertical-list li').eq(idx).should('contain', action);
          });
          cy.get('@actionTypeSelect').ngxClose();
        });
      });

      it('ROI metrics', () => {
        cy.get('@nodeEditor')
          .find('section.usage-tasks-properties')
          .within(() => {
            cy.get('p').should(
              'contain',
              'You must save this workflow before you can apply usage metrics to this action.'
            );
          });
      });

      it('set field action - text ', () => {
        cy.get('@nodeEditor').find('.form-group').eq(3).as('fields');
        cy.get('@fields').within(() => {
          cy.get('ngx-select').as('fieldListSelect');
          cy.get('@fieldListSelect').ngxGetValue().should('contain', 'Text');
          cy.get('@fieldListSelect').ngxOpen();
          fields.forEach((field, idx) => {
            cy.get('.ngx-select-option-group .vertical-list li').eq(idx).should('contain', field.name);
          });
          cy.get('@fieldListSelect').ngxClose();
        });
        cy.get('@nodeEditor').find('.form-group').eq(4).as('textValue');
        cy.get('@textValue').within(() => {
          cy.get('ngx-dropdown-toggle button').as('params').should('contain', 'Insert Parameters');
          cy.get('@params').click();
          fields.forEach((field, idx) => {
            cy.get('.ngx-dropdown-menu .vertical-list li').eq(idx).should('contain', field.name);
          });
          cy.get('@params').click();
          cy.get('ngx-codemirror').should('be.visible');
        });
      });

      it('set field read/write', () => {
        cy.get('@actionType').within(() => {
          cy.get('ngx-select').as('actionTypeSelect');
          cy.get('@actionTypeSelect').select('Set Field Read/Write');
          cy.get('@actionTypeSelect').should('contain', 'Set Field Read/Write');
        });

        cy.get('@nodeEditor').find('.form-group').eq(3).as('fields');
        cy.get('@fields').find('button').should('contain', 'Select Fields').click();
        cy.get('.ngx-dialog').as('fieldList').should('be.visible');
        cy.get('@fieldList').within(() => {
          cy.get('.dialog-header h2').should('contain', 'Workflow Test App');
          cy.get('.field-item').should('have.length', 3);
          cy.get('.icon-x').click();
        });
      });

      it('set field required/optional', () => {
        cy.get('@actionType').within(() => {
          cy.get('ngx-select').select('Set Field Required/Optional');
        });
        cy.get('@nodeEditor').find('.form-group').eq(3).as('fields');
        cy.get('@fields').find('button').should('contain', 'Select Fields').click();
        cy.get('.error-messages').should('exist');
        cy.get('.ngx-dialog').as('fieldList').should('be.visible');
        cy.get('@fieldList').within(() => {
          cy.get('.dialog-header h2').should('contain', 'Workflow Test App');
          cy.get('.field-item').should('have.length', 3);
          cy.get('.field-item')
            .first()
            .within(element => {
              cy.get('.app-field-tools').children().should('have.length', 0);

              cy.root().click();

              cy.get('.app-field-tools ngx-icon i').as('fieldListIcon').should('have.class', 'ngx-check');

              cy.root().click();

              cy.get('@fieldListIcon').should('have.class', 'ngx-question');

              cy.root().click();
              cy.get('.app-field-tools').children().should('have.length', 0);
            });
          cy.get('h2 ngx-button').contains('Apply').click();
        });
        cy.get('.error-messages').should('not.be.visible');
      });

      it('filter section', () => {
        cy.get('@actionType').within(() => {
          cy.get('ngx-select').select('Filter Selection Options');
        });
        cy.get('.error-messages').should('exist');
        cy.get('.form-group')
          .last()
          .within(() => {
            cy.get('ngx-select').select('Selection');
          });
        cy.get('.form-group')
          .last()
          .within(() => {
            cy.get('ngx-select').select('one');
          });
        cy.get('.error-messages').should('not.be.visible');
      });

      it('modify layout', () => {
        cy.get('@actionType').within(() => {
          cy.get('ngx-select').select('Modify Layout');
        });

        cy.get('.error-messages').should('exist');

        cy.get('.form-group')
          .last()
          .within(() => {
            cy.get('button').click();
          });

        cy.get('.ngx-dialog').as('fieldList').should('be.visible');

        cy.get('@fieldList').within(() => {
          cy.get('.dialog-header h2').should('contain', 'Workflow Test App');

          cy.get('.field-item')
            .first()
            .within(() => {
              cy.get('.app-field-tools').children().should('have.length', 0);

              cy.root().click();

              cy.get('.app-field-tools ngx-icon i').as('fieldListIcon').should('have.class', 'ngx-eye');

              cy.root().click();

              cy.get('@fieldListIcon').should('have.class', 'ngx-eye-disabled');

              cy.root().click();

              cy.get('.app-field-tools').children().should('have.length', 0);
            });
          cy.get('h2 ngx-button').contains('Apply').click();
        });

        cy.get('.error-messages').should('not.be.visible');
      });

      it('trigger notification', () => {
        cy.get('@actionType').within(() => {
          cy.get('ngx-select').as('actionTypeSelect');
          cy.get('@actionTypeSelect').select('Trigger Notification');
          cy.get('@actionTypeSelect').ngxGetValue().should('contain', 'Trigger Notification');
        });
        cy.get('@nodeEditor').find('.form-group').eq(3).as('composeMsgBtn');
        cy.get('@composeMsgBtn').find('button').should('contain', 'Compose Message').click();
        cy.get('.ngx-dialog').as('messageDlg').should('be.visible');
        cy.get('@messageDlg').within(() => {
          cy.get('.header h4').should('contain', 'Compose Message');
          cy.get('.form-group')
            .eq(1)
            .within(() => {
              cy.get('ngx-dropdown').select('Record Id');
              cy.get('.CodeMirror-code > .CodeMirror-line > span').should('contain', '{{RecordId}}');
            });
          cy.get('.form-group')
            .eq(2)
            .within(() => {
              cy.get('ngx-dropdown').select('Record Tracking Id');
              cy.get('.CodeMirror-code > .CodeMirror-line > span').should('contain', '{{Tracking}}');
            });

          cy.get('state-save-button > ngx-button').click();
        });
      });

      it('trigger integration', () => {
        // after closing the create task dialog, workflow will refresh app, tasks and a few other resources.
        // need to make sure they are mocked to prevent null reference errors
        cy.setupStubbedSwimlane();

        cy.get('@actionType').within(() => {
          cy.get('ngx-select').as('actionTypeSelect');
          cy.get('@actionTypeSelect').select('Trigger Integration');
          cy.get('@actionTypeSelect').should('contain', 'Trigger Integration');
        });

        cy.get('@nodeEditor')
          .get('workflow-action-integration')
          .should('exist')
          .find('.form-group')
          .within(() => {
            cy.get('ngx-select').should('exist').ngxOpen();
            cy.get('.ngx-select-option-group .vertical-list li').should('have.length', 1);
            cy.get('.ngx-select-option-group .vertical-list li').first().should('contain', 'Create a Task');
            cy.get('ngx-select').select('Create a Task');
          });
        cy.get('.ngx-dialog').should('be.visible');
        cy.get('.ngx-dialog .ngx-card-title').first().should('not.contain', 'Email Import');
        cy.get('.ngx-dialog').find('.dialog-close button').click();

        // wait for API to return while aliases are available before moving on
        cy.wait('@GET:app/aIitXvMZ8ptg2tN0T');
        cy.wait('@GET:usage/app/*');

        cy.get('@nodeEditor')
          .find('.form-group')
          .eq(4)
          .find('.ngx-toggle-text')
          .should('contain', 'Immediately Execute');
        cy.get('@nodeEditor')
          .find('.form-group')
          .eq(5)
          .find('.ngx-toggle-text')
          .should('contain', 'Send Success Notification');
        cy.get('@nodeEditor')
          .find('.form-group')
          .eq(6)
          .find('.ngx-toggle-text')
          .should('contain', 'Send Failure Notification');
      });

      it('export and email record', () => {
        cy.setupStubbedSwimlane();

        cy.get('@actionType').within(() => {
          cy.get('ngx-select').select('Export and Email Record');
        });
      });
    });
  });

  describe('save', () => {
    beforeEach(() => {
      cy.get('@contentArea').find('ngx-graph .nodes .node-group').as('nodeGroups');
      cy.get('@nodeGroups').eq(3).click();
      cy.get('@centerGraph').click();
      cy.get('@contentArea')
        .find('.app-builder-toolbar ngx-toolbar-content')
        .find('.toolbar li ngx-button')
        .eq(0)
        .as('saveButton');
    });

    it('save and leave', () => {
      cy.get('@saveButton').should('not.have.class', 'disabled-button');
      cy.navigateSwimlane(`/workflow/${workflowId}`);
      cy.get('ngx-dialog').as('saveLeaveDlg').should('be.visible');
      cy.get('@saveLeaveDlg').within(() => {
        cy.get('h2').should('contain', 'You have unsaved changes to this workflow.');
        cy.get('p').should('contain', 'Are you sure you want to leave?');
        cy.get('.ngx-dialog-footer button').should('have.length', 3);
        cy.get('.ngx-dialog-footer button').eq(0).should('contain', 'Leave');
        cy.get('.ngx-dialog-footer button').eq(1).should('contain', 'Save and Leave');
        cy.get('.ngx-dialog-footer button').eq(2).should('contain', 'Cancel');
        cy.get('.ngx-dialog-footer button').eq(2).click();
      });
      cy.get('@saveButton').should('not.have.class', 'disabled-button');
    });

    it('save', () => {
      cy.setupStubbedSwimlane();
      cy.intercept(`/api/usage/app/${appId}`, []).as('appUsage');
      cy.intercept('/api/usage/app/common', []).as('appUsageCommon');
      cy.get('@saveButton').click({ force: true });
      cy.wait(`@PUT:workflow/${workflowId}`);
      cy.wait('@appUsage');
      cy.wait('@appUsageCommon');
      cy.get('ngx-notification').should('have.class', 'ngx-notification-success');
      cy.get('ngx-notification').find('.ngx-notification-close').eq(0).click({ force: true });
      cy.get('ngx-notification').should('not.exist');
      cy.get('@saveButton').should('have.class', 'disabled-button');
    });
  });
});

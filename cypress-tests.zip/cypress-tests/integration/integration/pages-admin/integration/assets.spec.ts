describe('Integrations page - Assets Tab', () => {
  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.intercept('/api/asset/list', {
      fixture: 'mocks/swimlane/asset/list/get-empty'
    }).as('GET:assets/list');
    cy.navigateSwimlane(`/integration/assets`);
    cy.wait('@GET:assets/list');
  });

  it('should display integration tabs', () => {
    cy.get('.page-toolbar')
      .should('contain', 'Tasks')
      .should('contain', 'Assets')
      .should('contain', 'Key Store')
      .should('contain', 'Plugins')
      .should('contain', 'Python Packages');
  });

  it('should set assets tab active', () => {
    cy.get('.page-toolbar').find('.main-tabs a').contains('Assets').parent('li').should('have.class', 'active');
  });

  describe('no assets', () => {
    before(() => {
      cy.login();

      cy.setupStubbedSwimlane();

      cy.intercept('/api/asset/list', {
        fixture: 'mocks/swimlane/asset/list/get-empty'
      }).as('GET:assets/list');
      cy.navigateSwimlane(`/integration/assets`);
      cy.wait('@GET:assets/list');
    });

    it('should show landing page', () => {
      cy.get('.no-items-container')
        .should('contain', 'Start by creating your first asset')
        .should(
          'contain',
          'Assets handle secure authentication and version management for external systems that are consumed by your tasks.'
        );
    });
  });

  describe('with assets', () => {
    before(() => {
      cy.login();

      cy.setupStubbedSwimlane();
      cy.navigateSwimlane(`/integration/assets`);

      cy.wait('@GET:asset/list');
    });

    beforeEach(() => {
      cy.get('.item-list--group').as('groups');
      cy.get('.ngx-card').as('cards');
      cy.get('@groups').eq(0).as('swimlane-group');
      cy.get('@groups').eq(1).as('twitter-group');
      cy.get('@groups').eq(2).as('unknown-group');
    });

    it('should have grouped asset list', () => {
      cy.get('@groups').should('have.length', 3);
      cy.get('@cards').should('have.length', 6);

      cy.get('@swimlane-group')
        .find('.item-list--group--header')
        .should('contain', 'Swimlane')
        .should('contain', 'Assets')
        .find('.tag')
        .should('contain', '4');

      cy.get('@twitter-group')
        .find('.item-list--group--header')
        .should('contain', 'Twitter')
        .should('contain', 'Asset')
        .find('.tag')
        .should('contain', '1');

      cy.get('@unknown-group')
        .find('.item-list--group--header')
        .should('contain', 'Vendor Unknown')
        .should('contain', 'Asset')
        .find('.tag')
        .should('contain', '1');
    });

    it('should show cards', () => {
      cy.get('@cards')
        .eq(4)
        .should('contain', 'Twitter')
        .should('contain', '1.0.0')
        .should('contain', 'Twitter')
        .find('.ngx-card-avatar--avatar img')
        .should('have.attr', 'src')
        .and('contain', 'data:image/png;base64');

      cy.get('@cards')
        .eq(0)
        .should('contain', 'IMAP')
        .should('contain', 'latest')
        .should('contain', 'Email Server')
        .should('contain', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.')
        .find('.ngx-card-avatar--avatar img')
        .should('have.attr', 'src')
        .and('contain', 'data:image/png;base64');

      cy.get('@cards')
        .eq(5)
        .should('contain', 'JIRA')
        .find('.ngx-card-avatar--avatar img')
        .should('have.attr', 'src')
        .and('contain', 'data:image/png;base64');
    });

    it('should show asset status', () => {
      cy.get('@cards').eq(0).find('.ngx-card--status').should('have.class', 'success');
      cy.get('@cards').eq(1).find('.ngx-card--status').should('have.class', 'error');
    });

    describe('filter', () => {
      it('shows results and can reset using input', () => {
        cy.get('.integration-page--search-box input').type('IMAP');
        cy.get('@groups').should('have.length', 1);
        cy.get('@swimlane-group').find('.tag').should('contain', '1');
        cy.get('.btn > ngx-icon > .ngx-icon').click();
      });

      it('shows message with no results and reset using message', () => {
        cy.get('.integration-page--search-box input').type('none');
        cy.get('.no-filters-match').should('contain', 'No assets have been found that match your criteria.');
        cy.get('.no-filters-match--reset-filters > span').click();
        cy.get('@groups').should('have.length', 3);
      });
    });

    describe('edit dialog', () => {
      beforeEach(() => {
        // Open/Reopen dialog if it doesn't exist
        cy.get('body').then($body => {
          if (!$body.find('.integration-page--asset-edit-dialog-container').length) {
            cy.setupStubbedSwimlane();
            cy.get('@cards').eq(0).click({ force: true });
            cy.wait('@GET:asset/*');
          }
        });

        cy.get('.integration-page--asset-edit-dialog-container', {
          timeout: 20000
        })
          .should('be.visible')
          .as('dialog');
        cy.get('@dialog').within(() => {
          cy.get('.ngx-card .ngx-card-title').as('card-title');
          cy.get('.ngx-card .ngx-card-section--description').as('card-description');
          cy.get('.ngx-card .ngx-card-subtitle').as('sub-title');

          cy.get('.ngx-input').eq(0).find('input').as('name-input');
          cy.get('.ngx-input').eq(1).find('textarea').as('description-input');

          cy.get('ngx-large-format-dialog-footer').within(() => {
            cy.get('.edit-asset-footer__save button').as('save-button');
            cy.get('.edit-asset-footer__test button').as('test-button');
            cy.get('.edit-asset-footer__close button').as('close-button');
          });
        });
      });

      it('shows dialog', () => {
        cy.get('@dialog').should('be.visible');
        cy.get('@dialog').find('.ngx-large-format-dialog-header-title').should('contain', 'Asset Management');
        cy.get('@close-button').should('contain', 'Close');
      });

      it('displays DO card', () => {
        cy.get('@card-title').should('contain', 'IMAP');
        cy.get('@card-description').should('contain', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.');
        cy.get('@sub-title').should('contain', 'Email Server');
      });

      describe('inputs', () => {
        it('displays inputs', () => {
          cy.get('@dialog').find('.ngx-input[label="Asset Name"]').should('exist').should('contain', '*');
          cy.get('@dialog').find('.ngx-input').eq(0).should('contain', 'A name for the asset');
          cy.get('@name-input').should('have.value', 'IMAP');
          cy.get('@dialog')
            .find('.ngx-input')
            .eq(1)
            .should('contain', 'Asset Description')
            .should('contain', 'A description for the asset');
          cy.get('@description-input').should('have.value', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.');
        });

        it('updates ngx-card on name changes', () => {
          cy.get('@name-input').clear().type('My IMAP Asset');
          cy.get('@card-title').should('contain', 'My IMAP Asset');
        });

        it('updates ngx-card on description changes', () => {
          cy.get('@description-input').clear().type('This is an IMAP input');
          cy.get('@card-description').should('contain', 'This is an IMAP input');
        });

        after(() => {
          // reset inputs
          cy.get('@name-input').clear().type('IMAP', { delay: 0 });
          cy.get('@description-input').clear().type('Lorem ipsum dolor sit amet, consectetur adipiscing elit.', {
            delay: 0
          });
        });
      });

      describe('JSON editor', () => {
        beforeEach(() => {
          cy.get('.ngx-json-editor-flat').as('json-editor');
          cy.get('@json-editor').find('.json-tree-node-flat .json-tree-node-flat').as('nodes');
        });

        it('displays the JSON editor', () => {
          cy.get('@json-editor').should('be.visible');
          cy.get('@nodes').should('have.length', 3);
          cy.get('@nodes').eq(0).should('contain', 'Use SSL');
          cy.get('@nodes').eq(1).should('contain', 'Host');
          cy.get('@nodes').eq(2).should('contain', 'Port');
        });

        it('disables save and test on invalid params', () => {
          cy.get('@nodes').eq(2).find('input').clear().blur();
          cy.get('@nodes').eq(2).should('contain', 'should be number');
          cy.get('@save-button').should('have.attr', 'disabled');
          cy.get('@test-button').should('have.attr', 'disabled');
          cy.get('@nodes').eq(2).find('input').clear().type('123').blur();
        });

        it('shows validation errors on empty strings', () => {
          cy.get('@nodes').eq(1).find('textarea').clear().type('   ').blur();
          cy.get('@nodes').eq(1).should('contain', 'non-empty string required');
          cy.get('@nodes').eq(1).find('textarea').clear().type('abc').blur();
        });

        it('enables save in valid dirty state', () => {
          cy.get('@nodes').eq(2).find('input').clear().type('456');
          cy.get('@save-button').should('not.have.attr', 'disabled');
          cy.get('@test-button').should('not.have.attr', 'disabled');
          cy.get('@nodes').eq(2).find('input').clear().type('123');
        });

        it('indicates required fields', () => {
          cy.get('@nodes').eq(0).find('.required').should('not.exist');
          cy.get('@nodes').eq(1).find('.required').should('exist');
          cy.get('@nodes').eq(2).find('.required').should('exist');
        });

        it('can add and remove additional non-required fields', () => {
          cy.get('@json-editor').find('.add-button').as('add-props');
          cy.get('@add-props').should('have.length', 2);
          cy.get('@add-props').first().should('contain', 'Password').should('contain', 'Include').click();
          cy.get('@json-editor')
            .find('.json-tree-node-flat .json-tree-node-flat')
            .should('have.length', 4)
            .eq(3)
            .should('contain', 'Password')
            .find('ngx-dropdown')
            .click()
            .find('li')
            .should('contain', 'Remove')
            .click();
          cy.get('@json-editor').find('.json-tree-node-flat .json-tree-node-flat').should('have.length', 3);
        });

        it('cannot remove require properties', () => {
          cy.get('@json-editor')
            .find('.json-tree-node-flat .json-tree-node-flat')
            .eq(1)
            .find('ngx-dropdown')
            .click()
            .find('li')
            .should('contain', 'Remove')
            .find('button')
            .should('have.attr', 'disabled');
        });
      });

      describe('test connections', () => {
        afterEach(() => {
          cy.get('.ngx-dialog-header > .btn').click();
        });

        it('can execute successful test', () => {
          cy.setupStubbedSwimlane();
          cy.get('@test-button').click();
          cy.wait('@POST:asset/test');
          cy.get('ngx-alert-dialog').find('.ngx-dialog-header').should('contain', 'Asset Test Successful');
          cy.get('ngx-alert-dialog').find('.ngx-dialog-body').should('contain', 'The connection test succeeded!');
        });

        it('can execute failed test', () => {
          cy.setupStubbedSwimlane();
          cy.intercept('POST', '/api/asset/test', {
            successful: false,
            errorMessage: 'This test should fail'
          }).as('testAsset');
          cy.get('@test-button').click();
          cy.wait('@testAsset');
          cy.get('ngx-alert-dialog').find('.ngx-dialog-header').should('contain', 'Asset Test Failed');
          cy.get('ngx-alert-dialog').find('.ngx-dialog-body').should('contain', 'This test should fail');
        });

        it('shows message on unknown error', () => {
          cy.setupStubbedSwimlane();
          cy.intercept('POST', '/api/asset/test', {
            statusCode: 503,
            body: {}
          }).as('testAsset');
          cy.get('@test-button').click();
          cy.wait('@testAsset');
          cy.get('ngx-alert-dialog').find('.ngx-dialog-header').should('contain', 'Asset Test Failed');
          cy.get('ngx-alert-dialog')
            .find('.ngx-dialog-body')
            .should('contain', 'An unknown error occurred while testing.');
        });
      });

      describe('close dialog', () => {
        beforeEach(() => {
          cy.setupStubbedSwimlane();
          cy.get('.integration-page--asset-edit-dialog-container')
            .find('.ngx-input')
            .eq(0)
            .find('input')
            .clear()
            .type('IMAP Dirty');

          cy.get('@close-button').click();
          cy.get('.save-button-leave-dialog').as('leave-dialog');
          cy.get('@leave-dialog').find('.icon-x').as('leave-dialog-close');
        });

        it('shows dialog in dirty state', () => {
          cy.get('@leave-dialog')
            .should('contain', 'You have unsaved changes.')
            .should('contain', 'Are you sure you want to leave?');
          cy.get('@leave-dialog-close').click();
        });

        it('can cancel', () => {
          cy.get('@leave-dialog').find('.ngx-dialog-footer > :nth-child(3)').click();
        });

        it('can leave', () => {
          cy.get('@leave-dialog').find('.ngx-dialog-footer > :nth-child(1)').click();

          // Wait for asset list to be updated
          cy.wait('@GET:asset/list');
        });

        it('can save and leave', () => {
          cy.get('@leave-dialog').find('.ngx-dialog-footer > :nth-child(2)').click();
          cy.wait('@PUT:asset/*');
          cy.get('.notification-content')
            .should('contain', 'Asset Saved')
            .should('contain', 'The asset has been successfully saved.');

          // Wait for asset list to be updated
          cy.wait('@GET:asset/list');
        });
      });

      describe('save', () => {
        it('shows save button', () => {
          cy.get('@save-button').should('contain', 'Save');
        });

        it('disables save button when not in dirty state', () => {
          cy.get('@name-input').clear().type('IMAP');
          cy.get('@description-input').clear().type('Lorem ipsum dolor sit amet, consectetur adipiscing elit.');
          cy.get('@save-button').should('contain', 'Save').should('have.attr', 'disabled');
        });

        it('enables save button when in dirty state', () => {
          cy.get('@name-input').type(' Asset');
          cy.get('@save-button').should('contain', 'Save').should('not.have.attr', 'disabled');
        });

        it('disables save button when inputs are invalid', () => {
          cy.get('@name-input').clear();
          cy.get('@save-button').should('contain', 'Save').should('have.attr', 'disabled');
        });

        it('disables save and leave when inputs are invalid', () => {
          cy.setupStubbedSwimlane();
          cy.get('@name-input').clear();
          cy.get('@close-button').click();
          cy.get('.save-button-leave-dialog').as('leave-dialog');
          cy.get('@leave-dialog').find('.icon-x').as('leave-dialog-close');
          cy.get('@leave-dialog').find('.ngx-dialog-footer > :nth-child(2)').should('have.attr', 'disabled');
          cy.get('@leave-dialog-close').click();
        });

        it('can save and close dialog', () => {
          cy.setupStubbedSwimlane();
          cy.get('@name-input').clear().type('IMAP Asset');
          cy.get('@save-button').should('not.have.attr', 'disabled');
          cy.get('@save-button').click();
          cy.wait('@PUT:asset/*');
          cy.get('.notification-content')
            .last()
            .should('contain', 'Asset Saved')
            .should('contain', 'The asset has been successfully saved.');
          cy.get('@close-button').should('contain', 'Close').click();

          // Wait for asset list to be updated
          cy.wait('@GET:asset/list');
        });
      });

      after(() => {
        cy.get('body').then($body => {
          if ($body.find('.integration-page--asset-edit-dialog-container').length) {
            cy.get('.integration-page--asset-edit-dialog-container')
              .find('.ngx-large-format-dialog-header-action__button')
              .click();
          }
        });
      });
    });
  });

  describe('create asset', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.get('.plus-menu-container').find('ngx-icon').click();
      cy.wait('@GET:asset/available');
    });

    beforeEach(() => {
      cy.get('.integration-page--asset-create-dialog-container').as('dialog');
      cy.get('@dialog').find('.ngx-dialog-header .dialog-close > .btn').as('close-button');
      cy.get('@dialog').find('ngx-stepper').as('stepper');
    });

    it('shows dialog', () => {
      cy.get('@dialog').should('be.visible');
      cy.get('@dialog').find('.ngx-dialog-header').should('contain', 'Select an Asset Type');
      cy.get('@close-button').should('contain', 'Close');
    });

    it('shows stepper', () => {
      cy.get('@stepper').find('ngx-step').should('have.length', 2);
      cy.get('@stepper').find('ngx-step').eq(0).should('have.class', 'ngx-step--active');
    });

    describe('available asset types', () => {
      beforeEach(() => {
        cy.get('.create-asset-content-container--list-container').find('ngx-card').as('cards');
      });

      it('shows available asset types', () => {
        cy.get('@cards').should('have.length', 9);
        cy.get('@cards').find('.ngx-card-header').should('contain', 'ASSET TYPE');
        cy.get('@cards').eq(0).find('.ngx-card-title').should('contain', 'Active Directory');
        cy.get('@cards')
          .eq(0)
          .find('.ngx-card-subtitle')
          .should('contain', 'Using')
          .should('contain', 'latest')
          .should('contain', 'Directory Server');
      });

      describe('filter', () => {
        beforeEach(() => {
          cy.get('.create-asset-content--search-box').as('filter');
          cy.get('@filter').find('input').as('input');
        });

        it('can filter and clear', () => {
          cy.get('@input').type('Email');
          cy.get('@filter').find('button').should('be.visible');
          cy.get('@cards').should('have.length', 4);
          cy.get('@filter').find('button').click();
          cy.get('@cards').should('have.length', 9);
        });
      });
    });

    describe('selecting asset type', () => {
      beforeEach(() => {
        cy.get('body').then($body => {
          if ($body.find('.create-asset-content-container--list-container').length) {
            cy.setupStubbedSwimlane();
            cy.get('.create-asset-content-container--list-container')
              .find('ngx-card')
              .eq(6)
              .find('.ngx-card-section .btn-primary')
              .click();
          }
        });

        cy.get('@dialog').find('.ngx-card .ngx-card-title').as('card-title');
        cy.get('@dialog').find('.ngx-card .ngx-card-section--description').as('card-description');
        cy.get('@dialog').find('.ngx-card .ngx-card-subtitle').as('sub-title');

        cy.get('@dialog').find('.ngx-input').eq(0).find('input').as('name-input');
        cy.get('@dialog').find('.ngx-input').eq(1).find('textarea').as('description-input');

        cy.get('@dialog').find('.ngx-dialog-footer state-save-button button').as('save-button');
      });

      it('updates stepper', () => {
        cy.get('@stepper').find('ngx-step').eq(1).should('have.class', 'ngx-step--active');
      });

      it('displays DO card', () => {
        cy.get('@card-title').should('contain', 'Swimlane Email');
        cy.get('@card-description').should('contain', 'Swimlane Email Credential Asset');
        cy.get('@sub-title').should('contain', 'Email');
      });

      it('can nav back to asset type selection', () => {
        cy.get('@dialog').find('.ngx-card--outline-text .inner-text').click();
        cy.get('@stepper').find('ngx-step').eq(0).should('have.class', 'ngx-step--active');
      });

      it('can save', () => {
        cy.setupStubbedSwimlane();
        cy.get('@name-input').clear().type('IMAP - Assert', { delay: 0 });
        cy.get('@save-button').should('contain', 'Save').click();
        cy.wait('@POST:asset');
        cy.get('.notification-content')
          .last()
          .should('contain', 'Asset Created')
          .should('contain', 'The asset has been successfully created.');
        cy.get('@close-button').should('contain', 'Close').click();

        // Wait for asset list to be updated
        cy.wait('@GET:asset/list');
      });
    });

    after(() => {
      cy.get('body').then($body => {
        if ($body.find('.integration-page--asset-create-dialog-container').length) {
          cy.get('.integration-page--asset-create-dialog-container')
            .find('.ngx-dialog-header .dialog-close > .btn')
            .click();
        }
      });
    });
  });
});

describe('Integrations page - Credentials Tab', () => {
  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.navigateSwimlane(`/integration/credentials`);
    cy.wait('@getEnabledFlags');
  });

  it('should display integration tabs', () => {
    cy.get('.page-toolbar')
      .should('contain', 'Tasks')
      .should('contain', 'Assets')
      .should('contain', 'Key Store')
      .should('contain', 'Plugins')
      .should('contain', 'Python Packages');
  });

  it('should set tasks tab active', () => {
    cy.get('.page-toolbar').find('.main-tabs a').contains('Key Store').parent('li').should('have.class', 'active');
  });
});

describe('Python Packages', () => {
  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.navigateSwimlane('/integration/python-packages');

    cy.wait('@getEnabledFlags');
    cy.wait('@GET:pip/packages/Python3');
  });

  describe('Listing', () => {
    it('shows package row details, python 3', () => {
      cy.get('.python-packages datatable-body-row').as('rows').should('have.length', 1);
      cy.get('@rows').first().find('datatable-body-cell').as('cells');
      cy.get('@cells').eq(1).should('contain', 'Sphinx');
      cy.get('@cells').eq(2).should('contain', '2.1.2');
      cy.get('@cells').eq(3).should('contain', 'Python documentation generator');
    });
  });

  describe('Install dialog', () => {
    beforeEach(() => {
      cy.setupStubbedSwimlane();

      cy.get('int-packages-list .plus-menu-container .ngx-icon').click();
      cy.get('int-package-upload-dialog').as('packageInstallDialog');
      cy.get('@packageInstallDialog').find('.installer').as('installForm');
      cy.get('@packageInstallDialog').find('.uploader').as('uploadForm');
    });

    it('shows the version chooser, install form, and upload form', () => {
      cy.get('@installForm').find('.package-name-input').should('exist');
      cy.get('@installForm').find('.package-version-input').should('exist');
      cy.get('@installForm').find('.install-button').should('exist').find('button').should('be.disabled');

      cy.get('@uploadForm').find('ngx-file-button').should('exist');

      cy.get('ngx-dialog').find('.icon-x').click();
      cy.get('int-package-upload-dialog').should('not.exist');
    });

    it('can install a package', () => {
      cy.get('@installForm').find('.package-name-input input').type('math-factors');
      cy.get('@installForm').find('.install-button').should('exist').find('button').should('be.enabled').click();
      cy.wait('@POST:pip/packages');
      cy.get('int-package-upload-dialog').should('not.exist');
    });

    it('can upload a package', () => {
      cy.fixture('pip-packages/math22-2.2-py3-none-any.whl', 'base64').then(fileContent => {
        cy.get('@uploadForm')
          .find('.ngx-file-button-input')
          .attachFile({
            fileContent: JSON.stringify(fileContent),
            fileName: 'math22-2.2-py3-none-any.whl',
            mimeType: 'application/octet-stream',
            encoding: 'utf-8'
          } as any);
      });

      cy.get('@packageInstallDialog').find('package-upload-status').as('uploadStatus');

      cy.get('@uploadStatus').within(() => {
        cy.get('.package-upload-status--title').contains('math22').should('exist');
        cy.get('.package-upload-status--version').contains('2.2').should('exist');
        cy.get('.package-upload-status--python-version').contains('Python 3').should('exist');
        cy.get('.package-upload-status--status').contains('Package Installed').should('exist');
      });

      cy.get('ngx-dialog').find('.icon-x').click();
      cy.get('int-package-upload-dialog').should('not.exist');
    });
  });
});

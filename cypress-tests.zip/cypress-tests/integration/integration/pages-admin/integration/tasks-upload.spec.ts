describe('Integrations page - Tasks Upload', () => {
  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.navigateSwimlane(`/integration`);
    cy.wait('@GET:task/list');
    cy.get('.plus-menu-container .ngx-plus-menu--circle').click();
    cy.get('.ngx-plus-menu--icon-0').click();
  });

  describe('task upload dialog', () => {
    it('opens dialog', () => {
      cy.get('int-task-upload-dialog').should('exist');
    });

    it('shows file uploader', () => {
      cy.get('.inner-content').should('contain', 'Drag + Drop');
    });

    describe('task upload', () => {
      before(() => {
        cy.get('.ngx-file-button-input').attachFile([
          {
            filePath: 'tasks/common-task.json',
            fileName: 'common-task.json',
            mimeType: 'application/json',
            encoding: 'utf-8'
          },
          {
            filePath: 'tasks/app-task.json',
            fileName: 'app-task.json',
            mimeType: 'application/json',
            encoding: 'utf-8'
          },
          {
            filePath: 'tasks/applet-task.json',
            fileName: 'applet-task.json',
            mimeType: 'application/json',
            encoding: 'utf-8'
          }
        ]);
      });

      it('shows the dialog and table', () => {
        cy.get('.task-upload-dialog--upload-progress').should('contain', 'Here Are the Tasks You Are Uploading');
        cy.get('.task-upload-dialog--tasks-header').within(() => {
          cy.get('span').eq(0).should('contain', 'Task Name');
          cy.get('span').eq(1).should('contain', 'Application or Applet');
          cy.get('span').eq(2).should('contain', 'Status');
        });
      });

      it('shows files after read before upload', () => {
        cy.get('.task-upload-dialog--tasks-scroll-region--loaded-file .file').should('have.length', 3).as('files');
        cy.get('@files')
          .eq(0)
          .within(() => {
            cy.get('ngx-input input').should('have.value', 'FEA - Applet Task 1');
            cy.get('ngx-select .ngx-select-input-option').should('contain', 'Applet 1');
          });
        cy.get('@files')
          .eq(1)
          .within(() => {
            cy.get('ngx-input input').should('have.value', 'FEA - App Task 1');
            cy.get('ngx-select .ngx-select-input-option').should('contain', 'Application 1');
          });
        cy.get('@files')
          .eq(2)
          .within(() => {
            cy.get('ngx-input input').should('have.value', 'FEA - Example Task 1');
            cy.get('ngx-select .ngx-select-input-option').should('contain', 'Common Task');
          });
      });

      it('validates task name', () => {
        cy.get('.task-upload-dialog--tasks-scroll-region--loaded-file .file')
          .first()
          .within(() => {
            cy.get('ngx-input input').clear().type('Task 1');
            cy.get('.file-status--text').should('contain', 'Task name already exists');
            cy.root()
              .closest('int-task-upload-dialog')
              .find('.ngx-dialog-footer ngx-button button')
              .should('be.disabled');
            cy.root()
              .closest('int-task-upload-dialog')
              .find('.task-upload-dialog--status-subtext')
              .should('contain', 'Resolve the errors below to continue the upload process.');
            cy.get('ngx-input input').clear().type('FEA - Example Task 1');
            cy.get('.file-status--text').should('contain', 'Ready for Upload');
          });
      });

      it('should remove an file', () => {
        cy.get('.task-upload-dialog--tasks-scroll-region--loaded-file').first().find('.remove-file').click();
        cy.get('.task-upload-dialog--tasks-scroll-region--loaded-file .file').should('have.length', 2);
      });

      // NOTE: requires test above
      it('uploads a task', () => {
        cy.setupStubbedSwimlane();
        cy.get('.ngx-dialog-footer ngx-button button').first().click();
        cy.wait('@POST:task/upload');
        cy.wait('@POST:task/upload');
      });

      // NOTE: requires test above
      it('displays task status', () => {
        cy.get('.task-upload-dialog--status-text').should('contain', 'Upload Complete');
        cy.get('.task-upload-dialog--tasks-header').within(() => {
          cy.get('span').eq(0).should('contain', 'Task Name');
          cy.get('span').eq(1).should('contain', 'Application or Applet');
          cy.get('span').eq(2).should('contain', 'Status');
        });
        cy.get('.task-upload-status')
          .should('contain', 'FEA - Example Task 1')
          .should('contain', 'Common Task')
          .should('contain', 'New Task Installed');
      });

      // NOTE: requires test above
      it('displays post-upload actions', () => {
        cy.get('.task-upload-dialog--status-actions')
          .should('contain', 'Upload more tasks')
          .should('contain', `I'm done adding tasks`);
      });

      it('resets dialog', () => {
        cy.get('.task-upload-dialog--status-action.reset-action').click();
        cy.get('ngx-file-button').should('exist');
        cy.get('.inner-content').should('contain', 'Drag + Drop');
      });
    });
  });

  describe('SPT-11017: task missing parent are converted to common', () => {
    it('opens dialog', () => {
      cy.get('int-task-upload-dialog').should('exist');
      cy.get('.inner-content').should('contain', 'Drag + Drop');
    });

    describe('task upload', () => {
      before(() => {
        cy.get('.ngx-file-button-input').attachFile([
          {
            filePath: 'tasks/missing-app-task.json',
            fileName: 'missing-app-task.json',
            mimeType: 'application/json',
            encoding: 'utf-8'
          },
          {
            filePath: 'tasks/missing-applet-task.json',
            fileName: 'missing-applet-task.json',
            mimeType: 'application/json',
            encoding: 'utf-8'
          }
        ]);
      });

      it('shows files after read before upload', () => {
        cy.get('.task-upload-dialog--tasks-scroll-region--loaded-file .file').should('have.length', 2).as('files');
        cy.get('@files')
          .eq(0)
          .within(() => {
            cy.get('ngx-input input').should('have.value', 'FEA - Applet Task 1');
            cy.get('ngx-select .ngx-select-input-option').should('contain', 'Common Task');
          });
        cy.get('@files')
          .eq(1)
          .within(() => {
            cy.get('ngx-input input').should('have.value', 'FEA - App Task 1');
            cy.get('ngx-select .ngx-select-input-option').should('contain', 'Common Task');
          });
      });

      it('closes dialog on cancel', () => {
        cy.setupStubbedSwimlane();
        cy.get('.ngx-button').contains('Cancel').click();
        cy.get('int-task-upload-dialog').should('not.exist');
        cy.get('.plus-menu-container .ngx-plus-menu--circle').click();
        cy.get('.ngx-plus-menu--icon-0').click();
      });
    });
  });

  describe('script upload dialog', () => {
    it('opens dialog', () => {
      cy.get('int-task-upload-dialog').should('exist');
    });

    it('shows file uploader', () => {
      cy.get('.inner-content').should('contain', 'Drag + Drop');
    });

    describe('task script', () => {
      before(() => {
        cy.get('.ngx-file-button-input').attachFile([
          {
            filePath: 'tasks/test.py',
            fileName: 'test.py',
            mimeType: 'text/x-python',
            encoding: 'utf-8'
          }
        ]);
      });

      it('shows files after read before upload', () => {
        cy.get('.task-upload-dialog--upload-progress').should('contain', 'Here Are the Tasks You Are Uploading');
        cy.get('.task-upload-dialog--tasks-scroll-region--loaded-file .file').should('have.length', 1).as('files');
        cy.get('@files')
          .eq(0)
          .within(() => {
            cy.get('ngx-input input').should('have.value', 'test.py');
            cy.get('ngx-select .ngx-select-input-option').should('contain', 'Common Task');
          });
      });

      it('validates task name', () => {
        cy.get('.task-upload-dialog--tasks-scroll-region--loaded-file .file')
          .first()
          .within(() => {
            cy.get('ngx-input input').clear().type('Task 1');
            cy.get('.file-status--text').should('contain', 'Task name already exists');
            cy.root()
              .closest('int-task-upload-dialog')
              .find('.ngx-dialog-footer ngx-button button')
              .should('be.disabled');
            cy.root()
              .closest('int-task-upload-dialog')
              .find('.task-upload-dialog--status-subtext')
              .should('contain', 'Resolve the errors below to continue the upload process.');
            cy.get('ngx-input input').clear().type('FEA - Example Task 2');
            cy.get('.file-status--text').should('contain', 'Ready for Upload');
          });
      });

      it('uploads a task', () => {
        cy.setupStubbedSwimlane();
        cy.get('.ngx-dialog-footer ngx-button button').first().click();
        cy.wait('@POST:task/upload-script');
      });

      it('displays task status', () => {
        cy.get('.task-upload-dialog--status-text').should('contain', 'Upload Complete');
        cy.get('.task-upload-status')
          .should('contain', 'FEA - Example Task 2')
          .should('contain', 'Common Task')
          .should('contain', 'New Task Installed');
      });

      it('displays post-upload actions', () => {
        cy.get('.task-upload-dialog--status-actions')
          .should('contain', 'Upload more tasks')
          .should('contain', `I'm done adding tasks`);
      });

      it('closes dialog', () => {
        cy.get('.task-upload-dialog--status-action.close-action').click();
        cy.get('int-task-upload-dialog').should('not.exist');
      });
    });
  });
});

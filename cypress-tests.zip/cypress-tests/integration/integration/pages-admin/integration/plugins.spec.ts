describe('Integrations page - Plugins Tab', () => {
  before(() => {
    cy.login();

    cy.setupStubbedSwimlane();
    cy.intercept('/api/task/packages', []).as('getPackages');
    cy.navigateSwimlane(`/integration/plugins`);
    cy.wait('@getPackages');
  });

  it('should display integration tabs', () => {
    cy.get('.page-toolbar')
      .should('contain', 'Tasks')
      .should('contain', 'Assets')
      .should('contain', 'Key Store')
      .should('contain', 'Plugins')
      .should('contain', 'Python Packages');
  });

  it('should set tasks tab active', () => {
    cy.get('.page-toolbar').find('.main-tabs a').contains('Plugins').parent('li').should('have.class', 'active');
  });

  describe('no plugins', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.intercept('/api/task/packages', []).as('getPackages');
      cy.navigateSwimlane(`/integration/plugins`);
      cy.wait('@getPackages');
    });

    it('should show landing page', () => {
      cy.get('.no-items-container')
        .should('contain', 'Start by uploading your first plugin')
        .should('contain', 'Plugins are distributable packages that provide integration functionality.');
    });

    it('shows top menu component on click', () => {
      cy.get('.plus-menu-container .ngx-icon').should('be.visible');
    });
  });

  describe('plugins list', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.navigateSwimlane(`/integration/plugins`);
      cy.wait('@GET:task/packages');
    });

    beforeEach(() => {
      cy.get('.item-list--group').as('groups');
      cy.get('@groups').eq(1).as('vendor1');
      cy.get('@groups').eq(2).as('vendor2');
      cy.get('ngx-card').as('cards');
    });

    it('should have grouped plugin list', () => {
      cy.get('@groups').should('have.length', 4);
      cy.get('@cards').should('have.length', 4);

      cy.get('@vendor1')
        .find('.item-list--group--header')
        .should('contain', 'Swimlane')
        .should('contain', 'Plugin')
        .find('.tag')
        .should('contain', '1');

      cy.get('@vendor2')
        .find('.item-list--group--header')
        .should('contain', 'Twitter')
        .should('contain', 'Plugin')
        .find('.tag')
        .should('contain', '1');
    });

    it('should show cards', () => {
      cy.get('@cards')
        .eq(2)
        .should('contain', 'Plugin')
        .should('contain', 'sw_twitter')
        .should('contain', '1.0.0')
        .should('contain', 'Twitter')
        .find('.ngx-card-avatar--avatar img')
        .should('have.attr', 'src')
        .and('contain', 'data:image/png;base64');

      cy.get('@cards')
        .eq(3)
        .should('contain', 'Plugin')
        .should('contain', 'sw_virus_total')
        .should('contain', '2.2.1')
        .should('contain', 'VirusTotal integration library')
        .find('.ngx-card-avatar--avatar img')
        .should('have.attr', 'src')
        .and('contain', 'data:image/png;base64');
    });

    describe('plugin detail drawer', () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.get('ngx-card').as('cards');
        cy.get('@cards').first().find('.ngx-card-section .view-details').click();
        cy.wait('@GET:task/packages/*');
        cy.get('int-plugin-detail').should('be.visible');
      });

      beforeEach(() => {
        cy.get('.ngx-tabs-list').find('.ngx-tab').first().as('overviewTab');
        cy.get('.ngx-tabs-list').find('.ngx-tab').eq(1).as('changelogTab');
        cy.get('.ngx-tabs-list').find('.ngx-tab').eq(2).as('assetsTab');
        cy.get('.ngx-tabs-list').find('.ngx-tab').eq(3).as('actionsTab');
      });

      after(() => {
        cy.get('.plugin-details-title img').click();
        cy.get('int-plugin-detail').should('not.exist');
      });

      it('shows drawer', () => {
        cy.get('.plugin-details-name').should('contain', 'GitLab');
        cy.get('@overviewTab').should('have.class', 'active');
        cy.get('.plugin-details-version-info')
          .should('contain', '1.0.0')
          .should('contain', 'sw_gitlab')
          .should('contain', 'GitLab')
          .should('contain', '3');
        cy.get('.support-text').should('contain', 'Questions on SecOps Hub');
      });

      it('assets tab', () => {
        cy.get('@assetsTab').click();
        cy.get('.int-plugin-io-card')
          .should('have.length', 1)
          .first()
          .within(() => {
            cy.get('.ngx-section-header').should('contain', 'gitlab');
            cy.get('.ngx-section-toggle').click();
          });
        cy.get('.plugin-io-card--body').within(() => {
          cy.get('.plugin-io-card--body-label').contains('Input Parameters');
          cy.get('.plugin-io-container').should('be.visible');
        });
      });

      it('actions tab', () => {
        cy.get('@actionsTab').click();
        cy.get('.int-plugin-io-card').as('actionCards').should('have.length', 11);
        cy.get('@actionCards')
          .first()
          .as('action')
          .within(() => {
            cy.get('.ngx-section-header').should('contain', 'GitLab Get Issue Comments');
            cy.get('.ngx-section-toggle').click();
          });
        cy.get('.plugin-io-card--body').within(() => {
          cy.get('.plugin-io-card--body-label').should('have.length', 3);
          cy.get('.plugin-io-card--body-label').first().should('contain', 'Description');
          cy.get('.plugin-io-card--body-label').eq(1).should('contain', 'Input Parameters');
          cy.get('.plugin-io-card--body-label').eq(2).should('contain', 'Output Parameters');
          cy.get('.plugin-io-container').should('have.length', 2);
        });
      });
    });

    describe('filter', () => {
      it('shows results and can reset using input', () => {
        cy.get('.integration-page--search-box input').type('twitter');
        cy.get('@groups').should('have.length', 1);
        cy.get('@vendor2').find('.tag').should('contain', '1');
        cy.get('.btn > ngx-icon > .ngx-icon').click();
      });

      it('shows message with no results and reset using message', () => {
        cy.get('.integration-page--search-box input').type('none');
        cy.get('.no-filters-match').should('contain', 'No plugins have been found that match your criteria.');
        cy.get('.no-filters-match--reset-filters > span').click();
        cy.get('@groups').should('have.length', 4);
      });
    });
  });

  describe('plugin upload dialog', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.get('.plus-menu-container .ngx-icon').click();
    });

    it('opens dialog', () => {
      cy.get('int-plugin-upload-dialog').should('exist');
    });

    it('shows file uploader', () => {
      cy.get('.inner-content').should('contain', 'Drag + Drop');
    });

    after(() => {
      cy.get('ngx-button.btn-close').should('exist').click({ force: true }); // may be behind a tooltip
      cy.get('int-plugin-upload-dialog').should('not.exist');
    });
  });

  describe('plugin upload - failed', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.intercept('POST', '/api/task/packages/upload', {
        packageIssue: { uploadStatus: 'failed' },
        product: 'Web Services'
      }).as('uploadPackage');
      cy.get('.plus-menu-container .ngx-icon').click();

      cy.get('.ngx-file-button-input').attachFile({
        fileContent: '{}',
        fileName: 'sw_microsoft_exchange-2.2.2-linux.swimbundle',
        mimeType: 'application/json',
        encoding: 'utf-8'
      } as any);

      cy.wait('@uploadPackage');
    });

    it('should display upload failed message', () => {
      cy.get('.plugin-upload-dialog--upload-progress')
        .should('contain', 'Here Are the Plugins You Have Uploaded')
        .should('contain', 'Review and take action on these plugins, as needed.');
    });

    after(() => {
      cy.get('ngx-button.btn-close').should('exist').click({ force: true });
      cy.get('int-plugin-upload-dialog').should('not.exist');
    });
  });

  describe('plugin upload - success', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.intercept('POST', '/api/task/packages/upload', {
        packageIssue: { uploadStatus: 'inserted' },
        product: 'Web Services'
      }).as('uploadPackage');
      cy.get('.plus-menu-container .ngx-icon').click();

      cy.get('.ngx-file-button-input').attachFile({
        fileContent: '{}',
        fileName: 'sw_microsoft_exchange-2.2.2-linux.swimbundle',
        mimeType: 'application/json',
        encoding: 'utf-8'
      } as any);

      cy.wait('@uploadPackage');
    });

    it('should open dialog', () => {
      cy.get('int-plugin-upload-dialog').should('exist');
    });

    it('should display upload complete message', () => {
      cy.get('.plugin-upload-dialog--upload-progress').should('contain', 'Here Are the Plugins You Have Uploaded');
    });

    it('should display plugin', () => {
      cy.get('.plugin-upload-status--success')
        .should('contain', 'Web Services')
        .should('contain', 'New Plugin Installed');
    });

    after(() => {
      cy.get('ngx-button.btn-close').should('exist').click({ force: true });
      cy.get('int-plugin-upload-dialog').should('not.exist');
    });
  });

  describe('plugin upload - need upgrade', () => {
    before(() => {
      cy.setupStubbedSwimlane();

      cy.get('.plus-menu-container .ngx-icon').click();

      cy.get('.ngx-file-button-input').attachFile({
        fileContent: '{}',
        fileName: 'sw_microsoft_exchange-2.2.2-linux.swimbundle',
        mimeType: 'application/json',
        encoding: 'utf-8'
      } as any);

      cy.wait('@POST:task/packages/upload');
    });

    it('should open dialog', () => {
      cy.get('int-plugin-upload-dialog').should('exist');
    });

    it('should display upload complete message', () => {
      cy.get('.plugin-upload-dialog--upload-progress').should('contain', 'Here Are the Plugins You Have Uploaded');
    });

    it('should display plugin', () => {
      cy.get('.plugin-upload-status--need-upgrade')
        .should('contain', 'Test Plugin')
        .should('contain', 'New Plugin Version Detected');
    });

    describe('plugin upgrade', () => {
      before(() => {
        cy.get('.plugin-upload-status--status-text > ngx-button').click();
      });

      it('shows upgrade panel', () => {
        cy.get('int-plugin-upgrade-drawer').should('exist').as('drawer');
        cy.get('@drawer').find('.ngx-toolbar-title-col').should('contain', 'Upgrade Plugin');
      });

      it('shows preview card', () => {
        cy.get('int-plugin-upgrade-drawer ngx-card').should('exist').as('preview');
        cy.get('@preview').find('.ngx-card-avatar--img').should('have.attr', 'src');
        cy.get('ngx-card').within(() => {
          cy.get('.ngx-card-header').should('contain', 'Test Plugin');
          cy.get('.plugin-version-current').should('contain', 'CURRENT').should('contain', '1.0.0');
          cy.get('.plugin-version-next').should('contain', 'UPGRADE').should('contain', '2.0.0');
        });
      });

      it('shows issues section', () => {
        cy.get('.upgrade-details--changes').should('exist').as('changes');
        cy.get('@changes').find('h4').should('contain', 'Assets & Tasks With Changes');
        cy.get('@changes').find('int-plugin-upgrade-issues-container').as('issue-containers');
        cy.get('@issue-containers').should('have.length', 3);

        cy.get('@issue-containers').eq(0).as('asset-issues');
        cy.get('@issue-containers').eq(1).as('task-1-issues');
        cy.get('@issue-containers').eq(2).as('task-2-issues');

        cy.get('@asset-issues').find('.issue-card--header').should('contain', 'asset').should('contain', 'Test Plugin');

        cy.get('@asset-issues')
          .find('.tip-container')
          .should('contain', 'You can fix these parameters after upgrading this plugin.');

        cy.get('@asset-issues')
          .find('int-plugin-upgrade-issue')
          .should('contain', 'New Required')
          .should('contain', 'input parameter')
          .should('contain', 'new_required_field');

        cy.get('@task-1-issues')
          .find('.issue-card--header')
          .should('contain', 'task')
          .should('contain', 'Task 1')
          .should('contain', 'Test Plugin this will be removed');

        cy.get('@task-1-issues')
          .find('.tip-container')
          .should('contain', 'You can swap this task after upgrading this plugin.');

        cy.get('@task-1-issues')
          .find('int-plugin-upgrade-issue')
          .should('contain', 'Removal of')
          .should('contain', 'Action')
          .should('contain', 'Test Plugin this will be removed');

        cy.get('@task-2-issues')
          .find('.issue-card--header')
          .should('contain', 'task')
          .should('contain', 'Task 2')
          .should('contain', 'Test Plugin IO changes');

        cy.get('@task-2-issues')
          .find('.tip-container')
          .should('contain', 'You can fix these parameters after upgrading this plugin.');

        cy.get('@task-2-issues')
          .find('int-plugin-upgrade-issue')
          .should('contain', 'Parameter Types are Different')
          .should('contain', 'input1');
      });

      it('shows help section', () => {
        cy.get('.upgrade-details--help-text').should('exist').as('help');
        cy.get('@help').find('h4').should('contain', 'Are You Sure You Want to Upgrade?');
      });

      it('shows steps', () => {
        cy.get('ngx-stepper').as('stepper');
        cy.get('@stepper').find('ngx-step').as('steps');

        cy.get('@stepper').should('exist');
        cy.get('@steps').should('have.length', 2);
        cy.get('@steps').eq(0).should('have.class', 'ngx-step--active').should('contain', 'Confirm Upgrade');
        cy.get('@steps').eq(1).should('contain', 'Review Assets & Tasks');
      });

      describe('Continue Upgrade', () => {
        before(() => {
          cy.get('.plugin-upgrade-drawer--content--footer .btn-primary').click();
        });

        describe('confirm dialog', () => {
          it('shows confirm dialog', () => {
            cy.get('.ngx-dialog.ngx-alert-dialog.confirm').should('be.visible').as('confirm');
            cy.get('@confirm').should(
              'contain',
              'You are about to upgrade a plugin. This will create breaking issues.'
            );
          });
        });

        describe('ok', () => {
          before(() => {
            cy.setupStubbedSwimlane();
            cy.get('.ngx-dialog.ngx-alert-dialog.confirm .btn-primary').click();
            cy.wait('@POST:task/packages/upgrade');
          });

          it('shows preview card and details', () => {
            cy.get('int-plugin-upgrade-drawer ngx-card').should('exist').as('preview');
            cy.get('@preview').find('.ngx-card-avatar--img').should('have.attr', 'src');
            cy.get('.ngx-card-header').should('contain', 'Test Plugin');
            cy.get('.ngx-card-section--complete').should('contain', 'Plugin Upgrade Complete');

            cy.get('int-plugin-upgrade-issues-container').should('have.length', 4);
          });

          it('updates steps', () => {
            cy.get('ngx-stepper').as('stepper');
            cy.get('@stepper').find('ngx-step').as('steps');

            cy.get('@steps').eq(1).should('have.class', 'ngx-step--active');
          });

          describe('manage issues', () => {
            beforeEach(() => {
              cy.get('int-plugin-upgrade-issues-container').as('issues');
            });

            describe('asset issues', () => {
              beforeEach(() => {
                cy.get('@issues').first().as('issue');
              });

              it('opens asset dialog', () => {
                cy.setupStubbedSwimlane();
                cy.get('@issue').find('.issue-card--count .btn').as('btn');
                cy.get('@btn').should('contain', 'Resolve 1 Issue');
                cy.get('@btn').click();

                cy.get('.integration-page--asset-edit-dialog-container').should('exist');

                cy.get('.ngx-input-box-wrap > #name').type('1234');

                cy.get('state-save-button > .btn').click();
                cy.wait('@PUT:asset/*');

                cy.get('.ngx-notification').find('.ngx-notification-title').should('contain', 'Asset Saved');
                cy.get('.ngx-large-format-dialog-footer').find('.btn-bordered').first().click();
                cy.get('@issue').find('.issue-card--count--issues-resolved').should('contain', 'Issues Resolved');
              });
            });

            describe('task issues', () => {
              beforeEach(() => {
                cy.get('@issues').last().as('issue');
              });

              it('opens task dialog', () => {
                cy.setupStubbedSwimlane();
                cy.get('@issue').find('.issue-card--count .btn').as('btn');
                cy.get('@btn').should('contain', 'Resolve 2 Issues');
                cy.get('@btn').click();
                cy.wait('@GET:task/*');

                cy.get('.stacks-sidebar.task-page').as('taskDialog');
                cy.get('@taskDialog').should('exist');
                cy.get('.stack-tabs a').contains('General').click();
                cy.get('@taskDialog').find('#name').type('1234');
                cy.get('@taskDialog').find('.save-button').first().click();
                cy.wait('@PUT:task/*');

                cy.get('@taskDialog').find('.back-btn').click();

                cy.get('@issue').find('.issue-card--count--issues-resolved').should('contain', 'Issues Resolved');
              });
            });

            describe('delete action', () => {
              beforeEach(() => {
                cy.get('@issues').eq(1).as('issue');
              });

              it('opens swap task dialog', () => {
                cy.setupStubbedSwimlane();
                cy.get('@issue').find('.issue-card--count .btn').as('btn');
                cy.get('@btn').should('contain', 'Resolve 1 Issue');
                cy.get('@btn').click();

                cy.wait('@GET:task/*');
                cy.wait('@GET:task/actions');

                cy.get('.integration-page--replace-dialog-container').as('dialog');
                cy.get('@dialog').should('exist');
                cy.get('@dialog').find('ngx-card').first().find('.ngx-card-section .btn').click();

                cy.get('.ngx-dialog.ngx-alert-dialog.confirm').as('confirm');
                cy.get('@confirm').should('exist');
                cy.get('@confirm').find('.btn').first().click();

                cy.wait('@DELETE:task/*');

                cy.get('@issue').find('.issue-card--count--issues-resolved').should('contain', 'Issues Resolved');
              });
            });

            describe('swap action', () => {
              beforeEach(() => {
                cy.get('@issues').eq(2).as('issue');
              });

              it('opens swap task dialog', () => {
                cy.setupStubbedSwimlane();
                cy.get('@issue').find('.issue-card--count .btn').as('btn');
                cy.get('@btn').should('contain', 'Resolve 1 Issue');
                cy.get('@btn').click();

                cy.wait('@GET:task/*');
                cy.wait('@GET:task/actions');

                cy.get('.integration-page--replace-dialog-container').as('dialog');
                cy.get('@dialog').should('exist');
                cy.get('@dialog').find('ngx-card .ngx-card-section .create').click();
                cy.wait('@GET:task/action/*/new');

                cy.get('.stacks-sidebar.task-page').as('taskDialog');
                cy.get('@taskDialog').should('exist');

                cy.get('.stack-tabs a').contains('General').click();
                cy.get('@taskDialog').find('#name').type('1234');
                cy.get('@taskDialog').find('.save-button').first().click();
                cy.wait('@PUT:task/*');

                cy.get('@taskDialog').find('.back-btn').click();

                // SPT-7593
                cy.get('.stacks-sidebar.task-page').should('not.exist');

                cy.get('@issue').find('.issue-card--count--issues-resolved').should('contain', 'Issues Resolved');
              });
            });
          });

          describe('should close upgrade drawer', () => {
            before(() => {
              cy.get('.plugin-upgrade-drawer--content--footer > .ng-star-inserted > .btn').click();
            });

            it('updates status', () => {
              cy.get('.plugin-upload-status--status-text').should('contain', 'Plugin Upgraded');
            });
          });
        });
      });
    });

    describe('closing', () => {
      it('should close dialog', () => {
        cy.get('.integration-page--plugin-upload-dialog-container ngx-button.btn-close').should('exist').click();
        cy.get('plugin-upload-dialog').should('not.exist');
      });
    });
  });

  describe('plugin delete', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.navigateSwimlane(`/integration/plugins`);
      cy.wait('@GET:task/packages');
    });

    it('opens delete dialog', () => {
      cy.setupStubbedSwimlane();
      cy.get('ngx-card > .ngx-card-section--dropdown')
        .find('.ngx-dropdown-toggle')
        .first()
        .as('ellipsis')
        .should('exist');
      cy.get('@ellipsis').click();
      cy.get('ngx-dropdown-menu').should('exist');
      cy.get('ngx-dropdown-menu')
        .find('ul.vertical-list li button')
        .first()
        .as('deleteButton')
        .should('contain', 'Delete Plugin');
      cy.get('@deleteButton').click({ force: true });

      cy.wait('@GET:task/packages/*/*/usage/*');
      cy.wait('@GET:task/list');
      cy.wait('@GET:asset/list');
      cy.get('.plugin-delete-dialog--content', { timeout: 20000 }).should('exist');
    });

    it('shows plugin card', () => {
      cy.get('.plugin-delete-dialog--content--plugin-card ngx-card').as('pluginCard').should('exist');
      cy.get('@pluginCard')
        .find('.ngx-card-avatar--avatar img')
        .should('have.attr', 'src')
        .and('contain', 'data:image/png;base64');
      cy.get('@pluginCard').should('contain', 'GitLab').should('contain', 'DELETE').should('contain', '1.0.0');
    });

    it('shows warning text', () => {
      cy.get('.plugin-delete-dialog--content--main--warning')
        .should('contain', 'Are You Sure You Want to Delete This Plugin?')
        .should('contain', 'This completely removes sw_gitlab 1.0.0 from Swimlane.');
      cy.get('.plugin-delete-dialog--content--main--warning ngx-tip').should(
        'contain',
        'Warning: You will need to resolve the issues outlined on this dialog before deleting the plugin. If not resolved, items utilizing this plugin will become invalid.'
      );
    });

    describe('shows to be deleted items', () => {
      it('deleted tasks', () => {
        cy.get('.plugin-delete-dialog--content--main .card').eq(0).as('task1').should('exist');
        cy.get('@task1')
          .find('.ngx-card-avatar--avatar img')
          .should('have.attr', 'src')
          .and('contain', 'data:image/png;base64');
        cy.get('@task1').find('.card--type').should('contain', 'TASK');
        cy.get('@task1').find('.card--title').should('contain', 'FEA - Example Task 1');
        cy.get('@task1').find('.card--subtitle').should('contain', 'Will Be Deleted');
        cy.get('@task1').find('.card--description .type').should('contain', 'Action');
        cy.get('@task1').find('.card--description .value').should('contain', 'GitLab action');

        cy.get('.plugin-delete-dialog--content--main .card').eq(1).as('task2').should('exist');
        cy.get('@task2')
          .find('.ngx-card-avatar--avatar img')
          .should('have.attr', 'src')
          .and('contain', 'data:image/png;base64');
        cy.get('@task2').find('.card--type').should('contain', 'TASK');
        cy.get('@task2').find('.card--title').should('contain', 'FEA - Example Task 2');
        cy.get('@task2').find('.card--subtitle').should('contain', 'Will Be Deleted');
        cy.get('@task2').find('.card--description .type').should('contain', 'Action');
        cy.get('@task2').find('.card--description .value').should('contain', 'GitLab Get Issue');

        cy.get('.plugin-delete-dialog--content--main .card').eq(2).as('task3').should('exist');
        cy.get('@task3')
          .find('.ngx-card-avatar--avatar img')
          .should('have.attr', 'src')
          .and('contain', 'data:image/png;base64');
        cy.get('@task3').find('.card--type').should('contain', 'TASK');
        cy.get('@task3').find('.card--title').should('contain', 'plugin test task');
        cy.get('@task3').find('.card--subtitle').should('contain', 'Will Be Deleted');
        cy.get('@task3').find('.card--description .type').should('contain', 'Action');
        cy.get('@task3').find('.card--description .value').should('contain', 'Rest API action');
      });

      it('assets', () => {
        cy.get('.plugin-delete-dialog--content--main .card').eq(3).as('asset').should('exist');
        cy.get('@asset')
          .find('.ngx-card-avatar--avatar img')
          .should('have.attr', 'src')
          .and('contain', 'data:image/png;base64');
        cy.get('@asset').find('.card--type').should('contain', 'ASSET');
        cy.get('@asset').find('.card--title').should('contain', 'IMAP');
        cy.get('@asset').find('.card--subtitle').should('contain', 'Will Be Deleted');
        cy.get('@asset').find('.card--description .type').should('contain', 'Plugin Asset');
        cy.get('@asset').find('.card--description .value').should('contain', 'GitLab');
      });
    });

    describe('shows affected items', () => {
      it('shows forked tasks', () => {
        cy.get('.plugin-delete-dialog--content--main .card').eq(4).as('forkedTask').should('exist');
        cy.get('@forkedTask')
          .find('.ngx-card-avatar--avatar img')
          .should('have.attr', 'src')
          .and('contain', 'data:image/png;base64');
        cy.get('@forkedTask').find('.card--type').should('contain', 'FORKED TASK');
        cy.get('@forkedTask').find('.card--title').should('contain', 'Forked Task');
        cy.get('@forkedTask').find('.card--subtitle').should('contain', 'Will Be Invalid');
        cy.get('@forkedTask').find('.card--description .type').should('contain', 'Action');
        cy.get('@forkedTask').find('.card--description .value').should('contain', 'python 3');
      });

      it('shows applications', () => {
        cy.get('.plugin-delete-dialog--content--main ngx-section')
          .eq(0)
          .should('exist')
          .within(() => {
            cy.get('ngx-section-header .card--header--acronym').should('contain', 'PT');
            cy.root().should('contain', 'application').should('contain', 'Application 1');
            cy.get('.ngx-section-content')
              .should('exist')
              .find('.card--body--item')
              .first()
              .should('exist')
              .within(() => {
                cy.get('.card--body--item--detail--type .type').should('contain', 'Removal of');
                cy.get('.card--body--item--detail--type .value').should(
                  'contain',
                  'Integration Task from Integration Action'
                );
                cy.get('.card--body--item--detail--name')
                  .should('contain', 'WORKFLOW ACTION')
                  .should('contain', 'Workflow Action')
                  .should('contain', 'TASK')
                  .should('contain', 'plugin test task');
              });
          });
      });

      it('shows referential tasks', () => {
        cy.get('.plugin-delete-dialog--content--main ngx-section')
          .eq(1)
          .should('exist')
          .within(() => {
            cy.get('.ngx-card-avatar--avatar img').should('have.attr', 'src').and('contain', 'data:image/png;base64');
            cy.get('.card--header--details .card--type').should('contain', 'TASK');
            cy.get('.card--header--details .card--name').should('contain', 'FEA - Example Task 3');
            cy.get('.card--description .type').should('contain', 'Action');
            cy.get('.card--description .value').should('contain', 'python 3');
            cy.get('.ngx-section-content')
              .should('exist')
              .find('.card--body--item')
              .first()
              .should('exist')
              .within(() => {
                cy.get('.card--body--item--detail--type')
                  .should('contain', 'Deletion of')
                  .should('contain', 'Triggered Integration Task');
                cy.get('.card--body--item--detail--name').should('contain', 'FEA - Example Task 1');
              });
          });
      });

      it('shows applets', () => {
        cy.get('.plugin-delete-dialog--content--main ngx-section')
          .eq(2)
          .should('exist')
          .within(() => {
            cy.get('ngx-section-header .card--header--acronym').should('contain', 'NA');
            cy.root().should('contain', 'applet').should('contain', 'New Applet');
            cy.get('.ngx-section-content')
              .should('exist')
              .find('.card--body--item')
              .first()
              .should('exist')
              .within(() => {
                cy.get('.card--body--item--detail--type .type').should('contain', 'Removal of');
                cy.get('.card--body--item--detail--type .value').should(
                  'contain',
                  'Integration Task from Integration Button'
                );
                cy.get('.card--body--item--detail--name')
                  .should('contain', 'BUTTON')
                  .should('contain', 'Integration Button')
                  .should('contain', 'TASK')
                  .should('contain', 'FEA - Example Task 1');
              });
          });
      });
    });
  });
});

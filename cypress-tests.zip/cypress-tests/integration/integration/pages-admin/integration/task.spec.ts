describe('Tasks Page', () => {
  const taskId = 'aIfR6KGZXpGPY7I1t';
  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.navigateSwimlane(`/integration/common/task/${taskId}`);
    cy.wait('@GET:task/*');
  });

  describe('task inputs', () => {
    before(() => {
      cy.get('.stack-tabs a').contains('Configuration').click();
      cy.get('div.tab-pane.active')
        .find('.editor-tester a')
        .contains(/^\s*Inputs\s*$/)
        .click();
    });

    it('shows inputs', () => {
      cy.get('.input-tab-header').should('contain', 'Script Inputs');
    });

    it('adds parameter and key store value', () => {
      cy.get('.editor-tester > .stack-tabs > .tab-content > .tab-pane.active').within(() => {
        cy.contains('Add Parameter').click();
        cy.get('.list-group-item').should('have.length', 1);
        cy.get('label').contains('Type').next().find('.ui-select-container').should('exist').as('select');
        cy.get('@select').find('.ui-select-toggle').click();
      });
      cy.get('.ui-select-choices-row').contains('Key Store').click();
      cy.get('a').contains('Add new key store value').click();
      cy.get('.modal-content')
        .should('exist')
        .within(() => {
          cy.get('input[name="name"]').type('Test');
          cy.get('input[name="value"]').type('Test');

          cy.intercept('POST', 'api/credentials', {
            body: { name: 'test', value: 'Test', isInternal: false }
          }).as('POST:api/credentials');

          cy.get('button').contains('Save').click();

          cy.wait('@POST:api/credentials').its('request.body').as('body');
          cy.get('@body').its('name').should('eq', 'test'); // NOTE: lowercase is sent to the server
          cy.get('@body').its('value').should('eq', 'Test');
        });
    });
  });

  describe('task debugger', () => {
    before(() => {
      cy.get('.stack-tabs a').contains('Configuration').click();
      cy.get('div.tab-pane.active')
        .find('.editor-tester a')
        .contains(/^\s*Debugger\s*$/)
        .click();
    });

    it('shows debugger', () => {
      cy.get('.task-test-container task-test').should('exist');
    });

    it('shows debugger settings', () => {
      cy.get('.debugger-section.inputs button')
        .contains(/^\s*Settings\s*$/)
        .click();
      cy.get('.bypass-section-toggle input').should('exist');
    });

    it('shows debugged task output tab', () => {
      cy.get('.debugger-section.results button')
        .contains(/^\s*Output\s*$/)
        .click();
      cy.get('ngx-tab[label="Output"')
        .should('exist')
        .within(() => {
          cy.get('button span').contains('Copy Output').should('exist');
        });
    });

    it('shows discover parameters tab on debugger', () => {
      cy.get('.debugger-section.results button')
        .contains(/^\s*Discovered Parameters\s*$/)
        .click();
      cy.get('ngx-tab[label="Discovered Parameters"')
        .should('exist')
        .within(() => {
          cy.get('button span').contains('Add Selected Parameters').should('exist');
        });
    });

    describe('input parameters', () => {
      it('displays inputs section', () => {
        cy.get('div.tab-pane.active')
          .find('.editor-tester a')
          .contains(/^\s*Inputs\s*$/)
          .click();
        cy.get('.task-test-container task-test').should('exist');
      });

      it('adds new input parameter of type keystore', () => {
        cy.get('.editor-tester span a').contains('Add Parameter').should('exist').click();
        cy.get('.ui-select-container a').eq(2).click();
        cy.get('ul.ui-select-choices li.ui-select-choices-group ul li').contains('Key').click();
      });

      it('adds new input parameter of type asset library', () => {
        cy.get('.editor-tester span a').contains('Add Parameter').should('exist').click();
        cy.get('.ui-select-container a').eq(4).click();
        cy.get('ul.ui-select-choices li.ui-select-choices-group ul li').contains('Asset').click();
      });

      it('adds new input parameter of type literal value', () => {
        cy.get('.editor-tester span a').contains('Add Parameter').should('exist').click();
        cy.get('.ui-select-container a').last().click();
        cy.get('ul.ui-select-choices li.ui-select-choices-group ul li').contains('Literal Value').click();
        cy.get('[data-cy=input-params__literal-input]').last().ngxFill('Testing literal value input param');
      });

      it('displays task has errors dialog on attempt to save', () => {
        cy.get('.save-button').contains('Save').should('exist').click();
        cy.get('.modal').within(() => {
          cy.get('.modal-header').find('.modal-title').should('have.text', 'The task has errors');
          cy.get('.modal-body').within(() => {
            cy.get('li')
              .first()
              .should('contain', 'Configuration')
              .should('contain', 'Please fill input variable name to save');
          });
          cy.get('.modal-footer').find('button').should('contain', 'Close').click();
        });
      });

      it('shows mapped keystore input on debugger and is disabled', () => {
        cy.get('div.tab-pane.active')
          .find('.editor-tester a')
          .contains(/^\s*Debugger\s*$/)
          .click();
        cy.get('.debugger-section.inputs button')
          .contains(/^\s*Input Values\s*$/)
          .click();
        cy.get('.inputs-table-row')
          .first()
          .should('be.visible')
          .within(() => {
            cy.get('ngx-input input').should('have.attr', 'disabled');
            cy.get('ngx-input-suffix').should('exist');
            cy.get('ngx-icon').should('exist').should('have.attr', 'fonticon', 'key');
          });
      });

      it('shows mapped asset library input on debugger and is disabled', () => {
        cy.get('.inputs-table-row')
          .eq(2)
          .should('be.visible')
          .within(() => {
            cy.get('ngx-input input').should('have.attr', 'disabled');
            cy.get('ngx-input-suffix').should('exist');
            cy.get('ngx-icon').should('exist').should('have.attr', 'fonticon', 'assets');
          });
      });

      it('shows mapped literal value input on debugger and is enabled', () => {
        cy.get('.inputs-table-row')
          .last()
          .should('be.visible')
          .within(() => {
            cy.get('ngx-input input').should('be.enabled').should('have.value', 'Testing literal value input param');
            cy.get('ngx-input-suffix').should('not.exist');
          });
      });

      it('shows Update Input Values button and is disabled', () => {
        cy.get('.task-test--table-header').within(() => {
          cy.get('[data-cy=update__values__literal] button').should('be.disabled');
          cy.get('.update-btn').whileHovering(() => {
            cy.root()
              .closest('body')
              .find('.tooltip-content')
              .should('exist')
              .should('contain', 'Debugger changes enable this button');
          });
          cy.get('[data-cy=reset__values__debugger]').should('not.exist');
        });
      });

      it('changes example for Template input param', () => {
        cy.get('.inputs-table-row')
          .last()
          .within(() => {
            cy.get('ngx-input input').clear().ngxFill('Changing literal value from the debugger tab');
            cy.get('ngx-input-suffix').should('not.exist');
          });
      });

      it('shows enabled Update Input Values and Reset Debugger Values buttons', () => {
        cy.get('.task-test--table-header').within(() => {
          cy.get('[data-cy=update__values__literal] button').should('be.enabled');
          cy.get('.update-btn').whileHovering(() => {
            cy.root()
              .closest('body')
              .find('.tooltip-content')
              .should('exist')
              .should('contain', 'This update will change your literal input values');
          });
          cy.get('[data-cy=reset__values__debugger] button')
            .should('be.enabled')
            .whileHovering(() => {
              cy.root()
                .closest('body')
                .find('.tooltip-content')
                .should('exist')
                .should('contain', 'This reset will change your debugger values');
            });
        });
      });

      it(`opens Don't show again dialog`, () => {
        cy.get('[data-cy=update__values__literal] button').click();
        cy.get('[data-cy=show-again-dialog]').within(() => {
          cy.get('[data-cy=show-again-dialog__title]').should('contain.text', 'Update Input Values');
          cy.get('[data-cy=show-again-dialog__message]').should(
            'contain.text',
            'This update changes the literal input values, which may impact your task. Are you sure?'
          );
          cy.get('[data-cy=show-again-dialog__ok-btn]').should('contain.text', 'Yes, Update');
          cy.get('[data-cy=show-again-dialog__cancel-btn]').should('contain.text', 'No, Cancel').click();
        });
      });

      it('removes recently added input parameters', () => {
        cy.get('div.tab-pane.active')
          .find('.editor-tester a')
          .contains(/^\s*Inputs\s*$/)
          .click();
        cy.get('.ui-select-container').should('exist');
        cy.get('a.ngx-trash').each($but => {
          cy.wrap($but).click();
        });
        cy.get('.ui-select-container').should('not.exist');
      });
    });
  });

  describe('output parameters', () => {
    const outputParametersAdded: Array<{ key: string; name: string }> = [];
    const jsonData = {
      sw_task_status: 'success',
      sw_task_error_type: '',
      sw_task_error_message: '',
      sw_task_stack_trace: '',
      stdOutput: '',
      'armstrong numbers': [0, 1, 153],
      'marvel heros': ['Ironman', 'Captain'],
      iAmaString: 'Tony',
      iAmaNumber: 21,
      heros: {
        ironMan: 'I am Tony!',
        team: [
          {
            name: 'Spidey'
          },
          {
            name: 'Widow'
          },
          {
            name: 'War Machine'
          }
        ]
      },
      '** AI ** @!#$# () - #': 'Jarvis',
      '" I am weird "': 'Thanos'
    };

    const publishTaskResult = (incomingJSONData = jsonData) => {
      cy.hubPublish('taskTestResult', taskId, JSON.stringify([incomingJSONData]));
    };

    const getType = value => (Array.isArray(value) ? 'array' : typeof value);
    // this utility method is written specifically to suite the behavior of JSON tree selection
    const getKeys = input => {
      const inputType = getType(input);
      if (!['array', 'object'].includes(inputType)) {
        return [];
      }

      const list = [];

      Object.keys(input).forEach(key => {
        const value = input[key];
        const type = getType(value);
        if (type === 'object') {
          list.push(key);
          list.push(...getKeys(value));
        }
        if (type === 'array') {
          list.push(key);
          list.push(`${key}[0]`);
          list.push(...getKeys(value[0]));
        } else list.push(key);
      });

      return list;
    };

    const openDiscoverParametersAndRunTask = () => {
      cy.get('output-variables button:first').click();
      cy.get('.debugger-section.results.discover-parameters button').contains('Discovered Parameters').click();
      cy.get('[data-cy=run__task__debugger]').click();
    };

    const setRequiredAliases = () => {
      cy.get('output-variables .parameter-table tbody').as('parametersTable');
      cy.get('.select-all-properties ngx-checkbox').as('selectAllProperties');
      cy.get('.content-container button.results-button').as('addSelectedParameters');
    };

    before(() => {
      cy.get('.stack-tabs a').contains('Output Parameters').click();
    });

    it('allows users to add valid JSON path as output parameters', () => {
      cy.get('output-variables .parameter-table').as('parametersTable');
      cy.get('app-create-output-parameter input').as('createOutputParameterInput');
      cy.get('app-create-output-parameter button').as('createOutputParameterAction');

      const addAndCheckParameter = (jsonQuery: string, isValid = true, errorMessage = '') => {
        cy.get('@createOutputParameterInput').type(jsonQuery);

        if (isValid) {
          cy.get('@createOutputParameterAction').click();

          cy.get('@parametersTable').find('.parameter-row--key').last().should('contain.text', jsonQuery);
          cy.get('@createOutputParameterInput').should('contain.text', '');

          outputParametersAdded.push({
            key: jsonQuery,
            name: ''
          });
        } else {
          cy.get('app-create-output-parameter .ngx-input-hint').should('contain.text', errorMessage);
        }
      };

      addAndCheckParameter('E.D.I.T.H');
      addAndCheckParameter(' $ $', false, 'Syntax error:');
      cy.get('@createOutputParameterInput').clear();
      addAndCheckParameter('Price * Quantity');
      addAndCheckParameter('$sum(Account.Order.Product.(Price * Quantity))');
    });

    it('shows selectable options via JSON tree - discover parameters', () => {
      openDiscoverParametersAndRunTask();
      publishTaskResult();
      setRequiredAliases();

      cy.get('@selectAllProperties').click();
      cy.get('@addSelectedParameters').should('not.be.disabled').click();

      cy.get('@parametersTable').find('.parameter-row--key').should('have.length.above', 15);

      const ignoreDefaultOutputs = [
        'Task status',
        'Task error type',
        'Task error message',
        'Task error stack trace',
        ''
      ];
      const allLabels = [...ignoreDefaultOutputs, ...getKeys(jsonData)];

      cy.get('@parametersTable')
        .find('tr')
        .each($row => {
          const $cells = $row.find('td');
          const key = $cells[0].innerText;
          const name = $cells[1].innerText;
          const type = $cells[2].innerText;
          expect(allLabels).to.include(name);
          outputParametersAdded.push({
            key,
            name
          });

          switch (name) {
            case 'armstrong numbers':
              expect(key).to.equal(`\`${name}\``);
              expect(type).to.equal('numericList');
              break;

            case 'marvel heros':
              expect(key).to.equal(`\`${name}\``);
              expect(type).to.equal('list');
              break;

            case 'iAmaString':
              expect(key).to.equal(`${name}`);
              expect(type).to.equal('text');
              break;

            case 'iAmaNumber':
              expect(key).to.equal(name);
              expect(type).to.equal('number');
              break;

            case 'ironMan':
              expect(key).to.equal('heros.ironMan');
              expect(type).to.equal('text');
              break;

            case `" I am weird "`:
              expect(key).to.equal(`\`" I am weird "\``);
              expect(type).to.equal('text');
              break;

            default:
              break;
          }
        });
    });

    it('disabled options which are already added as output parameters', () => {
      openDiscoverParametersAndRunTask();
      publishTaskResult({
        iAmANewProperty: true,
        ...jsonData
      });
      outputParametersAdded.push({ key: 'iAmANewProperty', name: 'iAmANewProperty' });
      setRequiredAliases();

      cy.get('@addSelectedParameters').should('be.disabled');
      cy.get('.output-parameters-section input[type=checkbox]:not(:disabled)').should('have.length', 2);
      cy.get('@selectAllProperties').click();
      cy.get('@addSelectedParameters').should('not.be.disabled').click().wait(100);
      cy.get('@parametersTable').find('.parameter-row--key').should('have.length', 19);
      cy.get('@parametersTable').find('.parameter-row--key').last().contains(`iAmANewProperty`);
    });

    it('shows all the discovered output parameters in outputs tab', () => {
      cy.get('.stack-tabs a').contains('Outputs').click();
      cy.get('.output-types__insert-update-record').click();
      cy.get('.update-current-record-dialog').as('updateCreateDialog');
      cy.get('@updateCreateDialog').find('.app-item:nth-child(2)').click();
      cy.get('@updateCreateDialog').find('.arrow-icon').click();
      cy.get('@updateCreateDialog').find('.dialog-option:first').click();
      cy.get('@updateCreateDialog').find('.basics--submit-button').click();

      cy.get('.fields-mapping-table tbody tr').as('rows');
      const uniqueOutputParameters = outputParametersAdded.filter(
        (item, index) => outputParametersAdded.findIndex(oParam => oParam.key === item.key) === index
      );

      const itemsToCompare = [{ name: 'Standard Output', key: 'Standard Output' }, ...uniqueOutputParameters];
      cy.get('@rows').should('have.length', itemsToCompare.length);

      cy.get('@rows').each($row => {
        const $parmNameCell = $row.find('td.output-mapping-parameter-name');
        const item = itemsToCompare.find(oParam => oParam.key === $parmNameCell[0].innerText);
        expect(item).to.not.undefined;
      });
    });
  });
});

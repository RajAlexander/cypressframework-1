import faker from 'faker/locale/en';

describe('Integrations page - Tasks Tab', () => {
  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.navigateSwimlane(`/integration`);
    cy.wait('@GET:task/list');
  });

  it('displays integration tabs', () => {
    cy.get('.page-toolbar')
      .should('contain', 'Tasks')
      .should('contain', 'Assets')
      .should('contain', 'Key Store')
      .should('contain', 'Plugins');
  });

  it('sets tasks tab active', () => {
    cy.get('.page-toolbar').find('.main-tabs a').contains('Tasks').parent('li').should('have.class', 'active');
  });

  describe('no tasks', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.intercept('GET', '/api/task/list', {
        fixture: 'mocks/swimlane/task/list/get-empty.json'
      }).as('getTasksList');
      cy.navigateSwimlane(`/integration`);
      cy.wait('@getTasksList');
    });

    it('shows landing page', () => {
      cy.get('.no-items-container').should('contain', 'Start by creating your first task');
    });

    it('shows plus icons', () => {
      cy.get('.plus-menu-container-bottom').should('contain', 'New Task');
    });

    describe('menu', () => {
      it('shows bottom menu component on click', () => {
        cy.get('.plus-menu-container-bottom .ngx-plus-menu--circle').click();
        cy.get('.plus-menu-container-bottom .ngx-plus-menu--items-container').should('be.visible');
      });

      it('shows top menu component on click', () => {
        cy.get('.plus-menu-container .ngx-plus-menu--circle').click();
        cy.get('.plus-menu-container .ngx-plus-menu--items-container').should('be.visible');
      });
    });
  });

  describe('tasks list', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.navigateSwimlane(`/integration`);
      cy.wait('@GET:task/list');
      cy.wait('@GET:app');
      cy.wait('@GET:applet');
    });

    beforeEach(() => {
      cy.get('.item-list--group').as('groups');
      cy.get('ngx-card').as('cards');
    });

    it('grouped by app/applet name', () => {
      cy.get('@groups').should('have.length', 5);
      cy.get('@cards').should('have.length', 7);

      cy.get('@groups')
        .eq(0)
        .find('.item-list--group--header')
        .should('contain', 'Applet 1')
        .should('contain', 'Applet Task')
        .find('.tag')
        .should('contain', '1');

      cy.get('@groups')
        .eq(1)
        .find('.item-list--group--header')
        .should('contain', 'Application 1')
        .should('contain', 'Application Task')
        .find('.tag')
        .should('contain', '1');

      cy.get('@groups')
        .eq(3)
        .find('.item-list--group--header')
        .should('contain', 'Test Application')
        .should('contain', 'Application Task')
        .find('.tag')
        .should('contain', '2');
    });

    it('shows task cards', () => {
      cy.get('@cards')
        .eq(0)
        .within(() => {
          cy.get('.ngx-card-header').should('contain', 'Task 4').should('contain', 'API');
          cy.get('.ngx-card-section--description p').should('contain', 'A REST API Action');
          cy.get('.ngx-card-avatar--avatar img').should('have.attr', 'src').and('contain', 'data:image/png;base64');
        });

      cy.get('@cards')
        .eq(1)
        .within(() => {
          cy.get('.ngx-card-header').should('contain', 'Task 1').should('contain', 'Python 3');
          cy.get('.ngx-card-section--description p').should('contain', 'A Python 3 script');
          cy.get('.ngx-card-avatar--avatar img').should('have.attr', 'src').and('contain', 'data:image/png;base64');
        });

      cy.get('@cards')
        .eq(2)
        .within(() => {
          cy.get('.ngx-card-header').should('contain', 'Task 2');
          cy.get('.ngx-card-section--description p').should('contain', 'A REST API Action');
          cy.get('.ngx-card-avatar--avatar img').should('have.attr', 'src').and('contain', 'data:image/png;base64');
        });
    });

    it('shows task status', () => {
      cy.get('@cards').eq(0).find('.ngx-card--status').should('have.class', 'inactive');

      cy.get('@cards').eq(1).find('.ngx-card--status').should('have.class', 'success'); // Task 1: valid and enabled

      cy.get('@cards').eq(2).find('.ngx-card--status').should('have.class', 'inactive'); // Task 2: valid and disabled

      cy.get('@cards').eq(3).find('.ngx-card--status').should('have.class', 'error'); // Task 3: invalid and enabled

      cy.get('@cards').eq(4).find('.ngx-card--status').should('have.class', 'error'); // Email Import: invalid and disabled

      cy.get('@cards').eq(5).find('.ngx-card--status').should('have.class', 'success'); // GitLab PR: valid and enabled

      cy.get('@cards').eq(6).find('.ngx-card--status').should('have.class', 'error'); // Slack-Create a Conversation : invalid and enabled
    });

    it('clicking a task opens the task in a drawer', () => {
      cy.setupStubbedSwimlane();

      cy.get('@cards').eq(1).click();
      cy.wait('@GET:task/*');
      cy.wait('@GET:workflow/*');
      cy.get('.stack-tabs a').contains('General').click();
      cy.get('.stacks-sidebar.task-page').as('taskDialog');
      cy.get('@taskDialog').should('exist');
      cy.get('@taskDialog').find('.back-btn').should('exist');

      cy.get('@taskDialog').find('.back-btn').click();
      cy.get('@taskDialog').should('not.exist');
    });

    describe('task filter', () => {
      it('has a search box', () => {
        cy.get('.integration-page--search-box input')
          .should('exist')
          .should('have.attr', 'placeholder', 'Filter by application, applet or task name...');
      });

      it('shows results and can reset using input', () => {
        cy.get('.integration-page--search-box input').type('Email Import');
        cy.get('@groups').should('have.length', 1);
        cy.get('@groups').first().find('.tag').should('contain', '1');
        cy.get('.btn > ngx-icon > .ngx-icon').click();
      });

      it('shows message with no results and reset using message', () => {
        cy.get('.integration-page--search-box input').type('none');
        cy.get('.no-filters-match').should('contain', 'No tasks have been found that match your criteria.');
        cy.get('.no-filters-match--reset-filters > span').click();
        cy.get('@groups').should('have.length', 5);
      });
    });
  });

  describe('task create dialog', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.navigateSwimlane(`/integration`);
      cy.wait('@GET:task/list');
      cy.wait('@GET:app');

      cy.get('.plus-menu-container .ngx-plus-menu--circle').click();
      cy.get('.ngx-plus-menu--icon-1').click();
      cy.wait('@GET:task/actions');
    });

    after(() => {
      cy.get('.ngx-dialog-header .dialog-close > .btn').should('exist').click();
      cy.get('int-new-task-dialog').should('not.exist');
    });

    beforeEach(() => {
      cy.get('.integration-page--new-task-dialog-container').as('dialog');
      cy.get('@dialog').find('ngx-stepper').as('stepper');
    });

    it('shows dialog', () => {
      cy.get('@dialog').should('be.visible');
      cy.get('@dialog').find('.ngx-dialog-header').should('contain', 'Create a Task');
    });

    it('shows stepper', () => {
      cy.get('@stepper').find('ngx-step').should('have.length', 2);
      cy.get('@stepper').find('ngx-step').eq(0).should('have.class', 'ngx-step--active');
    });

    describe('actions list', () => {
      beforeEach(() => {
        cy.get('.actions--container .actions--list-container').find('ngx-card').as('cards');
      });
      it('shows action cards', () => {
        cy.get('@cards').should('have.length', 8);
      });
      it('shows properties for built in action', () => {
        cy.get('@cards').eq(0).as('action');
        cy.get('@action').find('.ngx-card-header').should('contain', 'Email Import');
        cy.get('@action').find('.ngx-card-section--action').find('.ngx-button').as('buttons');
        cy.get('@buttons').should('have.length', 1);
      });

      it('shows properties for forkable action', () => {
        cy.get('@cards').eq(5).as('action');
        cy.get('@action').find('.ngx-card-header').should('contain', 'GitLab Get Issue Comments');
        cy.get('@action').find('.ngx-card-header').should('contain', '1.0.0').should('contain', 'GitLab');
        cy.get('@action').find('.vendor .vendor--name').should('contain', 'GitLab');
        cy.get('@action').find('.ngx-card-section--action').find('.ngx-button').as('buttons');
        cy.get('@buttons').should('have.length', 2);
      });

      describe('opens plugin detail drawer', () => {
        before(() => {
          cy.get('.actions--container .list-container').find('ngx-card').as('cards');
          cy.get('@cards').eq(5).as('action');
          cy.get('@action').find('.ngx-card-section--action').find('.ngx-button').as('buttons');
          cy.get('@buttons').first().click();
          cy.wait('@GET:task/packages/*');
          cy.get('int-plugin-detail').as('drawer').should('be.visible');
        });

        after(() => {
          cy.get('.plugin-details-title-container .ngx-icon').click();
          cy.get('int-plugin-detail').should('not.exist');
        });
      });

      describe('action filter', () => {
        beforeEach(() => {
          cy.get('.actions .search-box ngx-input').as('filter');
          cy.get('@filter').find('input').as('input');
          cy.get('int-vendor-list-filter').as('vendorsList');
          cy.get('.reset-filters').as('resetVendorFilter');
        });

        it('filters and clears', () => {
          cy.get('@input').type('GitLab');
          cy.get('@filter').find('button').should('be.visible');
          cy.get('@cards').should('have.length', 1);
          cy.get('@filter').find('button').click();
          cy.get('@cards').should('have.length', 8);
        });

        it('filters by vendor and clears', () => {
          cy.get('@vendorsList')
            .find('.vendor')
            .first()
            .should('contain', 'All Vendors')
            .should('have.class', 'active');
          cy.get('@vendorsList').find('.vendor').eq(2).as('vendor');
          cy.get('@vendor').should('contain', 'Google').click();
          cy.get('@vendor').should('have.class', 'active');
          cy.get('@cards').should('have.length', 2);
        });

        it('built in actions are classified as Swimlane', () => {
          cy.get('@vendorsList').find('.vendor').last().as('swimlane').should('contain', 'Swimlane');
          cy.get('@swimlane').click();
          cy.get('@cards').should('have.length', 5);
          cy.get('@resetVendorFilter').find('ngx-icon').click();
          cy.get('@cards').should('have.length', 8);
        });
      });

      describe('create and fork', () => {
        afterEach(() => {
          cy.get('@stepper').find('ngx-step').eq(0).click();
        });

        it('shows create step form', () => {
          cy.get('@cards').last().find('.ngx-card-section .ngx-button').eq(0).as('createButton');

          cy.get('@stepper').find('ngx-step').eq(0).should('have.class', 'ngx-step--active');
          cy.get('@createButton').should('contain', 'Create');
          cy.get('@createButton').click();
          cy.get('@stepper').find('ngx-step').eq(1).should('have.class', 'ngx-step--active');
          cy.get('.edit-task-content').should('be.visible');
          cy.get('.ngx-input').should('be.visible');
          cy.get('ngx-select .ngx-select-input-option').should('contain', 'Common Task');
        });

        it('shows fork step form', () => {
          cy.get('@cards').last().find('.ngx-card-section .ngx-button.caret').last().as('buttonDropdown');
          cy.get('@stepper').find('ngx-step').eq(0).should('have.class', 'ngx-step--active');
          cy.get('@buttonDropdown').click();
          cy.get('ngx-dropdown ngx-dropdown-menu')
            .find('ul.vertical-list.actions-list li button')
            .first()
            .should('contain', 'Create');
          cy.get('ngx-dropdown ngx-dropdown-menu')
            .find('ul.vertical-list.actions-list li button')
            .last()
            .should('contain', 'Fork')
            .click();
          cy.get('@stepper').find('ngx-step').eq(1).should('have.class', 'ngx-step--active');
          cy.get('@dialog').find('.ngx-dialog-header').should('contain', 'Create a Forked Task');
          cy.get('.edit-task-content').should('be.visible');
          cy.get('.ngx-input').should('be.visible');
          cy.get('ngx-select .ngx-select-input-option').should('contain', 'Common Task');
        });
      });
    });
  });

  describe('after creating a task', () => {
    const taskName = faker.random.word();

    before(() => {
      cy.setupStubbedSwimlane();
      cy.navigateSwimlane(`/integration`);
      cy.wait('@GET:task/list');
      cy.wait('@GET:app');

      cy.get('.plus-menu-container .ngx-plus-menu--circle').click();
      cy.get('.ngx-plus-menu--icon-1').click();
      cy.wait('@GET:task/actions');
      cy.get('.actions--container .actions--list-container').find('ngx-card').as('cards');
    });

    it('opens the task in a drawer', () => {
      cy.setupStubbedSwimlane();
      cy.get('.integration-page--new-task-dialog-container').as('dialog');
      cy.get('@cards').first().find('.ngx-card-section .ngx-button').as('createButton');
      cy.get('@createButton').click();

      cy.get('.edit-task-content .ngx-input[type=text]').type(`Task ${taskName}`);

      cy.get('@dialog').find('.ngx-dialog-footer .btn-primary').click();
      cy.wait('@POST:task');
      cy.get('@POST:task')
        .its('request.body')
        .should('deep.equal', {
          name: `Task ${taskName}`,
          valid: false,
          action: {
            type: 'email',
            packageDescriptorId: 'acU3_vRBh6XlMgdgO',
            readonly: false
          }
        });
      cy.wait('@GET:task/*');

      cy.get('.stacks-sidebar.task-page')
        .should('exist')
        .within(() => {
          cy.get('.back-btn').should('exist').click();
        });
      cy.get('.stacks-sidebar.task-page', { timeout: 1000 }).should('not.exist');
    });
  });

  describe('after forking a task', () => {
    const taskName = faker.random.word();

    before(() => {
      cy.setupStubbedSwimlane();
      cy.navigateSwimlane(`/integration`);
      cy.wait('@GET:task/list');
      cy.wait('@GET:app');

      cy.get('.plus-menu-container .ngx-plus-menu--circle').click();
      cy.get('.ngx-plus-menu--icon-1').click();
      cy.wait('@GET:task/actions');
    });

    beforeEach(() => {
      cy.get('.integration-page--new-task-dialog-container').as('dialog');
      cy.get('@dialog').find('.actions--container .actions--list-container').as('container');
      cy.get('@container').find('ngx-card').as('cards');
    });

    it('opens the task in a drawer', () => {
      cy.setupStubbedSwimlane();

      cy.get('@cards').eq(5).as('card');

      cy.get('@card').find('.caret').as('buttonDropdown');
      cy.get('@buttonDropdown').click();

      cy.get('@card')
        .find('ngx-dropdown ngx-dropdown-menu')
        .find('ul.vertical-list.actions-list li button')
        .last()
        .should('contain', 'Fork')
        .as('forkButton');

      cy.get('@forkButton').click();
      cy.get('.edit-task-content .ngx-input[type=text]').type(`Task ${taskName}`);
      cy.get('@dialog').find('.ngx-dialog-footer .btn-primary').click();
      cy.wait('@POST:task/fork');

      cy.wait('@GET:task/*');
      cy.get('@POST:task/fork')
        .its('request.body')
        .should('deep.equal', {
          name: `Task ${taskName}`,
          valid: false,
          action: {
            type: 'packaged',
            packageDescriptorId: 'aT1i6Qu9Btfmzh5Q5',
            readonly: true
          }
        });

      cy.get('.stacks-sidebar.task-page')
        .should('exist')
        .within(() => {
          cy.get('.back-btn').should('exist').click();
        });
      cy.get('.stacks-sidebar.task-page', { timeout: 1000 }).should('not.exist');
    });
  });

  describe('create new asset on task', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.navigateSwimlane(`/integration`);
      cy.wait('@GET:task/list');
      cy.wait('@GET:app');
    });
    beforeEach(() => {
      cy.setupStubbedSwimlane();
      cy.get('ngx-card').last().as('slack-task');
      cy.get('@slack-task').click();
      const taskId = 'aChQeM83y98J1Qu2';
      cy.intercept(`/api/task/${taskId}`, {
        fixture: `mocks/swimlane/task/${taskId}/get`
      }).as(`GET:task/${taskId}`);
      cy.intercept('/api/asset', { fixture: 'mocks/swimlane/asset/get-2' }).as('GET:asset');
      cy.wait([`@GET:task/${taskId}`, '@GET:asset']);
    });

    it('Open the task and open Create New Asset dialog', () => {
      cy.get('.stacks-sidebar.task-page').as('taskDialog');
      cy.get('@taskDialog').should('exist');
      cy.get('@taskDialog').find('.back-btn').should('exist');

      cy.get('asset-select').within(() => {
        cy.get('.ngx-select-caret').click();
        cy.get('ngx-select-dropdown').within(() => {
          cy.get('.ngx-select-dropdown-option').first().should('contain', 'Create New Asset').click();
        });
      });

      cy.get('int-new-asset-dialog')
        .should('exist')
        .within(() => {
          cy.get('.dialog-close').find('button').click();
        });
      cy.get('int-new-asset-dialog').should('not.exist');
      cy.get('@taskDialog').find('.back-btn').click();
      cy.get('.modal-dialog').within(() => {
        cy.get('.modal-footer').find('button').first().should('contain', 'Leave').click();
      });
      cy.get('@taskDialog').should('not.exist');
    });

    it('Open the task and open Configure Asset dialog', () => {
      cy.get('.stacks-sidebar.task-page').as('taskDialog');
      cy.get('@taskDialog').should('exist');
      cy.get('@taskDialog').find('.back-btn').should('exist');
      cy.get('asset-select').within(() => {
        cy.get('.ngx-select-caret').click();
        cy.get('ngx-select-dropdown').within(() => {
          cy.get('.ngx-select-dropdown-option').last().click();
        });
      });

      cy.get('[data-cy=configure_asset__btn]').should('contain', 'Configure Asset').click();
      const assetId = 'aNx0_NGBgpphaEZFc';
      cy.intercept(`/api/asset/${assetId}`, {
        fixture: `mocks/swimlane/asset/${assetId}/get`
      }).as(`GET:asset/${assetId}`);
      cy.wait(`@GET:asset/${assetId}`);
      cy.get('ngx-dialog')
        .should('exist')
        .within(() => {
          cy.get('ngx-large-format-dialog-header-action').find('button').click();
        });
      cy.get('@taskDialog').find('.back-btn').click();
      cy.get('.modal-dialog').within(() => {
        cy.get('.modal-footer').find('button').first().should('contain', 'Leave').click();
      });

      cy.get('@taskDialog').should('not.exist');
    });
  });
});

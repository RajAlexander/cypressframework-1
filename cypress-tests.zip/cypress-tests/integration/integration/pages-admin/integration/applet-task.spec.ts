describe('Task Page - Applet Task', () => {
  const appletId = 'a3nUjzwG9swHd8lS9';
  const taskId = 'aVrRjq5QA0l_rO9Mr';

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.navigateSwimlane(`/integration/${appletId}/applet-task/${taskId}`);
    cy.wait(`@GET:task/options`);
    cy.wait(`@GET:task/${taskId}`);
    cy.wait(`@GET:applet/${appletId}`);
  });

  describe('general tab', () => {
    beforeEach(() => {
      cy.get('.tab-pane.active').as('active-pane');
    });

    it('shows name and description inputs', () => {
      cy.get('#name')
        .should('exist')
        .should('have.attr', 'placeholder', 'Enter a task name')
        .ngxGetValue()
        .should('eq', 'Applet Task Name');
      cy.get('#description')
        .should('exist')
        .should('have.attr', 'placeholder', 'Enter description for the task')
        .ngxGetValue()
        .should('eq', '');
    });

    it('shows info', () => {
      cy.get('label').contains('Task Parent').next('p').should('contain', 'Applet: Test Applet');
      cy.get('label').contains('Task Type').next('p').should('contain', 'Scripts: Python 3.6');
    });

    it('does not show integration ROI Calculation Metrics', () => {
      cy.get('@active-pane').should('not.contain', 'Integration ROI Calculation Metrics');
    });

    it('has disable toggle', () => {
      cy.get('.toggle').find('input').ngxGetValue().should('eq', 'on');
    });
  });

  describe('configuration tab', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.get('.stack-tabs a').contains('Configuration').click();
    });

    it('has code input', () => {
      cy.get('.action-script-editor').find('.CodeMirror').should('exist');
    });

    describe('input parameters', () => {
      before('displays inputs section', () => {
        cy.get('div.tab-pane.active')
          .find('.editor-tester a')
          .contains(/^\s*Inputs\s*$/)
          .click();
        cy.get('.task-test-container task-test').should('exist');
      });

      it('adds new input parameter of type keystore', () => {
        cy.get('.editor-tester span a').contains('Add Parameter').should('exist').click();
        cy.get('.ui-select-container a').eq(2).click();
        cy.get('ul.ui-select-choices li.ui-select-choices-group ul li').contains('Key').click();
      });

      it('adds new input parameter of type asset library', () => {
        cy.get('.editor-tester span a').contains('Add Parameter').should('exist').click();
        cy.get('.ui-select-container a').last().click();
        cy.get('ul.ui-select-choices li.ui-select-choices-group ul li').contains('Asset').click();
      });

      it('shows mapped keystore input on debugger and is disabled', () => {
        cy.get('div.tab-pane.active')
          .find('.editor-tester a')
          .contains(/^\s*Debugger\s*$/)
          .click();
        cy.get('.debugger-section.inputs button')
          .contains(/^\s*Input Values\s*$/)
          .click();
        cy.get('.inputs-table-row')
          .first()
          .should('be.visible')
          .within(() => {
            cy.get('ngx-input input').should('have.attr', 'disabled');
            cy.get('ngx-input-suffix').should('exist');
            cy.get('ngx-icon').should('exist').should('have.attr', 'fonticon', 'key');
          });
      });

      it('shows mapped asset library input on debugger and is disabled', () => {
        cy.get('.inputs-table-row')
          .last()
          .should('be.visible')
          .within(() => {
            cy.get('ngx-input input').should('have.attr', 'disabled');
            cy.get('ngx-input-suffix').should('exist');
            cy.get('ngx-icon').should('exist').should('have.attr', 'fonticon', 'assets');
          });
      });

      it('removes recently added input parameters', () => {
        cy.get('div.tab-pane.active')
          .find('.editor-tester a')
          .contains(/^\s*Inputs\s*$/)
          .click();
        cy.get('.ui-select-container').should('exist');
        cy.get('a.ngx-trash').each($but => {
          cy.wrap($but).click();
        });
        cy.get('.ui-select-container').should('not.exist');
      });
    });

    describe('task debugger', () => {
      before(() => {
        cy.get('.tab-pane.active')
          .as('active-pane')
          .find('.editor-tester a')
          .contains(/^\s*Debugger\s*$/)
          .click();
      });

      it('shows debugger', () => {
        cy.get('.task-test-container task-test').should('exist');
      });

      it('does not show record selector', () => {
        cy.get('.task-test-container record-select').should('not.exist');
        // TODO: test record selector
      });

      it('shows debugger settings', () => {
        cy.get('.debugger-section.inputs button')
          .contains(/^\s*Settings\s*$/)
          .click();
        cy.get('.bypass-section-toggle input').should('exist');
      });

      it('shows debugged task output tab', () => {
        cy.get('.debugger-section.results button')
          .contains(/^\s*Output\s*$/)
          .click();
        cy.get('ngx-tab[label="Output"')
          .should('exist')
          .within(() => {
            cy.get('button span').contains('Copy Output').should('exist');
          });
      });

      it('shows discover parameters tab on debugger', () => {
        cy.get('.debugger-section.results button')
          .contains(/^\s*Discovered Parameters\s*$/)
          .click();
        cy.get('ngx-tab[label="Discovered Parameters"')
          .should('exist')
          .within(() => {
            cy.get('button span').contains('Add Selected Parameters').should('exist');
          });
      });
    });
  });

  describe('output parameters tab', () => {
    before(() => {
      cy.get('.stack-tabs a').contains('Parameters').click();
    });

    beforeEach(() => {
      cy.get('.tab-pane.active').as('active-pane');
    });

    it('has code input', () => {
      cy.get('@active-pane').within(() => {
        cy.get('h2').should('contain', '4 Output Parameters Defined');
        // TODO: test adding and removing parameters
      });
    });

    it('has discover parameters', () => {
      cy.get('output-variables button').should('contain', 'Discover Parameters');
      // TODO: test discover parameters
    });
  });

  describe('outputs tab', () => {
    before(() => {
      cy.get('.stack-tabs a').contains('Outputs').click();
    });

    beforeEach(() => {
      cy.get('.tab-pane.active').as('active-pane');
    });

    it('has output types', () => {
      cy.get('fieldset.output-types').should('exist');
      cy.get('.output-types .output-types__type').should('have.length', 5);

      cy.get('.output-types .output-types__type').within(() => {
        cy.root().eq(0).should('contain', 'Update Current Record').should('contain', '1x');
        cy.root().eq(1).should('contain', 'Create/Update Records').should('contain', '∞');
        cy.root().eq(2).should('contain', 'Send an Email').should('contain', '∞');
        cy.root().eq(3).should('contain', 'Save to File').should('contain', '∞');
        cy.root().eq(4).should('contain', 'Execute Another Task').should('contain', '∞');
      });
    });

    describe('Update Current Record', () => {
      before(() => {
        cy.get('.output-types .output-types__set-field-value').click();
        cy.get('.default > .btn').click();
      });

      it('adds a Update Current Record output', () => {
        cy.get('@active-pane').find('section').should('contain', 'Update Current Record');
      });

      it('output type is disabled', () => {
        cy.get('.output-types .output-types__set-field-value').should('have.class', 'disabled');
      });

      it('can remove Update Current Record output', () => {
        cy.get('@active-pane').find('section .btn > ngx-icon').click();
        cy.get('.ngx-dialog-footer > .btn-primary').click();
        cy.get('.output-types .output-types__set-field-value').should('not.have.class', 'disabled');
      });
    });

    describe('Create/Update Records', () => {
      before(() => {
        cy.get('.output-types .output-types__insert-update-record').click();
        cy.get('.app-list > :nth-child(3)').click();
        cy.get('.arrow-icon > .ngx-icon').click();
        cy.get('.default > .btn').click();
      });

      it('adds a Create/Update Records output', () => {
        cy.get('@active-pane')
          .find('section')
          .should('contain', 'Create/Update Records')
          .should('contain', 'Application 1');
      });

      it('can remove Send an Email output', () => {
        cy.get('@active-pane').find('section .btn > ngx-icon').click();
        cy.get('.ngx-dialog-footer > .btn-primary').click();
      });
    });

    describe('Send an Email', () => {
      before(() => {
        cy.get('.output-types .output-types__email').click();
      });

      it('adds a Send an Email output', () => {
        cy.get('@active-pane').find('section').should('contain', 'Send an Email');
      });

      it('can remove Send an Email output', () => {
        cy.get('@active-pane').find('section .btn > ngx-icon').click();
        cy.get('.ngx-dialog-footer > .btn-primary').click();
      });
    });

    describe('Save to File', () => {
      before(() => {
        cy.get('.output-types .output-types__save-to-file').click();
      });

      it('adds a Save to File output', () => {
        cy.get('@active-pane').find('section').should('contain', 'Save to File');
      });

      it('can remove Save to File output', () => {
        cy.get('@active-pane').find('section .btn > ngx-icon').click();
        cy.get('.ngx-dialog-footer > .btn-primary').click();
      });
    });

    describe('Execute Another Task', () => {
      before(() => {
        cy.get('.output-types .output-types__referential-task').click();
      });

      it('adds a Execute Another Task output', () => {
        cy.get('@active-pane').find('section').should('contain', 'Execute Another Task');
        // TODO: verify task list
      });

      it('can remove Save to File output', () => {
        cy.get('@active-pane').find('section .btn > ngx-icon').click();
        cy.get('.ngx-dialog-footer > .btn-primary').click();
      });
    });
  });

  describe('triggers tab', () => {
    before(() => {
      cy.get('.stack-tabs a').contains('Triggers').click();
    });

    beforeEach(() => {
      cy.get('.tab-pane.active').as('active-pane');
    });

    it('has automatic triggers', () => {
      cy.get('@active-pane').within(() => {
        cy.get('.nav.nav-tabs a').contains('Automatic').click();
        cy.get('.tab-pane.active').should('contain', 'No Triggers');
      });
    });

    it('has Workflow triggers', () => {
      cy.get('@active-pane').within(() => {
        cy.get('.nav.nav-tabs a').contains('Workflow').click();
        cy.get('.tab-pane.active').should('contain', 'No related actions');
        cy.get('.tab-pane.active a')
          .should('contain', 'Add / Edit Workflow')
          .should('have.attr', 'href', `/applet-workflow`);
      });
    });

    it('has Manual triggers', () => {
      cy.get('@active-pane').within(() => {
        cy.get('.nav.nav-tabs a').contains('Manual').click();
        cy.get('.tab-pane.active').should('contain', 'No buttons defined');
        cy.get('.tab-pane.active a')
          .should('contain', 'Open Applet Builder')
          .should('have.attr', 'href', `/applet-builder/${appletId}`);
      });
    });
  });
});

describe.skip('Orchestration Plugins', { tags: ['#bug'] }, () => {
  const MOCK_PLUGIN = {};

  before(() => {
    cy.login();

    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('DynamicOrchestration');
    cy.intercept('POST', '/orchestration/api/v1/plugin', {
      body: MOCK_PLUGIN,
      statusCode: 201
    });
    cy.intercept('POST', '/orchestration/api/v1/plugin/rql', {
      body: { items: [] },
      statusCode: 200
    }).as('getplugins');

    cy.navigateSwimlane('/orchestration/plugins');
    cy.wait('@getEnabledFlags');
  });

  describe('No plugins', () => {
    it('No plugins dialog displays on page', () => {
      cy.get('.new-plugin-icon').should('exist');
      cy.get('.new-plugin-header').should('contain', 'Start by adding your first plugin');
      cy.get('.new-plugin-content').should(
        'contain',
        "Plugins are distributable packages that provide integration functionality. They contain sensors, as well as actions that can be called from a workflow or from a playbook's actions. Get started here to explore the benefits of plugins."
      );
      cy.get('.new-plugin-illustration').should('exist');
      cy.get('.ngx-plus-menu--circle-container').should('exist').should('have.css', 'cursor', 'pointer');
    });
  });

  describe('With Plugins', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.setMockFeatureFlag('DynamicOrchestration');
      cy.intercept('POST', '/orchestration/api/v1/plugin/rql', {
        fixture: 'integration/dynamic-orchestration/get-plugins.json',
        statusCode: 200
      }).as('getplugins');
      cy.reloadSwimlane();
      cy.wait('@getEnabledFlags');
    });

    beforeEach(() => {
      cy.get('.plugin-section').as('plugin-section');
    });

    it('Displays the groups', () => {
      cy.get('@plugin-section').should('exist');
      cy.get('.plugin-section-header > div').eq(0).should('contain.text', 'CaliDog');
      cy.get('.plugin-section-header > div').eq(1).should('contain.text', '1');
      cy.get('.plugin-section-header > div').eq(2).should('contain.text', 'Plugin'); // TODO verify with design this is the right language
    });

    it('Displays the alphabet search', () => {
      cy.get('do-plugin-alphabet-nav').should('exist');
    });
  });

  describe('Plugin item', () => {
    describe('Plugin details drawer', () => {
      it('clicking view details for plugin opens details drawer', () => {
        cy.get('ngx-card').eq(0).click();

        cy.get('.ngx-drawer-content').should('exist');
        cy.get('.plugin-details-content').should('exist');
      });

      after(() => {
        cy.get('.plugin-details-title img').click();
      });
    });
  });

  describe('Plugin Upload Dialog', () => {
    before(() => {
      cy.get('.ngx-plus-menu--circle-container ngx-icon').click();
      cy.get('.ngx-plus-menu--icon.ngx-plus-menu--icon-0').click();
      cy.fixture('/integration/dynamic-orchestration/test-plugin.plugin').then(fileContent => {
        cy.get('#do-drag-and-drop--input').attachFile({
          fileContent,
          fileName: 'test-plugin.plugin',
          mimeType: 'text/plain',
          encoding: 'utf-8'
        });
      });
    });

    it('should open dialog', () => {
      cy.get('do-plugin-upload-dialog').should('exist');
    });

    it('should have completed one upload', () => {
      cy.get('do-plugin-upload-status').should('exist');
    });

    describe('reset', () => {
      it('should reset dialog and re-upload', () => {
        cy.get('.reset-action').click();
        cy.get('plugin-upload-status').should('not.exist');
      });
    });

    describe('close', () => {
      before(() => {
        cy.fixture('/integration/dynamic-orchestration/test-plugin.plugin').then(fileContent => {
          cy.get('#do-drag-and-drop--input').attachFile({
            fileContent,
            fileName: 'test-plugin.plugin',
            mimeType: 'text/plain',
            encoding: 'utf-8'
          });
        });
      });

      it('should close dialog', () => {
        cy.get('.close-action').should('exist').click();
        cy.get('plugin-upload-dialog').should('not.exist');
      });
    });
  });
});

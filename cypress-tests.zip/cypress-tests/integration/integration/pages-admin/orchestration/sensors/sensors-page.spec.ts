describe.skip('Orchestration Sensors', { tags: ['#bug'] }, () => {
  before(() => {
    cy.login();

    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('DynamicOrchestration');
    cy.intercept('POST', '/orchestration/api/v1/sensor/rql', { items: [] }).as('getSensors');

    cy.navigateSwimlane('/orchestration/eventstreams');
    cy.wait('@getEnabledFlags');
  });

  describe('No sensors', () => {
    it('No sensor dialog displays on page', () => {
      cy.get('.do-page-no-elements__icon').should('exist');
      cy.get('.do-page-no-elements__header').should('contain', 'Start by adding your first event stream');
      cy.get('.do-page-no-elements__content').should(
        'contain',
        'Sensors listen for events sent from a technology or service'
      );
      cy.get('.do-page-no-elements__illustration').should('exist');
    });
  });

  describe('With Sensors', () => {
    before(() => {
      // add mock sensor data
      cy.setupStubbedSwimlane();
      cy.setMockFeatureFlag('DynamicOrchestration');
      cy.intercept('POST', '/orchestration/api/v1/sensor/rql', {
        fixture: 'integration/dynamic-orchestration/get-sensors.json'
      }).as('getSensors');
      cy.intercept('POST', '/orchestration/api/v1/plugin/rql', {
        fixture: 'integration/dynamic-orchestration/get-plugins.json'
      }).as('getPlugins');
      cy.reloadSwimlane();
      cy.wait('@getEnabledFlags');
      cy.wait('@getSensors');
      cy.wait('@getPlugins');
    });

    describe('Creating a Sensor', () => {
      before(() => {
        cy.get('.do-page__add-button').click();
      });

      it('Opens the dialog', () => {
        cy.get('do-sensor-create-dialog').should('exist');
      });

      it('Lists all sensor types', () => {
        cy.get('.do-modal-dialog__item-selection-list ngx-card').should('have.length', 6);
      });

      it('Filtering works by plugin name', () => {
        cy.get('.do-modal-dialog__item-selection-search-bar .ngx-input-box').focus().clear().type('email');
        cy.get('.do-modal-dialog__item-selection-list ngx-card').should('have.length', 1);
        cy.get('.do-modal-dialog__item-selection-search-bar .ngx-input-box').focus().clear();
      });

      it('Filtering works by sensor name', () => {
        cy.get('.do-modal-dialog__item-selection-search-bar .ngx-input-box').focus().clear().type('json');
        cy.get('.do-modal-dialog__item-selection-list ngx-card').should('have.length', 1);
        cy.get('.do-modal-dialog__item-selection-search-bar .ngx-input-box').focus().clear();
      });

      it('Clear search input resets search and shows all sensors', () => {
        cy.get('.do-modal-dialog__item-selection-search-bar .ngx-input-box').focus().type('json');
        cy.get('.do-modal-dialog__item-selection-search-bar .ngx-input ngx-input-suffix').click();
        cy.get('.do-modal-dialog__item-selection-list ngx-card').should('have.length', 6);
      });

      it('Selecting a sensor type goes to step 2', () => {
        cy.get('.do-modal-dialog__item-selection-list ngx-card:first').click();
        cy.get('.do-modal-dialog__item-selection-list').should('not.exist');
        cy.get('.do-dialog-details-form__inputs-wrapper').should('exist');
        cy.get('.ngx-large-format-dialog-footer button').should('contain', 'Create');
        cy.get('.ngx-large-format-dialog-footer button').should('be.disabled');
      });

      it('Clicking the choose a different sensor button goes back to step 1', () => {
        cy.get('.ngx-card--outline-text .inner-text').click();
        cy.get('.do-modal-dialog__item-selection-list').should('exist');
        cy.get('.do-dialog-details-form__inputs-wrapper').should('not.exist');
        cy.get('.do-modal-dialog__item-selection-list ngx-card:first').click();
      });

      after(() => {
        cy.get('.ngx-large-format-dialog-header-action__button').click();
      });
    });

    describe('Sensor item', () => {
      beforeEach(() => {
        cy.get('ngx-card').eq(0).as('sensor-item');
        cy.get('ngx-card').eq(1).as('sensor-item-disabled');
      });

      describe('Enabling and Disabling a Sensor', () => {
        it('Disable a sensor', () => {
          cy.intercept('PUT', '**/sensor/**', {}).as('updateSensors');
          // sensor starts enabled
          cy.get('@sensor-item').as('sensor').find('.ngx-toggle-input').should('be.checked');

          // disable sensor
          cy.get('@sensor').find('ngx-toggle').click();
          cy.get('@sensor').find('.ngx-toggle-input').should('not.be.checked');

          cy.wait('@updateSensors').then(xhr => {
            assert.equal(xhr.request.body.meta.enabled, false);
          });

          // status icon indicates disabled
          cy.get('@sensor').find('.ngx-card--status').should('not.have.class', 'sensor-enabled');
        });

        it('Enable a sensor', () => {
          cy.intercept('PUT', '**/sensor/**', {}).as('updateSensors');

          // sensor starts disabled
          cy.get('@sensor-item-disabled').as('sensor').find('.ngx-toggle-input').should('not.be.checked');

          // enable sensor
          cy.get('@sensor').find('ngx-toggle').click();
          cy.get('@sensor').find('.ngx-toggle-input').should('be.checked');

          cy.wait('@updateSensors').then(xhr => {
            assert.equal(xhr.request.body.meta.enabled, true);
          });
        });
      });

      describe('Editing a Sensor', () => {
        before(() => {
          cy.get('ngx-card').eq(0).find('.ngx-card-title').click();
        });

        it('opens the sensor edit dialog', () => {
          cy.get('do-edit-sensor-dialog').as('edit-dialog');
          cy.get('@edit-dialog').should('exist');

          cy.get('@edit-dialog').find('.edit-dialog-header-label').should('contain', 'Sensor Management');
        });

        it('Shows the sensor details', () => {
          cy.get('do-edit-sensor-dialog').as('edit-dialog');
          cy.get('@edit-dialog').find('ngx-card').should('exist');
        });

        it('Shows the logs and settings tabs', () => {
          cy.get('do-edit-sensor-dialog').as('edit-dialog');
          cy.get('@edit-dialog').find('.ngx-tabs-list .ngx-tab').should('have.length', 2);

          // The logs tab is active
          cy.get('@edit-dialog').find('.ngx-tabs-list .ngx-tab.active').should('contain', 'Logs');
        });

        describe('Sensor form', () => {
          before(() => {
            cy.get('do-edit-sensor-dialog').as('edit-dialog');
            cy.get('@edit-dialog').find('.ngx-tabs-list .ngx-tab').contains('Settings').click();
          });

          it('Shows the sensor form', () => {
            cy.get('do-edit-sensor-dialog').as('edit-dialog');
            cy.get('@edit-dialog').find('do-sensor-form').should('exist');
          });

          it('Save button is disabled until form is valid & dirty', () => {
            cy.get('do-edit-sensor-dialog').as('edit-dialog');
            cy.get('@edit-dialog').find('do-sensor-form').as('sensorForm');

            cy.get('@edit-dialog').find('.sensor-dialog--footer button').as('saveButton');
            cy.get('@saveButton').should('have.attr', 'disabled');

            cy.get('.ngx-input__lock-toggle').click();

            // Dirty
            cy.get('@sensorForm').find('ngx-input[label="Sensor Name"]').find('input').type('hello');
            cy.get('@saveButton').should('not.have.attr', 'disabled');

            // Invalid
            cy.get('@sensorForm').find('ngx-input[label="Sensor Name"]').find('input').clear();
            cy.get('@saveButton').should('have.attr', 'disabled');
          });

          it('Saving updates the sensor', () => {
            cy.get('do-edit-sensor-dialog').as('edit-dialog');
            cy.get('@edit-dialog').find('do-sensor-form').as('sensorForm');

            cy.get('@edit-dialog').find('.sensor-dialog--footer button').as('saveButton');

            cy.intercept('PUT', 'orchestration/api/v1/sensor/sensor1', {
              id: 'sensor1',
              meta: {
                agentId: '5dc56a0fdf2064064e84bf91',
                plugin: {
                  name: 'loadtest',
                  checksum: '07b93525966447c96ccdb699f3b19923e15082d4'
                },
                description: 'a sensor 1',
                enabled: true,
                inputs: { numEvents: '1', interval: '2123123131' },
                name: 'NewName',
                title: 'My Sensor 1',
                workerId: '5d965fdac30614bd47828e16'
              },
              sensor: {
                description: 'Generates events at an interval',
                entrypoint: 'eventGenerator:EventGenerator',
                events: { event: { type: 'string' } },
                inputs: {
                  type: 'object',
                  properties: {},
                  required: ['numEvents']
                },
                name: 'eventGenerator',
                schema: 'sensor/1',
                title: 'Event Generator',
                type: 'canonical'
              }
            }).as('updateSensor');

            cy.get('@sensorForm').find('ngx-input[label="Sensor Name"]').find('input').type('NewName');
            cy.get('@saveButton').click();

            cy.wait('@updateSensor');

            cy.get('@edit-dialog').should('not.exist');
          });
        });
      });

      describe('Deleting a Sensor', () => {
        it('context menu has option for delete sensor', () => {
          cy.get('@sensor-item').find('ngx-dropdown').click();
          cy.get('@sensor-item').find('.ngx-dropdown-menu').should('contain.text', 'Delete Event Stream');
        });

        it('clicking delete sensor option brings up confirm dialog', () => {
          cy.get('@sensor-item').find('.ngx-dropdown-menu').click();

          cy.get('.ngx-alert-dialog').should('contain.text', 'Are you sure you want to delete the event stream');
        });

        it('clicking ok on confirm dialog removes sensor from page', () => {
          cy.intercept('DELETE', 'orchestration/api/v1/sensor/sensor1', {}).as('updateSensors');

          cy.get('.ngx-alert-dialog').find('button.btn-primary').contains('Ok').click();
          cy.wait('@updateSensors');

          cy.get('ngx-notification').should('contain.text', 'Event Stream successfully deleted.');
          cy.get('ngx-card').should('have.length', 2);
        });
      });
    });
  });
});

describe('playbook button', () => {
  const cleanAppId = 'a8k1c3QLv5u8kFHLM';
  before(() => {
    cy.login();

    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('DynamicOrchestration');
    cy.navigateSwimlane(`/app-builder/${cleanAppId}`);
  });

  beforeEach(() => {
    cy.get('.content-area').as('contentArea');
  });

  describe('playbook button editor', () => {
    beforeEach(() => {
      cy.get('@contentArea').find('.builder-target').find('fieldset').eq(0).as('formLayout');
      cy.get('@formLayout').find('.builder-target').as('builderTarget');
      cy.get('@contentArea').find('.builder-source').find('.ngx-section').eq(1).as('layoutItems');
      cy.get('@contentArea').find('.settings-panel').as('settingsPanel');
      cy.get('@settingsPanel').find('ngx-tabs .ngx-tab').eq(1).as('fieldPropertySettings');
    });

    it('drags and drops playbook button field', () => {
      cy.get('@layoutItems').find('.builder-source-item').eq(4).as('playbookButtonField');
      cy.dragAndDrop('@playbookButtonField', '@builderTarget');
    });

    it('opens playbook button field settings', () => {
      cy.setupStubbedSwimlane();
      cy.intercept('POST', '/orchestration/api/v1/playbook/rql', {
        fixture: 'integration/dynamic-orchestration/get-playbooks.json'
      }).as('getPlaybooks');
      cy.intercept('GET', '/api/orchestrationtask/**', '').as('getOrchestrationTask');
      cy.get('@formLayout')
        .find('.builder-target-item')
        .first()
        .within($targetItem => {
          cy.wrap($targetItem).click();
          cy.wait('@getPlaybooks');
          cy.wait('@getOrchestrationTask');
          cy.wrap($targetItem).should('have.class', 'active');
          cy.get('@fieldPropertySettings').should('have.class', 'active');
        });
    });

    it('checks button label and playbook inputs', () => {
      const playbookName = 'playbook_test_1';
      cy.get('@settingsPanel').within(() => {
        cy.get('[data-cy=record-action-trigger_configure-btn]')
          .contains(/^\s*Configure\s*$/)
          .should('be.disabled');

        cy.get('[data-cy=record-action-trigger_btn-label-input]')
          .should('exist')
          .should('have.attr', 'label', 'Button Label')
          .ngxFill('My cool record action trigger');

        cy.get('[data-cy=record-action-trigger_playbook-dropdown]')
          .should('exist')
          .should('have.attr', 'placeholder', 'Choose Playbook')
          .ngxOpen()
          .select(playbookName);
      });
    });

    it('opens playbook inputs mapper dialog', () => {
      cy.get('@settingsPanel')
        .find('[data-cy=record-action-trigger_configure-btn]')
        .contains(/^\s*Configure\s*$/)
        .should('not.be.disabled')
        .click();
      cy.get('do-record-trigger-inputs-mapper-dialog').as('mapperDialog').should('be.visible');
      cy.get('@mapperDialog').within(() => {
        cy.get('.no-inputs-available').should(
          'contain',
          'There are no playbook inputs to map. To use playbook inputs, configure them in your playbook input manager.'
        );
        cy.get('[data-cy=do-record-trigger-inputs-mapper-dialog__apply-btn]').should('not.exist');
        cy.get('[data-cy=do-record-trigger-inputs-mapper-dialog__close-btn]')
          .should('exist')
          .should('contain', 'Close')
          .click();
      });
    });

    // Adding a second button
    it('drags and drops a second playbook button field', () => {
      cy.get('@layoutItems').find('.builder-source-item').eq(4).as('playbookButtonField');
      cy.dragAndDrop('@playbookButtonField', '@builderTarget');
    });

    it('opens second playbook button field settings', () => {
      cy.intercept('GET', '/api/orchestrationtask/**', '').as('getOrchestrationTask');
      cy.get('@formLayout')
        .find('.builder-target-item')
        .last()
        .within($targetItem => {
          cy.wrap($targetItem).click();
          cy.wait('@getOrchestrationTask');
          cy.wrap($targetItem).should('have.class', 'active');
          cy.get('@fieldPropertySettings').should('have.class', 'active');
        });
    });

    it('checks second button label and playbook inputs', () => {
      const playbookName = 'playbook_test_2';
      cy.get('@settingsPanel').within(() => {
        cy.get('[data-cy=record-action-trigger_configure-btn]')
          .contains(/^\s*Configure\s*$/)
          .should('be.disabled');

        cy.get('[data-cy=record-action-trigger_btn-label-input]')
          .should('exist')
          .should('have.attr', 'label', 'Button Label')
          .ngxFill('My awesome record action trigger');

        cy.get('[data-cy=record-action-trigger_playbook-dropdown]')
          .should('exist')
          .should('have.attr', 'placeholder', 'Choose Playbook')
          .ngxOpen()
          .select(playbookName);
      });
    });

    it('opens second playbook inputs mapper dialog', () => {
      cy.setupStubbedSwimlane();
      cy.get('@settingsPanel')
        .find('[data-cy=record-action-trigger_configure-btn]')
        .contains(/^\s*Configure\s*$/)
        .should('not.be.disabled')
        .click();
      cy.get('do-record-trigger-inputs-mapper-dialog').as('mapperDialog').should('be.visible');
      cy.get('@mapperDialog').within(() => {
        cy.get('.inputs-available').should('contain', 'Available Inputs');
        cy.get('[data-cy=do-record-trigger-inputs-mapper-dialog__apply-btn]').should('exist');
        cy.get('[data-cy=do-record-trigger-inputs-mapper-dialog__close-btn]')
          .should('exist')
          .should('contain', 'Close')
          .click();
      });
    });

    it('updates label and playbook inputs when switching between fields', () => {
      cy.setupStubbedSwimlane();
      cy.intercept('GET', '/api/orchestrationtask/**', '').as('getOrchestrationTask');
      const playbook1Name = 'playbook_test_1';
      const button1Label = 'My cool record action trigger';
      const playbook2Name = 'playbook_test_2';
      const button2Label = 'My awesome record action trigger';

      cy.get('@formLayout').find('.builder-target-item').as('playbookButtonFields');
      cy.get('@playbookButtonFields').first().click();
      cy.wait('@getOrchestrationTask');
      cy.wait(1000);
      cy.get('@settingsPanel').within(() => {
        cy.get('[data-cy=record-action-trigger_btn-label-input]').ngxGetValue().should('contain', button1Label);
        cy.get('[data-cy=record-action-trigger_playbook-dropdown]').ngxGetValue().should('contain', playbook1Name);
      });
      cy.get('@playbookButtonFields').last().click();
      cy.wait('@getOrchestrationTask');
      cy.wait(1000);
      cy.get('@settingsPanel').within(() => {
        cy.get('[data-cy=record-action-trigger_btn-label-input]').ngxGetValue().should('contain', button2Label);
        cy.get('[data-cy=record-action-trigger_playbook-dropdown]').ngxGetValue().should('contain', playbook2Name);
      });
    });

    it('removes the two playbook button fields', () => {
      cy.get('@formLayout')
        .find('.builder-target-item')
        .each($targetItem => {
          cy.wrap($targetItem).trigger('mouseover');
          cy.wrap($targetItem).find('.drop-in').should('be.visible');
          cy.wrap($targetItem)
            .find('.drop-in')
            .within(() => {
              cy.get('.ngx-icon').first().click({ force: true });
            });
        });
      cy.get('@formLayout').find('.builder-target-item').should('have.length', 0);
    });

    describe('invalid playbook button', () => {
      beforeEach(() => {
        cy.get('@contentArea').find('.builder-target').find('fieldset').eq(0).as('formLayout');
        cy.get('@formLayout').find('.builder-target').as('builderTarget');
        cy.get('@contentArea').find('.builder-source').find('.ngx-section').eq(1).as('layoutItems');
        cy.get('@contentArea').find('.settings-panel').as('settingsPanel');
        cy.get('@settingsPanel').find('ngx-tabs .ngx-tab').eq(1).as('fieldPropertySettings');
      });

      it('drags and drops playbook button field', () => {
        cy.get('@layoutItems').find('.builder-source-item').eq(4).as('playbookButtonField');
        cy.dragAndDrop('@playbookButtonField', '@builderTarget');
      });

      it('opens playbook button field settings', () => {
        cy.setupStubbedSwimlane();
        cy.intercept('POST', '/orchestration/api/v1/playbook/rql', {
          fixture: 'integration/dynamic-orchestration/get-playbooks.json'
        }).as('getPlaybooks');
        cy.intercept('GET', '/api/orchestrationtask/**', '').as('getOrchestrationTask');
        cy.get('@formLayout')
          .find('.builder-target-item')
          .first()
          .within($targetItem => {
            cy.wrap($targetItem).click();
            cy.wait('@getPlaybooks');
            cy.wait('@getOrchestrationTask');
            cy.wrap($targetItem).should('have.class', 'active');
            cy.get('@fieldPropertySettings').should('have.class', 'active');
          });
      });

      it('sets empty button label', () => {
        cy.get('@settingsPanel').within(() => {
          cy.get('[data-cy=record-action-trigger_configure-btn]')
            .contains(/^\s*Configure\s*$/)
            .should('be.disabled');

          cy.get('[data-cy=record-action-trigger_btn-label-input]')
            .should('exist')
            .should('have.attr', 'label', 'Button Label')
            .ngxFill('');
        });
      });

      it('display nag becuase of invalid button label and no playbook selected', () => {
        cy.get('ngx-toolbar-content state-save-button').click();
        it('shows nag', () => {
          cy.get('.ngx-nag-content').within(() => {
            cy.get('ngx-toolbar-title > h2').should('contain', 'One error found in this application');
            cy.get('ngx-icon[fontIcon="arrow-down"]').click({ force: true });
            cy.get('.ngx-nag-body').should('be.visible');
          });
        });
      });

      it('sets valid button label', () => {
        cy.get('@settingsPanel').within(() => {
          cy.get('[data-cy=record-action-trigger_configure-btn]')
            .contains(/^\s*Configure\s*$/)
            .should('be.disabled');

          cy.get('[data-cy=record-action-trigger_btn-label-input]')
            .should('exist')
            .should('have.attr', 'label', 'Button Label')
            .ngxFill('My valid button');
        });
        // wait for validation to take place
        cy.wait(1000);
      });

      it('display nag becuase of playbook was not selected', () => {
        cy.get('ngx-toolbar-content state-save-button').click();
        it('shows nag', () => {
          cy.get('.ngx-nag-content').within(() => {
            cy.get('ngx-toolbar-title > h2').should('contain', 'One error found in this application');
            cy.get('ngx-icon[fontIcon="arrow-down"]').click({ force: true });
            cy.get('.ngx-nag-body').should('be.visible');
          });
        });
      });

      it('selects playbook', () => {
        const playbookName = 'playbook_test_1';
        cy.get('@settingsPanel').within(() => {
          cy.get('[data-cy=record-action-trigger_configure-btn]')
            .contains(/^\s*Configure\s*$/)
            .should('be.disabled');

          cy.get('[data-cy=record-action-trigger_playbook-dropdown]')
            .should('exist')
            .should('have.attr', 'placeholder', 'Choose Playbook')
            .ngxOpen()
            .select(playbookName);
        });
        // wait for validation to take place
        cy.wait(1000);
      });

      it('should not display nag since playbook button is valid', () => {
        cy.get('.ngx-nag-content').should('not.exist');
      });

      it('removes the playbook button', () => {
        cy.get('@formLayout')
          .find('.builder-target-item')
          .each($targetItem => {
            cy.wrap($targetItem).trigger('mouseover');
            cy.wrap($targetItem).find('.drop-in').should('be.visible');
            cy.wrap($targetItem)
              .find('.drop-in')
              .within(() => {
                cy.get('.ngx-icon').first().click({ force: true });
              });
          });
        cy.get('@formLayout').find('.builder-target-item').should('have.length', 0);
      });
    });
  });
});

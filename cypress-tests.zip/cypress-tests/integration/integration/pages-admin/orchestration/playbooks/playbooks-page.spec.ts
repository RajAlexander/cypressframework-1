/// <reference types="Cypress" />

describe('Orchestration Playbooks', () => {
  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('DynamicOrchestration');

    cy.intercept('POST', '/orchestration/api/v1/playbook/rql', { items: [] }).as('getPlaybooks');
    cy.intercept('POST', '/orchestration/api/v1/sensor/rql', { items: [] }).as('getSensors');
    cy.intercept('POST', '/orchestration/api/v1/asset/rql', { items: [] }).as('getAssets');
    cy.intercept('POST', '/orchestration/api/v1/plugin/rql', { items: [] }).as('getPlugins');

    cy.navigateSwimlane('/orchestration/playbooks');
    cy.wait('@getEnabledFlags');
  });

  describe('No playbooks', () => {
    it('Display mode toggle hidden when no playbooks present', () => {
      cy.get('.display-toggle').should('not.exist');
    });

    it('No playbook dialog displays on page', () => {
      cy.get('.do-page-no-elements__icon').should('exist');
      cy.get('.do-page-no-elements__header').should('contain', 'Start by connecting your first playbook');
      cy.get('.do-page-no-elements__content').should(
        'contain',
        'Playbooks are where all the orchestration magic happens.'
      );
      cy.get('.do-page-no-elements__illustration').should('exist');
      cy.get('.ngx-plus-menu.position-bottom').should('exist');
      cy.get('.ngx-plus-menu.position-bottom .ngx-plus-menu--circle').should('have.css', 'cursor', 'pointer');
    });
  });

  describe('With Playbooks', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.setMockFeatureFlag('DynamicOrchestration');
      cy.intercept('POST', '/orchestration/api/v1/playbook/rql', {
        fixture: 'integration/dynamic-orchestration/get-playbooks.json'
      }).as('getPlaybooks');
      cy.intercept('POST', '/orchestration/api/v1/sensor/rql', { items: [] }).as('getSensors');
      cy.intercept('POST', '/orchestration/api/v1/asset/rql', { items: [] }).as('getAssets');
      cy.intercept('POST', '/orchestration/api/v1/plugin/rql', { items: [] }).as('getPlugins');
      cy.reloadSwimlane();
      cy.wait('@getEnabledFlags');
    });

    describe('Playbook in list mode', () => {
      it('Clicking display icons changes active display mode', () => {
        // grid view active by default
        cy.get('.ngx-grid-view').should('have.class', 'do-viewmode-switch__toggle-item--active');
        cy.get('.ngx-field-multiselect').should('not.have.class', 'do-viewmode-switch__toggle-item--active');
        cy.get('.ngx-card-vertical').should('exist');

        // click to change to list view
        cy.get('.ngx-field-multiselect').click().should('have.class', 'do-viewmode-switch__toggle-item--active');
        cy.get('.ngx-grid-view').should('not.have.class', 'do-viewmode-switch__toggle-item--active');
        cy.get('.ngx-card-horizontal').should('exist');
      });
    });

    describe('Playbook menu', () => {
      it('Clicking on playbook menu upload button opens upload dialog', () => {
        cy.get('ngx-plus-menu')
          .first()
          .within(() => {
            cy.get('.ngx-plus-menu--circle-container').should('exist').click();
            cy.get('.ngx-plus-menu--icon-0').should('exist').click();
          });
        cy.get('do-playbook-upload-dialog').should('exist');
        cy.get('.ngx-large-format-dialog-header-action__button').click();
      });

      it('Clicking on playbook menu create button opens create dialog', () => {
        cy.get('ngx-plus-menu')
          .first()
          .within(() => {
            cy.get('.ngx-plus-menu--circle-container').should('exist').click();
            cy.get('.ngx-plus-menu--icon-1').should('exist').click();
          });

        cy.get('do-playbook-create-dialog').should('exist');
        cy.get('.ngx-large-format-dialog-header-action__button').click();
      });

      describe('Playbook Upload Dialog', () => {
        it('Clicking on playbook menu upload button opens upload dialog to upload step', () => {
          cy.get('ngx-plus-menu')
            .first()
            .within(() => {
              cy.get('.ngx-plus-menu--circle-container').should('exist').click();
              cy.get('.ngx-plus-menu--icon-0').should('exist').click();
            });
          cy.get('ngx-stepper').should('exist');
        });

        describe('Playbook Upload Dialog Contents', () => {
          beforeEach(() => {
            cy.get('.ngx-stepper--content').as('uploadDialog');
          });

          it('Has dialog title', () => {
            cy.get('.ngx-large-format-dialog-header-title__text-wrapper--title > h1').should(
              'contain.text',
              'Upload a Playbook'
            );
          });

          it('Has nav steps and starts at 1', () => {
            cy.get('ngx-stepper').should('exist').as('stepper');

            // first step should be active
            cy.get('@stepper').find('.ngx-step--active .ngx-step--circle .center').should('contain.text', '1');
          });
        });

        describe('Playbook Upload Dialog Contents', { tags: ['#bug'] }, () => {
          before(() => {
            cy.fixture('/integration/dynamic-orchestration/test-playbook.yaml').then(fileContent => {
              cy.get('#do-drag-and-drop--input').attachFile({
                fileContent,
                fileName: 'test-playbook.yml',
                mimeType: 'text/x-yaml',
                encoding: 'utf8'
              });
            });
          });

          it('uploading valid playbook yaml takes user to second step', () => {
            cy.get('.ngx-step--active .ngx-step--circle .center').should('contain.text', '2');
          });

          describe('Valid playbook second step', () => {
            beforeEach(() => {
              cy.get('.do-playbook-list__pb-card').as('listCard');
            });

            it('updating value of title input also updates title in playbook section', () => {
              const testTitle = 'Test Title';

              cy.get('ngx-input[formControlName="title"] input').type(testTitle, { force: true });
              cy.get('@listCard').find('ngx-card-title').should('contain.text', testTitle);
            });

            it('updating value of name input also updates name in playbook section', () => {
              const testName = 'Test_Name';

              cy.get('ngx-input[formControlName="name"] input').clear({ force: true }).type(testName, { force: true });
              cy.get('@listCard').find('ngx-card-subtitle').should('contain.text', testName);
            });

            it('name is required, empty name disables dialog confirm button', () => {
              cy.get('.ngx-large-format-dialog-footer--default > .btn').should('be.enabled');

              cy.get('ngx-input[formControlName="name"] input').clear({
                force: true
              });
              cy.get('.ngx-large-format-dialog-footer--default > .btn').should('be.disabled');

              // filling name field should re-enable
              cy.get('ngx-input[formControlName="name"] input').type('my_playbook', { force: true });

              cy.get('.ngx-large-format-dialog-footer--default > .btn').should('be.enabled');
            });

            it('clicking upload different playbook link takes you back to first upload step', () => {
              cy.get('@listCard').find('.ngx-card--outline-text .inner-text').click({ force: true });
              cy.get('.ngx-step--active .ngx-step--circle .center').should('contain.text', '1');
            });
          });
        });

        describe.skip('Playbook Detail Dialog', { tags: ['#bug'] }, () => {
          before(() => {
            cy.fixture('/integration/dynamic-orchestration/test-playbook.yaml').then(fileContent => {
              cy.get('#do-drag-and-drop--input').attachFile({
                fileContent,
                fileName: 'test-playbook.yml',
                mimeType: 'text/x-yaml',
                encoding: 'utf8'
              });
            });
          });

          before(() => {
            cy.get('.ngx-card--playbook .view-details').click();
          });

          it('should create', () => {
            cy.get('do-playbook-detail-dialog').should('exist');
          });

          it('should have description header', () => {
            cy.get('.dialog-header').should('exist');
          });

          it('should have plugins list', () => {
            cy.get('.dialog-overview__plugin-details').should('exist');
          });

          it('should have preview area', () => {
            cy.get('.dialog-overview__preview').should('exist');
            cy.get('.dialog-bar__action').click();
            cy.get('.ngx-large-format-dialog-header-action__button').click();
          });
        });
      });
    });

    describe.skip('Playbook Edit Dialog', { tags: ['#bug'] }, () => {
      before(() => {
        cy.get('ngx-card').first().as('playbookItem');
      });

      it('should open dialog', () => {
        cy.get('@playbookItem').within(() => {
          cy.get('ngx-dropdown.ellipsis').as('ellipsis').should('be.visible');
          cy.get('@ellipsis').click();
          cy.get('ngx-dropdown-menu').should('be.visible');
          cy.get('ngx-dropdown-menu > ul > li').first().click();
        });
        cy.get('do-playbook-edit-dialog').should('exist');
      });

      it('should have disabled submit button when pristine', () => {
        cy.get('do-playbook-edit-dialog')
          .get('.ngx-large-format-dialog-footer--default > button')
          .should('exist')
          .should('be.disabled');
      });

      it('should have playbook card', () => {
        cy.get('ngx-card.do-playbook-list__pb-card').should('exist');
      });

      it('should have enabled submit button when dirty', () => {
        cy.get('do-playbook-dialog-inputs input[type="text"]').first().focus().type('test');

        cy.get('do-playbook-edit-dialog').get('.ngx-large-format-dialog-footer--default > button').should('be.enabled');
      });

      it('should have disabled submit button when invalid', () => {
        cy.get('.ngx-input__lock-toggle').click();
        cy.get('ngx-input[formControlName="name"] input').clear();

        cy.get('do-playbook-edit-dialog')
          .get('.ngx-large-format-dialog-footer--default > button')
          .should('be.disabled');
      });

      it('should close', () => {
        cy.get('.ngx-large-format-dialog-header-action__button').should('exist').click();

        cy.get('do-playbook-edit-dialog').should('not.exist');
      });
    });
  });
});

import playbook from '../../../../fixtures/integration/dynamic-orchestration/get-playbook.json';

describe('Orchestration Playbook - Inputs Manager', () => {
  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('DynamicOrchestration');

    cy.intercept('POST', '/orchestration/api/v1/plugin/rql', {
      fixture: 'integration/dynamic-orchestration/get-plugins.json',
      statusCode: 201
    }).as('getPlugins');

    cy.intercept('POST', '/orchestration/api/v1/sensor/rql', { items: [] }).as('getSensors');
    cy.intercept('POST', '/orchestration/api/v1/asset/rql', { items: [] }).as('getAssets');

    cy.intercept('GET', '/orchestration/api/v1/featureflags', {
      fixture: 'integration/dynamic-orchestration/get-turbine-feature-flags.json'
    }).as('getTurbineFeatureFlags');

    cy.intercept('GET', `/orchestration/api/v1/playbook/${playbook.id}`, playbook).as('getPlaybook');
    cy.intercept('POST', '/orchestration/api/v1/playbook/rql', {
      items: [{ item: playbook }]
    }).as('getPlaybooks');

    cy.navigateSwimlane(`/orchestration/playbook/${playbook.id}`);

    cy.wait('@getTurbineFeatureFlags');
    cy.wait('@getEnabledFlags');
    cy.wait('@getPlaybook');
    cy.wait('@getPlaybooks');
    cy.wait('@getAssets');
    cy.wait('@getSensors');
    cy.wait('@getPlugins');
  });

  describe('playbook inputs dialog', () => {
    beforeEach(() => {
      cy.get('.playbook-editor .editor-panel-inner__header').first().should('exist').as('playbookHeader');
      cy.get('@playbookHeader').find('.playbook-input__btn').should('exist').as('playbookInputBtn');

      cy.get('do-playbook-code-editor').should('exist').as('playbookCodeEditor');
    });

    it('playbook-input button should exist', () => {
      cy.get('@playbookInputBtn').should('contain.text', 'Playbook Inputs');
    });

    describe('playbook input dialog', () => {
      // These test must run in sequence
      before(() => {
        cy.get('.playbook-editor .editor-panel-inner__header').first().should('exist').as('playbookHeader');
        cy.get('@playbookHeader').find('.playbook-input__btn').should('exist').as('playbookInputBtn');
        cy.get('@playbookInputBtn').click();
        cy.get('do-playbook-inputs-manager-dialog').should('exist');
      });

      beforeEach(() => {
        cy.get('.playbook-editor .editor-panel-inner__header').first().should('exist').as('playbookHeader');
        cy.get('do-playbook-inputs-manager-dialog').as('dialog');
      });

      it('should open dialog', () => {
        cy.get('@dialog').within(() => {
          cy.get('.ngx-large-format-dialog-header-title').should('contain.text', 'Playbook Inputs Manager');
          cy.get('.inputs-dialog-content__variables h4').should('contain.text', 'Playbook Inputs');
          cy.get('.inputs-dialog-content__information h5').should('contain.text', 'Using Playbook Inputs');
        });
      });

      // Note: some of these should move to ngx-ui library component tests

      it('can add a first property', () => {
        cy.get('@dialog').within(() => {
          cy.contains('button', 'Add a property').click();
          cy.get('ngx-dropdown-menu').should('exist').contains('button', 'String').click();
        });
        cy.get('ngx-property-config')
          .should('exist')
          .within(() => {
            cy.getByLabel('PROPERTY TITLE').ngxFill('My New Property');

            // New property name is generated from title
            cy.getByLabel('PROPERTY NAME').ngxGetValue().should('eq', 'My_New_Property');

            // New property can change type
            cy.getByLabel('TYPE').should('not.have.class', 'disabled').ngxGetValue().should('eq', 'string');
            cy.getByLabel('TYPE').select('integer');

            cy.contains('button', 'Apply').click();
          });

        cy.get('ngx-property-config').should('not.exist');

        cy.get('.node-container > .node')
          .should('have.length', 1)
          .within(() => {
            cy.get('.info-name').should('contain.text', 'My New Property');
            cy.get('.info-type > .property-name').should('contain.text', 'My_New_Property');
            cy.get('.info-type > .type').should('contain.text', 'Integer');
          });
      });

      it('can add a more properties', () => {
        cy.get('@dialog').within(() => {
          cy.contains('button', 'Add a property').click();
          cy.get('ngx-dropdown-menu').should('exist').contains('button', 'Boolean').click();
        });

        cy.get('ngx-property-config')
          .should('exist')
          .within(() => {
            cy.getByLabel('PROPERTY TITLE').ngxFill('My Second Property');

            // New property name is generated from title
            cy.getByLabel('PROPERTY NAME').ngxGetValue().should('eq', 'My_Second_Property');

            // New property can change type
            cy.getByLabel('TYPE').should('not.have.class', 'disabled').ngxGetValue().should('eq', 'boolean');
            cy.getByLabel('TYPE').select('string');

            cy.contains('button', 'Apply').click();
          });

        cy.get('ngx-property-config').should('not.exist');

        cy.get('.node-container > .node').should('have.length', 2);

        cy.get('.node-container > .node')
          .eq(1)
          .within(() => {
            cy.get('.info-name').should('contain.text', 'My Second Property');
            cy.get('.info-type > .property-name').should('contain.text', 'My_Second_Property');
            cy.get('.info-type > .type').should('contain.text', 'String');
          });
      });

      it('can edit a existing property', () => {
        // requires above test as setup
        cy.get('@dialog').within(() => {
          cy.get('.node-container > .node .node-options button').first().click();
        });
        cy.get('ngx-property-config')
          .should('exist')
          .within(() => {
            cy.getByLabel('PROPERTY TITLE').ngxFill('My Modified Property');

            // Existing property name is fixed
            cy.getByLabel('PROPERTY NAME').ngxGetValue().should('eq', 'My_New_Property');

            // Existing property cannot change type
            cy.getByLabel('TYPE').should('have.class', 'disabled').ngxGetValue().should('eq', 'integer');

            cy.contains('button', 'Apply').click();
          });

        cy.get('ngx-property-config').should('not.exist');

        cy.get('.node-container > .node').should('have.length', 2);

        cy.get('.node-container > .node')
          .first()
          .within(() => {
            cy.get('.info-name').should('contain.text', 'My Modified Property');
            cy.get('.info-type > .property-name').should('contain.text', 'My_New_Property');
            cy.get('.info-type > .type').should('contain.text', 'Integer');
          });
      });

      it('should close dialog and update playbook', () => {
        cy.get('@dialog').within(() => {
          cy.get('.ngx-large-format-dialog-footer').contains('button', 'Apply').click();
        });
        cy.get('@dialog').should('not.exist');

        // Assumes there is only one editor
        cy.window()
          .then((win: any) => win.monaco.editor.getModels()[0].getValue())
          .should('contain', 'My_New_Property')
          .should('contain', 'type: integer')
          .should('contain', 'title: My Modified Property');
      });
    });

    describe('reopens dialog', () => {
      // requires previous tests as setup
      before(() => {
        cy.get('.playbook-editor .editor-panel-inner__header').first().should('exist').as('playbookHeader');
        cy.get('@playbookHeader').find('.playbook-input__btn').should('exist').as('playbookInputBtn');
        cy.get('@playbookInputBtn').click();
        cy.get('do-playbook-inputs-manager-dialog').should('exist');
      });

      beforeEach(() => {
        cy.get('.playbook-editor .editor-panel-inner__header').first().should('exist').as('playbookHeader');
        cy.get('do-playbook-inputs-manager-dialog').as('dialog');
      });

      it('should open dialog', () => {
        cy.get('@dialog').within(() => {
          cy.get('.ngx-large-format-dialog-header-title').should('contain.text', 'Playbook Inputs Manager');
          cy.get('.inputs-dialog-content__variables h4').should('contain.text', 'Playbook Inputs');
          cy.get('.inputs-dialog-content__information h5').should('contain.text', 'Using Playbook Inputs');
        });
      });

      it('can remove a property', () => {
        cy.get('@dialog').within(() => {
          cy.get('.node-container > .node').should('have.length', 2);
          cy.get('.node-container > .node')
            .first()
            .within(() => {
              cy.get('.ngx-dropdown-toggle').click();
              cy.get('.ngx-dropdown-dark-outline').contains('button', 'Remove').click();
            });
          cy.get('.node-container > .node').should('have.length', 1);
        });
      });

      it('should show confirm when apply, abort', () => {
        cy.get('@dialog').within(() => {
          cy.get('.ngx-large-format-dialog-footer').contains('button', 'Apply').click();
        });

        cy.get('ngx-alert-dialog')
          .should('exist')
          .within(() => {
            cy.contains('button', 'Cancel').click();
          });

        cy.get('ngx-alert-dialog').should('not.exist');
      });

      it('should show confirm when apply, continue', () => {
        cy.get('@dialog').within(() => {
          cy.get('.ngx-large-format-dialog-footer').contains('button', 'Apply').click();
        });

        cy.get('ngx-alert-dialog')
          .should('exist')
          .within(() => {
            cy.contains('button', 'Ok').click();
          });

        cy.get('ngx-alert-dialog').should('not.exist');
        cy.get('@dialog').should('not.exist');
      });
    });
  });

  describe('using playbook inputs', () => {
    before(() => {
      cy.contains('.node', 'ListChan').click();
      cy.contains('Additional Configuration').click();
    });

    describe('action inputs', () => {
      beforeEach(() => {
        cy.get('do-playbook-action-dialog')
          .as('dialog')
          .find('.playbook-action-inputs-mapper-wrapper')
          .as('mapper')
          .find('do-playbook-action-inputs-mapper-card')
          .as('inputs');
      });

      it('should show playbook inputs drawer', () => {
        cy.get('@inputs')
          .should('have.length', 2)
          .first()
          .find('.playbook-action-inputs-mapper-card__field')
          .within(() => {
            cy.get('do-playbook-action-inputs-mapper-field-dropdown .ngx-dropdown-toggle').click();
            cy.contains('button', ' Playbook property ').click();
            cy.get('.playbook-action-inputs-mapper-field-control__tagBoxContainer').click();
          });

        cy.get('.do-playbook-action-inputs-drawer').should('exist');
      });

      it('should show properties', () => {
        cy.get('do-playbook-action-inputs-drawer-card')
          .should('have.length', 1)
          .within(() => {
            cy.get('.ngx-chevron-bold-right').click();
            cy.get('do-playbook-action-inputs-drawer-card-property').should('have.length', 1);
          });
      });

      it('allows new property creation', () => {
        cy.get('do-playbook-action-inputs-drawer-card')
          .first()
          .within(() => {
            cy.get('.properties-container__add-button').should('contain.text', 'Add a playbook input');

            cy.get('.properties-container__add-button').click();
            cy.get('.properties-container__add-button').should('not.exist');
            cy.get('.properties-container__new-property').should('exist');
            cy.get('.properties-container__new-property h4').should('contain.text', 'New Playbook Input');

            cy.get('.properties-container__new-property__cancel').click();
            cy.get('.properties-container__new-property').should('not.exist');
            cy.get('.properties-container__add-button').should('exist');

            cy.get('.properties-container__add-button').click();
            cy.get('.properties-container__add-button').should('not.exist');
            cy.get('.properties-container__new-property').should('exist');

            cy.getByLabel('Title').ngxFill('My New Property');
            cy.getByLabel('Description').ngxFill('My New Property Description');
            cy.getByLabel('Type').ngxGetValue().should('contain', 'string');

            cy.contains('button', 'Done').click();
            cy.get('do-playbook-action-inputs-drawer-card-property').should('have.length', 2);
            cy.get('do-playbook-action-inputs-drawer-card-property')
              .eq(1)
              .within(() => {
                cy.get('.property__container__content__title').should('contain.text', 'My New Property');
                cy.get('.property__container__content__subtitle__type').should('contain.text', 'string');
                cy.get('.property__container__content__subtitle__key').should('contain.text', 'My_New_Property');
              });
          });
      });

      it('should select a property', () => {
        cy.get('do-playbook-action-inputs-drawer-card-property .ngx-checkbox--box').first().click();
        cy.get('.do-playbook-action-inputs-drawer').should('not.exist');

        cy.get('@inputs')
          .first()
          .find('.playbook-action-inputs-mapper-card__field')
          .within(() => {
            cy.get('do-playbook-action-inputs-mapper-field-control-tag').should('have.length', 1).as('tag');
            cy.get('@tag').find('.playbook-action-inputs-mapper-field-control-tag__image').should('exist');
            cy.get('@tag')
              .find('.playbook-action-inputs-mapper-field-control-tag__label')
              .should('contain.text', 'inputs.My_Second_Property');
          });
      });

      after(() => {
        // remove it before continuing
        cy.get('@inputs').first().find('.ngx-disable').click();
      });
    });

    after(() => {
      cy.get('.ngx-large-format-dialog-footer').contains('button', 'Cancel').click();
      cy.get('ngx-alert-dialog').contains('Discard').click();
    });
  });
});

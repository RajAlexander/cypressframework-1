describe('Orchestration Playbook - Add record event trigger', () => {
  let playbook;

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.fixture('integration/dynamic-orchestration/get-playbook.json').then(mockPlaybook => {
      playbook = mockPlaybook;
      cy.setupStubbedSwimlane();
      cy.setMockFeatureFlag('DynamicOrchestration');

      cy.intercept('POST', '/orchestration/api/v1/plugin/rql', {
        fixture: 'integration/dynamic-orchestration/get-plugins.json',
        statusCode: 201
      }).as('getPlugins');
      cy.intercept('POST', '/orchestration/api/v1/sensor/rql', { items: [] }).as('getSensors');
      cy.intercept('POST', '/orchestration/api/v1/asset/rql', { items: [] }).as('getAssets');
      cy.intercept('GET', `/orchestration/api/v1/playbook/${playbook.id}`, playbook).as('getPlaybook');
      cy.intercept('POST', '/orchestration/api/v1/playbook/rql', {
        items: [{ item: playbook }]
      }).as('getPlaybooks');
      cy.intercept('GET', '/orchestration/api/v1/featureflags', {
        fixture: 'integration/dynamic-orchestration/get-turbine-feature-flags.json'
      }).as('getTurbineFeatureFlags');
      cy.navigateSwimlane(`/orchestration/playbook/${playbook.id}`);

      cy.wait('@getTurbineFeatureFlags');
      cy.wait('@getEnabledFlags');
      cy.wait('@getPlaybook');
      cy.wait('@getPlaybooks');
      cy.wait('@getAssets');
      cy.wait('@getSensors');
      cy.wait('@getPlugins');
    });
  });

  describe('Record Event Triggers', () => {
    describe('Add new trigger', () => {
      beforeEach(() => {
        cy.get('g.trigger .node__trigger--placeholder-action').as('addNewTriggerNode');
      });

      it('should render add a trigger node', () => {
        cy.get('@addNewTriggerNode').should('exist').should('be.visible').should('contain', 'Add a trigger');
        cy.get('@addNewTriggerNode').click();
      });

      it('should allow to create a record event trigger', () => {
        cy.get('g.trigger-menu-item').contains('Record Event').as('recordEventOption').should('be.visible');
        cy.get('@recordEventOption').click();
        // allow node to be created
        cy.wait(1000);
      });

      it('should create the node for the record event trigger', () => {
        cy.get('g[data-cy="visual-editor__trigger-node__event-node-0"]')
          .first()
          .should('be.visible')
          .as('recordEventNode');
        cy.get('@recordEventNode').should('contain', 'Record Event');
      });

      it('should display record event icon', () => {
        cy.get('g[data-cy="visual-editor__trigger-node__event-node-0"] image')
          .first()
          .should('be.visible')
          .should('have.attr', 'xlink:href', '/assets/turbine-ui-common/record-event-trigger-logo.svg');
      });
    });

    describe('Record Event Trigger Config Side Panel', () => {
      beforeEach(() => {
        cy.get('.panel-body record-event-trigger-config').as('triggerConfigSidePanel');
      });
      it('should display the config side panel with Record Event title', () => {
        cy.get('@triggerConfigSidePanel').should('exist').should('be.visible');
        cy.get('@triggerConfigSidePanel').find('h5.trigger-config-form__header').should('contain', 'Record Event');
      });

      it('should display configure button and should be disabled', () => {
        cy.get('@triggerConfigSidePanel')
          .find('.record-event-container-configure .ngx-button button')
          .should('be.visible')
          .should('contain', 'Configure')
          .should('have.attr', 'disabled');
      });

      it('should allow user to select app for the trigger', () => {
        cy.get('@triggerConfigSidePanel')
          .find('.ngx-select')
          .as('appSelect')
          .should('be.visible')
          .should('have.attr', 'label', 'Application');

        cy.get('@appSelect').select('Test Application');
      });

      it('should allow user to select record event types for the trigger', () => {
        cy.get('@triggerConfigSidePanel').find('.ngx-checkbox').contains('Record Create').should('be.visible').click();
        cy.get('@triggerConfigSidePanel').find('.ngx-checkbox').contains('Record Update').should('be.visible').click();
      });

      it('should update trigger node with app name and record event types', () => {
        cy.get('g[data-cy="visual-editor__trigger-node__event-node-0"]')
          .first()
          .within(() => {
            cy.get('.node-label').should('contain', 'Created/Updated');
            cy.get('.node-sub-label').should('contain', 'Test Application');
          });
      });

      it('should display enabled configure button since trigger has app and record event type', () => {
        cy.get('@triggerConfigSidePanel')
          .find('.record-event-container-configure .ngx-button button')
          .should('be.visible')
          .should('contain', 'Configure')
          .should('not.have.attr', 'disabled');
      });
    });

    describe('Playbook Input mapping Dialog without playbook inputs', () => {
      beforeEach(() => {
        cy.get('.panel-body record-event-trigger-config').as('triggerConfigSidePanel');
      });
      it('should open dialog and display title, subtitle and image in header', () => {
        cy.get('@triggerConfigSidePanel').find('.record-event-container-configure .ngx-button button').click();
        // allow dialog to be opened
        cy.wait(1000);
        cy.get('.ngx-dialog do-record-trigger-inputs-mapper-dialog')
          .as('playbookInputMappingDialog')
          .should('be.visible');
        cy.get('@playbookInputMappingDialog')
          .find('.ngx-large-format-dialog-header-title h1')
          .should('contain', 'Map to Playbook Inputs');
        cy.get('@playbookInputMappingDialog')
          .find('.ngx-large-format-dialog-header-title h4')
          .should('contain', 'Map the record fields to the playbook inputs');

        cy.get('@playbookInputMappingDialog')
          .find('.ngx-large-format-dialog-header-title img')
          .should('be.visible')
          .should('have.attr', 'src', '/assets/turbine-ui-common/nested-playbook-logo.svg');
      });

      it('should render message if playbook has no inputs', () => {
        cy.get('.ngx-dialog do-record-trigger-inputs-mapper-dialog')
          .find('section.dialog-container__body')
          .should('be.visible')
          .should(
            'contain',
            'There are no playbook inputs to map. To use playbook inputs, configure them in your playbook input manager.'
          );
      });

      it('should not display open playbook link', () => {
        cy.get('.ngx-dialog do-record-trigger-inputs-mapper-dialog')
          .find('section.dialog-container__body .open-playbook-btn')
          .should('not.exist');
      });

      it('should close dialog', () => {
        cy.get('.ngx-dialog do-record-trigger-inputs-mapper-dialog')
          .find('ngx-large-format-dialog-footer button')
          .should('be.visible')
          .should('contain', 'Close')
          .click();
      });
    });

    describe('Add playbook inputs', () => {
      beforeEach(() => {
        cy.get('.playbook-editor .editor-panel-inner__header').first().should('exist').as('playbookHeader');
        cy.get('@playbookHeader').find('.playbook-input__btn').should('exist').as('playbookInputBtn');

        cy.get('do-playbook-code-editor').should('exist').as('playbookCodeEditor');
      });

      describe('playbook input dialog', () => {
        before(() => {
          cy.get('.playbook-editor .editor-panel-inner__header').first().should('exist').as('playbookHeader');
          cy.get('@playbookHeader').find('.playbook-input__btn').should('exist').as('playbookInputBtn');
          cy.get('@playbookInputBtn').click();
          cy.get('do-playbook-inputs-manager-dialog').should('exist');
        });

        beforeEach(() => {
          cy.get('.playbook-editor .editor-panel-inner__header').first().should('exist').as('playbookHeader');
          cy.get('do-playbook-inputs-manager-dialog').as('dialog');
        });

        it('can add a string property', () => {
          cy.get('@dialog').within(() => {
            cy.contains('button', 'Add a property').click();
            cy.get('ngx-dropdown-menu').should('exist').contains('button', 'String').click();
          });
          cy.get('ngx-property-config')
            .should('exist')
            .within(() => {
              cy.getByLabel('PROPERTY TITLE').ngxFill('Message');
              cy.contains('button', 'Apply').click();
            });

          cy.get('ngx-property-config').should('not.exist');
        });

        it('can add numeric property', () => {
          cy.get('@dialog').within(() => {
            cy.contains('button', 'Add a property').click();
            cy.get('ngx-dropdown-menu').should('exist').contains('button', 'Number').click();
          });

          cy.get('ngx-property-config')
            .should('exist')
            .within(() => {
              cy.getByLabel('PROPERTY TITLE').ngxFill('Threat Score');
              cy.contains('button', 'Apply').click();
            });

          cy.get('ngx-property-config').should('not.exist');

          cy.get('.node-container > .node').should('have.length', 2);
        });
        it('should close dialog', () => {
          cy.get('@dialog').within(() => {
            cy.get('.ngx-large-format-dialog-footer').contains('button', 'Apply').click();
          });
          // allow dialog to be closed
          cy.wait(1000);
          cy.get('@dialog').should('not.exist');
        });
      });
    });

    describe('Playbook Input mapping Dialog with playbook inputs', () => {
      beforeEach(() => {
        cy.get('.panel-body record-event-trigger-config').as('triggerConfigSidePanel');
      });
      it('should open dialog and display title, subtitle and image in header', () => {
        cy.get('@triggerConfigSidePanel').find('.record-event-container-configure .ngx-button button').click();
        // allow dialog to be opened
        cy.wait(1000);
      });

      it('should display available inputs', () => {
        cy.get('.ngx-dialog do-record-trigger-inputs-mapper-dialog')
          .find('section.dialog-container__body do-trigger-inputs-mapper-dialog-content')
          .as('mapperDialogContent')
          .should('be.visible');

        cy.get('@mapperDialogContent').find('.do-trigger-inputs-mapper-title').should('contain', 'Available Inputs');
        cy.get('@mapperDialogContent')
          .find('.do-trigger-inputs-mapper-list-titles h1')
          .should('contain', 'Playbook Inputs');
        cy.get('@mapperDialogContent')
          .find('.do-trigger-inputs-mapper-list-titles h4')
          .should('contain', 'User configurable inputs. You can manage inputs in playbook inputs.');
      });

      it('should allow user to map inputs', () => {
        cy.get('.ngx-dialog do-record-trigger-inputs-mapper-dialog .do-trigger-inputs-mapper-card')
          .first()
          .as('firstPlybookInput')
          .should('be.visible');
        cy.get('@firstPlybookInput').find('.do-trigger-inputs-mapper-card__title').should('contain', 'Message');
        cy.get('@firstPlybookInput')
          .find('.do-trigger-inputs-mapper-card__field .ngx-select')
          .should('be.visible')
          .select('Text');

        cy.get('.ngx-dialog do-record-trigger-inputs-mapper-dialog .do-trigger-inputs-mapper-card')
          .eq(1)
          .as('secondPlybookInput')
          .should('be.visible');
        cy.get('@secondPlybookInput').find('.do-trigger-inputs-mapper-card__title').should('contain', 'Threat Score');
        cy.get('@secondPlybookInput')
          .find('.do-trigger-inputs-mapper-card__field .ngx-select')
          .should('be.visible')
          .select('Numeric');
      });

      it('should close dialog', () => {
        cy.get('.ngx-dialog do-record-trigger-inputs-mapper-dialog')
          .find('ngx-large-format-dialog-footer button')
          .contains('Apply')
          .should('be.visible')
          .click();
      });
    });

    describe('Duplicate a trigger', () => {
      it('should create the node for the record event trigger', () => {
        cy.get('g[data-cy="visual-editor__trigger-node__event-node-0"]').first().click();
        cy.get('g[data-cy="visual-editor__trigger-node__event-node-0"] foreignObject .copy-icon')
          .first()
          .should('be.visible')
          .click();
        // wait for trigger to be created
        cy.wait(1000);
      });

      it('should display new trigger created', () => {
        cy.get('g[data-cy="visual-editor__trigger-node__event-node-0"]')
          .eq(1)
          .as('duplicatedTrigger')
          .should('be.visible');
        cy.get('@duplicatedTrigger').within(() => {
          cy.get('image').should('have.attr', 'xlink:href', '/assets/turbine-ui-common/record-event-trigger-logo.svg');
          cy.get('.node-label').should('contain', 'Created/Updated');
          cy.get('.node-sub-label').should('contain', 'Test Application');
        });
      });

      it('should display two record event nodes and 2 record action nodes', () => {
        cy.get('g[data-cy="visual-editor__trigger-node__event-node-0"]').should('have.length', 4);
      });
    });

    describe('Removes triggers', () => {
      it('should remove the triggers created', () => {
        cy.get('g[data-cy="visual-editor__trigger-node__event-node-0"]').first().click();
        cy.get('g[data-cy="visual-editor__trigger-node__event-node-0"] foreignObject .delete-icon')
          .first()
          .should('be.visible')
          .click();
        // wait for trigger to be deleted
        cy.wait(1000);
      });

      it('should display delte trigger confirmation dialog', () => {
        cy.get('ngx-alert-dialog').should('be.visible').as('alertDialog');
        cy.get('@alertDialog').within(() => {
          cy.get('.ngx-dialog-header h1').should('contain', 'Delete trigger');
          cy.get('.ngx-dialog-body').should('contain', 'Are you sure you want to delete the trigger?');
          cy.get('.ngx-dialog-footer').contains('button', 'Ok').click();
        });
      });

      it('should have only one record event node left', () => {
        cy.get('g[data-cy="visual-editor__trigger-node__event-node-0"]').should('have.length', 3);
      });
    });
  });

  after(() => {
    playbook = undefined;
  });
});

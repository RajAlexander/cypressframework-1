const stringInput = 'Message';
const numberInput = 'Score';
const arrayInput = 'List';

describe('Orchestration Playbook - Additional Options (repeat and asset selection)', () => {
  let playbook;

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.fixture('integration/dynamic-orchestration/get-playbook.json').then(mockPlaybook => {
      playbook = mockPlaybook;
      cy.setupStubbedSwimlane();
      cy.setMockFeatureFlag('DynamicOrchestration');

      cy.intercept('POST', '/orchestration/api/v1/plugin/rql', {
        fixture: 'integration/dynamic-orchestration/get-plugins.json',
        statusCode: 201
      }).as('getPlugins');
      cy.intercept('POST', '/orchestration/api/v1/sensor/rql', { items: [] }).as('getSensors');
      cy.intercept('POST', '/orchestration/api/v1/asset/rql', { items: [] }).as('getAssets');
      cy.intercept('GET', `/orchestration/api/v1/playbook/${playbook.id}`, playbook).as('getPlaybook');
      cy.intercept('POST', '/orchestration/api/v1/playbook/rql', {
        items: [{ item: playbook }]
      }).as('getPlaybooks');
      cy.intercept('GET', '/orchestration/api/v1/featureflags', {
        fixture: 'integration/dynamic-orchestration/get-turbine-feature-flags.json'
      }).as('getTurbineFeatureFlags');
      cy.navigateSwimlane(`/orchestration/playbook/${playbook.id}`);

      cy.wait('@getTurbineFeatureFlags');
      cy.wait('@getEnabledFlags');
      cy.wait('@getPlaybook');
      cy.wait('@getPlaybooks');
      cy.wait('@getAssets');
      cy.wait('@getSensors');
      cy.wait('@getPlugins');
    });
  });

  describe('Add playbook inputs', () => {
    before(() => {
      cy.get('.playbook-editor .editor-panel-inner__header').first().should('exist').as('playbookHeader');
      cy.get('@playbookHeader').find('.playbook-input__btn').should('exist').as('playbookInputBtn');
      cy.get('@playbookInputBtn').click();
      cy.get('do-playbook-inputs-manager-dialog').should('exist');
    });

    beforeEach(() => {
      cy.get('.playbook-editor .editor-panel-inner__header').first().should('exist').as('playbookHeader');
      cy.get('do-playbook-inputs-manager-dialog').as('dialog');
    });

    it('can add a string property', () => {
      cy.get('@dialog').within(() => {
        cy.contains('button', 'Add a property').click();
        cy.get('ngx-dropdown-menu').should('exist').contains('button', 'String').click();
      });
      cy.get('ngx-property-config')
        .should('exist')
        .within(() => {
          cy.getByLabel('PROPERTY TITLE').ngxFill(stringInput);
          cy.contains('button', 'Apply').click();
        });

      cy.get('ngx-property-config').should('not.exist');
    });
    it('can add a number property', () => {
      cy.get('@dialog').within(() => {
        cy.contains('button', 'Add a property').click();
        cy.get('ngx-dropdown-menu').should('exist').contains('button', 'Number').click();
      });
      cy.get('ngx-property-config')
        .should('exist')
        .within(() => {
          cy.getByLabel('PROPERTY TITLE').ngxFill(numberInput);
          cy.contains('button', 'Apply').click();
        });

      cy.get('ngx-property-config').should('not.exist');
    });

    it('can add array property', () => {
      cy.get('@dialog').within(() => {
        cy.contains('button', 'Add a property').click();
        cy.get('ngx-dropdown-menu').should('exist').contains('button', 'Array').click();
      });

      cy.get('ngx-property-config')
        .should('exist')
        .within(() => {
          cy.getByLabel('PROPERTY TITLE').ngxFill(arrayInput);
          cy.contains('button', 'Apply').click();
        });

      cy.get('ngx-property-config').should('not.exist');

      cy.get('.node-container > .node').should('have.length', 3);
    });

    it('should close dialog', () => {
      cy.get('@dialog').within(() => {
        cy.get('.ngx-large-format-dialog-footer').contains('button', 'Apply').click();
      });
      // allow dialog to be closed
      cy.wait(1000);
      cy.get('@dialog').should('not.exist');
    });
  });

  describe('Additional options', () => {
    beforeEach(() => {
      cy.get('g#new_action_a9rq7 > .node.action').as('actionNode');
    });

    it('should show action config drawer', () => {
      cy.get('@actionNode').should('exist').should('be.visible');
      cy.get('@actionNode').click();
      cy.get('turbine-action-config').should('exist').should('be.visible');
    });

    it('should open action additional configuration dialog', () => {
      cy.get('turbine-action-config .panel-footer > button').as('addConfBtn');
      cy.get('@addConfBtn').should('be.visible');
      cy.get('@addConfBtn').click();
    });

    it('should display additional options header', () => {
      cy.get('.do-modal-dialog__input-selection-wrapper').should('be.visible').as('actionInputs');
      cy.get('@actionInputs').find('.do-input-options h2').should('be.visible').and('have.text', 'Additional Options');
    });
  });

  describe('Asset configuration', () => {
    it('display asset selection card title, subtitle and no tip when no asset selected', () => {
      cy.get('do-action-input-asset').should('be.visible').as('actionInputsAssets');
      cy.get('@actionInputsAssets')
        .find('.do-no-asset-configured h1')
        .should('be.visible')
        .and('have.text', 'Select from available assets');
      cy.get('@actionInputsAssets')
        .find('h4.do-subtitle')
        .should('be.visible')
        .and('have.text', 'Can replace static values for recurring criteria');
      cy.get('@actionInputsAssets').find('.asset-info-tip').should('not.exist');
      cy.get('@actionInputsAssets').find('.add-asset-btn button').should('be.visible').click();
    });

    it('should display tip after clicking add asset plus icon', () => {
      cy.get('do-action-input-asset').should('be.visible').as('actionInputsAssets');
      cy.get('@actionInputsAssets')
        .find('.asset-info-tip')
        .should('be.visible')
        .should(
          'have.text',
          'You can now select asset property in the property drop down to populate asset properties in those fields.'
        );
    });

    it('should display asset select', () => {
      cy.get('do-action-input-asset').should('be.visible').as('actionInputsAssets');
      cy.get('@actionInputsAssets')
        .find('.asset-info-tip')
        .should('be.visible')
        .should(
          'have.text',
          'You can now select asset property in the property drop down to populate asset properties in those fields.'
        );

      cy.get('@actionInputsAssets').find('ngx-select').should('be.visible').should('have.text', 'Select an asset');
    });
  });

  describe('Repeat an action', () => {
    it('should display no repeat configure card when action has no repeat', () => {
      cy.get('do-playbook-action-repeat').should('be.visible').as('actionInputsRepeat');
      cy.get('@actionInputsRepeat').find('.do-no-repeat-configured h1').should('be.visible').and('have.text', 'Repeat');
      cy.get('@actionInputsRepeat')
        .find('.do-subtitle')
        .should('be.visible')
        .and('have.text', 'Set static or playbook properties to repeat');
      cy.get('@actionInputsRepeat').find('.repeat-info-tip').should('not.exist');
      cy.get('@actionInputsRepeat').find('.add-repeat-btn button').should('be.visible').click();
    });

    it('should display tip after clicking add repeat plus icon', () => {
      cy.get('do-playbook-action-repeat').should('be.visible').as('actionInputsRepeat');
      cy.get('@actionInputsRepeat').find('.do-repeat-configured h1').should('be.visible').and('have.text', 'Repeat');
      cy.get('@actionInputsRepeat')
        .find('.do-subtitle')
        .should('be.visible')
        .and('have.text', 'Select or statically define a property');
      cy.get('@actionInputsRepeat')
        .find('.repeat-info-tip')
        .should('be.visible')
        .and(
          'have.text',
          'You can now select repeat property in the property drop down to map the property, static values, or properties from an object to an input.'
        );
    });

    it('should display repeat icon', () => {
      cy.get('do-playbook-action-repeat').should('be.visible').as('actionInputsRepeat');
      cy.get('@actionInputsRepeat')
        .find('.do-repeat-configured ngx-icon')
        .should('be.visible')
        .and('have.attr', 'fonticon', 'repeat');
    });

    describe('Playbook property', () => {
      it('should allow to add a repeat', () => {
        cy.get('do-playbook-action-repeat').should('be.visible').as('actionInputsRepeat');
        cy.get('@actionInputsRepeat')
          .find('do-playbook-action-repeat-field')
          .within(() => {
            cy.get('do-playbook-action-repeat-field-dropdown .ngx-dropdown-toggle').should('be.visible').click();
            cy.contains('button', ' Playbook property ').should('be.visible');
            cy.get('.playbook-action-repeat-field-control__tagBoxContainer').click();
          });
      });

      it('should show properties', () => {
        cy.get('do-playbook-action-inputs-drawer-card').should('have.length', 2);
        cy.get('do-playbook-action-inputs-drawer-card')
          .eq(1)
          .within(() => {
            cy.get('.ngx-chevron-bold-right').click();
          });
      });

      it('should display three playbook inputs added', () => {
        cy.get('do-playbook-action-inputs-drawer-card-property').should('have.length', 3);
      });

      it('should only have the array type input as selectable', () => {
        cy.get('do-playbook-action-inputs-drawer-card-property')
          .eq(0)
          .should('be.visible')
          .find('.ngx-checkbox--box')
          .should('not.exist');
        cy.get('do-playbook-action-inputs-drawer-card-property')
          .eq(1)
          .should('be.visible')
          .find('.ngx-checkbox--box')
          .should('not.exist');
        cy.get('do-playbook-action-inputs-drawer-card-property')
          .eq(2)
          .should('be.visible')
          .find('.ngx-checkbox--box')
          .should('exist');
      });

      it('should allow user to select array playbook input', () => {
        cy.get('do-playbook-action-inputs-drawer-card-property')
          .eq(2)
          .should('be.visible')
          .find('.ngx-checkbox--box')
          .should('exist')
          .click();
        // let drawer close animation happen
        cy.wait(1000);
      });

      it('should have array playbook input property selected', () => {
        cy.get('do-playbook-action-inputs-mapper-field-control-tag')
          .should('be.visible')
          .and('have.text', `inputs.${arrayInput}`);
      });

      describe('Simple Values array', () => {
        beforeEach(() => {
          cy.get('do-playbook-action-inputs-mapper-card').first().should('be.visible').as('inputCard');
        });
        it('should allow user to select repeat property on input when a repeat is selected', () => {
          cy.get('@inputCard').find('do-playbook-action-inputs-mapper-field-dropdown ngx-dropdown-toggle').click();
          cy.contains('button', ' Repeat property ').should('be.visible').click();
        });

        it('should auto populate the repeat value selected on the right side panel', () => {
          cy.get('@inputCard')
            .find('do-playbook-action-repeat-field-control')
            .should('be.visible')
            .and('have.text', `${arrayInput}`);
        });

        it('should allow user to clear the repeat property', () => {
          cy.get('@inputCard').find('.playbook-action-inputs-mapper-field-control__icon').should('be.visible').click();
          cy.get('@inputCard').find('do-playbook-action-repeat-field-control').should('not.exist');
          cy.get('@inputCard')
            .find(
              'do-playbook-action-inputs-mapper-field-dropdown .playbook-action-inputs-mapper-field-dropdown__toggle'
            )
            .should('have.text', 'Static value');
        });
      });

      it('should apply repeat with playbook property value', () => {
        cy.get('do-playbook-action-dialog').find('ngx-large-format-dialog-footer button').contains('Apply').click();
      });

      it('should display repeat icon for updated action', () => {
        cy.get('g#new_action_a9rq7 > .node.action').find('[data-cy="repeat-icon"]').should('be.visible');
      });

      it('should persist selected playbook property for repeat value', () => {
        cy.get('turbine-action-config .panel-footer > button').as('addConfBtn').click();
        cy.get('do-playbook-action-inputs-mapper-field-control-tag')
          .should('be.visible')
          .and('have.text', `inputs.${arrayInput}`);
      });
    });
  });

  describe('Remove Repeat', () => {
    beforeEach(() => {
      cy.get('g#new_action_a9rq7 > .node.action').as('actionNode');
    });

    it('should render remove repeat button', () => {
      cy.get('.do-remove-repeat-btn button')
        .should('be.visible')
        .as('removeBtn')
        .should('contain.text', 'Remove')
        .click();
    });

    it('shows remove confirm dialog', () => {
      // wait for alert dialog to mount
      cy.wait(500);
      cy.get('ngx-alert-dialog').should('be.visible').as('confirm');
      cy.get('@confirm').should(
        'contain',
        'You are about to delete a repeat action. Are you sure you want to continue?'
      );
      cy.get('@confirm').find('.ngx-dialog-footer button').contains('Ok').click();
    });

    it('should remove repeat', () => {
      cy.get('do-playbook-action-repeat').should('be.visible').as('actionInputsRepeat');
      cy.get('@actionInputsRepeat').find('.do-no-repeat-configured h1').should('be.visible').and('have.text', 'Repeat');
      cy.get('@actionInputsRepeat')
        .find('.do-subtitle')
        .should('be.visible')
        .and('have.text', 'Set static or playbook properties to repeat');
      cy.get('@actionInputsRepeat').find('.repeat-info-tip').should('not.exist');
      cy.get('@actionInputsRepeat').find('.add-repeat-btn button').should('be.visible');
      cy.get('do-playbook-action-dialog').find('ngx-large-format-dialog-footer button').contains('Apply').click();
    });

    it('should not display repeat icon on action', () => {
      cy.get('@actionNode').find('[data-cy="repeat-icon"]').should('not.exist');
    });
  });

  after(() => {
    playbook = undefined;
  });
});

import playbook from '../../../../fixtures/integration/dynamic-orchestration/get-playbook.json';

describe('Orchestration Playbook - Outputs Dialog - Application Mappings', () => {
  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('DynamicOrchestration');

    cy.intercept('POST', '/orchestration/api/v1/sensor/rql', { items: [] }).as('getSensors');
    cy.intercept('POST', '/orchestration/api/v1/asset/rql', { items: [] }).as('getAssets');

    cy.intercept('GET', '/orchestration/api/v1/featureflags', {
      fixture: 'integration/dynamic-orchestration/get-turbine-feature-flags.json'
    }).as('getTurbineFeatureFlags');

    cy.intercept('GET', `/orchestration/api/v1/playbook/${playbook.id}`, playbook).as('getPlaybook');
    cy.intercept('POST', '/orchestration/api/v1/playbook/rql', {
      items: [{ item: playbook }]
    }).as('getPlaybooks');
    cy.intercept('GET', `/api/ingestion-rules/playbook/${playbook.id}`, []).as('getPlaybookIngestionRules');

    cy.navigateSwimlane(`/orchestration/playbook/${playbook.id}`);

    cy.wait('@getTurbineFeatureFlags');
    cy.wait('@getEnabledFlags');
    cy.wait('@getPlaybook');
    cy.wait('@getPlaybooks');
    cy.wait('@getAssets');
    cy.wait('@getSensors');
  });

  describe('playbook outputs dialog - application mappings', () => {
    const applicationWithIngestionRules = new Map<
      string,
      {
        createType: string;
        errorType: string;
        field: string;
      }
    >();

    describe('playbook application mappings', () => {
      //#region Helper functions
      const openPlaybookOutputsDialogAndSetAliases = () => {
        cy.get('@playbookOutputsAction').click();

        cy.get('do-playbook-outputs-dialog')
          .should('exist')
          .as('dialog')
          .within(() => {
            cy.get('.dialog-container--tabs .ngx-tabs  .ngx-tabs-list button:last')
              .should('exist')
              .should('contain.text', 'Application Mapping')
              .as('applicationMappingTabAction')
              .click();

            cy.get('[data-cy=playbook-outputs-cancel-close-action]')
              .should('exist')
              .should('contain.text', 'Close')
              .as('cancelAction');

            cy.get('[data-cy=playbook-outputs-apply-action]')
              .should('exist')
              .should('contain.text', 'Apply')
              .as('applyAction');
          });
      };

      const addApplication = (appName: string, fromSplashScreen = false) => {
        if (!fromSplashScreen) {
          selectApplication('Add Application', true);
        }

        cy.get('do-playbook-outputs-application-selector-dialog')
          .should('exist')
          .as('appSelectorDialog')
          .within(() => {
            cy.get('input').type(appName);
            cy.get('.playbook-outputs__application-selector__app:first').click();
            cy.get('.ngx-large-format-dialog-footer button:last')
              .should('exist')
              .should('contain.text', 'Confirm')
              .click();
          });
      };

      const selectApplication = (appName: string, isPlaceholder: boolean) => {
        if (isPlaceholder) {
          cy.get(`do-playbook-outputs-selected-application-list>button h2`).contains(appName).should('exist').click();
        } else {
          cy.get(`do-playbook-outputs-selected-application-list>div>button h2`).contains(appName).should('exist').click();
        }
      };

      const setIngestionRuleAliases = () => {
        cy.get('do-playbook-application-ingestion-rule-setting').should('exist').as('ingestionRules');
        cy.get('@ingestionRules').within(() => {
          cy.get('[data-cy=application-mapping-config-container__create-type]')
            .within(() => cy.get('.ngx-dropdown-toggle ngx-button'))
            .as('createTypeAction');

          cy.get('[data-cy=application-mapping-config-container__error-strategy]')
            .within(() => cy.get('.ngx-dropdown-toggle ngx-button'))
            .as('errorTypeAction');
        });
      };
      //#endregion

      beforeEach(() => {
        cy.get('.playbook-editor .editor-panel-inner__header').first().should('exist').as('playbookHeader');
        cy.get('@playbookHeader').find('.playbook-output__btn').should('exist').as('playbookOutputsAction');
        cy.get('@playbookHeader').find('[data-cy=playbook__editor-save__btn]').should('exist').as('playbookSaveAction');
      });

      it('add an app with ingestion rules and apply changes', () => {
        openPlaybookOutputsDialogAndSetAliases();
        cy.get('@dialog').within(() => {
          cy.get('do-playbook-outputs-dialog-splash-screen .mapping-container:not(.disabled)').should('exist').click();
        });

        addApplication('Test Application', true);

        cy.get('@dialog').within(() => {
          selectApplication('Test Application', false);
          cy.get('@applyAction').should('be.enabled');

          setIngestionRuleAliases();

          cy.get('@createTypeAction').should('contain.text', 'Create new records');
          cy.get('@errorTypeAction').should('contain.text', 'Set fields as empty on error');

          const selectedCreateType = 'Update or create new records';
          const selectedErrorType = 'Stop record creation on error';
          const selectedField = 'Text';
          applicationWithIngestionRules.set('Test Application', {
            createType: selectedCreateType,
            errorType: selectedErrorType,
            field: selectedField
          });

          cy.get('@createTypeAction').click();

          cy.get('ngx-dropdown-menu').within(() => {
            cy.get('h5').should('contain.text', 'Record Creation');
            cy.get('p').should(
              'contain.text',
              `Select how you want to handle distribution of new response data from a task's output`
            );

            cy.get('[data-cy=application-mapping-config-container__create-type-options]').within(() =>
              cy.get('ngx-radiobutton').contains(selectedCreateType).click()
            );
            cy.get('[data-cy=application-mapping-config-container__create-type-field]').select(selectedField);
          });

          cy.get('@errorTypeAction').click();
          cy.get('ngx-dropdown-menu').within(() => {
            cy.get('h5').should('contain.text', 'Error Handling');
            cy.get('p').should(
              'contain.text',
              `Select how you want to handle errors encountered during the insertion process.`
            );

            cy.get('[data-cy=application-mapping-config-container__error-strategy-options]').within(() =>
              cy.get('ngx-radiobutton').contains(selectedErrorType).click()
            );
          });

          cy.get('@applyAction').click();
        });
      });

      it('check if the changes are persisting before saving the playbook', () => {
        openPlaybookOutputsDialogAndSetAliases();
        const appIngestionRules = applicationWithIngestionRules.get('Test Application');

        cy.get('@dialog').within(() => {
          selectApplication('Test Application', false);
          setIngestionRuleAliases();

          cy.get('@createTypeAction').should('contain.text', appIngestionRules.createType);
          cy.get('@errorTypeAction').should('contain.text', appIngestionRules.errorType);
          cy.get('@applyAction').should('be.disabled');
        });

        const newApplicationAdded = 'Application 1';
        addApplication(newApplicationAdded);

        cy.get('@dialog').within(() => {
          cy.get('@applyAction').should('be.enabled');
          selectApplication('Test Application', false);
          cy.get('@createTypeAction').should('contain.text', appIngestionRules.createType);
          cy.get('@errorTypeAction').should('contain.text', appIngestionRules.errorType);

          selectApplication(newApplicationAdded, false);
          cy.get('@createTypeAction').should('contain.text', 'Create new records');
          cy.get('@errorTypeAction').should('contain.text', 'Set fields as empty on error');

          applicationWithIngestionRules.set(newApplicationAdded, {
            createType: 'Create new records',
            errorType: 'Skip record on error',
            field: ''
          });

          const application1Rules = applicationWithIngestionRules.get(newApplicationAdded);

          cy.get('@errorTypeAction').click();
          cy.get('ngx-dropdown-menu').within(() => {
            cy.get('[data-cy=application-mapping-config-container__error-strategy-options]').within(() =>
              cy.get('ngx-radiobutton').contains(application1Rules.errorType).click()
            );
          });

          selectApplication('Test Application', false);
          cy.get('@createTypeAction').should('contain.text', appIngestionRules.createType);
          cy.get('@errorTypeAction').should('contain.text', appIngestionRules.errorType);

          cy.get('@applyAction').click();
        });
      });
    });
  });
});

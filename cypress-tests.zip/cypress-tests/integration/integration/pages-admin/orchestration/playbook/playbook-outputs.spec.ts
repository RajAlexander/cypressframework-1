import playbook from '../../../../fixtures/integration/dynamic-orchestration/get-playbook.json';

describe('Orchestration Playbook - Outputs Dialog', () => {
  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('DynamicOrchestration');

    cy.intercept('POST', '/orchestration/api/v1/plugin/rql', {
      fixture: 'integration/dynamic-orchestration/get-plugins.json',
      statusCode: 201
    }).as('getPlugins');

    cy.intercept('POST', '/orchestration/api/v1/sensor/rql', { items: [] }).as('getSensors');
    cy.intercept('POST', '/orchestration/api/v1/asset/rql', { items: [] }).as('getAssets');

    cy.intercept('GET', '/orchestration/api/v1/featureflags', {
      fixture: 'integration/dynamic-orchestration/get-turbine-feature-flags.json'
    }).as('getTurbineFeatureFlags');

    cy.intercept('GET', `/orchestration/api/v1/playbook/${playbook.id}`, playbook).as('getPlaybook');
    cy.intercept('POST', '/orchestration/api/v1/playbook/rql', {
      items: [{ item: playbook }]
    }).as('getPlaybooks');

    cy.navigateSwimlane(`/orchestration/playbook/${playbook.id}`);

    cy.wait('@getTurbineFeatureFlags');
    cy.wait('@getEnabledFlags');
    cy.wait('@getPlaybook');
    cy.wait('@getPlaybooks');
    cy.wait('@getAssets');
    cy.wait('@getSensors');
    cy.wait('@getPlugins');
  });

  describe('playbook outputs dialog', () => {
    const promotedProperties = ['name', 'is_channel', 'is_archived', 'purpose'];
    beforeEach(() => {
      cy.get('.playbook-editor .editor-panel-inner__header').first().should('exist').as('playbookHeader');
      cy.get('@playbookHeader').find('.playbook-output__btn').should('exist').as('playbookOutputAction');
    });

    it('playbook-output button should exist', () => {
      cy.get('@playbookOutputAction').should('contain.text', 'Playbook Outputs');
    });

    describe('playbook outputs dialog', () => {
      before(() => {
        cy.get('.playbook-editor .editor-panel-inner__header').first().should('exist').as('playbookHeader');
        cy.get('@playbookHeader').find('.playbook-output__btn').should('exist').as('playbookOutputsAction');
        cy.get('@playbookOutputsAction').click();
      });

      beforeEach(() => {
        cy.get('do-playbook-outputs-dialog')
          .should('exist')
          .as('dialog')
          .within(() => {
            cy.get('.outputs-dialog-content__variables__editor_container__scroll-container__add-action-wrapper button')
              .should('exist')
              .as('promoteActionOutput');

            cy.get('.ngx-input').should('exist').as('searchBox');

            cy.get('.ngx-large-format-dialog-footer button:last')
              .should('exist')
              .should('contain.text', 'Apply')
              .as('applyAction');
          });
      });

      it('should open dialog with title and information', () => {
        cy.get('@dialog').within(() => {
          cy.get('.ngx-large-format-dialog-header-title').should('contain.text', 'Playbook Outputs');
          cy.get('.outputs-dialog-content__variables__header h4').should('contain.text', 'Promoted Playbook Outputs');
          cy.get('.outputs-dialog-content__variables__header p').should(
            'contain.text',
            "Action output promoted to this playbook's outputs"
          );

          cy.get('.outputs-dialog-content__information h5').should('contain.text', 'Using playbook outputs');
          cy.get('.outputs-dialog-content__information p:first').should(
            'contain.text',
            `From this dialog, or from each action in your playbook, you may denote action outputs that map results from a run to an application—or to another playbook that references this playbook.`
          );

          cy.get('.outputs-dialog-content__information p:last').should(
            'contain.text',
            `All outputs shown here will be available for mapping to an application in Application Mapping`
          );
        });
      });

      it('promote properties', () => {
        cy.get('@promoteActionOutput').should('contain.text', `Promote an action's output`).click();
        cy.get('.ngx-dialog-drawer-content').should('exist').as('actionOutputsDrawer');
        cy.get('do-playbook-action-inputs-drawer-card:first').should('exist').as('actionCard');

        cy.get('@dialog').within(() => {
          cy.get('@actionCard')
            .click()
            .within(() => {
              cy.get('do-playbook-action-inputs-drawer-card-property').as('properties');
              cy.get('@properties')
                .its('length')
                .then(length => cy.wrap(length).as('lengthOfOutputs'));

              promotedProperties.forEach(selector => {
                cy.get(`do-playbook-action-inputs-drawer-card-property .property .property__container__content__title`)
                  .contains(selector)
                  .parent()
                  .parent()
                  .within(() => {
                    cy.get('ngx-checkbox').click();
                  });
              });
            });

          cy.get('turbine-playbook-promoted-action-outputs')
            .should('have.length', 1)
            .within(() => {
              cy.get('turbine-action-outputs .node').should('have.length', 5);
              cy.get('turbine-action-outputs .node')
                .eq(2)
                .within(() => {
                  cy.get('button').should('contain.text', 'Remove').click();
                });
            });
        });

        cy.get('.ngx-alert-dialog .ngx-dialog-content')
          .should('exist')
          .within(() => {
            cy.get('.ngx-dialog-header').should('contain.text', 'Are you sure?');
            cy.get('.ngx-dialog-body').should(
              'contain.text',
              'Removing this promoted output will remove it anywhere else it is used.'
            );

            cy.get('.ngx-dialog-footer button:first').click();
            promotedProperties.pop();
          });

        cy.get('turbine-action-outputs .node').should('have.length', 4);
      });

      it('promote and array property and its children should not be promoted', () => {
        cy.get('@promoteActionOutput').should('contain.text', `Promote an action's output`).click();
        cy.get('.ngx-dialog-drawer-content').should('exist').as('actionOutputsDrawer');
        cy.get('do-playbook-action-inputs-drawer-card:first').should('exist').as('actionCard');

        cy.get('@dialog').within(() => {
          cy.get('@actionCard')
            .click()
            .within(() => {
              const propName = 'previous_names';
              cy.get('do-playbook-action-inputs-drawer-card-property').as('properties');
              cy.get(`do-playbook-action-inputs-drawer-card-property .property .property__container__content__title`)
                .contains(propName)
                .parent()
                .parent()
                .within(() => {
                  cy.get('ngx-checkbox').click();
                });

              promotedProperties.push(propName);
            });

          cy.get('turbine-playbook-promoted-action-outputs')
            .should('have.length', 1)
            .within(() => {
              cy.get('turbine-action-outputs .node').should('have.length', 5);
            });
        });
      });

      it('ask user to confirm the cancel change', () => {
        cy.get('@dialog').within(() => {
          cy.get('.ngx-large-format-dialog-footer button:first')
            .should('exist')
            .should('contain.text', 'Cancel')
            .as('cancelAction');

          cy.get('@cancelAction').click();
        });

        cy.get('.ngx-alert-dialog .ngx-dialog-content')
          .should('exist')
          .within(() => {
            cy.get('.ngx-dialog-header').should('contain.text', 'You Have Unsaved Changes');
            cy.get('.ngx-dialog-body').should('contain.text', 'Are you sure you want to discard your changes?');

            cy.get('.ngx-dialog-footer button:first').click();
          });
      });

      it('search action outputs', () => {
        cy.get('@dialog').within(() => {
          cy.get('@searchBox').type('there are no outputs matching the search');
          cy.get('turbine-playbook-promoted-action-output').should('not.exist');
          cy.get('button.clear-search-btn').should('exist').as('clearSearch').click();

          cy.get('turbine-action-outputs .node').should('have.length', 5);

          cy.get('@searchBox').type('archived');
          cy.get('turbine-action-outputs .node').should('have.length', 2);
          cy.get('@clearSearch').click();

          cy.get('@searchBox').type('purpose');
          cy.get('turbine-action-outputs .node').should('have.length', 2);
          cy.get('@clearSearch').click();

          cy.get('@applyAction').click();
        });

        cy.get('@playbookOutputAction').click();

        cy.get('@dialog').within(() => {
          cy.get('turbine-action-outputs .node').should('have.length', 5);
        });
      });

      it('un-promote action outputs', () => {
        const confirmUnPromote = () => {
          cy.get('.ngx-alert-dialog .ngx-dialog-content')
            .should('exist')
            .within(() => {
              cy.get('.ngx-dialog-header').should('contain.text', 'Are you sure?');
              cy.get('.ngx-dialog-body').should(
                'contain.text',
                'Removing this promoted output will remove it anywhere else it is used.'
              );

              cy.get('.ngx-dialog-footer button:first').click();
            });
        };

        // un-promote a prop without any children
        cy.get('@dialog').within(() => {
          cy.get('turbine-playbook-promoted-action-outputs').within(() => {
            cy.get('turbine-action-outputs .node:nth(2)').within(() => {
              cy.get('button').should('contain.text', 'Remove').click();
            });
          });
        });

        confirmUnPromote();

        cy.get('turbine-action-outputs .node').should('have.length', 4);

        cy.get('@dialog').within(() => {
          cy.get('turbine-playbook-promoted-action-outputs')
            .should('have.length', 1)
            .within(() => {
              cy.get('turbine-action-outputs .node:nth(2)').within(() => {
                cy.get('button').should('contain.text', 'Remove').click();
              });
            });
        });

        confirmUnPromote();

        cy.get('turbine-action-outputs .node').should('have.length', 3);
      });
    });
  });
});

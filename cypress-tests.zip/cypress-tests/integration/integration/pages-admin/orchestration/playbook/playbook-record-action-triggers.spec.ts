import apps from '../../../../fixtures/mocks/swimlane/app/get.json';

const baseUrl = Cypress.config().baseUrl;

const { id: app1Id, name: app1Name } = apps[2];
const { id: app2Id, name: app2Name } = apps[1];

describe('Orchestration Playbook - Record Action Triggers', () => {
  let playbook;

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.fixture('integration/dynamic-orchestration/get-playbook.json').then(mockPlaybook => {
      playbook = mockPlaybook;
      cy.setupStubbedSwimlane();
      cy.setMockFeatureFlag('DynamicOrchestration');

      cy.intercept('POST', '/orchestration/api/v1/plugin/rql', {
        fixture: 'integration/dynamic-orchestration/get-plugins.json',
        statusCode: 201
      }).as('getPlugins');
      cy.intercept('POST', '/orchestration/api/v1/sensor/rql', { items: [] }).as('getSensors');
      cy.intercept('POST', '/orchestration/api/v1/asset/rql', { items: [] }).as('getAssets');
      cy.intercept('GET', `/orchestration/api/v1/playbook/${playbook.id}`, playbook).as('getPlaybook');
      cy.intercept('POST', '/orchestration/api/v1/playbook/rql', {
        items: [{ item: playbook }]
      }).as('getPlaybooks');
      cy.intercept('GET', '/orchestration/api/v1/featureflags', {
        fixture: 'integration/dynamic-orchestration/get-turbine-feature-flags.json'
      }).as('getTurbineFeatureFlags');
      cy.navigateSwimlane(`/orchestration/playbook/${playbook.id}`);

      cy.wait('@getTurbineFeatureFlags');
      cy.wait('@getEnabledFlags');
      cy.wait('@getPlaybook');
      cy.wait('@getPlaybooks');
      cy.wait('@getAssets');
      cy.wait('@getSensors');
      cy.wait('@getPlugins');
    });
  });

  describe('Record Action Triggers', () => {
    describe('Nodes', () => {
      it('should display two record action nodes', () => {
        cy.get('g[data-cy="visual-editor__trigger-node__event-node-0"]').should('have.length', 2);
      });

      it('should display correct correct labels on nodes', () => {
        cy.get('g[data-cy="visual-editor__trigger-node__event-node-0"]')
          .eq(0)
          .within(() => {
            cy.get('.node-type').should('contain', 'Record Action');
            cy.get('.node-label').should('contain', 'Playbook btn');
            cy.get('.node-sub-label').should('contain', app1Name);
            cy.get('.ngx-card-avatar--content').should('contain', 'TA');
          });
        cy.get('g[data-cy="visual-editor__trigger-node__event-node-0"]')
          .eq(1)
          .within(() => {
            cy.get('.node-type').should('contain', 'Record Action');
            cy.get('.node-label').should('contain', 'Trigger Btn');
            cy.get('.node-sub-label').should('contain', app2Name);
            cy.get('.ngx-card-avatar--content').should('contain', 'CA');
          });
      });

      it('should not allow to delete or duplicate record action triggers', () => {
        cy.get('g[data-cy="visual-editor__trigger-node__event-node-0"]').first().click();
        cy.get('g[data-cy="visual-editor__trigger-node__event-node-0"] foreignObject .delete-icon').should('not.exist');
        cy.get('g[data-cy="visual-editor__trigger-node__event-node-0"] foreignObject .copy-icon').should('not.exist');
      });
    });

    describe('Record Action Trigger Config Side Panel', () => {
      beforeEach(() => {
        cy.get('.panel-body read-only-trigger-config').as('triggerConfigSidePanel');
      });
      it('should display the config side panel with Record Action title', () => {
        cy.get('@triggerConfigSidePanel').should('exist').should('be.visible');
        cy.get('@triggerConfigSidePanel').find('h5.trigger-config-form__header').should('contain', 'Record Action');
      });

      it('should display ngx-tip with information message', () => {
        cy.get('@triggerConfigSidePanel').within(() => {
          cy.get('ngx-tip').should('be.visible').should('have.attr', 'status', 'notice');
          cy.get('ngx-tip .tip-content--template').should(
            'contain',
            'This trigger was created in APPLICATION & APPLETS. Click the link below to view and/or update this application.'
          );
        });
      });

      it('should display link to open application in a new tab on ngx-tip', () => {
        cy.get('@triggerConfigSidePanel').within(() => {
          cy.get('ngx-tip a').should('exist').should('have.attr', 'target', '_blank');
          cy.get('ngx-tip a').should('exist').should('have.attr', 'href', `${baseUrl}/app-builder/${app1Id}`);
        });
      });

      it('should display trigger name as read only disabled input', () => {
        cy.get('@triggerConfigSidePanel').within(() => {
          cy.get('ngx-input').should('exist').should('have.length', 2);
          cy.get('ngx-input input').eq(0).should('have.attr', 'disabled');
          cy.get('ngx-input').eq(0).should('have.attr', 'label', 'Trigger Name');
          cy.get('ngx-input').eq(0).ngxGetValue().should('contain', 'Playbook btn');
        });
      });

      it('should display application name as read only disabled input', () => {
        cy.get('@triggerConfigSidePanel').within(() => {
          cy.get('ngx-input input').eq(1).should('have.attr', 'disabled');
          cy.get('ngx-input').eq(1).should('have.attr', 'label', 'Application Name');
          cy.get('ngx-input').eq(1).ngxGetValue().should('contain', app1Name);
        });
      });

      describe('Updates side panel when clicking on record actions', () => {
        beforeEach(() => {
          cy.get('.panel-body read-only-trigger-config').as('triggerConfigSidePanel');
        });
        it('updates side panel', () => {
          cy.get('g[data-cy="visual-editor__trigger-node__event-node-0"]').eq(1).click();
          cy.get('@triggerConfigSidePanel').should('exist').should('be.visible');
        });

        it('should display link to open application in a new tab on ngx-tip', () => {
          cy.get('@triggerConfigSidePanel').within(() => {
            cy.get('ngx-tip a').should('exist').should('have.attr', 'target', '_blank');
            cy.get('ngx-tip a').should('exist').should('have.attr', 'href', `${baseUrl}/app-builder/${app2Id}`);
          });
        });

        it('should display updated trigger name as read only disabled input', () => {
          cy.get('@triggerConfigSidePanel').within(() => {
            cy.get('ngx-input input').eq(0).should('have.attr', 'disabled');
            cy.get('ngx-input').eq(0).should('have.attr', 'label', 'Trigger Name');
            cy.get('ngx-input').eq(0).ngxGetValue().should('contain', 'Trigger Btn');
          });
        });

        it('should display updated application name as read only disabled input', () => {
          cy.get('@triggerConfigSidePanel').within(() => {
            cy.get('ngx-input input').eq(1).should('have.attr', 'disabled');
            cy.get('ngx-input').eq(1).should('have.attr', 'label', 'Application Name');
            cy.get('ngx-input').eq(1).ngxGetValue().should('contain', app2Name);
          });
        });
      });
    });
  });

  after(() => {
    playbook = undefined;
  });
});

import playbook from '../../../../fixtures/integration/dynamic-orchestration/get-playbook.json';
describe('Orchestration Playbook - Rename promoted output', () => {
  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('DynamicOrchestration');

    cy.intercept('POST', '/orchestration/api/v1/plugin/rql', {
      fixture: 'integration/dynamic-orchestration/get-plugins.json',
      statusCode: 201
    }).as('getPlugins');

    cy.intercept('POST', '/orchestration/api/v1/sensor/rql', { items: [] }).as('getSensors');
    cy.intercept('POST', '/orchestration/api/v1/asset/rql', { items: [] }).as('getAssets');

    cy.intercept('GET', '/orchestration/api/v1/featureflags', {
      fixture: 'integration/dynamic-orchestration/get-turbine-feature-flags.json'
    }).as('getTurbineFeatureFlags');

    cy.intercept('GET', `/orchestration/api/v1/playbook/${playbook.id}`, playbook).as('getPlaybook');
    cy.intercept('POST', '/orchestration/api/v1/playbook/rql', {
      items: [{ item: playbook }]
    }).as('getPlaybooks');

    cy.navigateSwimlane(`/orchestration/playbook/${playbook.id}`);

    cy.wait('@getTurbineFeatureFlags');
    cy.wait('@getEnabledFlags');
    cy.wait('@getPlaybook');
    cy.wait('@getPlaybooks');
    cy.wait('@getAssets');
    cy.wait('@getSensors');
    cy.wait('@getPlugins');
  });

  describe('playbook outputs dialog', () => {
    beforeEach(() => {
      cy.get('.playbook-editor .editor-panel-inner__header').first().should('exist').as('playbookHeader');
      cy.get('@playbookHeader').find('.playbook-output__btn').should('exist').as('playbookOutputAction');
    });

    describe('rename playbook output property', () => {
      before(() => {
        cy.get('.playbook-editor .editor-panel-inner__header').first().should('exist').as('playbookHeader');
        cy.get('@playbookHeader').find('.playbook-output__btn').should('exist').as('playbookOutputsAction');
      });

      const promoteProperty = (promotePropertyKey: string): void => {
        cy.get('@promoteActionOutput').click();
        cy.get('do-playbook-action-inputs-drawer-card:first').should('exist').as('actionCard');

        cy.get('@actionCard')
          .click()
          .within(() => {
            cy.get(`do-playbook-action-inputs-drawer-card-property .property .property__container__content__title`)
              .contains(promotePropertyKey)
              .parent()
              .parent()
              .within(() => {
                cy.get('ngx-checkbox').click();
              });
          });
      };

      const openEditDialogForProperty = (promotePropertyKey: string): void => {
        cy.get('turbine-playbook-promoted-action-outputs')
          .should('have.length', 1)
          .within(() => {
            cy.get('turbine-action-outputs .node .name-actions-container')
              .contains(promotePropertyKey)
              .parent()
              .within(() => {
                cy.get('.actions').get('.edit-title').click();
              });
          });
      };

      const openActionDialog = () => {
        cy.get('g#new_action > .node.action').as('actionNode');
        cy.get('@actionNode').click();
        cy.get('.action-config').as('triggerConfigSidePanel');

        cy.get('@triggerConfigSidePanel').should('exist').should('be.visible');
        cy.get('@triggerConfigSidePanel').within(() => {
          cy.contains('Additional Configuration').click();
        });

        cy.get('do-playbook-action-dialog').as('actionDialog');
        cy.get('@actionDialog').find('ngx-tabs button').eq(1).as('outputTab');
        cy.get('@outputTab').click();
        cy.get('@actionDialog').get('turbine-action-outputs-promoted').as('outputsPromoted');
        cy.get('@actionDialog').get('turbine-action-outputs').as('outputs');
      };

      const namePropertyKey = 'name';
      const nameRenamedTitle = `__${namePropertyKey}__`;

      it('promote a property and rename', () => {
        cy.get('@playbookOutputsAction').click();

        cy.get('do-playbook-outputs-dialog')
          .should('exist')
          .as('dialog')
          .within(() => {
            cy.get('.outputs-dialog-content__variables__editor_container__scroll-container__add-action-wrapper button')
              .should('exist')
              .as('promoteActionOutput');
            cy.dataCy('playbook-outputs-apply-action')
              .should('exist')
              .should('contain.text', 'Apply')
              .as('applyAction');
          });

        cy.get('@dialog').within(() => {
          promoteProperty(namePropertyKey);
          openEditDialogForProperty(namePropertyKey);
        });

        cy.get('.rename-property-title-dialog__wrapper').within(() => {
          cy.get('ngx-input').should('exist').as('titleInput').ngxFindLabel().should('contain.text', 'Key');

          cy.get('.btn-primary').contains('OK').as('applyRenamedTitle');

          cy.get('@titleInput').clear();
          cy.get('@applyRenamedTitle').should('be.disabled');

          cy.get('@titleInput').ngxFill(nameRenamedTitle);
          cy.get('@applyRenamedTitle').should('be.enabled').click();
        });

        cy.get('@dialog').within(() => {
          cy.get('turbine-action-outputs .node .name-actions-container').contains(nameRenamedTitle).should('exist');

          promoteProperty('is_archived');
          cy.get('turbine-action-outputs .node .name-actions-container').contains('is_archived').should('exist');
        });

        cy.get('@applyAction').click();
      });

      it('check if the property renamed in action dialog', () => {
        openActionDialog();

        cy.get('@outputsPromoted').within(() => {
          cy.get('.node.compressed .name-actions-container')
            .parent()
            .within(() => {
              cy.get('.key').contains(nameRenamedTitle).should('exist');
            });
        });
      });
    });
  });
});

import { verifyDoubleCheck } from '../../../../../functional/support/page-objects/main-app-objects/common-pieces/popupMessages';

describe('Orchestration Playbook', () => {
  let playbook;

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.fixture('integration/dynamic-orchestration/get-playbook.json').then(mockPlaybook => {
      playbook = mockPlaybook;
      cy.setupStubbedSwimlane();
      cy.setMockFeatureFlag('DynamicOrchestration');

      cy.intercept('POST', '/orchestration/api/v1/plugin/rql', {
        fixture: 'integration/dynamic-orchestration/get-plugins.json',
        statusCode: 201
      }).as('getPlugins');
      cy.intercept('POST', '/orchestration/api/v1/sensor/rql', { items: [] }).as('getSensors');
      cy.intercept('POST', '/orchestration/api/v1/asset/rql', { items: [] }).as('getAssets');
      cy.intercept('GET', `/orchestration/api/v1/playbook/${playbook.id}`, playbook).as('getPlaybook');
      cy.intercept('POST', '/orchestration/api/v1/playbook/rql', {
        items: [{ item: playbook }]
      }).as('getPlaybooks');
      cy.intercept('GET', '/orchestration/api/v1/featureflags', {
        fixture: 'integration/dynamic-orchestration/get-turbine-feature-flags.json'
      }).as('getTurbineFeatureFlags');
      cy.navigateSwimlane(`/orchestration/playbook/${playbook.id}`);

      cy.wait('@getTurbineFeatureFlags');
      cy.wait('@getEnabledFlags');
      cy.wait('@getPlaybook');
      cy.wait('@getPlaybooks');
      cy.wait('@getAssets');
      cy.wait('@getSensors');
      cy.wait('@getPlugins');
    });
  });

  beforeEach(() => {
    cy.get('.primary-nav').as('playbookNav');
    cy.get('.playbook-name').as('playbookHeader');
    cy.get('div.buttons').as('playbookEditHeader');
  });

  describe('playbook nav', () => {
    it('should exist', () => {
      cy.get('@playbookNav').should('exist');
    });

    it('should have active item playbook', () => {
      cy.get('@playbookNav').find('.active').should('exist');
    });
  });

  describe('playbook header', () => {
    it('should exist', () => {
      cy.get('@playbookHeader').should('exist');
    });

    it('should have title', () => {
      cy.get('@playbookHeader')
        .find('.playbook-name-label')
        .should('exist')
        .should('contain.text', playbook.playbook.title);
    });

    it('should have disabled save button when pristine', () => {
      cy.get('@playbookEditHeader')
        .find('[data-cy=playbook__editor-save__btn]')
        .should('exist')
        .should('have.class', 'disabled-button');
    });

    it('should show a save spinner when saving is in progress', () => {
      cy.get('@playbookEditHeader').find('[data-cy=playbook__editor-save__btn]').as('saveButton');
      // Create a promise which will stay pending until we manually resolve it, so we can test the button's pending state
      let resolvePutRequest;
      const putResponsePromise = new Promise(resolve => {
        resolvePutRequest = resolve;
      });
      cy.intercept('PUT', `/orchestration/api/v1/playbook/${playbook.id}`, async request => {
        await putResponsePromise;
        request.reply(playbook);
      }).as('putPlaybook');
      cy.get('g#new_action > .node.action').click();
      cy.get('turbine-action-config').find('[data-cy=input__action__title]').ngxFill('New action name');
      cy.get('@saveButton').click();
      cy.get('@saveButton')
        .should('have.class', 'in-progress')
        .then(() => {
          resolvePutRequest();
        });
    });

    describe('playbook view menu', () => {
      beforeEach(() => {
        cy.get('@playbookNav').find('do-playbook-menu').as('playbookEditSplitItems');
      });

      it('should be split view', () => {
        cy.get('@playbookEditSplitItems')
          .find('.active > svg > path')
          .then(path => {
            const svgData =
              'M0 0V0.916667V19.25V20.1667H0.916667H21.0833H22V19.25V0.916667V0H21.0833H0.916667H0ZM1.83333 1.83333H20.1667V3.66667H1.83333V1.83333ZM1.83333 5.5H20.1667V18.3333H1.83333V5.5Z';
            expect(path.attr('d')).to.equal(svgData);
          })
          .should('exist');

        cy.get('.code-editor').should('be.visible');

        cy.get('do-playbook-visual-editor').should('be.visible');
      });

      it('should be code view', () => {
        cy.get('@playbookEditSplitItems').find('li[tooltiptitle="Code View"]').should('exist').click();

        cy.get('@playbookEditSplitItems')
          .find('.active > svg > path')
          .then(path => {
            const svgData =
              'M0 0V0.916667V19.25V20.1667H0.916667H21.0833H22V19.25V0.916667V0H21.0833H0.916667H0ZM1.83333 1.83333H20.1667V3.66667H1.83333V1.83333ZM1.83333 5.5H20.1667V18.3333H1.83333V5.5ZM11 7.33333L9.16667 16.5H11L12.8333 7.33333H11ZM6.58854 7.70573L3.83854 11.3724L3.4375 11.9167L3.83854 12.4609L6.58854 16.1276L8.07812 15.0391L5.72917 11.9167L8.07812 8.79427L6.58854 7.70573ZM15.4115 7.70573L13.9219 8.79427L16.2708 11.9167L13.9219 15.0391L15.4115 16.1276L18.1615 12.4609L18.5625 11.9167L18.1615 11.3724L15.4115 7.70573Z';
            expect(path.attr('d')).to.equal(svgData);
          })
          .should('exist');

        cy.get('do-playbook-visual-editor').should('not.be.visible');

        cy.get('.code-editor').should('be.visible');
      });

      it('should be graph view', () => {
        cy.get('@playbookEditSplitItems').find('li[tooltiptitle="Graph View"]').should('exist').click();

        cy.get('@playbookEditSplitItems')
          .find('.active > svg > path')
          .then(path => {
            let isOk = true;
            const svgData = [
              'M0 0V0.916667V19.25V20.1667H0.916667H21.0833H22V19.25V0.916667V0H21.0833H0.916667H0ZM1.83333 1.83333H20.1667V3.66667H1.83333V1.83333ZM1.83333 5.5H20.1667V18.3333H1.83333V5.5Z',
              'M14.217 7C14.0919 7 13.9523 7.05625 13.8522 7.15625L13.001 8.00697L15.0161 10.0035L15.85 9.15283C16.0501 8.95282 16.0501 8.60837 15.85 8.45837L14.5644 7.15625C14.4638 7.05625 14.3421 7 14.217 7Z',
              'M12.5145 8.54492L6 15.0034V17H7.99777L14.4601 10.5068L12.5145 8.54492Z'
            ];
            for (let i = 0; i < path.length; i++) {
              if (path[i].getAttribute('d') !== svgData[i]) {
                isOk = false;
                break;
              }
            }
            expect(isOk).to.be.true;
          })
          .should('exist');

        cy.get('do-playbook-visual-editor').should('be.visible');

        cy.get('.code-editor').should('not.be.visible');
      });
    });

    describe('Playbook actions', () => {
      beforeEach(() => {
        cy.get('g#new_action > .node.action').as('actionNode');
      });

      describe('Action config drawer', () => {
        it('should show action config drawer', () => {
          cy.get('@actionNode').should('exist').should('be.visible');
          cy.get('@actionNode').click();
          cy.get('turbine-action-config').should('exist').should('be.visible');
        });

        it('should disable additional configuration button when no action selected', () => {
          cy.get('ngx-select').first().as('actionsDropDownList');
          cy.get('@actionsDropDownList').clear();
          cy.get('turbine-action-config .panel-footer > button').should('be.disabled');
          // Re select the List Channels, added forceDownwardOpening in template
          cy.get('@actionsDropDownList').select('List Channels', { force: true });
        });

        it('should open action additional configuration dialog', () => {
          cy.get('turbine-action-config .panel-footer > button').as('addConfBtn');
          cy.get('@addConfBtn').should('be.visible');
          cy.get('@addConfBtn').click();
        });

        describe('Action config - Output Tab', () => {
          beforeEach(() => {
            cy.get('do-playbook-action-dialog').as('actionDialog');
            cy.get('@actionDialog').find('turbine-action-outputs-promoted').as('outputsPromoted');
            cy.get('@actionDialog').find('turbine-action-outputs').as('outputsToPromote');
          });

          it('should have Output tab', () => {
            cy.get('@actionDialog').find('ngx-tabs button').eq(1).as('outputTab');
            cy.get('@outputTab').should('have.text', 'Outputs');
            cy.get('@outputTab').click();
          });

          it('should have promoted section with message', () => {
            cy.get('@outputsPromoted').should('be.visible');
            cy.get('@outputsPromoted')
              .find('div')
              .should('contain.text', 'Promote an output from the list to the left');
          });

          it('should have a list of properties to promote', () => {
            cy.get('@outputsToPromote').should('exist');
            cy.get('@outputsToPromote').find('div.node.compressed').should('be.visible');
          });

          it('should promote a property', () => {
            cy.get('@outputsToPromote').find('div.node.compressed').first().as('firstProperty');
            cy.get('@outputsPromoted').find('div.node.compressed').should('not.exist');
            cy.get('@firstProperty')
              .find('.node-options > button')
              .should('be.visible')
              .should('have.class', 'promote')
              .click();
            cy.wait(200);
            cy.get('@firstProperty').find('.node-options > button').should('not.have.class', 'promote');
            cy.get('@firstProperty')
              .find('.node-options > button')
              .should('be.visible')
              .should('have.class', 'promoted');
            cy.get('@outputsPromoted').find('div.node.compressed').should('be.visible');
          });

          it('should unpromote a property', () => {
            cy.get('@outputsPromoted').find('div.node.compressed').first().as('firstPromotedProperty');
            cy.get('@firstPromotedProperty')
              .find('.node-options > button')
              .should('be.visible')
              .should('have.class', 'promote')
              .click();
            cy.wait(200);
            cy.get('@outputsPromoted').find('div.node.compressed').should('not.exist');
          });

          it('should apply promoted properties and restore promotions', () => {
            // promoting the prop
            cy.get('@outputsToPromote').find('div.node.compressed').first().as('firstProperty');
            cy.get('@outputsPromoted').find('div.node.compressed').should('not.exist');
            cy.get('@firstProperty').find('.node-options > button').click();
            cy.wait(200);
            // checking the promotion
            cy.get('@outputsPromoted').find('div.node.compressed').should('be.visible');
            // applying the promotion
            cy.get('@actionDialog').find('ngx-large-format-dialog-footer > button.btn-primary').click();
            // editing the action
            cy.intercept('GET', `/orchestration/api/v1/playbook/${playbook.id}`, {
              fixture: 'integration/dynamic-orchestration/get-playbook-promoted-outputs.json'
            }).as('getPlaybookWithPromotedProps');
            cy.get('turbine-action-config .panel-footer > button').as('addConfBtn');
            cy.get('@addConfBtn').should('be.visible');
            cy.get('@addConfBtn').click();
            // checking if the promotions were restored
            cy.get('@actionDialog').find('ngx-tabs button').eq(1).as('outputTab');
            cy.get('@outputTab').click();
            cy.get('@firstProperty')
              .find('.node-options > button')
              .should('be.visible')
              .should('have.class', 'promoted');
            cy.get('@outputsPromoted').find('div.node.compressed').should('be.visible');
            cy.get('@actionDialog').find('ngx-large-format-dialog-footer button > span.content').click();
          });
        });
      });
    });

    describe('Condition Builder', () => {
      beforeEach(() => {
        cy.get('#edges_new_action_on-success_new_action_a9rq7 > .edge > .invisible-line').as('linkLine');
      });

      describe('Dismiss condition', () => {
        it('should open condition builder dialog when diamond contextual icon is pressed', () => {
          cy.get('@linkLine').click({ force: true });
          cy.wait(100);
          cy.get('g.context-menu-group span.condition-indicator-container').as('contextualCondButton');
          cy.get('@contextualCondButton').click();
          cy.get('do-condition-builder-dialog').as('condBuilderDialog');
          cy.get('@condBuilderDialog').should('be.visible');
          // close dialog for next test
          cy.get('@condBuilderDialog')
            .find('ngx-large-format-dialog-footer > ngx-button > button > span.content')
            .click();
        });

        it('should not show IF icon because condition was not created', () => {
          cy.get('.condition-label').should('not.exist');
        });
      });

      describe('Condition nodes', () => {
        it('should open dialog', () => {
          cy.get('@linkLine').click({ force: true });
          cy.wait(100);
          cy.get('g.context-menu-group span.condition-indicator-container').as('contextualCondButton');
          cy.get('@contextualCondButton').click();
          cy.get('do-condition-builder-dialog').should('be.visible');
        });

        describe('Add and remove conditions', () => {
          beforeEach(() => {
            cy.get('do-condition-builder-dialog').as('condBuilderDialog');
            cy.get('@condBuilderDialog')
              .find('.do-condition-group--add-container i.ngx-add-circle')
              .as('addConditionButton');
          });

          describe('Add', () => {
            it('should add conditions', () => {
              // open condition drawer
              cy.get('@addConditionButton').click();
              cy.get('.do-playbook-action-inputs-drawer').as('propertiesDrawer');
              // getting the first card
              cy.get('@propertiesDrawer').find('do-playbook-action-inputs-drawer-card ngx-card').eq(0).as('card1');
              cy.get('@propertiesDrawer').should('be.visible');
              // clicking the properties inside the card
              [1, 3, 4].forEach(val => {
                cy.get('@card1').click();
                cy.wait(1000);
                cy.get('.property__container div.ngx-checkbox--box').eq(val).click();
                cy.wait(1000);
                cy.get('@addConditionButton').click();
              });
              // 3 properties selected plus 1 empty condition node (the drawer is opened at this point)
              cy.get('.do-condition-group--conditions-wrapper .do-condition-group--conditions').should(
                'have.length',
                4
              );
            });

            describe('Property drawer', () => {
              it('should dismiss', () => {
                cy.get('do-condition-builder-dialog').as('condBuilderDialog');
                cy.get('@condBuilderDialog').should('be.visible');
                cy.get('do-condition-builder-dialog header button.ngx-dialog-drawer-content__dismiss-btn').click({
                  force: true
                });
                // 3 properties selected (the drawer was closed in the above step so there is no empty condition node anymore)
                cy.get('.do-condition-group--conditions-wrapper .do-condition-group--conditions').should(
                  'have.length',
                  3
                );
              });
            });

            describe('Error icons for nodes', () => {
              beforeEach(() => {
                cy.get('.do-condition-group--conditions-wrapper .do-condition-group--conditions').as('conditionNodes');
              });

              it('should have error icon for empty condition nodes', () => {
                cy.get('@conditionNodes').eq(0).find('ngx-input.ng-invalid').should('exist');
              });

              it('should not have error icon for empty condition nodes', () => {
                cy.get('@conditionNodes').eq(0).find('ngx-input').type('abc');
                cy.get('@conditionNodes').eq(0).find('ngx-input').should('not.have.class', 'ng-invalid');
              });
            });

            describe('Condition groups', () => {
              it('add group', () => {
                cy.get('@condBuilderDialog').find('.add-container--group i.ngx-add-circle').as('addGroupButton');
                cy.get('@addGroupButton').click();
                cy.get('.do-condition-group--add-container').should('have.length', 2);
              });

              it('add condition node into group', () => {
                cy.get('.do-condition-group--container').eq(1).as('groupContainer');
                cy.get('@groupContainer').find('.add-container--and i.ngx-add-circle').click();
                cy.get('.do-playbook-action-inputs-drawer').as('propertiesDrawer');
                // getting the first card
                cy.get('@propertiesDrawer').find('do-playbook-action-inputs-drawer-card ngx-card').eq(0).as('card1');
                cy.get('@propertiesDrawer').should('be.visible');
                // clicking the properties inside the card
                cy.get('@card1').click();
                cy.wait(1000);
                cy.get('.property__container div.ngx-checkbox--box').eq(9).click();
                cy.wait(1000);
                cy.get('@groupContainer').find('.do-condition-group--conditions').should('have.length', 1);
              });

              it('remove group', () => {
                cy.get('.do-condition-group--container').eq(1).as('groupContainer');
                cy.get('@groupContainer').find('div.header--remove .ngx-icon.ngx-x').click();
                cy.get('ngx-alert-dialog').as('deleteConfirmation');
                cy.get('@deleteConfirmation').should('exist');
                cy.get('@deleteConfirmation').find('.ngx-dialog-footer button.btn-primary').click();
                cy.get('.do-condition-group--add-container').should('have.length', 1);
              });
            });

            describe('Condition nodes values', () => {
              beforeEach(() => {
                cy.get('.do-condition-group--conditions-wrapper .do-condition-group--conditions').as('conditionNodes');
              });

              describe('String condition node', () => {
                beforeEach(() => {
                  cy.get('@conditionNodes').eq(0).as('stringNode');
                });

                it('should change comparison operator', () => {
                  cy.get('@stringNode').find('ngx-select').as('selector');
                  cy.get('@selector').should('have.text', 'Matches');
                  // opening dropdown options
                  cy.get('@selector').click();
                  // selecting new option
                  cy.get('@selector').find('ul > li').contains('Does not match').click();
                  // checking selection
                  cy.get('@selector').should('have.text', 'Does not match');
                });

                it('should change value', () => {
                  cy.get('@stringNode').find('input.ngx-input-box').as('input');
                  cy.get('@input').should('have.value', 'abc');
                  cy.get('@input').clear();
                  cy.get('@input').type('test');
                  cy.get('@input').should('have.value', 'test');
                });
              });

              describe('Numeric condition node', () => {
                beforeEach(() => {
                  cy.get('@conditionNodes').eq(1).as('numericNode');
                });

                it('should change comparison operator', () => {
                  cy.get('@numericNode').find('ngx-select').as('selector');
                  cy.get('@selector').should('have.text', 'Is equal to');
                  // opening dropdown options
                  cy.get('@selector').click();
                  // selecting new option
                  cy.get('@selector').find('ul > li').contains('Is less than').click();
                  // checking selection
                  cy.get('@selector').should('have.text', 'Is less than');
                });

                it('should change value', () => {
                  cy.get('@numericNode').find('input.ngx-input-box').as('input');
                  cy.get('@input').should('have.value', '0');
                  cy.get('@input').clear();
                  cy.get('@input').type('100');
                  cy.get('@input').should('have.value', '100');
                });
              });

              describe('Boolean condition node', () => {
                beforeEach(() => {
                  cy.get('@conditionNodes').eq(2).as('booleanNode');
                });

                it('should change comparison operator', () => {
                  cy.get('@booleanNode').find('ngx-select').as('selector');
                  cy.get('@selector').should('have.text', 'Is false');
                  // opening dropdown options
                  cy.get('@selector').click();
                  // selecting new option
                  cy.get('@selector').find('ul > li').contains('Is true').click();
                  // checking selection
                  cy.get('@selector').should('have.text', 'Is true');
                });
              });
            });
          });

          describe('Remove', () => {
            it('should remove condition', () => {
              cy.get('.do-condition-group--conditions-wrapper .do-condition-group--conditions').as('conditionNodes');
              cy.get('@conditionNodes').eq(2).as('conditionNode');
              cy.get('@conditionNodes').should('have.length', 3);
              cy.get('@conditionNode').find('.condition--remove').click();
              cy.get('@conditionNodes').should('have.length', 2);
            });
          });
        });
      });

      describe('Save and restore conditions', () => {
        it('should save condition', () => {
          cy.get('do-condition-builder-dialog').as('condBuilderDialog');
          cy.get('@condBuilderDialog').should('be.visible');
          cy.get('do-condition-builder-dialog ngx-large-format-dialog-footer button.btn-primary').click({
            force: true
          });
          cy.get('@condBuilderDialog').should('not.exist');
        });

        it('should restore condition', () => {
          // open cond dialog
          cy.get('@linkLine').click({ force: true });
          cy.wait(100);
          cy.get('g.context-menu-group .ngx-edit-outline-small').as('editCondButton');
          cy.get('@editCondButton').click();
          cy.get('do-condition-builder-dialog').should('be.visible');

          cy.get('.do-condition-group--conditions-wrapper .do-condition-group--conditions').as('conditionNodes');
          cy.get('@conditionNodes').should('have.length', 2);
          cy.get('do-condition-builder-dialog ngx-large-format-dialog-footer > ngx-button > button > span.content').click();
        });
      });

      describe('Diamond and pencil icons', () => {
        it('should open condition builder dialog when pencil contextual icon is pressed', () => {
          cy.get('@linkLine').click({ force: true }); //aaaaa
          cy.wait(100);
          cy.get('g.context-menu-group .ngx-edit-outline-small').as('editCondButton');
          cy.get('@editCondButton').click();
          cy.get('do-condition-builder-dialog').as('condBuilderDialog');
          cy.get('@condBuilderDialog').should('be.visible');
          // close dialog for next test
          cy.get('@condBuilderDialog')
            .find('ngx-large-format-dialog-footer > ngx-button > button > span.content')
            .click();
        });

        it('should show the diamond icon for condition', () => {
          cy.get('.condition-label').as('ifIcon');
          cy.get('@ifIcon').should('be.visible');
          cy.get('@ifIcon').contains(' IF ');
        });

        it('should remove the diamond icon for condition', () => { //ccccc
          cy.get('g.context-menu-group span.condition-indicator-container').as('contextualCondButton');
          cy.get('@contextualCondButton').click();
          verifyDoubleCheck('Are you sure?', `This will remove the applied conditions.`);
          cy.get('.condition-label').should('not.exist');
        });
      });

    });
  });

  after(() => {
    playbook = undefined;
  });
});

// TODO (caleb) unskip tests when updating selectors
describe('Orchestration', { tags: ['#bug'] }, () => {
  describe('Feature enabled', () => {
    before(() => {
      cy.login();
      cy.setupStubbedSwimlane();
      cy.setMockFeatureFlag('DynamicOrchestration');
      cy.navigateSwimlane('/orchestration');
      cy.wait('@getEnabledFlags');
    });

    describe('Nav bar', () => {
      it('Nav bar has PLAYBOOKS, ASSETS, PLUGINS', () => {
        const navLabels = [
          'PLAYBOOKS',
          // 'EVENT STREAMS',  // SPT-13435: Hide event stream - Add it in the test name once the comment is removed
          'ASSETS',
          'PLUGINS'
        ];
        cy.get('.ngx-tabs-list > li').each((el, indx) => {
          cy.wrap(el).should('contain', navLabels[indx]);
        });
      });

      it('Clicking on a tab changes it to active and goes to appropriate route', () => {
        cy.get('.ngx-tabs-list > li').contains('PLAYBOOKS').click();
        cy.get('.ngx-tabs-list > li.active').should('contain', 'PLAYBOOKS');
        cy.location('pathname').should('equal', '/orchestration/playbooks');

        // SPT-13435: Hide event stream
        /*cy.get('.ngx-tabs-list > li').contains('EVENT STREAMS').click();
        cy.get('.ngx-tabs-list > li.active').should('contain', 'EVENT STREAMS');
        cy.location('pathname').should('equal', '/orchestration/eventstreams');*/

        cy.get('.ngx-tabs-list > li').contains('ASSETS').click();
        cy.get('.ngx-tabs-list > li.active').should('contain', 'ASSETS');
        cy.location('pathname').should('equal', '/orchestration/assets');

        cy.get('.ngx-tabs-list > li').contains('PLUGINS').click();
        cy.get('.ngx-tabs-list > li.active').should('contain', 'PLUGINS');
        cy.location('pathname').should('equal', '/orchestration/plugins');
      });
    });
  });

  describe('Feature disabled', () => {
    before(() => {
      cy.login();
      cy.setupStubbedSwimlane();
      cy.navigateSwimlane('/orchestration', { forceReload: true });
      cy.wait('@getEnabledFlags');
    });

    it('Cannot reach orchestration page when feature is disabled', () => {
      cy.location('pathname').should('equal', '/error');

      cy.navigateSwimlane('/orchestration/playbooks');
      cy.location('pathname').should('equal', '/error');

      // SPT-13435: Hide event stream
      /*cy.navigateSwimlane('/orchestration/eventstreams');
      cy.location('pathname').should('equal', '/error');*/

      cy.navigateSwimlane('/orchestration/assets');
      cy.location('pathname').should('equal', '/error');

      cy.navigateSwimlane('/orchestration/plugins');
      cy.location('pathname').should('equal', '/error');
    });
  });
});

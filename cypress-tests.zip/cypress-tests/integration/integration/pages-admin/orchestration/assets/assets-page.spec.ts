describe.skip('Orchestration Assets', { tags: ['#bug'] }, () => {
  describe('No assets', () => {
    before(() => {
      cy.login();
      cy.setupStubbedSwimlane();
      cy.setMockFeatureFlag('DynamicOrchestration');
      cy.intercept('/orchestration/api/v1/asset', { items: [] }).as('getAssets');
      cy.intercept('POST', '/orchestration/api/v1/pool/rql', { items: [] }).as('getPools');
      cy.intercept('POST', '/orchestration/api/v1/plugin/rql', { items: [] }).as('getPlugins');

      cy.navigateSwimlane('/orchestration/assets');
      cy.wait('@getEnabledFlags');
      cy.wait('@getAssets');
      cy.wait('@getPools');
      cy.wait('@getPlugins');
    });

    it('No asset dialog displays on page', () => {
      cy.get('.do-page-no-elements__icon ').should('exist');
      cy.get('.do-page-no-elements__header').should('contain', 'Start by creating your first asset');
      cy.get('.do-page-no-elements__content').should(
        'contain',
        'Assets are reusable, structured, and vendor-specific objects'
      );
      cy.get('.do-page-no-elements__illustration').should('exist');
      cy.get('.do-page-no-elements__connect').should('exist').should('have.css', 'cursor', 'pointer');
    });
  });

  describe('With Assets', () => {
    before(() => {
      // add mock asset data
      cy.login();
      cy.setupStubbedSwimlane();
      cy.setMockFeatureFlag('DynamicOrchestration');
      cy.intercept('/orchestration/api/v1/asset', {
        fixture: 'integration/dynamic-orchestration/get-assets.json'
      }).as('getAssets');
      cy.intercept('POST', '/orchestration/api/v1/pool/rql', {
        fixture: 'integration/dynamic-orchestration/get-pools.json'
      }).as('getPools');
      cy.intercept('POST', '/orchestration/api/v1/plugin/rql', {
        fixture: 'integration/dynamic-orchestration/get-plugins.json'
      }).as('getPlugins');

      cy.reloadSwimlane();
      cy.wait('@getEnabledFlags');
      cy.wait('@getAssets');
      cy.wait('@getPools');
      cy.wait('@getPlugins');
    });

    describe('asset cards', () => {
      it('shows asset cards list', () => {
        cy.get('ngx-card').should('have.length', 1);
      });
    });

    describe('Create Asset Dialog', () => {
      it('should open dialog', () => {
        cy.get('.do-page__add-button > .ngx-icon').should('exist').click();
        cy.get('do-asset-create-dialog').should('exist');
      });

      it('should have all asset plugin items when not filtered', () => {
        cy.get('.do-modal-dialog__item-selection-list ngx-card').should('have.length', 7);
      });

      it('should have matching asset plugin item when filtered', () => {
        cy.get('.do-modal-dialog__item-selection-search-bar .ngx-input-box').focus().type('imap');
        cy.get('.do-modal-dialog__item-selection-list ngx-card').should('have.length', 1);
      });

      it('should clear search input and show all asset plugin items', () => {
        cy.get('.do-modal-dialog__item-selection-search-bar .ngx-input  ngx-input-suffix').click();
        cy.get('.do-modal-dialog__item-selection-list ngx-card').should('have.length', 7);
      });

      it('should select asset plugin', () => {
        cy.get('.do-modal-dialog__item-selection-list ngx-card:first').click();
        cy.get('ngx-card').should('exist');
      });

      it('should go back to previous step on border button click', () => {
        cy.get('.ngx-card--outline-text .inner-text').click();
        cy.get('.do-modal-dialog__item-selection-search-bar .ngx-input-box').should('exist');
        cy.get('.do-modal-dialog__item-selection-list ngx-card:first').click();
      });

      it('should disable submit and test button when form is invalid', () => {
        cy.get('.ngx-large-format-dialog-footer .btn-primary').should('be.disabled');

        cy.get('.do-dialog-details-form__inputs-wrapper input[type=text]').first().focus().type('testing123');

        cy.get('.ngx-large-format-dialog-footer .btn-primary').should('be.enabled');

        cy.get('.do-dialog-details-form__inputs-wrapper input[type=text]').first().focus().clear().type('*');

        cy.get('.ngx-large-format-dialog-footer .btn-primary').should('be.disabled');
        cy.get('.ngx-large-format-dialog-footer .btn-bordered button').should('be.disabled');
        cy.get('.ngx-large-format-dialog-header-action__button').click();
      });
    });

    describe('Edit Asset Dialog', () => {
      it('should open dialog', () => {
        cy.get('ngx-card').eq(0).click();
        cy.get('do-asset-edit-dialog').should('exist');
      });

      it('should disable submit and test button when form is invalid', () => {
        cy.get('.ngx-large-format-dialog-footer .btn-primary').should('be.disabled');
        cy.get('.do-dialog-details-form__inputs-wrapper input[type=text]').eq(1).as('assetNameInput');
        cy.get('@assetNameInput').should('be.disabled');
        cy.get('.ngx-input__lock-toggle').click();
        cy.get('@assetNameInput').should('be.enabled');
        cy.get('@assetNameInput').focus().type(' ');

        cy.get('.ngx-large-format-dialog-footer .btn-primary').should('be.disabled');
        cy.get('.ngx-large-format-dialog-footer .btn-bordered button').should('be.disabled');

        cy.get('@assetNameInput').focus().clear().type('testing123');
      });

      it('should have valid asset title', () => {
        cy.get('.ngx-card .ngx-card-title').should('contain.text', 'testing123');
      });
    });
  });
});

/// <reference types="Cypress" />

import { getLoremText } from '../../support/helpers/faker-helper';

describe('Admin pages', () => {
  before(() => {
    cy.login();

    cy.setupStubbedSwimlane();
  });

  describe('as admin', () => {
    describe('Apps Page', () => {
      before(() => {
        cy.navigateSwimlane('/apps');
      });

      describe('toolbar', () => {
        beforeEach(() => {
          cy.get('.ngx-plus-menu').as('navbar-apps');
        });

        it('has header', () => {
          cy.get('.ngx-toolbar-title').should('contain', 'Applications & Applets');
        });

        it('has controls', () => {
          cy.get('@navbar-apps').find('.ngx-plus-menu--circle-container').should('be.visible');
        });

        it('open shows new controls', () => {
          cy.get('@navbar-apps').find('.ngx-plus-menu--circle-container').click();
          cy.get('@navbar-apps')
            .find('.ngx-plus-menu--item')
            .contains('Import applications and applets')
            .should('be.visible');
          cy.get('@navbar-apps').find('.ngx-plus-menu--item').contains('Create a new application').should('be.visible');
          cy.get('@navbar-apps').find('.ngx-plus-menu--item').contains('Create a new applet').should('be.visible');
        });

        describe('new controls', () => {
          describe('new application dialog', () => {
            const loremText = getLoremText(130);

            before(() => {
              cy.get('.ngx-plus-menu').as('navbar-apps');
              cy.get('@navbar-apps').find('.ngx-plus-menu--item').contains('Create a new application').click();
            });

            it('shows dialog', () => {
              cy.get('.help-banner h2').should('contain', 'Create Application');
            });

            describe('name input', () => {
              beforeEach(() => {
                cy.get('input#input-name').as('name');
              });

              it('limits application name to 128 chars', () => {
                cy.get('@name').clear().type(loremText, { delay: 0 });

                cy.get('@name').should('have.value', loremText.slice(0, 128));
              });

              it('shows errors on inputs larger than 128 characters', () => {
                cy.get('@name').should('have.class', 'ng-valid');

                cy.get('@name').invoke('prop', 'value', loremText).trigger('input');

                cy.get('@name').should('have.class', 'ng-invalid');
              });
            });

            after(() => {
              cy.get('.icon-x').click();
            });
          });
        });
      });

      describe('apps list', () => {
        it('has list', () => {
          cy.get('.apps-list').should('be.visible');
        });
      });
    });

    describe('Users Page', () => {
      before(() => {
        cy.navigateSwimlane('/users');
      });

      it('toolbar', () => {
        cy.get('.ngx-toolbar').should('contain', 'Users').should('contain', 'New User');
      });
    });

    describe('Groups Page', () => {
      before(() => {
        cy.navigateSwimlane('/groups');
      });

      it('toolbar', () => {
        cy.get('ngx-toolbar').should('contain', 'Groups').should('contain', 'New Group');
      });
    });

    describe('Settings Page', () => {
      before(() => {
        cy.navigateSwimlane('/settings');
      });

      it('toolbar', () => {
        cy.get('.ngx-toolbar').should('contain', 'Settings');
      });
    });
  });

  describe('As non-admin', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.setMockFeatureFlag('DynamicOrchestration');
      // Reset login to a limited user
      cy.intercept('/api/user/authorize', {
        fixture: 'mocks/swimlane/user/authorize/get-user.json'
      }).as('GET:user/authorize');
      cy.navigateSwimlane(`/apps`, { forceReload: true });
      cy.wait('@getEnabledFlags');
    });

    describe('Apps Page', () => {
      describe('toolbar', () => {
        beforeEach(() => {
          cy.get('.ngx-plus-menu').as('navbar-apps');
        });

        it('has header', () => {
          cy.get('.ngx-toolbar-title').should('contain', 'Applications & Applets');
        });

        it('has controls', () => {
          cy.get('@navbar-apps').find('.ngx-plus-menu--circle-container').should('be.visible');
        });

        it('open shows new controls', () => {
          cy.get('@navbar-apps').find('.ngx-plus-menu--circle-container').click();
          cy.get('@navbar-apps').find('.ngx-plus-menu--item').should('have.length', 2);
          cy.get('@navbar-apps').find('.ngx-plus-menu--item').contains('Create a new application').should('be.visible');
          cy.get('@navbar-apps').find('.ngx-plus-menu--item').contains('Create a new applet').should('be.visible');
          cy.get('@navbar-apps').find('.ngx-plus-menu--circle-container').click();
        });
      });

      describe('apps list', () => {
        it('has list', () => {
          cy.get('.apps-list').should('be.visible');
        });

        it('no export in app-controls', () => {
          cy.get('.app-tools')
            .first()
            .click()
            .within(() => {
              cy.get('.ngx-dropdown-menu li').should('have.length', 8);
            });
        });
      });
    });

    describe('Users Page', () => {
      before(() => {
        cy.navigateSwimlane('/users');
      });

      it('error-page', () => {
        cy.get('.error-page').should('contain', 'Unauthorized Access');
      });
    });

    describe('Groups Page', () => {
      before(() => {
        cy.navigateSwimlane('/groups');
      });

      it('error-page', () => {
        cy.get('.error-page').should('contain', 'Unauthorized Access');
      });
    });

    describe('Settings Page', () => {
      before(() => {
        cy.navigateSwimlane('/settings');
      });

      it('error-page', () => {
        cy.get('.error-page').should('contain', 'Unauthorized Access');
      });
    });

    describe('Orchestration Pages', () => {
      [
        'agents',
        'playbooks',
        // 'eventstreams',  // SPT-13435: Hide event stream
        'webhooks',
        'assets',
        'runs',
        'connectors',
        'events'
      ].forEach(orchestrationRoute => {
        it(`should not allow access to /orchestration/${orchestrationRoute}`, () => {
          cy.navigateSwimlane(`/orchestration/${orchestrationRoute}`);
          cy.get('.error-page').should('contain', 'Unauthorized Access');
        });
      });
    });
  });
});

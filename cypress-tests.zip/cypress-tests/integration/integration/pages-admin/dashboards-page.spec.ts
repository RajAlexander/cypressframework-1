describe('Dashboards Page', () => {
  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.navigateSwimlane('/dashboards');
    cy.wait('@GET:scheduled/dashboard');
    cy.wait('@GET:dashboard/status/workspace/aP6rDZMhfXU0550sc');
  });

  describe('as admin', () => {
    it('shows the content toolbar', () => {
      cy.get('.ngx-toolbar').should('contain', 'Dashboards').should('contain', 'New Dashboard');
    });

    it('has correct column names', () => {
      cy.get('.datatable-header-cell-wrapper').first().should('have.text', 'Name');
      cy.get('.datatable-header-cell-wrapper').eq(1).should('have.text', 'Description');
      cy.get('.datatable-header-cell-wrapper').eq(2).should('have.text', 'Created');
      cy.get('.datatable-header-cell-wrapper').eq(3).should('have.text', 'Personal Dashboard');
      cy.get('.datatable-header-cell-wrapper').eq(4).should('have.text', 'Schedules');
    });

    describe('scheduled dashboard actions', () => {
      beforeEach(() => {
        cy.get('.main.dashboards').find('ngx-section').first().as('dashboard-1');
        cy.get('@dashboard-1').find('datatable-body-row').first().as('dash-1');
        cy.get('@dash-1').find('.badge-container').as('container');
        cy.get('@container').find('.badge').first().as('schedule-1');
      });

      it('should display scheduled dashboard pill', () => {
        cy.get('@schedule-1').should('contain', 'Recurs');
        cy.get('@container').find('.badge').eq(2).should('contain', 'One Time');
      });

      it('should open scheduled dashboard details dialog', () => {
        cy.get('@schedule-1').click();
        cy.get('.schedule-report-dialog').should('be.visible');
        cy.get('.dialog-footer').within(() => {
          cy.get('.btn').first().should('contain', 'Close').click();
        });
        cy.get('.schedule-report-dialog').should('not.exist');
      });

      it('should open delete scheduled report dialog', () => {
        cy.get('@schedule-1').find('.ngx-x').click();
        cy.get('.confirm').within(() => {
          cy.get('.btn').first().should('contain', 'Delete');
          cy.get('.btn').eq(1).click();
        });
        cy.get('.confirm').should('not.exist');
      });
    });

    describe('reports tab on nav bar', () => {
      it('should display schedule status icon on nav bar', () => {
        cy.get('.nav-items').find('.nav-item-container').eq(1).as('dashboard-nav').click();
        cy.get('@dashboard-nav')
          .find('.dashboards > div.ng-star-inserted > .vertical-list > li.ng-star-inserted')
          .as('dashboards');
        cy.get('@dashboards').first().find('.sub-nav-item > .schedule-enabled').should('be.visible');
        cy.get('@dashboards').eq(1).find('.sub-nav-item > .schedule-disabled').should('be.visible');
        cy.get('@dashboards').last().find('.sub-nav-item > .schedule-disabled').should('not.exist');
        cy.get('@dashboards').last().find('.sub-nav-item > .schedule-enabled').should('not.exist');
      });
    });

    it('shows the dashboard tables', () => {
      cy.get('.main.dashboards').find('ngx-section').as('workspaces');
      cy.get('@workspaces').should('have.length', 3);
      cy.get('@workspaces').first().as('workspace-1');
      cy.get('@workspace-1').find('header').should('contain', 'Workspace 1');
      cy.get('@workspace-1').find('datatable-body-row').as('rows');
      cy.get('@rows').should('have.length', 2);
      cy.get('@rows').first().should('contain', 'Dashboard 1');
      cy.get('@rows').last().should('contain', 'Dashboard 2');
    });

    describe('new dashboard', () => {
      before(() => {
        cy.get('.ngx-toolbar').find('.btn').contains('New Dashboard').click();
      });

      after(() => {
        cy.get('body').then($body => {
          if ($body.find('ngx-dialog .icon-x').length) {
            cy.get('ngx-dialog .icon-x').click();
          }
        });
      });

      beforeEach(() => {
        cy.get('.ngx-dialog ngx-tabs').as('tabs');
        cy.get('@tabs').find('.ngx-tabs-list').find('button').contains('General').as('general-tab');
        cy.get('@tabs').find('.ngx-tabs-list').find('button').contains('Advanced').as('advanced-tab');
        cy.get('@tabs').find('.ngx-tabs-list').find('button').contains('Permissions').as('permissions-tab');
      });

      it('opens new dashboard dialog', () => {
        cy.get('ngx-dialog').should('contain', 'New Dashboard');
        cy.get('@general-tab').should('have.class', 'active');
      });

      it('starts with general tab active', () => {
        cy.get('@general-tab').should('have.class', 'active');
      });

      it('opens advanced tab', () => {
        cy.get('@advanced-tab').click();
        cy.get('@advanced-tab').should('have.class', 'active');
      });

      describe('permissions tab', () => {
        before(() => {
          cy.get('.ngx-dialog ngx-tabs').find('.ngx-tabs-list').contains('button', 'Permissions').click();
        });

        it('opens permissions tab', () => {
          cy.get('@permissions-tab').should('have.class', 'active');
          cy.get('.ngx-toggle').should('not.have.class', 'disabled');
        });
      });

      describe('general tab', () => {
        before(() => {
          cy.get('.ngx-dialog ngx-tabs').find('.ngx-tabs-list').contains('button', 'General').click();
        });

        it('opens general tab', () => {
          cy.get('@general-tab').should('have.class', 'active');
        });

        it('can save', () => {
          cy.setupStubbedSwimlane();
          cy.get('.ngx-input-box').first().type('Dashboard 4');

          cy.get('.ngx-tab-content ngx-tab').first().find('.ngx-select-caret').click({ force: true });
          cy.get('.ngx-select-dropdown-options li').first().click();
          cy.get('.ngx-tab-content ngx-tab').first().find('.ngx-select-caret').click({ force: true });

          cy.get('state-save-button ngx-button').click();
          cy.wait('@POST:dashboard');
        });
      });
    });
  });

  describe('updates dashboard', () => {
    before(() => {
      cy.setupStubbedSwimlane();
    });
    it('displays recently added dashboard', () => {
      cy.get('.main.dashboards').find('ngx-section').as('workspaces');
      cy.get('@workspaces').should('have.length', 3);
      cy.get('@workspaces').first().as('workspace-1');
      cy.get('@workspace-1').find('header').should('contain', 'Workspace 1');
      cy.get('@workspace-1').find('datatable-body-row').as('rows');
      cy.get('@rows').should('have.length', 3);
      cy.get('@rows').eq(0).should('contain', 'Dashboard 1');
      cy.get('@rows').eq(1).should('contain', 'Dashboard 2');
      cy.get('@rows').eq(2).should('contain', 'Dashboard 4');
    });
  });

  describe('as user', () => {
    before(() => {
      cy.setupStubbedSwimlane();

      // Reset login to a limited user
      cy.intercept('/api/user/authorize', {
        fixture: 'mocks/swimlane/user/authorize/get-user.json'
      }).as('GET:user/authorize');
      cy.navigateSwimlane(`/dashboards`, { forceReload: true });
    });

    it('shows content toolbar', () => {
      cy.get('.ngx-toolbar').should('contain', 'Dashboards').should('contain', 'New Dashboard');
    });

    describe('new dashboard', () => {
      before(() => {
        cy.get('.ngx-toolbar').find('.btn').contains('New Dashboard').click();
      });

      beforeEach(() => {
        cy.get('.ngx-dialog ngx-tabs').as('tabs');
        cy.get('@tabs').find('.ngx-tabs-list').find('button').contains('General').as('general-tab');
        cy.get('@tabs').find('.ngx-tabs-list').find('button').contains('Advanced').as('advanced-tab');
        cy.get('@tabs').find('.ngx-tabs-list').find('button').contains('Permissions').as('permissions-tab');
      });

      after(() => {
        cy.get('body').then($body => {
          if ($body.find('ngx-dialog .icon-x').length) {
            cy.get('ngx-dialog .icon-x').click();
          }
        });
      });

      it('opens new dashboard dialog', () => {
        cy.get('ngx-dialog').should('contain', 'New Dashboard');
        cy.get('@general-tab').should('have.class', 'active');
      });

      it('start with general tab active', () => {
        cy.get('@general-tab').should('have.class', 'active');
      });

      it('opens advanced tab', () => {
        cy.get('@advanced-tab').click();
        cy.get('@advanced-tab').should('have.class', 'active');
      });

      it('should open permissions tab', () => {
        cy.get('@permissions-tab').click();
        cy.get('@permissions-tab').should('have.class', 'active');
      });

      describe('permissions tab', () => {
        before(() => {
          cy.get('.ngx-tabs-list').find('button').contains('Permissions').parent().as('permissions-tab');
          cy.get('@permissions-tab').click();
        });

        it('opens permissions tab', () => {
          cy.get('@permissions-tab').should('have.class', 'active');
          cy.get('.ngx-toggle').should('have.class', 'disabled');
        });
      });
    });
  });
});

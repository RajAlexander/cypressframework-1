import { dom } from '@swimlane/cy-dom-diff';

const NGCLASS = /c\d+-\d+/;

describe('Settings Page', () => {
  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.intercept('/api/settings/features', [
      {
        id: 'ScheduledReports',
        disabled: false,
        system: false
      }
    ]).as('getFeatureFlags');
    cy.navigateSwimlane('/settings');
    cy.wait('@getFeatureFlags');
  });

  it('has a toolbar', () => {
    cy.get('.ngx-toolbar').should('contain', 'Settings');
  });

  it('shows items', () => {
    cy.get('.grid-item').should('have.length', 7);
    cy.get('.grid-item-logs').domMatch(
      dom` <ngx-icon fonticon="alert">
          <i class="ng-star-inserted ngx ngx-alert ngx-icon"></i>
        </ngx-icon>
        <h1>Logs</h1>
        <small>View and Configure Swimlane Logs</small>`,
      { ignoreAttributes: ['ng-reflect-ng-class', 'ng-reflect-font-icon'] }
    );

    cy.get('.grid-item-metrics').domMatch(
      dom` <ngx-icon fonticon="chart-bar-bar">
          <i class="ng-star-inserted ngx ngx-chart-bar-bar ngx-icon"></i>
        </ngx-icon>
        <h1>Usage Metrics</h1>
        <small> Cost Savings: $15 </small>`,
      { ignoreAttributes: ['ng-reflect-ng-class', 'ng-reflect-font-icon'] }
    );

    cy.get('.grid-item-sessions').domMatch(
      dom`<ngx-icon fonticon="lock">
          <i class="ng-star-inserted ngx ngx-icon ngx-lock"></i>
        </ngx-icon>
        <h1>Sessions & Security</h1>
        <small> Session Timeout: 4 hours </small>`,
      { ignoreAttributes: ['ng-reflect-ng-class', 'ng-reflect-font-icon'] }
    );

    cy.get('.grid-item-email').domMatch(
      dom`<ngx-icon fonticon="mail">
          <i class="ng-star-inserted ngx ngx-icon ngx-mail"></i>
        </ngx-icon>
        <h1>Email and PDF Settings</h1>
        <small> Outgoing Mail Settings & Formatting </small>`,
      { ignoreAttributes: ['ng-reflect-ng-class', 'ng-reflect-font-icon'] }
    );

    cy.get('.grid-item-jobs').domMatch(
      dom`<ngx-icon fonticon="integrations">
          <i class="ng-star-inserted ngx ngx-icon ngx-integrations"></i>
        </ngx-icon>
        <h1>Background Jobs</h1>
        <small> Hangfire Dashboards </small>`,
      { ignoreAttributes: ['ng-reflect-ng-class', 'ng-reflect-font-icon'] }
    );

    cy.get('.grid-item-docs').domMatch(
      dom`<ngx-icon fonticon="document">
          <i class="ng-star-inserted ngx ngx-document ngx-icon"> </i>
        </ngx-icon>
        <h1>API Docs</h1>
        <small> Swimlane Platform API </small>`,
      { ignoreAttributes: ['ng-reflect-ng-class', 'ng-reflect-font-icon'] }
    );

    cy.get('.grid-item-features').domMatch(
      dom`<ngx-icon fonticon="star-filled">
          <i class="ng-star-inserted ngx ngx-star-filled ngx-icon"> </i>
        </ngx-icon>
        <h1>Features</h1>
        <small> Enable or disable features </small>`,
      { ignoreAttributes: ['ng-reflect-ng-class', 'ng-reflect-font-icon'] }
    );
  });

  describe('logs', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.get('.grid-item-logs').click();
      cy.wait('@POST:logging/recent');
    });

    it('shows page title', () => {
      cy.get('[data-cy=logging-page__title]').should('contain', 'Logging');
    });

    it('shows table header', () => {
      cy.get('[data-cy=logging-page__table-header]').within(() => {
        cy.get('th').first().should('contain', 'Timestamp');
        cy.get('th').eq(1).should('contain', 'Level');
        cy.get('th').last().should('contain', 'Message');
      });
    });

    it('shows filter options', () => {
      cy.get('[data-cy=logging-page__filter-options-section]').within(() => {
        cy.get('[data-cy=logging-page__expanded-mode-filter]').should('have.text', 'Expanded mode');
        cy.get('[data-cy=logging-page__jump-to-date-filter]')
          .should('contain', ' Jump to date')
          .click()
          .within(() => {
            cy.get('[data-cy=logging-page__jump-to-date-calendar]').should('be.visible');
          });
        cy.get('[data-cy=logging-page__jump-to-date-filter]').click();
        cy.get('[data-cy=logging-page__level-filter]')
          .should('contain', ' Filter by Level')
          .click({ multiple: true })
          .within(() => {
            cy.get('[data-cy=logging-page__level-filter]').should('be.visible');
            cy.get('[data-cy=logging-page__level-filter-cancel-btn]').click();
          });
        cy.get('[data-cy=logging-page__refresh-option]')
          .should('have.class', 'refresh-header')
          .within(() => {
            cy.get('ngx-icon[fontIcon="refresh"]').should('be.visible');
          });
      });
    });

    it('shows table content', () => {
      cy.get('table tbody tr').should('have.length', 27);
    });

    after(() => {
      cy.go('back');
    });
  });

  describe('metrics', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.get('.grid-item-metrics').click();
      cy.wait('@POST:usage/stats');
    });

    it('should show header', () => {
      cy.get('h1').should('contain', 'Usage Metrics: Dashboard');
    });

    it('has a number chart', () => {
      cy.get('ngx-charts-number-card').within(() => {
        cy.get('g[ngx-charts-card]').should('have.length', 4);

        cy.get('g[ngx-charts-card]')
          .eq(0)
          .within(() => {
            cy.get('foreignObject').domMatch(dom`<p
              style="color: rgb(211, 212, 215); font-size: 15px; line-height: 15px;"
            >
              Automations Performed
              <br />
              <small class="number-card-label"> This Month </small>
            </p>`);
            cy.get('text').should('contain', 4);
          });

        cy.get('g[ngx-charts-card]')
          .eq(1)
          .within(() => {
            cy.get('foreignObject').domMatch(dom`<p
              style="color: rgb(211, 212, 215); font-size: 15px; line-height: 15px;"
            >
              Records Created
              <br />
              <small class="number-card-label"> This Month </small>
            </p>`);
            cy.get('text').should('contain', 5);
          });

        cy.get('g[ngx-charts-card]')
          .eq(2)
          .within(() => {
            cy.get('foreignObject').domMatch(dom`<p
              style="color: rgb(211, 212, 215); font-size: 15px; line-height: 15px;"
            >
              Hours Saved
              <br />
              <small class="number-card-label"> This Month </small>
            </p>`);
            cy.get('text').should('contain', '0:11');
          });

        cy.get('g[ngx-charts-card]')
          .eq(3)
          .within(() => {
            cy.get('foreignObject').domMatch(dom`<p
              style="color: rgb(211, 212, 215); font-size: 15px; line-height: 15px;"
            >
              Cost Savings
              <br />
              <small class="number-card-label"> This Month </small>
            </p>`);
            cy.get('text').should('contain', '$15');
          });
      });
    });

    it('has a bar chart', () => {
      cy.get('ngx-charts-bar-vertical-2d').should('exist');
    });

    it('has a tree map', () => {
      cy.get('ngx-charts-tree-map').should('exist');
      cy.get('ngx-charts-tree-map foreignObject').domMatch(
        dom`<p style="color: rgb(213, 209, 222); height: 480px; width: ${/\d+/}px;">
          <span class="treemap-label"> No Application </span>
          <br />
          <span class="ng-star-inserted treemap-val" ngx-charts-count-up=""> 11m 51s </span>
        </p>`,
        {
          ignoreAttributes: ['ng-reflect-count-to', 'ng-reflect-value-formatting']
        }
      );
    });

    it('has a data table', () => {
      cy.get('ngx-datatable').should('exist');
      cy.get('ngx-datatable').within(() => {
        cy.get('.datatable-header-cell-label').eq(0).should('contain', 'Task');
        cy.get('.datatable-header-cell-label').eq(1).should('contain', 'Type');
        cy.get('.datatable-header-cell-label').eq(2).should('contain', 'Applications');
        cy.get('.datatable-header-cell-label').eq(3).should('contain', 'Executions');
        cy.get('.datatable-header-cell-label').eq(4).should('contain', 'Avg Execution Time (s)');
        cy.get('.datatable-header-cell-label').eq(5).should('contain', 'Avg Time Savings');
        cy.get('.datatable-header-cell-label').eq(6).should('contain', 'Avg Cost Savings ($)');
        cy.get('.datatable-row-center')
          .eq(1)
          .within(() => {
            cy.get('datatable-body-cell').eq(0).should('contain', 'QAE2E- email output Centralized');
            cy.get('datatable-body-cell').eq(1).should('contain', 'integration');
            cy.get('datatable-body-cell').eq(2).should('contain', 'No Application');
            cy.get('datatable-body-cell').eq(3).should('contain', '1');
            cy.get('datatable-body-cell').eq(4).should('contain', '2.8734');
            cy.get('datatable-body-cell').eq(5).should('contain', '2m 57s');
            cy.get('datatable-body-cell').eq(6).should('contain', '3.65');
          });
      });
    });

    describe('Configuration', () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.get('.header-buttons > .btn').click();
      });

      it('shows default usage metrics', () => {
        cy.get('.default-values-header').domMatch(dom`<h4 class="ng-tns-${NGCLASS}">
            Apply Default Usage Metrics Values
          </h4>
          <small class="ng-tns-${NGCLASS}">
            Default usage metric values are applied to every integration and workflow task that doesn't have a custom value set
          </small>`);

        cy.get('.default-values-container input').eq(0).should('have.value', 3);
        cy.get('.default-values-container input').eq(1).should('have.value', 74.23);

        cy.get('.default-values-container state-save-button  ngx-button').should('have.class', 'disabled-button');
      });

      it('shows applications', () => {
        cy.get('.ngx-section-header').eq(0).should('contain', 'Application 1');
        cy.get('.ngx-section-header').eq(1).should('contain', 'Application 2');
        cy.get('.ngx-section-header').eq(2).should('contain', 'Test Application');
        cy.get('.ngx-section-header').eq(3).should('contain', 'Common Tasks');

        cy.get('.ngx-section-header').withinEach(() => {
          cy.get('.ngx-section-toggle').click();
          cy.get('state-save-button ngx-button').should('have.class', 'disabled-button');
        });
      });

      after(() => {
        cy.go('back');
      });
    });

    after(() => {
      cy.go('back');
    });
  });

  describe('sessions', () => {
    before(() => {
      cy.get('.grid-item-sessions').click();
    });

    it('should show header', () => {
      cy.get('h1').should('contain', 'Sessions & Security');
    });

    it('shows sections', () => {
      cy.get('.sessions-content > section').within(() => {
        cy.get('ngx-section').should('have.length', 5);
        cy.get('ngx-section').eq(0).should('have.attr', 'sectiontitle', 'Login Settings');
        cy.get('ngx-section').eq(1).should('have.attr', 'sectiontitle', 'Proxy Settings for Integrations');
        cy.get('ngx-section').eq(2).should('have.attr', 'sectiontitle', 'Session');
        cy.get('ngx-section').eq(3).should('have.attr', 'sectiontitle', 'Password');
        cy.get('ngx-section').eq(4).should('have.attr', 'sectiontitle', 'Authentication');
      });
    });

    describe('Password', () => {
      it('display password fields', () => {
        cy.get('.sessions-content > section').within(() => {
          cy.get('ngx-section')
            .eq(3)
            .should('have.attr', 'sectiontitle', 'Password')
            .within(() => {
              cy.get('button').click();
              cy.get('.flexbox-container').should('have.length', 3);
              cy.get('.flexbox-container')
                .first()
                .within(() => {
                  cy.get('[data-cy=sessions__password-expiration-days]').should(
                    'have.attr',
                    'label',
                    'Password Expiration (days)'
                  );
                  cy.get('[data-cy=sessions__password-expiration-unit]').should(
                    'have.attr',
                    'label',
                    'Password Expiration Unit'
                  );
                });
              cy.get('.flexbox-container')
                .eq(1)
                .within(() => {
                  cy.get('[data-cy=sessions__password-complexity]').should(
                    'have.attr',
                    'label',
                    'Minimum Password Complexity'
                  );
                  cy.get('[data-cy=sessions__password-failed-attempts]').should(
                    'have.attr',
                    'label',
                    'Number of Allowable Failed Logins'
                  );
                });
              cy.get('.flexbox-container')
                .last()
                .within(() => {
                  cy.get('[data-cy=sessions__password-notification-email]').should(
                    'have.attr',
                    'label',
                    'Security Notification Email'
                  );
                });
            });
        });
      });
    });

    it('starts with save button disabled', () => {
      cy.get('state-save-button ngx-button').should('have.class', 'disabled-button');
    });

    after(() => {
      cy.go('back');
    });
  });

  describe('email', () => {
    before(() => {
      cy.get('.grid-item-email').click();
    });

    it('should show header', () => {
      cy.get('h1').should('contain', 'Email and PDF Settings');
    });

    it('shows sections', () => {
      cy.get('.email-content > section').within(() => {
        cy.get('ngx-section').should('have.length', 3);
        cy.get('ngx-section').eq(0).should('have.attr', 'sectiontitle', 'Outgoing Mail Server');
        cy.get('ngx-section').eq(1).should('have.attr', 'sectiontitle', 'Mail Formatting');
        cy.get('ngx-section').eq(2).should('have.attr', 'sectiontitle', 'Shareable PDF Formatting');
      });
    });

    it('starts with save button disabled', () => {
      cy.get('state-save-button ngx-button').should('have.class', 'disabled-button');
    });

    it('mail formatting', () => {
      cy.get('[sectiontitle="Mail Formatting"]').within(() => {
        cy.get('.ngx-section-toggle').click();

        cy.get('.CodeMirror').first().type('hello');
        cy.get('.CodeMirror').last().type('world');

        cy.get('iframe').withinBody(() => {
          cy.get('#mailHeader').should('contain', 'hello');
          cy.get('#mailFooter').should('contain', 'world');
        });
      });
    });

    it('pdf formatting', () => {
      cy.get('[sectiontitle="Shareable PDF Formatting"]').within(() => {
        cy.get('.ngx-section-toggle').click();

        cy.get('.ngx-tab-content').within(() => {
          cy.getRTE().focus().clear().type('pdf header').blur();
        });

        cy.get('.ngx-tabs-list').find('.ngx-tab').eq(1).click();

        cy.get('.ngx-tab-content').within(() => {
          cy.getRTE().clear().type('pdf footer').blur();
        });

        cy.get('#pdfPreviewFrame')
          .its('0.contentDocument')
          .should('exist')
          .its('body')
          .should('not.be.undefined')
          .then(el => {
            cy.wrap(el).find('#pdfHeader').should('contain', 'pdf header');
            cy.wrap(el).find('#pdfFooter').should('contain', 'pdf footer');
          });
      });
    });

    after(() => {
      cy.go('back');
      cy.get('.ngx-dialog-footer button').contains('Leave').click();
    });
  });

  describe('advanced', () => {
    before(() => {
      cy.navigateSwimlane('/settings/advanced');
    });

    it('should show header', () => {
      cy.get('h1').should('contain', 'Advanced');
    });

    it('shows sections', () => {
      cy.get('.advanced-content > section').within(() => {
        cy.get('ngx-section').should('have.length', 3);
        cy.get('ngx-section').eq(0).should('have.attr', 'sectiontitle', 'Configuration');
        cy.get('ngx-section').eq(1).should('have.attr', 'sectiontitle', 'Licensing');
        cy.get('ngx-section').eq(2).should('have.attr', 'sectiontitle', 'Directory Services');
      });
    });

    it('starts with save button disabled', () => {
      cy.get('state-save-button ngx-button').should('have.class', 'disabled-button');
    });
  });

  describe('features - hide', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.intercept('/api/settings/features', []).as('getFeatureFlags');
      cy.navigateSwimlane('/settings', { forceReload: true });
      cy.wait('@getFeatureFlags');
    });

    it('hides features button when there is no enabled features and no user available features', () => {
      cy.get('.grid-item').should('have.length', 6);
    });
  });

  describe('features - show', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.intercept('/api/settings/features', []).as('getFeatureFlags');
      cy.intercept('/api/settings/features/enabled', [
        {
          id: 'SystemFlagTest',
          system: true,
          disabled: false
        }
      ]).as('getEnabledFlags');
      cy.navigateSwimlane('/settings', { forceReload: true });
      cy.wait('@getFeatureFlags');
      cy.wait('@getEnabledFlags');
    });

    it('shows features button when there is enabled system flag and no user available features', () => {
      cy.get('.grid-item').should('have.length', 7);
      cy.get('.grid-item-features').should('be.visible');
    });
  });
});

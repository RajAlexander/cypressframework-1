const newRole = 'Active Maintainer';

describe('Roles pages', () => {
  before(() => {
    cy.login();

    cy.setupStubbedSwimlane();

    cy.intercept('/api/roles/?*', {
      fixture: 'mocks/swimlane/roles/get-new-role'
    }).as('GET:roles');
    cy.navigateSwimlane('/roles/');

    cy.wait('@GET:roles');
  });

  it('toolbar', () => {
    cy.get('ngx-toolbar').should('contain', 'Roles').should('contain', 'New Role');
    cy.get('[data-cy=roles__filter-input]')
      .should('exist')
      .should('have.attr', 'placeholder', 'Filter by role name...');
  });

  describe('roles list', () => {
    it('shows data table', () => {
      cy.get('ngx-datatable').should('be.visible');
    });

    it('should have "Admin" role', () => {
      cy.get('ngx-datatable datatable-body-row').first().should('contain', 'Administrator');
    });

    it('"Admin" cannot be deleted', () => {
      cy.get('ngx-datatable datatable-body-row')
        .first()
        .get('datatable-body-cell')
        .last()
        .should('not.contain', 'ngx-icon[font-icon]="trash"');
    });
  });

  describe('creating a new role', () => {
    before(() => {
      cy.get('ngx-toolbar').find('.btn').contains('New Role').click();
    });

    beforeEach(() => {
      cy.get('.ngx-tabs-list').find('.ngx-tab').first().as('general-tab');
      cy.get('.ngx-tabs-list').find('.ngx-tab').eq(1).as('permissions-tab');
    });

    it('should open new role dialog', () => {
      cy.get('.ngx-dialog-header h2').should('contain', 'New Role');
    });

    it('should start on general tab', () => {
      cy.get('@general-tab').should('have.class', 'active');
    });

    it('should add a name', () => {
      cy.get('.ngx-input[label="Name"]').type(newRole);
    });

    describe('permissions tab', () => {
      before(() => {
        cy.get('.ngx-tabs-list').find('.ngx-tab').eq(1).as('permissions-tab');
        cy.get('@permissions-tab').click();
      });

      beforeEach(() => {
        cy.get('.permissions-tabs').find('.ngx-tabs-list .ngx-tab').eq(0).as('workspaces-tab');
        cy.get('.permissions-tabs').find('.ngx-tabs-list .ngx-tab').eq(1).as('dashboards-tab');
        cy.get('.permissions-tabs').find('.ngx-tabs-list .ngx-tab').eq(2).as('applications-tab');
        cy.get('.permissions-tabs').find('.ngx-tabs-list .ngx-tab').eq(3).as('applets-tab');
        cy.get('.permissions-tabs').find('.ngx-tabs-list .ngx-tab').eq(4).as('records-tab');
        cy.get('.permissions-tabs').find('.ngx-tabs-list .ngx-tab').eq(5).as('reports-tab');
      });

      it('should open permissions tab', () => {
        cy.get('@permissions-tab').should('have.class', 'active');
      });

      it('should start on workspaces tab', () => {
        cy.get('@workspaces-tab').should('have.class', 'active');
      });

      describe('dashboards', () => {
        before(() => {
          cy.get('.permissions-tabs').find('.ngx-tabs-list .ngx-tab').eq(1).as('dashboards-tab');
          cy.get('@dashboards-tab').click();
        });

        it('should open dashboards tab', () => {
          cy.get('@dashboards-tab').should('have.class', 'active');
        });

        it('should toggle create permission', () => {
          cy.get('table.dashboard ngx-toggle').should('not.exist');
          cy.get('table.dashboard td').eq(1).find('ngx-checkbox').click();
          cy.get('table.dashboard ngx-toggle').should('exist');
        });

        it('should toggle can create personal dashboards', () => {
          cy.get('table.dashboard ngx-toggle').find('.ngx-toggle-input').click({ force: true });
        });
      });

      it('should open applications tab', () => {
        cy.get('@applications-tab').click();
        cy.get('@applications-tab').should('have.class', 'active');
      });

      it('should open applets tab', () => {
        cy.get('@applets-tab').click();
        cy.get('@applets-tab').should('have.class', 'active');
      });

      it('should open records tab', () => {
        cy.get('@records-tab').click();
        cy.get('@records-tab').should('have.class', 'active');
      });

      it('should open reports tab', () => {
        cy.get('@reports-tab').click();
        cy.get('@reports-tab').should('have.class', 'active');
      });

      describe('reports', () => {
        before(() => {
          cy.get('.permissions-tabs').find('.ngx-tabs-list .ngx-tab').eq(5).as('reports-tab');
          cy.get('@reports-tab').click();
        });

        it('should open reports tab', () => {
          cy.get('@reports-tab').should('have.class', 'active');
        });

        it('should toggle create permission', () => {
          cy.get('table.report ngx-toggle').should('not.exist');
          cy.get('table.report td').eq(1).find('ngx-checkbox').click();
          cy.get('table.report ngx-toggle').should('exist');
        });

        it('should toggle can create personal reports', () => {
          cy.get('table.report ngx-toggle').find('.ngx-toggle-input').click({ force: true });
        });
      });

      it('should open applications tab', () => {
        cy.get('@applications-tab').click();
        cy.get('@applications-tab').should('have.class', 'active');
      });
    });

    describe('save', () => {
      it('saves role', () => {
        cy.setupStubbedSwimlane();
        cy.intercept('/api/roles/?*', {
          fixture: 'mocks/swimlane/roles/get-new-role'
        }).as('GET:roles');

        cy.get('.ngx-dialog-footer').find('button').first().click();

        cy.wait('@POST:roles');
        cy.wait('@GET:roles');
      });
    });
  });

  describe('editing a role', () => {
    it('should exist', () => {
      cy.get('.datatable-body-cell').contains(newRole).should('exist');
    });

    describe('opens role', () => {
      before(() => {
        cy.get('.datatable-body-cell').contains(newRole).click();
      });

      describe('permissions', () => {
        before(() => {
          cy.get('.ngx-tabs-list').find('.ngx-tab').eq(1).click();
        });

        describe('personal dashboards toggle', () => {
          before(() => {
            cy.get('.permissions-tabs').find('.ngx-tabs-list .ngx-tab').eq(1).click();
          });

          it('should show checked toggle', () => {
            cy.get('table.dashboard')
              .should('be.visible')
              .within(() => {
                cy.get('th').first().should('have.text', 'Dashboards');
                cy.get('ngx-toggle label').eq(1).should('have.text', 'Can Create Personal Dashboards');
                cy.get('ngx-toggle .ngx-toggle-input').should('be.checked');
              });
          });
        });

        describe('personal reports toggle', () => {
          before(() => {
            cy.get('.permissions-tabs').find('.ngx-tabs-list .ngx-tab').eq(5).click();
          });

          it('should show checked toggle', () => {
            cy.get('table.report')
              .should('be.visible')
              .within(() => {
                cy.get('th').first().should('have.text', 'Reports');
                cy.get('ngx-toggle label').eq(1).should('have.text', 'Can Create Personal Reports');
                cy.get('ngx-toggle .ngx-toggle-input').should('be.checked');
              });
          });
        });
      });

      describe('save', () => {
        it('saves role', () => {
          // close dialog
          cy.setupStubbedSwimlane();
          cy.intercept('GET', '/api/roles/?*', {
            fixture: 'mocks/swimlane/roles/get-new-role'
          }).as('GET:roles');

          cy.get('.ngx-dialog-footer').find('button').last().click();
          cy.wait('@GET:roles');
        });
      });
    });
  });

  describe('delete a role', () => {
    it('can delete role', () => {
      cy.get('.datatable-body-cell').contains(newRole).closest('datatable-body-row').as('new-role-row');

      cy.setupStubbedSwimlane();
      cy.intercept('GET', '/api/roles/?*', {
        fixture: 'mocks/swimlane/roles/get-new-role'
      }).as('GET:roles');
      cy.get('@new-role-row').find('.roles-list--trash-row ngx-icon').click();
      cy.get('.ngx-dialog-footer').find('button').first().click();
      cy.wait('@DELETE:roles/*');
      cy.wait('@GET:roles');
    });
  });
});

describe('Groups page', () => {
  before(() => {
    cy.login();

    cy.setupStubbedSwimlane();

    cy.navigateSwimlane('/groups');

    // not an error, there are actually 2 requests being made
    cy.wait('@GET:groups?*');
    cy.wait('@GET:groups?*');
  });

  it('toolbar', () => {
    cy.get('ngx-toolbar').should('contain', 'Groups').should('contain', 'New Group');
    cy.get('[data-cy=groups__filter-input]')
      .should('exist')
      .should('have.attr', 'placeholder', 'Filter by group name...');
  });

  describe('groups list', () => {
    it('shows data table', () => {
      cy.get('ngx-datatable').should('exist');
    });

    it('should have "Everyone" group', () => {
      cy.get('ngx-datatable datatable-body-row').first().should('contain', 'Everyone');
    });

    it('should have second group', () => {
      cy.get('ngx-datatable datatable-body-row').eq(1).should('contain', 'Test Group');
    });

    it('"Everyone" cannot be deleted', () => {
      cy.get('ngx-datatable datatable-body-row')
        .first()
        .get('datatable-body-cell')
        .last()
        .should('not.contain', 'ngx-icon[font-icon]="trash"');
    });
  });

  describe('new group dialog', () => {
    before(() => {
      cy.get('ngx-toolbar').find('.btn').contains('New Group').click();
    });

    beforeEach(() => {
      cy.get('ngx-dialog').as('newUserDialog');
    });

    after(() => {
      cy.get('.ngx-dialog-footer').find('button').last().click();
    });

    it('opens new group dialog', () => {
      cy.get('ngx-dialog').should('contain', 'New Group');
    });

    it('shows "Name" input', () => {
      cy.get('@newUserDialog').find('ngx-input').first().as('name').should('contain', 'Name');
      cy.get('@name').should('have.attr', 'required');
    });

    it('shows "Description" input', () => {
      cy.get('@newUserDialog').find('ngx-input').eq(1).should('contain', 'Description');
    });

    it('shows "Roles" select input', () => {
      cy.get('ngx-select').first().should('contain', 'Roles');
    });

    it('shows "Groups" select input', () => {
      cy.get('ngx-select').eq(1).should('contain', 'Groups');
    });

    it('shows "Users" select input', () => {
      cy.get('ngx-select').eq(2).should('contain', 'Users');
    });

    it('shows toggle', () => {
      cy.get('ngx-toggle').should('contain', 'Disabled');
    });
  });

  describe('Edit group dialog', () => {
    before(() => {
      cy.get('ngx-datatable datatable-body-row').eq(1).find('datatable-body-cell').first().find('.group-name').click();
    });

    after(() => {
      cy.get('.ngx-dialog-footer').find('button').last().click();
    });

    it('opens edit group dialog', () => {
      cy.get('ngx-dialog').should('contain', 'Test Group');
    });

    it('shows existing data', () => {
      cy.get('ngx-select')
        .last()
        .find('ngx-select-input .ngx-select-input-list .ngx-select-input-option')
        .as('userOptions');
      cy.get('@userOptions').its('length').should('eq', 2);
      cy.get('@userOptions').first().should('contain', 'admin');
      cy.get('@userOptions').last().should('contain', 'user1');
    });
  });
});

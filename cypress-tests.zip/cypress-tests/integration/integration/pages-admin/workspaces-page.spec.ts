describe('Workspaces Page', () => {
  before(() => {
    cy.login();

    cy.setupStubbedSwimlane();
    cy.navigateSwimlane('/workspaces');
  });

  describe('as admin', () => {
    it('has toolbar', () => {
      cy.get('.ngx-toolbar').should('contain', 'Workspaces').should('contain', 'New Workspace');
    });

    it('shows workspaces table', () => {
      cy.get('.datatable-body-row').should('have.length', 2);
      cy.get('.datatable-body-row').eq(0).contains('Workspace 1');
      cy.get('.datatable-body-row').eq(1).contains('Workspace 2');
    });

    describe('new workspace', () => {
      before(() => {
        cy.get('.ngx-toolbar').find('.btn').contains('New Workspace').click();
      });

      after(() => {
        cy.get('body').then($body => {
          if ($body.find('ngx-dialog .icon-x').length) {
            cy.get('ngx-dialog .icon-x').click();
          }
        });
      });

      beforeEach(() => {
        cy.get('.ngx-tabs-list').find('button').contains('General').as('general-tab');
        cy.get('.ngx-tabs-list').find('button').contains('Permissions').as('permissions-tab');
      });

      it('opens new workspace dialog', () => {
        cy.get('ngx-dialog').should('contain', 'New Workspace');
        cy.get('@general-tab').should('have.class', 'active');
      });

      it('starts with general tab active', () => {
        cy.get('@general-tab').should('have.class', 'active');
      });

      describe('permissions tab', () => {
        before(() => {
          cy.get('.ngx-tabs-list').find('button').contains('Permissions').click();
        });

        it('opens permissions tab', () => {
          cy.get('@permissions-tab').should('have.class', 'active');
        });
      });

      describe('general tab', () => {
        before(() => {
          cy.get('.ngx-tabs-list').find('button').contains('General').click();
        });

        it('opens general tab', () => {
          cy.get('@general-tab').should('have.class', 'active');
        });

        it('can save', () => {
          cy.setupStubbedSwimlane();
          cy.get('.ngx-input-box').first().type('Workspace 3');
          cy.get('state-save-button ngx-button').click();
          cy.wait('@POST:workspaces');

          cy.get('.datatable-body-row').should('have.length', 3);
          cy.get('.datatable-body-row').eq(0).contains('Workspace 1');
          cy.get('.datatable-body-row').eq(1).contains('Workspace 2');
          cy.get('.datatable-body-row').eq(2).contains('Workspace 3');
        });
      });
    });
  });
});

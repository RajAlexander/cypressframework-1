describe('Reports Page', () => {
  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();

    cy.navigateSwimlane('/reports/');
    cy.wait('@GET:scheduled/reports');
    cy.wait('@GET:reports/status/workspace/aP6rDZMhfXU0550sc');
  });

  describe('as admin', () => {
    beforeEach(() => {
      cy.get('.main.reports').find('ngx-section').as('reports');
      cy.get('@reports').first().as('application-1');
      cy.get('@application-1').find('datatable-body-row').as('rows');
    });

    it('shows the reports tables', () => {
      cy.get('@reports').should('have.length', 3);
      cy.get('@application-1').find('header').should('contain', 'Application 1');
      cy.get('@rows').should('have.length', 4);
    });

    it('has correct column names', () => {
      cy.get('.datatable-header-cell-wrapper').first().should('have.text', 'Name');
      cy.get('.datatable-header-cell-wrapper').eq(1).should('have.text', 'Created');
      cy.get('.datatable-header-cell-wrapper').eq(2).should('have.text', 'Modified');
      cy.get('.datatable-header-cell-wrapper').eq(3).should('have.text', 'Personal Report');
      cy.get('.datatable-header-cell-wrapper').eq(4).should('have.text', 'Schedules');
    });

    describe('scheduled report actions', () => {
      beforeEach(() => {
        cy.get('@rows').eq(1).as('report-2');
        cy.get('@report-2').find('.badge-container').as('container');
        cy.get('@container').find('.badge').first().as('schedule-1');
      });

      it('should display scheduled report pill', () => {
        cy.get('@schedule-1').should('contain', 'Recurs');
        cy.get('@container').find('.badge').eq(1).should('contain', 'One Time');
      });

      it('should open scheduled report details dialog', () => {
        cy.get('@schedule-1').click();
        cy.get('.schedule-report-dialog').should('be.visible');
        cy.get('.dialog-footer').within(() => {
          cy.get('.btn').first().should('contain', 'Close').click();
        });
        cy.get('.schedule-report-dialog').should('not.exist');
      });

      it('should open are you sure? dialog when trying to cancel after edit scheduled', () => {
        cy.get('@schedule-1').click();
        cy.get('.schedule-details-content').find('.ngx-input').eq(0).type('- Testing');
        cy.get('.dialog-footer').within(() => {
          cy.get('.btn').first().should('contain', 'Cancel').click();
        });
        cy.get('.save-button-leave-dialog').within(() => {
          cy.get('.ngx-dialog-title').should('contain', 'You have unsaved changes.');
          cy.get('.btn').last().should('contain', 'Cancel');
          cy.get('.btn').eq(1).should('contain', 'Save and Leave');
          cy.get('.btn').first().should('contain', 'Leave').click();
        });
      });

      it('should open delete scheduled report dialog', () => {
        cy.get('@schedule-1').find('.ngx-x').click();
        cy.get('.confirm').within(() => {
          cy.get('.btn').first().should('contain', 'Delete');
          cy.get('.btn').eq(1).click();
        });
        cy.get('.confirm').should('not.exist');
      });
    });

    it('should hide delete button for default report', () => {
      cy.get('@rows').first().as('row');
      cy.get('@row').should('contain', 'Default');
      cy.get('@row').find('.datatable-row-center > :nth-child(6) .ngx-icon').as('icons');
      cy.get('@icons').should('have.length', 1);
      cy.get('@icons').first().should('have.class', 'ngx-edit');
    });

    it('should not hide delete button for other reports', () => {
      cy.get('@rows').last().as('row');
      cy.get('@row').should('contain', 'Report 4');
      cy.get('@row').find('.datatable-row-center > :nth-child(6) .ngx-icon').as('icons');
      cy.get('@icons').should('have.length', 2);
      cy.get('@icons').first().should('have.class', 'ngx-edit');
      cy.get('@icons').last().should('have.class', 'ngx-trash');
    });
  });
  describe('reports tab on nav bar', () => {
    it('should display schedule status icon on nav bar', () => {
      cy.get('.nav-items').find('.nav-item-container').eq(3).as('reports-nav').click();
      cy.get('@reports-nav')
        .find('.reports > div.ng-star-inserted > .vertical-list > li.ng-star-inserted')
        .as('reports');
      cy.get('@reports').first().find('.sub-nav-item > .schedule-enabled').should('be.visible');
      cy.get('@reports').eq(1).find('.sub-nav-item > .schedule-enabled').should('be.visible');
      cy.get('@reports').eq(2).find('.sub-nav-item > .schedule-disabled').should('be.visible');
      cy.get('@reports').last().find('.sub-nav-item > .schedule-disabled').should('not.exist');
      cy.get('@reports').last().find('.sub-nav-item > .schedule-enabled').should('not.exist');
    });
  });
});

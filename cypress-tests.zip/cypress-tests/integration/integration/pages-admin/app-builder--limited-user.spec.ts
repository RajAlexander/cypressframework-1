describe('App Builder as non admin', () => {
  const appId = 'ad2xJUGes5TNRKG4M';

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();

    // Reset login to a limited user
    cy.intercept('GET', '/api/user/authorize', {
      fixture: 'mocks/swimlane/user/authorize/get-user.json'
    }).as('GET:user/authorize');
    cy.navigateSwimlane(`/app-builder/${appId}`);
  });

  beforeEach(() => {
    cy.get('.content-area').as('contentArea');
    cy.get('@contentArea').find('.app-builder-toolbar ngx-toolbar-content').as('toolBar');
    cy.get('@toolBar').find('.app-nav').as('nav');
    cy.get('@toolBar').find('.toolbar li').eq(0).as('saveButton');
    cy.get('@toolBar').find('.toolbar li').eq(1).as('ellipsis');
  });

  describe('tool bar', () => {
    it('header', () => {
      cy.get('@contentArea').find('.app-builder-toolbar .ngx-toolbar-title > span').should('contain', 'Application 1');
    });

    it('has ellipsis', () => {
      cy.get('@ellipsis').within(() => {
        cy.get('ngx-dropdown-toggle').click();
        cy.get('ngx-dropdown-menu').should('exist');
        cy.get('ngx-dropdown-menu')
          .should('contain', 'Validate')
          .should('contain', 'Manage Export Templates')
          .should('not.contain', 'Export Application')
          .should('contain', 'History')
          .should('contain', 'Delete Records')
          .should('contain', 'Delete Application');
        cy.get('ngx-dropdown-toggle').click();
      });
    });
  });
});

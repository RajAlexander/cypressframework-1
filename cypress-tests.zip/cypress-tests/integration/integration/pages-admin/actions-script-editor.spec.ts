describe('Supports Python 3 [SPT-4853]', () => {
  before(() => {
    cy.login();

    cy.setupStubbedSwimlane();
    cy.intercept('/api/task*', []).as('getTasks');
    cy.navigateSwimlane('/integration/common/task/aIfR6KGZXpGPY7I1t');

    cy.wait('@getEnabledFlags');
    cy.wait('@GET:task/*');
    cy.wait('@GET:task/options');
    cy.wait('@GET:task/light');
    cy.get('body > div.preloader > div.ngx-preloader').should('not.exist');
    cy.get('.stack-tabs').should('exist');
  });

  it('title and type', () => {
    cy.get('.page-toolbar').find('h4').should('contain', 'Python 3');
    cy.get('.tab-content .tab-pane > .form-group')
      .contains('Task Type')
      .closest('.form-group')
      .should('contain', 'Scripts: Python 3');
  });

  it('configuration tab', () => {
    cy.get('.stack-tabs a').contains('Configuration').click();
    cy.get('.CodeMirror-scroll').should('be.visible');
    cy.get('.output-parameters-help').should('contain', 'sw_context.user');
  });

  it('output parameters atb', () => {
    cy.get('.stack-tabs a').contains('Output Parameters').click();
    cy.get('output-variables > button').contains('Discover Parameters').should('be.visible');
    cy.get('output-variables').find('.output-variables--mapping-panel').should('be.visible');
  });
});

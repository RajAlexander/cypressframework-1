const openDashboardDropdown = () => {
  cy.get('.page-toolbar').as('page-toolbar');
  cy.get('@page-toolbar').find('.ngx-icon.ngx-dots-vert-round').as('dropdown-button');
  cy.get('@page-toolbar').then($bar => {
    if (!$bar.find('.ngx-dropdown').hasClass('open')) {
      cy.get('@dropdown-button').click();
    }
  });
  cy.get('@page-toolbar').find('.ngx-dropdown-menu li').as('dropdown-list');
};

const openNewDashboardDialog = () => {
  openDashboardDropdown();
  cy.get('@dropdown-list').eq(1).click();
};

const openEditDashboardDialog = () => {
  openDashboardDropdown();
  cy.get('@dropdown-list').eq(2).click();
};

const openCardDropdown = index => {
  cy.get('dashboard-item').eq(index).as('dashboard-item');
  cy.get('@dashboard-item').should('be.visible');

  cy.get('@dashboard-item').find('.card-toolbar').fakeHover();
  cy.get('@dashboard-item')
    .find('.card-controls .card-settings ngx-dropdown-toggle')
    .should('be.visible')
    .fakeHover()
    .click();
  cy.get('@dashboard-item').find('.card-controls .card-settings .ngx-dropdown-menu').as('dropdown-list').fakeHover();
};

const openNewCardDialog = () => {
  cy.get('.new-card-button').click();
};

const openEditCardDialog = index => {
  openCardDropdown(index);
  cy.get('@dropdown-list').find('li').eq(1).click();
};

const showAutoRefreshToolbar = index => {
  cy.get('dashboard-item').eq(index).as('dashboard-item');
  cy.get('@dashboard-item').should('be.visible');

  cy.get('@dashboard-item').find('.card-toolbar').fakeHover();
  cy.get('@dashboard-item').find('.card-controls .auto-refresh-toolbar').should('be.visible').fakeHover();
};

describe('Dashboard', () => {
  const workspaceId = 'aP6rDZMhfXU0550sc';
  const dashboardId = '5d321ea175df8a0319656f01';
  const dashboardId2 = '5d446bf01d7979031a54f7e3';
  const dashboardId3 = '5d707ee32ae4ab0319ff8ea9';

  before(() => {
    cy.login();
  });

  describe('Empty', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.navigateSwimlane(`/workspace/${workspaceId}/${dashboardId}`);
      cy.wait(`@GET:dashboard/${dashboardId}`);
    });

    beforeEach(() => {
      cy.get('.main-toolbar').as('main-toolbar');
      cy.get('.page-toolbar').as('page-toolbar');
      cy.get('@page-toolbar').find('.new-card-button a').as('new-card-button');
      cy.get('@page-toolbar').find('.ngx-icon.ngx-dots-vert-round').as('dropdown-button');
    });

    it('has a main-toolbar with workspace label', () => {
      cy.get('@main-toolbar').find('.main-toolbar--workspace-label').should('contain', 'Workspace');
      cy.get('@new-card-button').find('i').should('have.class', 'ngx-plus-bold');
    });

    it('has a page-toolbar with workspace name and controls', () => {
      cy.get('@page-toolbar').find('h2').should('contain', 'Dashboard 1');
      cy.get('@new-card-button').find('i').should('have.class', 'ngx-plus-bold');
    });

    it('shows a message when there are no cards', () => {
      cy.get('.content-area .dashboard-controls').should('contain', 'Add cards to your dashboard to make it useful!');
    });

    describe('dropdown', () => {
      before(() => {
        openDashboardDropdown();
      });

      beforeEach(() => {
        cy.get('@page-toolbar').find('.ngx-dropdown-menu li').as('dropdown-list');
      });

      it('has dropdown items', () => {
        cy.get('@dropdown-list').first().should('contain', 'DASHBOARD');
        cy.get('@dropdown-list').eq(1).should('contain', 'New');
        cy.get('@dropdown-list').eq(2).should('contain', 'Settings and Schedules');
        cy.get('@dropdown-list').eq(3).should('contain', 'Delete');
        cy.get('@dropdown-list').eq(5).should('contain', 'SHARING OPTIONS');
        cy.get('@dropdown-list').eq(6).should('contain', 'Schedule');
        cy.get('@dropdown-list').eq(7).should('contain', 'Email');
        cy.get('@dropdown-list').eq(8).should('contain', 'Download');
        cy.get('@dropdown-list').eq(10).should('contain', 'WORKSPACE');
        cy.get('@dropdown-list').eq(11).should('contain', 'New');
        cy.get('@dropdown-list').eq(12).should('contain', 'Edit');
      });

      describe('new dashboard', () => {
        before(() => {
          openDashboardDropdown();
          cy.get('@dropdown-list').eq(1).click();
        });

        beforeEach(() => {
          cy.get('.ngx-tabs-list').find('button').contains('General').as('general-tab');
          cy.get('.ngx-tabs-list').find('button').contains('Advanced').as('advanced-tab');
          cy.get('.ngx-tabs-list').find('button').contains('Permissions').as('permissions-tab');
        });

        after(() => {
          cy.get('body').then($body => {
            if ($body.find('ngx-dialog .icon-x').length) {
              cy.get('ngx-dialog button.close .icon-x').click();
            }
          });
        });

        it('opens new dashboard dialog', () => {
          cy.get('ngx-dialog').should('contain', 'New Dashboard');
          cy.get('@general-tab').should('have.class', 'active');
        });
      });

      describe('edit dashboard', () => {
        before(() => {
          openDashboardDropdown();
          cy.get('@dropdown-list').eq(2).click();
        });

        beforeEach(() => {
          cy.get('.ngx-tabs-list').find('button').contains('General').as('general-tab');
          cy.get('.ngx-tabs-list').find('button').contains('Advanced').as('advanced-tab');
          cy.get('.ngx-tabs-list').find('button').contains('Permissions').as('permissions-tab');
        });

        after(() => {
          cy.get('body').then($body => {
            if ($body.find('ngx-dialog .icon-x').length) {
              cy.get('ngx-dialog button.close .icon-x').click();
            }
          });
        });

        it('opens edit dashboard dialog', () => {
          cy.get('ngx-dialog').should('contain', 'Dashboard Settings and Schedules');
          cy.get('@general-tab').should('have.class', 'active');
        });
      });
    });
  });

  describe('With cards and Timeline', () => {
    beforeEach(() => {
      cy.get('.main-toolbar').as('main-toolbar');
      cy.get('.page-toolbar').as('page-toolbar');
    });

    describe('Cards', () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.navigateSwimlane(`/workspace/${workspaceId}/${dashboardId2}`);
        cy.wait(`@GET:dashboard/${dashboardId2}`);
      });

      it('has a main-toolbar with workspace label', () => {
        cy.get('@main-toolbar').find('.main-toolbar--workspace-label').should('contain', 'Workspace');
      });

      it('shows dashboard cards', () => {
        cy.get('dashboard-item').first().as('dashboard-item');
        cy.get('@dashboard-item').should('be.visible');
        cy.get('@dashboard-item').find('.card-title').should('contain', 'HTML Card');
        cy.get('@dashboard-item').find('.card-html-container').should('contain', 'Hello');
      });

      it('shows the timeline', () => {
        cy.get('.timeline-filter').should('be.visible');
        cy.get('.timeline-filter').should('contain', 'Aug 01, 2019');
        cy.get('.timeline-filter').should('contain', 'Aug 03, 2019');
      });
    });

    describe('Card dialog', () => {
      describe('New card', () => {
        before(() => {
          cy.setupStubbedSwimlane();
          cy.navigateSwimlane(`/workspace/${workspaceId}/${dashboardId2}`);
          cy.wait(`@GET:dashboard/${dashboardId2}`);

          openNewCardDialog();
        });

        after(() => {
          cy.get('body').then($body => {
            if ($body.find('ngx-dialog .icon-x').length) {
              cy.get('ngx-dialog button.close .icon-x').click();
            }
          });
        });

        it("shows the auto refresh select and it's off by default ", () => {
          cy.get('.ngx-select[label="Auto Refresh"]').as('auto-refresh-select').should('exist');

          cy.get('@auto-refresh-select').find('.ngx-select-input-option').should('have.text', 'off');

          cy.get('@auto-refresh-select').click();
          cy.get('.ngx-select-dropdown-option').eq(3).click();
        });

        it('selecting a value ', () => {
          cy.get('.ngx-select[label="Auto Refresh"]').as('auto-refresh-select');

          cy.get('@auto-refresh-select').click();
          cy.get('.ngx-select-dropdown-option').eq(3).click();

          cy.get('@auto-refresh-select').find('.ngx-select-input-option').should('have.text', '30 seconds');
        });
      });

      describe('Existing card', () => {
        before(() => {
          cy.setupStubbedSwimlane();
          cy.navigateSwimlane(`/workspace/${workspaceId}/${dashboardId2}`);
          cy.wait(`@GET:dashboard/${dashboardId2}`);
        });

        after(() => {
          cy.get('body').then($body => {
            if ($body.find('ngx-dialog .icon-x').length) {
              cy.get('ngx-dialog button.close .icon-x').click();
            }
          });
        });

        it('the auto refresh property is properly set to the correct value', () => {
          openEditCardDialog(1);
          cy.get('.ngx-select[label="Auto Refresh"]').should('exist').as('auto-refresh-select');

          cy.get('@auto-refresh-select').find('.ngx-select-input-option').should('have.text', '5 minutes');
        });
      });

      describe('Card with auto refresh', () => {
        before(() => {
          cy.setupStubbedSwimlane();
          cy.navigateSwimlane(`/workspace/${workspaceId}/${dashboardId2}`);
          cy.wait(`@GET:dashboard/${dashboardId2}`);

          showAutoRefreshToolbar(1);
        });

        it('shows refresh icon on the dashboard', () => {
          cy.get('.dashboard-auto-refresh-toolbar').find('.ngx-refresh').should('exist');
        });

        it('shows pause icon on the dashboard', () => {
          cy.get('.dashboard-auto-refresh-toolbar').find('.ngx-pause-circle').should('exist');
        });

        it('shows auto refresh toolbars with icons on the card', () => {
          cy.get('.auto-refresh-toolbar').should('exist');
        });

        it('sets auto refresh property through dropdown', () => {
          cy.get('.auto-refresh-toolbar button').eq(2).click();
        });
      });

      describe('Dashboard pause icon', () => {
        before(() => {
          cy.setupStubbedSwimlane();
          cy.navigateSwimlane(`/workspace/${workspaceId}/${dashboardId2}`);
          cy.wait(`@GET:dashboard/${dashboardId2}`);
        });

        it('pauses cards', () => {
          cy.get('.dashboard-auto-refresh-toolbar').find('.ngx-pause-circle').as('dashboardPause');
          cy.get('@dashboardPause').click({ force: true });

          cy.get('.dashboard-auto-refresh-toolbar').find('.ngx-play-circle').should('exist');
          cy.get('dashboard-item').eq(1).get('.auto-refresh-toolbar').find('.ngx-play-circle').should('exist');
        });
      });

      describe('Card with no auto refresh', () => {
        before(() => {
          cy.setupStubbedSwimlane();
          cy.navigateSwimlane(`/workspace/${workspaceId}/${dashboardId3}`);
          cy.wait(`@GET:dashboard/${dashboardId3}`);
          cy.wait(`@GET:workspaces`);
          cy.wait(`@GET:app/light`);
          cy.wait(`@GET:reports`);
          cy.wait(`@POST:search`);
        });

        beforeEach(() => {
          showAutoRefreshToolbar(0);
        });

        it('shows refresh icon', () => {
          cy.get('.auto-refresh-toolbar').find('.ngx-refresh').should('exist');
        });

        it('hides pause icon', () => {
          cy.get('.auto-refresh-toolbar .ngx-pause-circle').should('not.exist');
        });

        it('shows count down icon', () => {
          cy.get('.auto-refresh-toolbar .count-down-icon').should('exist');
        });

        it('shows refresh icon on the dashboard', () => {
          cy.get('.dashboard-auto-refresh-toolbar').find('.ngx-refresh').should('exist');
        });

        it('hides pause icon on the dashboard', () => {
          cy.get('.dashboard-auto-refresh-toolbar .ngx-pause-circle').should('not.exist');
        });
      });
    });
  });
});

describe('Record Page', () => {
  const appId = 'ad2xJUGes5TNRKG4M';

  const closeLookupModal = () => {
    cy.get('body').then($body => {
      if ($body.find('.reference-lookup-modal--close-button').length) {
        cy.get('.reference-lookup-modal--close-button').click();
      }
    });
  };

  const aliasControlByLabel = label => {
    cy.get('label').contains(label).closest('.field-container').find('.reference-field').as('control');
    cy.get('@control').closest('.field-container').as('control-container');
    cy.get('@control-container').find('.input-group-addon').eq(0).as('add-new-button');
    cy.get('@control-container').find('.input-group-addon').eq(1).as('lookup-button');
  };

  before(() => {
    cy.login();

    cy.setupStubbedSwimlane();
    cy.navigateSwimlane(`/record/${appId}/`);
    cy.wait(`@GET:app/${appId}`);
    cy.wait(`@GET:app/aRIlkHzEA3Lou9JvS`);
  });

  beforeEach(() => {
    cy.intercept('POST', '/api/search/keyword?*', {
      fixture: 'mocks/swimlane/search/keyword/post-3.json'
    }).as('POST:search/keyword?*');
  });

  it('shows content header', () => {
    cy.get('.content-area .page-toolbar h4').should('contain', 'New Record');
  });

  describe('Reference Fields', () => {
    describe('Grid', () => {
      const aliasGrid = () => {
        cy.get('.reference-field--grid').as('grid');
        cy.get('@grid').closest('.field-container').as('grid-container');
      };

      beforeEach(() => {
        aliasGrid();
        cy.get('@grid-container').find('a i').eq(0).as('add-new-button');
        cy.get('@grid-container').find('a i').eq(1).as('lookup-button');
      });

      it('shows reference grid', () => {
        cy.get('@grid-container').find('.panel-heading').should('contain', 'Reference Grid');
        cy.get('@add-new-button').should('have.class', 'ngx-plus');
        cy.get('@lookup-button').should('have.class', 'ngx-search');
        cy.get('@grid').find('.dt-row').should('have.length', 0);
      });

      describe('New Record', () => {
        before(() => {
          cy.setupStubbedSwimlane();
          aliasGrid();
          cy.get('@grid-container').find('a i').eq(0).click().trigger('mouseout', { force: true });
          cy.wait('@GET:app/*/record');
        });

        after(() => {
          cy.get('.stacks-backdrop').click({ force: true });
        });

        it('shows record header', () => {
          cy.get('.stacks-content .page-toolbar h4').should('contain', 'New Record');
        });
      });

      describe('Lookup', () => {
        before(() => {
          cy.setupStubbedSwimlane();
          aliasGrid();
          cy.get('@grid-container').find('a').eq(1).click().trigger('mouseout', { force: true });
          cy.wait('@GET:app');
        });

        after(closeLookupModal);

        beforeEach(() => {
          cy.get('.search-banner--input input').as('input');
        });

        it('starts with input focused', () => {
          cy.get('@input').should('have.focus');
        });

        describe('search', () => {
          before(() => {
            cy.setupStubbedSwimlane();
            cy.intercept('POST', '/api/search/keyword?*', {
              fixture: 'mocks/swimlane/search/keyword/post-3.json'
            }).as('POST:search/keyword?*');
            cy.intercept('POST', '/api/search/keyword/count?*', {
              fixture: 'mocks/swimlane/search/keyword/count/post-3.json'
            }).as('POST:search/keyword/count?*');

            cy.get('.search-banner--input input').as('input');
            cy.get('@input').should('have.focus');
            cy.get('@input').type('cat{enter}');
            cy.wait('@POST:search/keyword?*');
            cy.wait('@POST:search/keyword/count?*');
          });

          it('shows result counts', () => {
            cy.get('.search-left > .results-meta > .results-meta--label').should('contain', 'Records');
            cy.get('.search-left > .results-meta > .results-meta--count').should('contain', '5 results');
            cy.get('.search-sidebar--selection-list > .results-meta > .results-meta--label').should(
              'contain',
              'Selected Records'
            );
            cy.get('.search-sidebar--selection-list > .results-meta > .results-meta--count').should(
              'contain',
              '0 selected'
            );
          });

          it('shows record results', () => {
            cy.get('.search-results .app-results').first().as('first-item');
            cy.get('@first-item').find('.record-heading').should('contain', 'CA-7');
            cy.get('@first-item').find('.record-values').as('values');
            cy.get('@values').should('contain', 'Record Id');
            cy.get('@values').should('contain', 'aV4WbUU5g2OfN3Onc');
            cy.get('@values').should('contain', 'Text');
            cy.get('@values').should('contain', 'Curiosity Killed The Cat');
          });

          it('shows tooltip when hovering over record name', () => {
            cy.get('.search-results .app-results .record-label').first().trigger('mouseenter');
            cy.get('.sw-popover-text').should('be.visible');
            cy.get('.sw-popover-text')
              .should('contain', 'Created')
              .should('contain', 'Updated')
              .should('contain', 'ago')
              .should('contain', 'admin');
            cy.get('.search-results .app-results .record-label').first().trigger('mouseleave');
          });

          it('selects records', () => {
            cy.get('.record-selector').first().click();
            cy.get('.selected-item').first().should('contain', 'CA-7');
            cy.get('.selected-item').first().should('contain', 'Matching "cat"');
            cy.get('.record-selector').eq(1).click();
            cy.get('.selected-item').eq(1).should('contain', 'CA-11');
            cy.get('.selected-item').eq(1).should('contain', 'Matching "cat"');
          });

          it('changing search and selecting records', () => {
            cy.intercept('POST', '/api/search/keyword/count?*', {
              fixture: 'mocks/swimlane/search/keyword/count/post-5.json'
            }).as('POST:search/keyword/count?*');
            cy.intercept('POST', '/api/search/keyword?*', {
              fixture: 'mocks/swimlane/search/keyword/post-5.json'
            }).as('POST:search/keyword?*');
            cy.get('@input').should('not.have.attr', 'disabled');
            cy.get('@input').focus();
            cy.get('@input').type('{backspace}{backspace}{backspace}bag{enter}');
            cy.wait('@POST:search/keyword/count?*');
            cy.wait('@POST:search/keyword?*');
            cy.get('.record-selector').eq(0).click();
            cy.get('.selected-item', { timeout: 5000 }).eq(2).should('contain', 'CA-10');
            cy.get('.selected-item').eq(2).should('contain', 'Matching "bag"');
          });

          it('applies records', () => {
            cy.get('.search-sidebar--selection-list--actions > .btn').click();
            cy.get('.reference-lookup-modal').should('not.exist');
            cy.get('@grid').find('.dt-row').as('rows').should('have.length', 3);
            cy.get('@rows').eq(0).should('contain', 'Curiosity Killed The Cat');
            cy.get('@rows').eq(1).should('contain', 'Cat got your tongue?');
            cy.get('@rows').eq(2).should('contain', 'Let the cat out of the bag');
          });
        });
      });
    });

    describe('Single-Select', () => {
      describe('Tracking ID', () => {
        beforeEach(() => {
          aliasControlByLabel('Reference Single Select, Tracking ID');
        });

        it('shows single select', () => {
          cy.get('@control-container').should('contain', 'Reference Single Select');
          cy.get('@control').find('.reference-value--label').should('have.length', 0);
        });

        it('open lookup using field', () => {
          cy.setupStubbedSwimlane();
          cy.get('@control').click().trigger('mouseout', { force: true });
          cy.wait('@GET:app');
          cy.wait('@GET:app'); // dialog makes two api calls, fix this
          cy.get('.search-banner--input input').should('have.focus');
          cy.get('.reference-lookup-modal--close-button').click();
          cy.get('.reference-lookup-modal').should('not.exist');
        });

        describe('New Record', () => {
          before(() => {
            cy.setupStubbedSwimlane();
            aliasControlByLabel('Reference Single Select, Tracking ID');
            cy.get('@control-container').find('.input-group-addon').eq(0).click().trigger('mouseout', { force: true });
            cy.wait('@GET:app/*/record');
          });

          after(() => {
            cy.get('.stacks-backdrop').click({ force: true });
          });

          it('shows record header', () => {
            cy.get('.stacks-content .page-toolbar h4').should('contain', 'New Record');
          });
        });

        describe('Reference Lookup', () => {
          before(() => {
            cy.setupStubbedSwimlane();
            aliasControlByLabel('Reference Single Select, Tracking ID');
            cy.get('@control-container').find('.input-group-addon').eq(1).click().trigger('mouseout', { force: true });
            cy.wait('@GET:app');
            cy.wait('@GET:app'); // dialog makes two api calls, fix this
          });

          after(closeLookupModal);

          beforeEach(() => {
            cy.get('.search-banner--input input').as('input');
          });

          it('starts with input focused', () => {
            cy.get('.search-banner--input input').as('input');
            cy.get('@input').should('have.focus');
          });

          describe('search', () => {
            before(() => {
              cy.setupStubbedSwimlane();
              cy.intercept('POST', '/api/search/keyword?*', {
                fixture: 'mocks/swimlane/search/keyword/post-3.json'
              }).as('POST:search/keyword?*');
              cy.intercept('POST', '/api/search/keyword/count?*', {
                fixture: 'mocks/swimlane/search/keyword/count/post-3.json'
              }).as('POST:search/keyword/count?*');
              cy.get('.search-banner--input input').as('input');
              cy.get('@input').type('cat{enter}');
              cy.wait('@POST:search/keyword?*');
              cy.wait('@POST:search/keyword/count?*');
            });

            it('shows result counts', () => {
              cy.get('.search-left > .results-meta > .results-meta--label').should('contain', 'Records');
              cy.get('.search-left > .results-meta > .results-meta--count').should('contain', '5 results');
              cy.get('.search-sidebar--selection-list > .results-meta > .results-meta--label').should(
                'contain',
                'Selected Record'
              );
            });

            it('selects only one records', () => {
              cy.get('.record-selector').first().click();
              cy.get('.selected-item').should('have.length', 1);
              cy.get('.selected-item').first().should('contain', 'CA-7');
              cy.get('.selected-item').first().should('contain', 'Matching "cat"');

              cy.get('.record-selector').eq(1).click();
              cy.get('.selected-item').should('have.length', 1);
              cy.get('.selected-item').eq(0).should('contain', 'CA-11');
              cy.get('.selected-item').eq(0).should('contain', 'Matching "cat"');
            });

            it('applies records', () => {
              cy.get('.search-sidebar--selection-list--actions > .btn > button').click();
              cy.get('.reference-lookup-modal').should('not.exist');
              cy.get('@control').find('.reference-value--label').as('rows').should('have.length', 1);
              cy.get('@rows').eq(0).should('contain', 'CA-11');
            });
          });
        });
      });

      describe('Text Field', () => {
        const aliasControl = aliasControlByLabel.bind(null, 'Reference Single Select, Text Field');

        beforeEach(() => {
          aliasControl();
        });

        it('shows single select', () => {
          cy.get('@control-container').should('contain', 'Reference Single Select');
          cy.get('@control').find('.reference-value--label').should('have.length', 0);
        });

        it('open lookup using field', () => {
          cy.setupStubbedSwimlane();
          cy.get('@control').click().trigger('mouseout', { force: true });
          cy.wait('@GET:app');
          cy.wait('@GET:app'); // dialog makes two api calls, fix this
          cy.get('.search-banner--input input').should('have.focus');
          cy.get('.reference-lookup-modal--close-button').click();
        });

        describe('Reference Lookup', () => {
          before(() => {
            cy.setupStubbedSwimlane();
            aliasControl();
            cy.get('@control-container').find('.input-group-addon').eq(1).click().trigger('mouseout', { force: true });
            cy.wait('@GET:app');
            cy.wait('@GET:app'); // dialog makes two api calls, fix this
          });

          after(closeLookupModal);

          beforeEach(() => {
            cy.get('.search-banner--input input').as('input');
          });

          it('starts with input focused', () => {
            cy.get('.search-banner--input input').as('input');
            cy.get('@input').should('have.focus');
          });

          describe('search', () => {
            before(() => {
              cy.setupStubbedSwimlane();
              cy.intercept('POST', '/api/search/keyword?*', {
                fixture: 'mocks/swimlane/search/keyword/post-3.json'
              }).as('POST:search/keyword?*');
              cy.intercept('POST', '/api/search/keyword/count?*', {
                fixture: 'mocks/swimlane/search/keyword/count/post-3.json'
              }).as('POST:search/keyword/count?*');
              cy.get('.search-banner--input input').as('input');
              cy.get('@input').type('cat{enter}');
              cy.wait('@POST:search/keyword?*');
              cy.wait('@POST:search/keyword/count?*');
            });

            it('shows result counts', () => {
              cy.get('.search-left > .results-meta > .results-meta--label').should('contain', 'Records');
              cy.get('.search-left > .results-meta > .results-meta--count').should('contain', '5 results');
              cy.get('.search-sidebar--selection-list > .results-meta > .results-meta--label').should(
                'contain',
                'Selected Record'
              );
            });

            it('selects only one records', () => {
              cy.get('.record-selector').first().click();
              cy.get('.selected-item').should('have.length', 1);
              cy.get('.selected-item').first().should('contain', 'CA-7');
              cy.get('.selected-item').first().should('contain', 'Matching "cat"');

              cy.get('.record-selector').eq(1).click();
              cy.get('.selected-item').should('have.length', 1);
              cy.get('.selected-item').eq(0).should('contain', 'CA-11');
              cy.get('.selected-item').eq(0).should('contain', 'Matching "cat"');
            });

            it('applies records', () => {
              cy.get('.search-sidebar--selection-list--actions > .btn > button').click();
              cy.get('.reference-lookup-modal').should('not.exist');
              cy.get('@control').find('.reference-value--label').as('rows').should('have.length', 1);
              cy.get('@rows').first().should('contain', 'Cat got your ton... (CA-11)');
              cy.get('@rows').first().should('have.attr', 'title', 'Cat got your tongue?');
            });
          });
        });
      });
    });

    describe('Multi-Select', () => {
      describe('Tracking ID', () => {
        const aliasControl = aliasControlByLabel.bind(null, 'Reference Multi Select, Tracking ID');

        beforeEach(() => {
          cy.setupStubbedSwimlane();
          aliasControl();
        });

        it('shows multi select', () => {
          cy.get('@control-container').should('contain', 'Reference Multi Select');
          cy.get('@control').find('.reference-value--label').should('have.length', 0);
        });

        it('open lookup using field', () => {
          cy.setupStubbedSwimlane();
          cy.get('@control').click().trigger('mouseout', { force: true });
          cy.wait('@GET:app');
          cy.wait('@GET:app'); // dialog makes two api calls, fix this
          cy.get('.search-banner--input input').as('input');
          cy.get('@input').should('have.focus');
          cy.get('.reference-lookup-modal--close-button').click();
        });

        describe('New Record', () => {
          before(() => {
            cy.setupStubbedSwimlane();
            aliasControl();
            cy.get('@control-container').find('.input-group-addon').eq(0).click().trigger('mouseout', { force: true });
            cy.wait('@GET:app/*/record');
          });

          after(() => {
            cy.get('.stacks-backdrop').click({ force: true });
          });

          it('shows record header', () => {
            cy.get('.stacks-content .page-toolbar h4').should('contain', 'New Record');
          });
        });

        describe('Reference Lookup', () => {
          before(() => {
            cy.setupStubbedSwimlane();
            aliasControl();
            cy.get('@control-container').find('.input-group-addon').eq(1).click().trigger('mouseout', { force: true });
            cy.wait('@GET:app');
            cy.wait('@GET:app'); // dialog makes two api calls, fix this
          });

          after(closeLookupModal);

          beforeEach(() => {
            cy.get('.search-banner--input input').as('input');
          });

          it('starts with input focused', () => {
            cy.get('@input').should('have.focus');
          });

          describe('search', () => {
            before(() => {
              cy.setupStubbedSwimlane();
              cy.intercept('POST', '/api/search/keyword?*', {
                fixture: 'mocks/swimlane/search/keyword/post-3.json'
              }).as('POST:search/keyword?*');
              cy.intercept('POST', '/api/search/keyword/count?*', {
                fixture: 'mocks/swimlane/search/keyword/count/post-3.json'
              }).as('POST:search/keyword/count?*');
              cy.get('.search-banner--input input').as('input');
              cy.get('@input').should('have.focus');
              cy.get('@input').type('cat{enter}');
              cy.wait('@POST:search/keyword?*');
              cy.wait('@POST:search/keyword/count?*');
            });

            it('shows result counts', () => {
              cy.get('.search-left > .results-meta > .results-meta--label').should('contain', 'Records');
              cy.get('.search-left > .results-meta > .results-meta--count').should('contain', '5 results');
              cy.get('.search-sidebar--selection-list > .results-meta > .results-meta--label').should(
                'contain',
                'Selected Records'
              );
              cy.get('.search-sidebar--selection-list > .results-meta > .results-meta--count').should(
                'contain',
                '0 selected'
              );
            });

            it('selects records', () => {
              cy.get('.record-selector').first().click();
              cy.get('.selected-item').should('have.length', 1);
              cy.get('.selected-item').first().should('contain', 'CA-7');
              cy.get('.selected-item').first().should('contain', 'Matching "cat"');

              cy.get('.record-selector').eq(1).click();
              cy.get('.selected-item').should('have.length', 2);
              cy.get('.selected-item').eq(1).should('contain', 'CA-11');
              cy.get('.selected-item').eq(1).should('contain', 'Matching "cat"');
            });

            it('applies records', () => {
              cy.get('.search-sidebar--selection-list--actions > .btn > button').click();
              cy.get('.reference-lookup-modal').should('not.exist');
              cy.get('@control').find('.reference-value--label').as('rows').should('have.length', 2);
              cy.get('@rows').eq(0).should('contain', 'CA-7');
              cy.get('@rows').eq(1).should('contain', 'CA-11');
            });
          });
        });
      });

      describe('Text Field', () => {
        const aliasControl = aliasControlByLabel.bind(null, 'Reference Multi Select, Text Field');

        beforeEach(() => {
          cy.setupStubbedSwimlane();
          aliasControl();
        });

        it('shows multi select', () => {
          cy.get('@control-container').should('contain', 'Reference Multi Select');
          cy.get('@control').find('.reference-value--label').should('have.length', 0);
        });

        it('open lookup using field', () => {
          cy.setupStubbedSwimlane();
          cy.get('@control').click().trigger('mouseout', { force: true });
          cy.wait('@GET:app');
          cy.wait('@GET:app'); // dialog makes two api calls, fix this
          cy.get('.search-banner--input input').as('input');
          cy.get('@input').should('have.focus');
          cy.get('.reference-lookup-modal--close-button').click();
        });

        describe('New Record', () => {
          before(() => {
            cy.setupStubbedSwimlane();
            aliasControl();
            cy.get('@control-container').find('.input-group-addon').eq(0).click().trigger('mouseout', { force: true });
            cy.wait('@GET:app/*/record');
          });

          after(() => {
            cy.get('.stacks-backdrop').click({ force: true });
          });

          it('shows record header', () => {
            cy.get('.stacks-content .page-toolbar h4').should('contain', 'New Record');
          });
        });

        describe('Reference Lookup', () => {
          before(() => {
            cy.setupStubbedSwimlane();
            aliasControl();
            cy.get('@control-container').find('.input-group-addon').eq(1).click().trigger('mouseout', { force: true });
            cy.wait('@GET:app');
            cy.wait('@GET:app'); // dialog makes two api calls, fix this
          });

          after(closeLookupModal);

          beforeEach(() => {
            cy.get('.search-banner--input input').as('input');
          });

          it('starts with input focused', () => {
            cy.get('@input').should('have.focus');
          });

          describe('search', () => {
            before(() => {
              cy.setupStubbedSwimlane();
              cy.intercept('POST', '/api/search/keyword?*', {
                fixture: 'mocks/swimlane/search/keyword/post-3.json'
              }).as('POST:search/keyword?*');
              cy.intercept('POST', '/api/search/keyword/count?*', {
                fixture: 'mocks/swimlane/search/keyword/count/post-3.json'
              }).as('POST:search/keyword/count?*');
              cy.get('.search-banner--input input').as('input');
              cy.get('@input').should('have.focus');
              cy.get('@input').type('cat{enter}');
              cy.wait('@POST:search/keyword?*');
              cy.wait('@POST:search/keyword/count?*');
            });

            it('shows result counts', () => {
              cy.get('.search-left > .results-meta > .results-meta--label').should('contain', 'Records');
              cy.get('.search-left > .results-meta > .results-meta--count').should('contain', '5 results');
              cy.get('.search-sidebar--selection-list > .results-meta > .results-meta--label').should(
                'contain',
                'Selected Records'
              );
              cy.get('.search-sidebar--selection-list > .results-meta > .results-meta--count').should(
                'contain',
                '0 selected'
              );
            });

            it('selects records', () => {
              cy.get('.record-selector').first().click();
              cy.get('.selected-item').should('have.length', 1);
              cy.get('.selected-item').first().should('contain', 'CA-7');
              cy.get('.selected-item').first().should('contain', 'Matching "cat"');

              cy.get('.record-selector').eq(1).click();
              cy.get('.selected-item').should('have.length', 2);
              cy.get('.selected-item').eq(1).should('contain', 'CA-11');
              cy.get('.selected-item').eq(1).should('contain', 'Matching "cat"');

              cy.get('.record-selector').eq(3).click();
              cy.get('.selected-item').should('have.length', 3);
              cy.get('.selected-item').eq(2).should('contain', 'CA-9');
              cy.get('.selected-item').eq(2).should('contain', 'Matching "cat"');
            });

            it('applies records', () => {
              cy.get('.search-sidebar--selection-list--actions > .btn > button').click();
              cy.get('.reference-lookup-modal').should('not.exist');
              cy.get('@control').find('.reference-value--label').as('rows').should('have.length', 3);
              cy.get('@rows').eq(0).should('contain', 'Curiosity Killed... (CA-7)');
              cy.get('@rows').eq(0).should('have.attr', 'title', 'Curiosity Killed The Cat');
              cy.get('@rows').eq(1).should('contain', 'Cat got your ton... (CA-11)');
              cy.get('@rows').eq(1).should('have.attr', 'title', 'Cat got your tongue?');
              cy.get('@rows').eq(2).should('contain', 'No Value (CA-9)');
              cy.get('@rows').eq(2).should('have.attr', 'title', '');
            });
          });
        });
      });
    });
  });
});

describe('Record Page', () => {
  const appId = 'ad2xJUGes5TNRKG4M';
  const workspaceId = 'aP6rDZMhfXU0550sc';

  const aliasControlByLabel = label => {
    cy.get('label').contains(label).closest('.field-container').as('control-container');
  };

  before(() => {
    cy.login();

    cy.setupStubbedSwimlane();
    cy.navigateSwimlane(`/record/${appId}/`);
  });

  it('shows content header', () => {
    cy.get('.content-area .page-toolbar h4').should('contain', 'New Record');
  });

  describe('Attachment Fields', () => {
    describe('Attachment', () => {
      beforeEach(() => {
        aliasControlByLabel('Attachment');
      });

      it('has label', () => {
        cy.get('@control-container').find('.field-name').should('contain', 'Attachment:');
      });

      it('has input', () => {
        cy.get('@control-container').find('input').should('have.attr', 'type', 'file');
      });

      it('has upload button', () => {
        cy.get('@control-container').find('.attachment-table thead .btn').should('contain', 'Upload file(s)');
      });

      it('shows message', () => {
        cy.get('@control-container').find('.attachment-table tbody td').should('contain', 'No attachments uploaded');
      });
    });
  });
});

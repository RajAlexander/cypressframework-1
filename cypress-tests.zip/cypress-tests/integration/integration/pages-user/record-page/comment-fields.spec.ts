const getIframeDocument = selector => {
  return cy.get(selector).find('iframe').its('0.contentDocument').should('exist');
};

const getEditor = selector => {
  return getIframeDocument(selector).its('body').should('not.be.undefined').then(cy.wrap);
};

describe('Comment Fields', () => {
  const appId = 'ad2xJUGes5TNRKG4M';
  const recordId = 'a3Kjp2HL5YFzEfYzJ';

  const aliasControlByLabel = label => {
    cy.get('label').contains(label).closest('.field-container').as('control-container');
  };

  describe('New Record', () => {
    before(() => {
      cy.login();

      cy.setupStubbedSwimlane();
      cy.navigateSwimlane(`/record/${appId}/`);
    });

    it('shows content header', () => {
      cy.get('.content-area .page-toolbar h4').should('contain', 'New Record');
    });

    describe('Comment Field', () => {
      describe('Comments', () => {
        beforeEach(() => {
          aliasControlByLabel('Comments');
        });

        it('has label', () => {
          cy.get('@control-container').find('.field-name').should('contain', 'Comments:');
        });

        it('has rich text editor', () => {
          cy.get('@control-container').find('rte').should('have.length', 1);
        });

        describe('Comments', () => {
          it('setup comments', () => {
            cy.setupStubbedSwimlane();
            aliasControlByLabel('Comments');

            cy.get('@control-container')
              .scrollIntoView()
              .within(() => {
                cy.getRTE().focus().type('Hello');
                cy.get('.btn-primary').click();

                cy.getRTE().focus().type('Hello ').type('{meta}B').type('World');
                cy.get('.btn-primary').click();

                cy.getRTE().focus().type('1{enter}2{enter}3{enter}4{enter}5{enter}6');
                cy.get('.btn-primary').click();
              });
          });

          it('shows comment count', () => {
            cy.get('.comments-field--comments-header').should('contain', 'Comments 3');
          });

          it('shows comment text', () => {
            cy.get('.comment--body').should('have.length', 3);
            cy.get('.comment--body').eq(0).should('to.contain', 'Hello');
            cy.get('.comment--body')
              .eq(1)
              .invoke('text')
              .should('match', /Hello.+World/);

            // The HTML in comments doesn't seem to render properly when running the tests
            // from the current cypress/included:4.3.0 docker image
            // uncomment after https://github.com/cypress-io/cypress-docker-images/pull/290 gets merged
            // cy.get('.comment--body').eq(1).find('strong').should('have.length', 1);
            // cy.get('.comment--body').eq(1).find('strong').should('to.contain', 'World');

            cy.get('.comment--body')
              .eq(2)
              .find('.comment--body--rich')
              .should('have.html', '<p>1</p>\n<p>2</p>\n<p>3</p>\n<p>4</p>\n<p>5</p>\n<p>6</p>');
          });

          it('shows help lines', () => {
            cy.get('.comment--media-body .help-block').should('have.length', 3);
            cy.get('.comment--media-body .help-block').should('contain', 'Created:');
          });

          it('shows avatars', () => {
            cy.get('@control-container').scrollIntoView();
            cy.get('.avatar').should('have.length', 3);
            cy.get('.avatar').should('contain', 'AD');
          });
        });
      });

      describe('Record', () => {
        it('saves', () => {
          cy.setupStubbedSwimlane();
          cy.get('toolbar button span').should('contain', 'Save').eq(0).as('saveButton');

          cy.get('@saveButton').click();
          cy.wait(`@POST:app/*/record`);
          cy.wait(`@GET:app/*/record/*`);
        });
      });
    });
  });

  describe('Existing Record', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.login();

      cy.navigateSwimlane(`/record/${appId}/${recordId}`);
    });

    beforeEach(() => {
      cy.setupStubbedSwimlane();
    });

    it('shows content header', () => {
      cy.get('.content-area .page-toolbar').find('h4').should('contain', 'TW-5');
    });

    describe('Comment Field', () => {
      describe('Comments', () => {
        beforeEach(() => {
          aliasControlByLabel('Comments');
        });

        it('has label', () => {
          cy.get('@control-container').find('.field-name').should('contain', 'Comments:');
        });

        it('has rich text editor', () => {
          cy.get('@control-container').find('rte').should('have.length', 1);
        });

        describe('Comments', () => {
          it('shows comment count', () => {
            cy.get('.comments-field--comments-header').should('contain', 'Comments 3');
          });

          it('shows comment text', () => {
            cy.get('.comment--body').should('have.length', 3);
            cy.get('.comment--body').eq(1).should('to.contain', 'Hello');

            cy.get('.comment--body').eq(2).should('to.contain', '123456');
          });

          it('shows help lines', () => {
            cy.get('.comment--media-body .help-block').should('have.length', 3);
            cy.get('.comment--media-body .help-block').should('contain', 'Created:');
          });

          it('shows avatars', () => {
            cy.get('@control-container').scrollIntoView();
            cy.get('.avatar').should('have.length', 3);
            cy.get('.avatar').should('contain', 'AD');
          });
        });
      });

      describe('Posting New Comment', () => {
        before(() => {
          cy.setupStubbedSwimlane();
          aliasControlByLabel('Comments');
          cy.get('@control-container').scrollIntoView();
          getEditor('@control-container').focus().type('This will get saved when posting');
        });

        it('saves when posting', () => {
          cy.get('@control-container').find('.btn-primary').click();
          cy.wait(`@POST:app/*/record/*/*/comment`);
        });
      });

      describe('New Comment via Signalr', () => {
        before(() => {
          cy.setupStubbedSwimlane();
          aliasControlByLabel('Comments');

          cy.fixture(`integration/wholeRecordUpdate.json`).then(record => {
            cy.hubPublish('updated', 'records', record);
          });
        });

        it('receives update via signalr', () => {
          // cy.get('.ng-notification-content').should('contain', 'Record was updated by admin');
          cy.get('.comment--body').should('have.length', 5);
          cy.get('.comment--body').eq(3).should('to.contain', 'Whole Record Update Comment');
        });
      });

      describe('Image Thumbnail', () => {
        it('clicks image thumbnail and opens image in large size', () => {
          cy.get('.comment--body')
            .eq(4)
            .within(() => {
              cy.get('.comment--body--rich').within(() => {
                cy.get('img')
                  .should('have.css', 'width', '150px')
                  .and('have.css', 'height', '92.46875px')
                  .and('have.css', 'max-width', '150px')
                  .and('have.css', 'max-height', '150px')
                  .click();
              });
            });
          cy.get('.comment-image-dialog').within(() => {
            cy.get('img').should('have.css', 'width', '500px').and('have.css', 'height', '303px');
            cy.get('.close').click();
          });
        });
      });
    });
  });
});

describe('Select Fields', () => {
  const appId = 'ad2xJUGes5TNRKG4M';
  const workspaceId = 'aP6rDZMhfXU0550sc';
  const recordId = 'a3Kjp2HL5YFzEfYzJ';

  const aliasControlByLabel = label => {
    cy.get('label').contains(label).closest('.field-container').as('control-container');
  };

  describe('New Record Page', () => {
    before(() => {
      cy.login();

      cy.setupStubbedSwimlane();
      cy.navigateSwimlane(`/record/${appId}/`);
    });

    it('shows content header', () => {
      cy.get('.content-area').should('exist');
      cy.get('.content-area .page-toolbar').should('exist');
      cy.get('.content-area .page-toolbar h4').should('contain', 'New Record');
    });

    describe('Single-select', () => {
      beforeEach(() => {
        aliasControlByLabel('Single-select');
      });

      it('has label', () => {
        cy.get('@control-container').find('.field-name').should('contain', 'Single-select:');
      });

      it('has select box', () => {
        cy.get('@control-container').find('.ui-select-container').should('have.length', 1);
      });
    });

    describe('Multi-select', () => {
      beforeEach(() => {
        aliasControlByLabel('Multi-select');
      });

      it('has label', () => {
        cy.get('@control-container').find('.field-name').should('contain', 'Multi-select:');
      });

      it('has select box', () => {
        cy.get('@control-container').find('.ui-select-container').should('have.length', 1);
      });
    });

    describe('Radio buttons', () => {
      beforeEach(() => {
        aliasControlByLabel('Radio buttons');
      });

      it('has label', () => {
        cy.get('@control-container').find('.field-name').should('contain', 'Radio buttons:');
      });

      it('has select box', () => {
        cy.get('@control-container').find('input[type="radio"]').should('have.length', 4);
      });
    });

    describe('Checkboxes', () => {
      beforeEach(() => {
        aliasControlByLabel('Checkboxes');
      });

      it('has label', () => {
        cy.get('@control-container').find('.field-name').should('contain', 'Checkboxes:');
      });

      it('has select box', () => {
        cy.get('@control-container').find('input[type="checkbox"]').should('have.length', 4);
      });
    });
  });

  describe('Existing Record', () => {
    before(() => {
      cy.setupStubbedSwimlane();

      cy.login();
      cy.navigateSwimlane(`/record/${appId}/${recordId}`);
    });

    it('shows content header', () => {
      cy.get('.content-area').should('exist');
      cy.get('.content-area .page-toolbar').should('exist');
      cy.get('.content-area .page-toolbar h4').should('contain', 'TW-5');
    });

    describe('Single-select', () => {
      beforeEach(() => {
        aliasControlByLabel('Single-select');
      });

      it('has label', () => {
        cy.get('@control-container').find('.field-name').should('contain', 'Single-select:');
      });

      it('has select box', () => {
        cy.get('@control-container').find('.ui-select-container').should('have.length', 1);
      });

      it('has value', () => {
        cy.get('@control-container').find('.ui-select-match').should('contain', 'Value (2)');
      });
    });

    describe('Multi-select', () => {
      beforeEach(() => {
        aliasControlByLabel('Multi-select');
      });

      it('has label', () => {
        cy.get('@control-container').find('.field-name').should('contain', 'Multi-select:');
      });

      it('has select box', () => {
        cy.get('@control-container').find('.ui-select-container').should('have.length', 1);
      });

      it('has values', () => {
        cy.get('@control-container').find('.ui-select-match-item').should('have.length', 1);
        cy.get('@control-container').find('.ui-select-match-item').should('contain', 'Value (2)');
      });
    });

    describe('Radio buttons', () => {
      beforeEach(() => {
        aliasControlByLabel('Radio buttons');
      });

      it('has label', () => {
        cy.get('@control-container').find('.field-name').should('contain', 'Radio buttons:');
      });

      it('has select box', () => {
        cy.get('@control-container').find('input[type="radio"]').should('have.length', 4);
      });

      it('has values', () => {
        cy.get('@control-container').find('input[type="radio"]').eq(0).should('have.prop', 'checked', false);
        cy.get('@control-container').find('input[type="radio"]').eq(3).should('have.prop', 'checked', true);
      });
    });

    describe('Checkboxes', () => {
      beforeEach(() => {
        aliasControlByLabel('Checkboxes');
      });

      it('has label', () => {
        cy.get('@control-container').find('.field-name').should('contain', 'Checkboxes:');
      });

      it('has select box', () => {
        cy.get('@control-container').find('input[type="checkbox"]').should('have.length', 4);
      });

      it('has values', () => {
        cy.get('@control-container').find('input[type="checkbox"]').eq(1).should('have.prop', 'checked', false);
        cy.get('@control-container').find('input[type="checkbox"]').eq(3).should('have.prop', 'checked', true);
      });
    });

    describe('co-edit updates', () => {
      const MOCK_COEDITOR = {
        id: 'aO_RunwkwbYwkml6X',
        name: 'joetester'
      };

      describe('Single-select', () => {
        before(() => {
          cy.hubPublish('coeditUpdated', {
            userId: MOCK_COEDITOR,
            messageType: 'editing',
            recordId,
            applicationId: appId,
            fieldId: 'atdq3',
            value: {
              id: '5dd2fd55fd50f9e02f21765c',
              value: 'Value (3)'
            }
          });
        });

        it('updates', () => {
          aliasControlByLabel('Single-select');
          cy.get('@control-container').find('.ui-select-match').should('contain', 'Value (3)');
        });
      });

      describe('Multi-select', () => {
        before(() => {
          cy.hubPublish('coeditUpdated', {
            userId: MOCK_COEDITOR,
            messageType: 'editing',
            recordId,
            applicationId: appId,
            fieldId: 'a07bz',
            value: [
              {
                id: '5dd2fd5ae7a07b0f1531d89e',
                value: 'Value (2)'
              },
              {
                id: '5dd2fd59cf50ab9d9a939fd7',
                value: 'Value (1)'
              }
            ]
          });
        });

        it('updates values', () => {
          aliasControlByLabel('Multi-select');
          cy.get('@control-container').find('.ui-select-match-item').should('have.length', 2);
          cy.get('@control-container').find('.ui-select-match-item').eq(0).should('contain', 'Value (2)');
          cy.get('@control-container').find('.ui-select-match-item').eq(1).should('contain', 'Value (1)');
        });
      });
    });
  });
});

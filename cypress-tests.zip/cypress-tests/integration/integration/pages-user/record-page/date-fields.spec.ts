describe('Record Page', () => {
  const appId = 'ad2xJUGes5TNRKG4M';

  const aliasControlByLabel = label => {
    cy.get('label')
      // tslint:disable-next-line: tsr-detect-non-literal-regexp
      .contains(new RegExp(`^${label}$`))
      .closest('.field-container')
      .as('control-container');
  };

  before(() => {
    cy.login();

    cy.setupStubbedSwimlane();
    cy.navigateSwimlane(`/record/${appId}/`);
  });

  it('shows content header', () => {
    cy.get('.content-area .page-toolbar h4').should('contain', 'New Record');
  });

  describe('Date Fields', () => {
    describe('Date & Time', () => {
      beforeEach(() => {
        aliasControlByLabel('Date & Time');
      });

      it('has label', () => {
        cy.get('@control-container').find('.field-name').should('contain', 'Date & Time:');
      });

      it('has textbox', () => {
        cy.get('@control-container').find('input').should('have.attr', 'type', 'text');
      });

      it('has calender-clock button', () => {
        cy.get('@control-container').find('button.calendar-dialog-btn').should('have.class', 'icon-calendar-clock');
      });
    });

    describe('Date', () => {
      beforeEach(() => {
        aliasControlByLabel('Date');
      });

      it('has label', () => {
        cy.get('@control-container').find('.field-name').should('contain', 'Date');
      });

      it('has textbox', () => {
        cy.get('@control-container').find('input').should('have.attr', 'type', 'text');
      });

      it('has calender button', () => {
        cy.get('@control-container').find('button.calendar-dialog-btn').should('have.class', 'icon-calendar');
      });
    });

    describe('Time', () => {
      beforeEach(() => {
        aliasControlByLabel('Time');
      });

      it('has label', () => {
        cy.get('@control-container').find('.field-name').should('contain', 'Time');
      });

      it('has textbox', () => {
        cy.get('@control-container').find('input').should('have.attr', 'type', 'text');
      });

      it('has clock button', () => {
        cy.get('@control-container').find('button.calendar-dialog-btn').should('have.class', 'icon-clock');
      });
    });

    describe('Timespan', () => {
      beforeEach(() => {
        aliasControlByLabel('Timespan');
      });

      it('has label', () => {
        cy.get('@control-container').find('.field-name').should('contain', 'Timespan:');
      });

      it('has textbox', () => {
        cy.get('@control-container').find('input').should('have.attr', 'placeholder', '(e.g. 3w 4d 12h)');
      });
    });

    describe('First Created', () => {
      beforeEach(() => {
        aliasControlByLabel('First Created');
      });

      it('has label', () => {
        cy.get('@control-container').find('.field-name').should('contain', 'First Created:');
      });

      it('shows message', () => {
        cy.get('@control-container').find('.field-container--readonly').should('contain', 'Save record to populate');
      });
    });

    describe('Last Updated', () => {
      beforeEach(() => {
        aliasControlByLabel('Last Updated');
      });

      it('has label', () => {
        cy.get('@control-container').find('.field-name').should('contain', 'Last Updated:');
      });

      it('shows message', () => {
        cy.get('@control-container')
          .find('.field-container--readonly')
          .should('contain', 'Record has not been modified');
      });
    });
  });
});

describe('Record Page', () => {
  const appId = 'ad2xJUGes5TNRKG4M';
  const workspaceId = 'aP6rDZMhfXU0550sc';

  const aliasControlByLabel = label => {
    cy.get('label').contains(label).closest('.field-container').as('control-container');
  };

  before(() => {
    cy.login();

    cy.setupStubbedSwimlane();
    cy.navigateSwimlane(`/record/${appId}/`);
  });

  it('shows content header', () => {
    cy.get('.content-area .page-toolbar h4').should('contain', 'New Record');
  });

  describe('Numeric Fields', () => {
    describe('Numeric', () => {
      beforeEach(() => {
        aliasControlByLabel('Numeric');
      });

      it('has label', () => {
        cy.get('@control-container').find('.field-name').should('contain', 'Numeric:');
      });

      it('has textbox', () => {
        cy.get('@control-container').find('input').should('have.attr', 'type', 'number');
      });

      it('has help text', () => {
        cy.get('@control-container').find('.help-block').should('contain', 'Numeric Field Help Text');
      });
    });

    describe('Numeric List', () => {
      beforeEach(() => {
        aliasControlByLabel('Numeric List');
      });

      it('has label', () => {
        cy.get('@control-container').find('.field-name').should('contain', 'Numeric List:');
      });

      it('has textbox', () => {
        cy.get('@control-container').find('input').should('have.length', 1);
      });

      it('has help text', () => {
        cy.get('@control-container').find('.help-block').should('contain', 'Numeric List Help Text');
      });
    });
  });
});

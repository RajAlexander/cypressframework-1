import moment from 'moment';
import existingRecord from '../../../fixtures/mocks/swimlane/app/__/record/get.json';

describe('Record Page', () => {
  const appId = 'ad2xJUGes5TNRKG4M';
  const recordId = 'a3Kjp2HL5YFzEfYzJ';
  const fieldId = '#azzzm';

  before(() => {
    cy.setupStubbedSwimlane();

    cy.login();
    cy.setMockFeatureFlag('RecordPage');

    // Gives a location for navigation after delete
    cy.navigateSwimlane(`/welcome`);

    cy.navigateSwimlane(`/record2/${appId}/${recordId}`);
    cy.waitForNetworkIdle(2000);
  });

  it('shows content header', () => {
    cy.get('.record-state__toolbar').should('exist');
    cy.dataCy('record_page__title').should('exist').should('contain', 'TW-5');
  });

  it('shows created and updated information in popup', () => {
    cy.dataCy('record_page__title').whileHovering(() => {
      cy.root()
        .closest('body')
        .find('.tooltip-content')
        .should('exist')
        .should('contain', 'Created')
        .should('contain', `${moment(existingRecord.createdDate).fromNow()}`)
        .should('contain', 'by admin')
        .should('contain', 'Updated')
        .should('contain', `${moment(existingRecord.modifiedDate).fromNow()}`)
        .should('contain', 'by john');
    });
  });

  it('shows controls', () => {
    cy.get('.record-state__toolbar__controls').should('exist');
    cy.get('.record-state__toolbar__controls .btn-primary').should('exist').should('contain', 'Save');
    cy.get('.record-state__toolbar__controls .btn-link').first().should('exist').should('contain', 'New Record');
    // cy.get('.record-state__toolbar__controls .btn-link').eq(1).should('exist').should('contain', 'Delete');

    cy.get('.record-state__toolbar__controls ngx-dropdown').within(() => {
      cy.get('.ngx-dropdown-toggle button').click();
      cy.get('li button').first().should('contain', 'Delete');
      cy.get('.ngx-dropdown-toggle button').click();
    });
  });

  it('loads record values', () => {
    cy.get(fieldId).ngxGetValue().should('eq', 'Text Field Value');
  });

  it('disables buttons that have no tasks', () => {
    cy.get('#6202e5a26e71da4702eec47d button').should('not.be.disabled');
    cy.get('#6202ff259084a331c1c43014 button').should('be.disabled');
  });

  it('block navigation when dirty', () => {
    cy.get(fieldId).ngxFill('Hello');

    cy.get('.nav-logo').click();
    cy.get('.ngx-dialog-content')
      .should('exist')
      .should('contain', 'You have unsaved changes')
      .contains('Cancel')
      .click();
  });

  it('can save', () => {
    cy.setupStubbedSwimlane();

    cy.get(fieldId).ngxFill('hello');

    cy.get('.record-state__toolbar__controls').should('exist');
    cy.get('.record-state__toolbar__controls .btn-primary').contains('Save').click();

    cy.wait('@PUT:app/*/record');
    cy.get('.notification-content').whileHovering($el => {
      cy.wrap($el).should('contain', 'Record saved');
    });
    cy.ngxCloseNotifications();
  });

  it('can delete', () => {
    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('RecordPage');

    cy.get('.record-state__toolbar__controls').should('exist');
    cy.get('.record-state__toolbar__controls ngx-dropdown').within(() => {
      cy.get('.ngx-dropdown-toggle button').click();
      cy.get('li button').contains('Delete').click();
    });

    cy.get('ngx-alert-dialog').within(() => {
      // TODO: verify delete dialog contents
      cy.get('button').contains('Ok').click();
    });

    cy.wait('@DELETE:app/*/record/*');
    cy.url().should('include', `/welcome`);
    cy.waitForNetworkIdle(3000);

    cy.navigateSwimlane(`/record2/${appId}/${recordId}`); // go back to record page after delete
    cy.waitForNetworkIdle(3000);
  });

  it('can navigate to new record', () => {
    cy.setupStubbedSwimlane();

    cy.get('.record-state__toolbar__controls .btn-link').contains('New Record').click();

    cy.url().should('include', `/record2/${appId}/`);
    cy.get('.record-state__toolbar .record-state__toolbar__title').should('exist').should('contain', 'New Record');
  });
});

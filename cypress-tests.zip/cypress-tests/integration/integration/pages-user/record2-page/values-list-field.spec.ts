describe('Values List Fields', () => {
  const appId = 'values_list_fields';
  const recordId = 'values_list_fields_record';

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('RecordPage');
    cy.navigateSwimlane(`/record2/${appId}/${recordId}`);
  });

  describe('single selects', () => {
    it('default value', () => {
      cy.getByLabel('Default Single Select').as('selectField');
      cy.get('@selectField').ngxGetValue().should('eq', 'Selected By Default');
    });

    it('option description text', () => {
      cy.getByLabel('Default Single Select').as('selectField');
      cy.get('@selectField').ngxOpen();
      cy.get('@selectField').within(() => {
        cy.get('ngx-select-dropdown li.ngx-select-dropdown-option').as('options');
        cy.get('@options')
          .contains('Selected By Default')
          .whileHovering(() => {
            cy.root()
              .closest('body')
              .find('.ngx-tooltip__content')
              .should('contain', 'Selected By Default Description Text');
          });
      });
    });

    it('other text field', () => {
      cy.getByLabel('Default Single Select').as('selectField');
      cy.get('@selectField').ngxOpen();
      cy.get('@selectField').within(() => {
        cy.get('ngx-select-dropdown li.ngx-select-dropdown-option').as('options');
        cy.get('@options')
          .contains('New Value (2)')
          .as('option')
          .whileHovering(() => {
            cy.root()
              .closest('body')
              .find('.ngx-tooltip__content')
              .should('contain', 'New Value (2) Default Description Text');
          });
        cy.get('@option').click();
      });
      cy.get('@selectField')
        .siblings()
        .closest('.values-list-field__other-text')
        .within(() => {
          cy.getByLabel('Enter text for selection').as('otherTextField');
          cy.get('@otherTextField').ngxFindNativeInput().should('have.attr', 'placeholder', 'other text placeholder');
          cy.get('@otherTextField').find('.ngx-input-hint').should('contain', 'this is other text description');
          cy.get('@otherTextField').ngxGetValue().should('eq', 'other text value');
        });
    });

    it('required', () => {
      cy.getByLabel('Required Single Select').as('selectField');
      cy.get('@selectField').within(() => {
        cy.get('label.ngx-select-label').should('contain', '*');
      });
      cy.get('@selectField').clear();
      cy.get('@selectField').find('.ngx-select-hint').should('contain', 'Error: Required Single Select is required.');
    });

    describe('help text', () => {
      it('below', () => {
        cy.getByLabel('Single Select Help Text Below').closest('.values-list-field').as('selectField');
        cy.get('@selectField').find('.record-field__help-text--below').should('contain', 'Help Text');
      });

      it('above', () => {
        cy.getByLabel('Single Select Help Text Above').closest('.values-list-field').as('selectField');
        cy.get('@selectField').find('.record-field__help-text--above').should('contain', 'Help Text');
      });
    });

    it('readonly', () => {
      cy.getByLabel('Readonly Single Select').as('selectField');
      cy.get('@selectField').should('contain', 'New Value');
    });
  });

  describe('Multi selects', () => {
    it('default values', () => {
      cy.getByLabel('Default Multi Select').as('selectField');
      const defaultVals = cy.get('@selectField').ngxGetValue();
      defaultVals.should('deep.equal', ['Selected By Default', 'Selected By Default 2']);
    });

    it('option description text', () => {
      cy.getByLabel('Default Multi Select').as('selectField');
      cy.get('@selectField').ngxOpen();
      cy.get('@selectField').within(() => {
        cy.get('ngx-select-dropdown li.ngx-select-dropdown-option').as('options');
        cy.get('@options')
          .contains('Selected By Default')
          .whileHovering(() => {
            cy.root()
              .closest('body')
              .find('.ngx-tooltip__content')
              .should('contain', 'Selected By Default Description Text');
          });
      });
    });

    it('required', () => {
      cy.getByLabel('Required Multi Select').as('selectField');
      cy.get('@selectField').within(() => {
        cy.get('label.ngx-select-label').should('contain', '*');
      });
      cy.get('@selectField').clear();
      cy.get('@selectField').find('.ngx-select-hint').should('contain', 'Error: Required Multi Select is required.');
    });

    it('readonly', () => {
      cy.getByLabel('Readonly Multi Select').as('selectField');
      cy.get('@selectField').within(() => {
        cy.get('ul li').as('li').should('have.length', 2);
        cy.get('@li').eq(0).should('contain', 'New Value (2)');
        cy.get('@li').eq(1).should('contain', 'New Value');
      });
    });
  });

  describe('Radio Buttons', () => {
    it('default value', () => {
      cy.getByLabel('Default Radio buttons').as('selectField');
      cy.get('@selectField').within(() => {
        cy.get('ngx-radiobutton').should('have.length', 3);
        cy.getByLabel('Selected By Default').as('on');
        cy.get('@on').should('have.attr', 'aria-checked', 'true');
        cy.getByLabel('New Value').as('off');
        cy.get('@off').should('have.attr', 'aria-checked', 'false');
        cy.getByLabel('New Value (2)').as('off2');
        cy.get('@off2').should('have.attr', 'aria-checked', 'false');
        cy.get('@off').click();
        cy.get('@on').should('have.attr', 'aria-checked', 'false');
        cy.get('@off').should('have.attr', 'aria-checked', 'true');
      });
    });

    it('option description text', () => {
      cy.getByLabel('Default Radio buttons').as('selectField');
      cy.get('@selectField').within(() => {
        cy.getByLabel('Selected By Default')
          .parents()
          .nextUntil('.option-description')
          .should('contain', 'Selected By Default Description Text');
      });
    });

    it('other text field', () => {
      cy.getByLabel('Default Radio buttons').as('selectField');
      cy.get('@selectField').within(() => {
        cy.getByLabel('Selected By Default').click();
      });

      cy.get('@selectField')
        .siblings()
        .closest('.values-list-field__other-text')
        .within(() => {
          cy.getByLabel('Enter text for selection').as('otherTextField');
          cy.get('@otherTextField').ngxFindNativeInput().should('have.attr', 'placeholder', 'other text placeholder');
          cy.get('@otherTextField').find('.ngx-input-hint').should('contain', 'this is other text description');
          cy.get('@otherTextField').ngxGetValue().should('eq', 'other text value');
        });

      cy.get('@selectField').within(() => {
        cy.getByLabel('New Value').click();
      });

      cy.get('@selectField').siblings().closest('.values-list-field__other-text').should('not.exist');
    });

    it('required', () => {
      cy.get('.record-field__field-label')
        .contains('Required Radio buttons')
        .closest('.values-list-field')
        .as('selectField');
      cy.get('@selectField').find('.record-field__field-label').should('contain', '*');
      cy.get('.record-state__toolbar__controls .btn-primary').should('contain', 'Save').find('button').click();
      cy.get('@selectField')
        .find('.record-field__error-message')
        .should('contain', 'Error: Required Radio buttons is required.');
    });

    describe('help text', () => {
      it('below', () => {
        cy.getByLabel('Radio buttons Help Text Below').closest('.values-list-field').as('selectField');
        cy.get('@selectField').find('.record-field__help-text--below').should('contain', 'Help Text');
      });

      it('above', () => {
        cy.getByLabel('Radio buttons Help Text Above').closest('.values-list-field').as('selectField');
        cy.get('@selectField').find('.record-field__help-text--above').should('contain', 'Help Text');
      });
    });

    it('readonly', () => {
      cy.getByLabel('Readonly Radio buttons').as('selectField');
      cy.get('@selectField').should('contain', 'New Value');
    });
  });

  describe('Checkboxes', () => {
    it('default value', () => {
      cy.getByLabel('Default Checkboxes').as('selectField');
      cy.get('@selectField').within(() => {
        cy.get('ngx-checkbox').should('have.length', 4);
        cy.getByLabel('Selected By Default').as('on');
        cy.get('@on').siblings('.ngx-checkbox--box').should('have.class', 'checked');

        cy.getByLabel('Selected By Default 2').as('on2');
        cy.get('@on2').siblings('.ngx-checkbox--box').should('exist');

        cy.getByLabel('New Value').as('off');
        cy.get('@off').siblings('.ngx-checkbox--box').should('not.have.class', 'checked');

        cy.getByLabel('New Value (2)').as('off2');
        cy.get('@off2').siblings('.ngx-checkbox--box').should('not.have.class', 'checked');
      });
    });

    it('option description text', () => {
      cy.getByLabel('Default Checkboxes').as('selectField');
      cy.get('@selectField').within(() => {
        cy.getByLabel('Selected By Default')
          .closest('ngx-checkbox')
          .next('.option-description')
          .should('contain', 'Selected By Default Description Text');
        cy.getByLabel('Selected By Default 2')
          .closest('ngx-checkbox')
          .next('.option-description')
          .should('contain', 'Selected By Default 2 Description Text');
      });
    });

    it('required', () => {
      cy.get('.record-field__field-label')
        .contains('Required Checkboxes')
        .closest('.values-list-field')
        .as('selectField');
      cy.get('@selectField').within(() => {
        cy.get('.record-field__field-label').should('contain', '*');
        cy.getByLabel('New Value (2)').as('checkbox');
        cy.get('@checkbox').siblings('.ngx-checkbox--box').should('have.class', 'checked');
        cy.get('@checkbox').click({ force: true });
        cy.get('@checkbox').siblings('.ngx-checkbox--box').should('not.have.class', 'checked');
        cy.get('.record-field__error-message').should('contain', 'Error: Required Checkboxes is required.');
      });
    });

    describe('help text', () => {
      it('below', () => {
        cy.getByLabel('Checkboxes Help Text Below').closest('.values-list-field').as('selectField');
        cy.get('@selectField').find('.record-field__help-text--below').should('contain', 'Help Text');
      });

      it('above', () => {
        cy.getByLabel('Checkboxes Help Text Above').closest('.values-list-field').as('selectField');
        cy.get('@selectField').find('.record-field__help-text--above').should('contain', 'Help Text');
      });
    });

    it('readonly', () => {
      cy.getByLabel('Readonly Checkboxes').as('selectField');
      cy.get('@selectField').within(() => {
        cy.get('ul li').as('li').should('have.length', 2);
        cy.get('@li').eq(0).should('contain', 'New Value (2)');
        cy.get('@li').eq(1).should('contain', 'New Value');
      });
    });
  });
});

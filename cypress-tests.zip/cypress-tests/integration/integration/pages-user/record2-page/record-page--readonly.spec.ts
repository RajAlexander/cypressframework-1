import moment from 'moment';
import existingRecord from '../../../fixtures/mocks/swimlane/app/__/record/get.json';

describe('Record Page - Readonly Permissions', () => {
  const appId = 'ad2xJUGes5TNRKG4M';
  // const workspaceId = 'aP6rDZMhfXU0550sc';
  const recordId = 'a3Kjp2HL5YFzEfYzJ';
  const fieldId = '#azzzm';

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();

    // Reset login to a limited user
    // This user only has read permissions
    cy.intercept('GET', '/api/user/authorize', {
      fixture: 'mocks/swimlane/user/authorize/get-user-readonly.json'
    }).as('GET:user/authorize');

    cy.setMockFeatureFlag('RecordPage');
    cy.navigateSwimlane(`/record2/${appId}/${recordId}`);
  });

  it('shows content header', () => {
    cy.get('.record-state__toolbar').should('exist');
    cy.dataCy('record_page__title').should('exist').should('contain', 'TW-5');
  });

  it('shows created and updated information in popup', () => {
    cy.dataCy('record_page__title').whileHovering(() => {
      cy.root()
        .closest('body')
        .find('.tooltip-content')
        .should('exist')
        .should('contain', 'Created')
        .should('contain', `${moment(existingRecord.createdDate).fromNow()}`)
        .should('contain', 'by admin')
        .should('contain', 'Updated')
        .should('contain', `${moment(existingRecord.modifiedDate).fromNow()}`)
        .should('contain', 'by john');
    });
  });

  it('does not shows controls', () => {
    cy.get('.record-state__toolbar__controls').should('exist');
    cy.get('.record-state__toolbar__controls button').should('have.length', 0);
    cy.get('.record-state__toolbar__controls ngx-dropdown').should('not.exist', { timeout: 1000 });
  });

  it('loads record values', () => {
    cy.get(fieldId).ngxGetValue().should('contain', 'Text Field Value');
  });

  it('disables all buttons', () => {
    cy.get('#6202e5a26e71da4702eec47d button').should('be.disabled');
    cy.get('#6202ff259084a331c1c43014 button').should('be.disabled');
  });
});

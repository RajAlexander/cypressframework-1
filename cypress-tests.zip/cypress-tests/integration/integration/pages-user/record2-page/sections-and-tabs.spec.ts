const findSection = (sectionHeaderName: string, alias = 'section') => {
  return cy
    .get('record-section ngx-section ngx-section-header')
    .contains(sectionHeaderName)
    .closest('ngx-section')
    .as(alias);
};

describe('Sections and Tabs', () => {
  const appId = 'layout';
  const recordId = 'layout_record';

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('RecordPage');
    cy.navigateSwimlane(`/record2/${appId}/${recordId}`);
  });

  describe('section', () => {
    it('default section', () => {
      findSection('default section');
      cy.get('@section').should('exist');
      cy.get('@section').within(() => {
        cy.get('ngx-section-header').should('contain', 'default section');
        cy.get('.hide-empty-fields-toggle').should('have.class', 'show-empty');
        cy.getByLabel('default section text').as('textField');
        cy.get('.ngx-section-toggle').click();
        cy.get('.ngx-section-content').should('not.exist');
      });
    });

    it('hidden border section', () => {
      cy.getByLabel('section with hidden border text').as('textField');
      cy.get('@textField').find('input').should('have.value', 'section with hidden border text value');
      cy.get('@textField').closest('record-section').as('section');
      cy.get('@section').within(() => {
        cy.get('ngx-section').should('not.exist');
        cy.get('.record-layout').find('ngx-input').as('textFieldMatch');
        cy.get('@textFieldMatch').find('input').should('have.value', 'section with hidden border text value');
      });
    });

    it('collapsed section', () => {
      findSection('section collapsed');
      cy.get('@section').should('exist');
      cy.get('@section').within(() => {
        cy.get('ngx-section-header').should('contain', 'section collapsed');
        cy.get('.hide-empty-fields-toggle').should('have.class', 'show-empty');
        cy.get('.ngx-section-content').should('not.exist');
        cy.get('.ngx-section-toggle').click();
        cy.get('.ngx-section-content').should('exist');
        cy.getByLabel('section collapsed text').as('textField');
        cy.get('@textField').find('input').should('have.value', 'section collapsed text value');
      });
    });

    it('section help text - above', () => {
      findSection('section with help text above');
      cy.get('@section').within(() => {
        cy.get('.record-section__help-text--above').as('helpText').should('contain', 'help text above');
      });
    });

    it('section help text - below', () => {
      findSection('section with help text below');
      cy.get('@section').within(() => {
        cy.get('.record-section__help-text--below').as('helpText').should('contain', 'help text below');
      });
    });
  });

  describe('tabs', () => {
    it('active tab', () => {
      cy.get('ngx-tabs').eq(0).as('tabs');
      cy.get('@tabs').within(() => {
        cy.get('.ngx-tab').contains('Tab 2').should('have.class', 'active');
        cy.get('.ngx-tab-content ngx-tab')
          .eq(1)
          .find('.record-layout')
          .within(() => {
            cy.getByLabel('active tab text').as('textField');
            cy.get('@textField').find('input').should('have.value', 'active tab text value');
          });
      });
    });

    it('switch tab', () => {
      cy.get('ngx-tabs').eq(0).as('tabs');
      cy.get('@tabs').within(() => {
        cy.get('.ngx-tab').contains('Tab 1').as('tab1').should('not.have.class', 'active');
        cy.get('@tab1').click();
        cy.get('@tab1').should('have.class', 'active');
        cy.get('.ngx-tab-content ngx-tab')
          .eq(0)
          .find('.record-layout')
          .within(() => {
            cy.get('ngx-input').should('not.exist');
          });
      });
    });
  });

  describe('hide empty field - clean', () => {
    it(`hide all children's fields on toggling "hide empty fields" icon`, () => {
      findSection('section with children', 'parentSection');
      cy.get('@parentSection').within(() => {
        cy.get('ngx-section-header')
          .contains('section with children')
          .closest('ngx-section-header')
          .find('.hide-empty-fields-toggle')
          .as('parentSectionToggle')
          .should('have.class', 'show-empty');
        cy.getByLabel('section with children text').as('field1');
        cy.getByLabel('child section text').as('field2');
        cy.getByLabel('child tab text').as('field3');
        cy.get('@field1').find('input').should('have.value', '');
        cy.get('@field2').find('input').should('have.value', '');
        cy.get('@field3').find('input').should('have.value', '');
        cy.get('ngx-input').should('have.length', 3);
        findSection('child section', 'childSection');
        cy.get('@childSection')
          .find('.hide-empty-fields-toggle')
          .as('childSectionToggle')
          .should('have.class', 'show-empty');
        cy.get('@parentSectionToggle').click();

        cy.get('@parentSectionToggle').should('have.class', 'hide-empty');
        cy.get('@childSectionToggle').should('have.class', 'hide-empty');
        cy.get('ngx-input').should('not.exist');
      });
    });

    it(`child section can override parent's toggle setting`, () => {
      findSection('section with children', 'parentSection');
      findSection('child section', 'childSection');
      cy.get('@childSection').within(() => {
        cy.get('@childSection')
          .find('.hide-empty-fields-toggle')
          .as('childSectionToggle')
          .should('have.class', 'hide-empty');
        cy.get('ngx-input').should('not.exist');
        cy.get('@childSectionToggle').click();
        cy.get('@childSectionToggle').should('have.class', 'show-empty');
        cy.getByLabel('child section text').as('textField');
        cy.get('@textField').find('input').should('have.value', '');
      });
      cy.get('@parentSection').find('ngx-input').should('have.length', 1);
    });

    it('if field is not empty, toggle does not hide field', () => {
      findSection('child section', 'childSection');
      cy.get('@childSection').within(() => {
        cy.get('@childSection')
          .find('.hide-empty-fields-toggle')
          .as('childSectionToggle')
          .should('have.class', 'show-empty');
        cy.getByLabel('child section text').as('textField');
        cy.get('@textField').ngxFill('hello');
        cy.get('@childSectionToggle').click();
        cy.get('@childSectionToggle').should('have.class', 'hide-empty');
        cy.get('@textField').find('input').should('have.value', 'hello');
        cy.get('@textField').clear();
        cy.get('ngx-input').should('not.exist');
      });
    });
  });

  describe('hide empty field - local storage', () => {
    const key = `hide-empty-fields-${appId}-${recordId}`;
    const defaultSectionId = '61a3077176366befdcf770f5';

    before(() => {
      cy.login();
      cy.setupStubbedSwimlane();
      cy.setMockFeatureFlag('RecordPage');
      cy.navigateSwimlane(`/record2/${appId}/${recordId}`).then(() => {
        let map = window.localStorage.getItem(key);
        map = JSON.parse(map);
        map[defaultSectionId] = true;
        window.localStorage.setItem(key, JSON.stringify(map));
      });
    });

    it('field is hidden due to local storage map', () => {
      findSection('default section');
      cy.get('@section').should('exist');
      cy.get('@section').within(() => {
        cy.get('ngx-section-header').should('contain', 'default section');
        cy.get('.hide-empty-fields-toggle').should('have.class', 'hide-empty');
        cy.get('ngx-input').should('not.exist');
      });
    });
  });
});

describe('User Group Fields', () => {
  const appId = 'user_group_fields';
  const recordId = 'user_group_fields_record';

  const userId = 'aVdPPtOZRjobxxp6p';
  const groupId = 'aYnfTOxsoL17qPA5t';

  before(() => {
    cy.intercept('GET', '/api/user/*', {
      id: userId,
      name: 'admin',
      displayName: 'admin'
    }).as('setUpUsers');

    cy.intercept('GET', '/api/groups/*', {
      id: groupId,
      name: 'analysts',
      displayName: 'analysts'
    }).as('setUpGroups');

    cy.login();
    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('RecordPage');
    cy.navigateSwimlane(`/record2/${appId}/${recordId}`);
    cy.wait('@setUpUsers');
    cy.wait('@setUpGroups');
  });

  describe('single selects', () => {
    it('basic', () => {
      cy.intercept('GET', '/api/user/search?*', {
        fixture: 'mocks/swimlane/user/search/--__.get.json'
      }).as('GET:users');
      cy.intercept('GET', '/api/groups/lookup?*', {
        fixture: 'mocks/swimlane/groups/lookup/--__.get.json'
      }).as('GET:groups');
      cy.getByLabel('Single User/Groups').as('ugField');

      // search
      cy.get('@ugField').ngxFill('admin');
      cy.wait('@GET:users');
      cy.wait('@GET:groups');
      cy.get('@ugField').within(() => {
        cy.get('.ngx-select-dropdown li.ngx-select-option-group').eq(0).as('users');
        cy.get('.ngx-select-dropdown li.ngx-select-option-group').eq(1).as('groups');
        cy.get('@users').within(() => {
          cy.get('.ngx-select-option-group-name').should('contain', 'Users');
          cy.get('.ngx-select-dropdown-option').first().should('contain', 'admin');
        });
        cy.get('@groups').within(() => {
          cy.get('.ngx-select-option-group-name').should('contain', 'Groups');
          cy.get('.ngx-select-dropdown-option').first().should('contain', 'Everyone');
        });
      });
      cy.get('@ugField').ngxSetValue('admin');
      cy.get('@ugField').ngxGetValue().should('eq', 'admin');
    });

    it('required', () => {
      cy.getByLabel('Single User/Groups Required').as('ugField');
      cy.get('@ugField').within(() => {
        cy.get('label.ngx-select-label').should('contain', '*');
      });
      cy.get('@ugField').ngxGetValue().should('eq', 'admin');
      cy.get('@ugField').clear();
      cy.get('@ugField').find('.ngx-select-hint').should('contain', 'Error: Single User/Groups Required is required.');
    });

    describe('help text', () => {
      it('above', () => {
        cy.getByLabel('Single User/Groups').closest('.user-group-field').as('ugField');
        cy.get('@ugField').find('.record-field__help-text--above').should('contain', 'Help Text');
      });
    });

    it('readonly', () => {
      cy.getByLabel('Single User/Groups Readonly').as('ugField');
      cy.get('@ugField').should('contain', 'admin');
    });
  });

  describe('Multi selects', () => {
    it('basic', () => {
      cy.getByLabel('Multi User/Groups').as('ugField');
      cy.intercept('GET', '/api/user/search?*', {
        fixture: 'mocks/swimlane/user/search/--__.get.json'
      }).as('GET:users');
      cy.intercept('GET', '/api/groups/lookup?*', {
        fixture: 'mocks/swimlane/groups/lookup/--__.get.json'
      }).as('GET:groups');

      // search
      cy.get('@ugField').ngxFill('admin');
      cy.wait('@GET:users');
      cy.wait('@GET:groups');
      cy.get('@ugField').within(() => {
        cy.get('.ngx-select-dropdown li.ngx-select-option-group').eq(0).as('users');
        cy.get('.ngx-select-dropdown li.ngx-select-option-group').eq(1).as('groups');
        cy.get('@users').within(() => {
          cy.get('.ngx-select-option-group-name').should('contain', 'Users');
          cy.get('.ngx-select-dropdown-option').first().should('contain', 'admin');
        });
        cy.get('@groups').within(() => {
          cy.get('.ngx-select-option-group-name').should('contain', 'Groups');
          cy.get('.ngx-select-dropdown-option').first().should('contain', 'Everyone');
        });
      });
      cy.get('@ugField').find('.ngx-select-dropdown .ngx-select-dropdown-option').contains('admin').click();
      cy.get('@ugField').find('.ngx-select-dropdown .ngx-select-dropdown-option').contains('Everyone').click();
      cy.get('@ugField').ngxClose();
      cy.get('@ugField').ngxGetValue().should('deep.eq', ['admin', 'Everyone']);
    });

    it('required', () => {
      cy.getByLabel('Multi User/Groups Required').as('ugField');
      cy.get('@ugField').within(() => {
        cy.get('label.ngx-select-label').should('contain', '*');
      });
      cy.get('@ugField').ngxGetValue().should('deep.eq', ['admin', 'analysts']);
      cy.get('@ugField').clear();
      cy.get('@ugField').find('.ngx-select-hint').should('contain', 'Error: Multi User/Groups Required is required.');
    });

    it('readonly', () => {
      cy.getByLabel('Multi User/Groups Readonly').as('ugField');
      cy.get('@ugField').within(() => {
        cy.get('ul li').as('li').should('have.length', 2);
        cy.get('@li').eq(0).should('contain', 'admin');
        cy.get('@li').eq(1).should('contain', 'analysts');
      });
    });

    describe('help text', () => {
      it('below', () => {
        cy.getByLabel('Multi User/Groups').closest('.user-group-field').as('ugField');
        cy.get('@ugField').find('.record-field__help-text--below').should('contain', 'Help Text');
      });
    });
  });

  it('Created by', () => {
    cy.getByLabel('Created by').as('ugField');
    cy.get('@ugField').should('contain', 'admin');
  });

  it('Last updated by', () => {
    cy.getByLabel('Last updated by').as('ugField');
    cy.get('@ugField').should('contain', 'admin');
  });
});

describe('Reference Fields - Existing Record', () => {
  const appId = 'reference_fields';
  const recordId = 'reference_fields_record';

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('RecordPage');
    cy.navigateSwimlane(`/record2/${appId}/${recordId}`);
    cy.wait('@GET:app/aRIlkHzEA3Lou9JvS');

    // In general these will be three different posts
    cy.wait('@POST:app/aRIlkHzEA3Lou9JvS/record/reference_fields_record/references');
    cy.wait('@POST:app/aRIlkHzEA3Lou9JvS/record/reference_fields_record/references');
    cy.wait('@POST:app/aRIlkHzEA3Lou9JvS/record/reference_fields_record/references');
  });

  describe('single select', () => {
    beforeEach(() => {
      cy.getByLabel('Single-select Reference').as('CUT');
    });

    it('renders component', () => {
      cy.get('@CUT')
        .should('have.attr', 'id', 'afbd9')
        .should('have.class', 'fill')
        .ngxGetValue()
        .should('eq', 'Hello(REF-2)');

      cy.get('@CUT')
        .closest('.record-field')
        .find('.reference-field__select__controls')
        .within(() => {
          cy.get('button').should('have.length', 2);
          cy.get('button')
            .first()
            .should('have.attr', 'aria-label', 'Add New')
            .find('i')
            .should('have.class', 'ngx-plus');
          cy.get('button')
            .last()
            .should('have.attr', 'aria-label', 'Lookup')
            .find('i')
            .should('have.class', 'ngx-search');
        });
    });

    it('shows help text above', () => {
      cy.get('@CUT')
        .closest('.record-field')
        .find('.record-field__help-text--above')
        .should('contain', 'Help Text Above');
    });

    it('should render values', () => {
      cy.get('@CUT').find(`.reference-field__tag`).should('contain.text', 'Hello').should('contain.text', '(REF-2)');
    });

    it('can remove value', () => {
      cy.get('@CUT').find('.ngx-select-clear').click();
      cy.get('@CUT').ngxGetValue().should('eq', '');
    });

    it('can open search on component click when empty', () => {
      cy.get('@CUT').click();
      cy.get('.reference-field__search_dialog').should('exist').find('.close').click();
    });

    describe('adds new record', () => {
      it('open new record drawer', () => {
        cy.setupStubbedSwimlane();
        cy.getByLabel('Single-select Reference').as('CUT');
        cy.get('@CUT').closest('.record-field').find('.reference-field__select__controls__new').click();
        cy.wait('@GET:app/*/record');
        cy.waitForNetworkIdle(1000);

        cy.get('.ngx-drawer-content > app-record')
          .should('exist')
          .within(() => {
            cy.get('.ngx-toolbar-title-col').should('contain.text', 'New Record');
          });
        cy.get('.ngx-drawer').next('ngx-overlay').find('.ngx-overlay').click({ force: true });
      });
    });

    describe('lookup', () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.getByLabel('Single-select Reference').as('CUT');
        cy.get('@CUT').closest('.record-field').find('.reference-field__select__controls__search').click();
        cy.wait('@GET:app');
      });

      describe('search', () => {
        before(() => {
          cy.setupStubbedSwimlane();
          cy.intercept('POST', '/api/search/keyword?*', {
            fixture: 'mocks/swimlane/search/keyword/post-3.json'
          }).as('POST:search/keyword?*');
          cy.intercept('POST', '/api/search/keyword/count?*', {
            fixture: 'mocks/swimlane/search/keyword/count/post-3.json'
          }).as('POST:search/keyword/count?*');

          cy.get('.search-banner--input input').as('input');
          cy.get('@input').type('cat{enter}');
          cy.wait('@POST:search/keyword?*');
          cy.wait('@POST:search/keyword/count?*');
        });

        beforeEach(() => {
          cy.intercept('POST', '/api/search/keyword?*', {
            fixture: 'mocks/swimlane/search/keyword/post-3.json'
          }).as('POST:search/keyword?*');
        });

        it('selects record', () => {
          cy.get('.record-selector').first().click();
          cy.get('.selected-item').first().should('contain', 'CA-7');
          cy.get('.selected-item').first().should('contain', 'Matching "cat"');
          cy.get('.record-selector').eq(1).click();
          cy.get('.selected-item').first().should('contain', 'CA-11');
          cy.get('.selected-item').first().should('contain', 'Matching "cat"');
        });

        it('applies records', () => {
          cy.setupStubbedSwimlane();
          cy.get('.search-sidebar--selection-list--actions > .btn').click();
          cy.get('.reference-lookup-modal').should('not.exist');

          cy.get('@CUT')
            .find(`.reference-field__tag`)
            .should('contain.text', 'Cat got your tongue?')
            .should('contain.text', '(REF-4)');
        });
      });
    });

    describe('opens existing record drawer', () => {
      it('open existing record drawer', () => {
        cy.setupStubbedSwimlane();
        cy.getByLabel('Single-select Reference').as('CUT');
        cy.get('@CUT').find('.reference-field__tag').click();
        cy.wait('@GET:app/*/record/*');
        cy.waitForNetworkIdle(1000);

        cy.get('.ngx-drawer-content > app-record')
          .should('exist')
          .within(() => {
            cy.get('.ngx-toolbar-title-col').should('contain.text', 'TW-5');
          });
        cy.get('.ngx-drawer').next('ngx-overlay').find('.ngx-overlay').click({ force: true });
      });
    });
  });

  describe('multi select', () => {
    beforeEach(() => {
      cy.getByLabel('Multi-select Reference').as('CUT');
    });

    it('renders component', () => {
      cy.get('@CUT')
        .should('have.attr', 'id', 'atkuf')
        .should('have.class', 'fill')
        .find('label')
        .should('contain', 'Multi-select Reference');
      cy.get('@CUT')
        .closest('.record-field')
        .find('.reference-field__select__controls')
        .within(() => {
          cy.get('button').should('have.length', 2);
          cy.get('button')
            .first()
            .should('have.attr', 'aria-label', 'Add New')
            .find('i')
            .should('have.class', 'ngx-plus');
          cy.get('button')
            .last()
            .should('have.attr', 'aria-label', 'Lookup')
            .find('i')
            .should('have.class', 'ngx-search');
        });
    });

    it('shows help text below', () => {
      cy.get('@CUT')
        .closest('.record-field')
        .find('.record-field__help-text--below')
        .should('contain', 'Help Text Below');
    });

    it('should render values', () => {
      cy.get('@CUT').within(() => {
        cy.get(`.reference-field__tag`).should('have.length', 2);
        cy.get(`.reference-field__tag`).first().should('contain.text', '86').should('contain.text', '(REF-1)');
        cy.get(`.reference-field__tag`).eq(1).should('contain.text', '42').should('contain.text', '(REF-2)');
      });
    });

    it('adds new record', { tags: ['SPT-13587'] }, () => {
      cy.setupStubbedSwimlane();
      cy.getByLabel('Single-select Reference').as('CUT');
      cy.get('@CUT').closest('.record-field').find('.reference-field__select__controls__new').click();
      cy.wait('@GET:app/*/record');
      cy.waitForNetworkIdle(1000);

      cy.get('.ngx-drawer-content > app-record')
        .should('exist')
        .within(() => {
          cy.get('.ngx-toolbar-title-col').should('contain.text', 'New Record');
        });
      cy.get('.ngx-drawer').next('ngx-overlay').find('.ngx-overlay').click({ force: true });
    });

    it('can open search on component click', { tags: ['SPT-13587'] }, () => {
      cy.setupStubbedSwimlane();
      cy.get('@CUT').find('.ngx-select-input-box').click('right');
      cy.wait('@GET:app');
      cy.get('.search-banner').should('exist');
      cy.get('.ngx-dialog-content .close').click();
    });

    describe('lookup', { tags: ['SPT-13587'] }, () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.getByLabel('Multi-select Reference').as('CUT');
        cy.get('@CUT').closest('.reference-field').find('.reference-field__select__controls__search').click();
        cy.wait('@GET:app');
      });

      describe('search', () => {
        before(() => {
          cy.setupStubbedSwimlane();
          cy.intercept('POST', '/api/search/keyword?*', {
            fixture: 'mocks/swimlane/search/keyword/post-3.json'
          }).as('POST:search/keyword?*');
          cy.intercept('POST', '/api/search/keyword/count?*', {
            fixture: 'mocks/swimlane/search/keyword/count/post-3.json'
          }).as('POST:search/keyword/count?*');

          cy.get('.search-banner--input input').as('input');
          cy.get('@input').type('cat{enter}');
          cy.wait('@POST:search/keyword?*');
          cy.wait('@POST:search/keyword/count?*');
        });

        beforeEach(() => {
          cy.intercept('POST', '/api/search/keyword?*', {
            fixture: 'mocks/swimlane/search/keyword/post-3.json'
          }).as('POST:search/keyword?*');
        });

        it('selects records', { tags: ['SPT-13587'] }, () => {
          cy.get('.record-selector').first().click();
          cy.get('.selected-item').first().should('contain', 'CA-7');
          cy.get('.selected-item').first().should('contain', 'Matching "cat"');
          cy.get('.record-selector').eq(1).click();
          cy.get('.selected-item').eq(1).should('contain', 'CA-11');
          cy.get('.selected-item').eq(1).should('contain', 'Matching "cat"');
        });

        it('applies records', () => {
          cy.setupStubbedSwimlane();
          cy.get('.search-sidebar--selection-list--actions > .btn').click();
          cy.get('.reference-lookup-modal').should('not.exist');

          cy.get('@CUT').find('.reference-field__tag').should('have.length', 4);

          cy.get('@CUT')
            .find('.reference-field__tag')
            .within(() => {
              cy.root().first().should('contain.text', '86').should('contain.text', '(REF-1)');
              cy.root().eq(1).should('contain.text', '42').should('contain.text', '(REF-2)');
              cy.root().eq(2).should('contain.text', '43').should('contain.text', '(REF-3)');
              cy.root().eq(3).should('contain.text', '47').should('contain.text', '(REF-4)');
            });
        });

        it('can remove', { tags: ['SPT-13587'] }, () => {
          cy.get('@CUT').within(() => {
            cy.root().find('.reference-field__tag').should('have.length', 4);
            cy.root().find('.reference-field__tag').eq(3).next('.ngx-select-clear').click();
            cy.root().find('.reference-field__tag').eq(2).next('.ngx-select-clear').click();
            cy.root().find('.reference-field__tag').should('have.length', 2);
          });
        });
      });
    });

    describe('new record', () => {
      it('open new record drawer', { tags: ['SPT-13587'] }, () => {
        cy.setupStubbedSwimlane();
        cy.getByLabel('Single-select Reference').as('CUT');
        cy.get('@CUT').find('.reference-field__tag').click();
        cy.wait('@GET:app/*/record/*');
        cy.waitForNetworkIdle(1000);

        cy.get('.ngx-drawer-content > app-record')
          .should('exist')
          .within(() => {
            cy.get('.ngx-toolbar-title-col').should('contain.text', 'TW-5');
          });
        cy.get('.ngx-drawer').next('ngx-overlay').find('.ngx-overlay').click({ force: true });
      });
    });
  });

  describe('grid', () => {
    beforeEach(() => {
      cy.getByLabel('Reference Grid').as('CUT');
    });

    it('shows reference grid with controls in the footer', () => {
      cy.get('@CUT')
        .closest('.reference-field')
        .within(() => {
          cy.get('.record-field__field-label').should('contain.text', 'Reference Grid');
          cy.get('.reference-field__grid__controls').within(() => {
            cy.get('button').should('have.length', 2);
            cy.get('button')
              .first()
              .should('have.attr', 'aria-label', 'Add New')
              .find('i')
              .should('have.class', 'ngx-plus');
            cy.get('button')
              .last()
              .should('have.attr', 'aria-label', 'Lookup')
              .find('i')
              .should('have.class', 'ngx-search');
          });
        });
    });

    it('shows help text above', () => {
      cy.get('@CUT')
        .closest('.record-field')
        .find('.record-field__help-text--above')
        .should('contain', 'Help Text Above');
    });

    it('should render values', () => {
      cy.get('@CUT').within(() => {
        cy.get('.datatable-body-row').should('have.length', 2);
        cy.get('.datatable-body-row')
          .first()
          .should('contain.text', 'REF-2')
          .should('contain.text', 'Hello')
          .should('contain.text', '42');
        cy.get('.datatable-body-row')
          .eq(1)
          .should('contain.text', 'REF-1')
          .should('contain.text', 'Goodbye')
          .should('contain.text', '86');
      });
    });

    describe('adds new record', { tags: ['SPT-13587'] }, () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.getByLabel('Reference Grid').as('CUT');
        cy.get('@CUT').find('.reference-field__grid__controls__new').first().click();
        cy.wait('@GET:app/*/record');
        cy.waitForNetworkIdle(1000);
      });

      it('open new record drawer', { tags: ['SPT-13587'] }, () => {
        cy.get('.ngx-drawer-content > app-record')
          .should('exist')
          .within(() => {
            cy.get('.ngx-toolbar-title-col').should('contain.text', 'New Record');
          });
      });

      it('saves new record and updates grid', () => {
        cy.setupStubbedSwimlane();

        cy.get('.ngx-drawer-content > app-record')
          .should('exist')
          .within(() => {
            cy.get('.ngx-input').first().ngxFill('10');
            cy.get('.ngx-input').last().ngxFill('Hello');
            cy.get('.record-state__toolbar__controls button').click();
          });

        cy.wait('@POST:app/*/record');
        cy.wait('@POST:app/aRIlkHzEA3Lou9JvS/record/reference_fields_record/references');
        cy.wait('@POST:app/aRIlkHzEA3Lou9JvS/record/reference_fields_record/references');
        cy.wait('@POST:app/aRIlkHzEA3Lou9JvS/record/reference_fields_record/references');

        cy.get('@CUT').within(() => {
          cy.get('.datatable-body-row').should('have.length', 3);
          cy.get('.datatable-body-row').last().should('contain.text', 'REF-5').should('contain.text', 'Hello');

          cy.get('.datatable-body-row').last().find('.reference-field__grid__row_controls__delete').click();
        });
      });
    });

    describe('lookup', { tags: ['SPT-13587'] }, () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.getByLabel('Reference Grid').as('CUT');
        cy.get('@CUT').find('.reference-field__grid__controls__search').click();
        cy.wait('@GET:app');
        cy.waitForNetworkIdle(1000);
      });

      it('has focus', { tags: ['SPT-13587'] }, () => {
        cy.get('.search-banner--input input').as('input');
        cy.get('@input').should('have.focus');
      });

      describe('search', () => {
        before(() => {
          cy.setupStubbedSwimlane();
          cy.intercept('POST', '/api/search/keyword?*', {
            fixture: 'mocks/swimlane/search/keyword/post-3.json'
          }).as('POST:search/keyword?*');
          cy.intercept('POST', '/api/search/keyword/count?*', {
            fixture: 'mocks/swimlane/search/keyword/count/post-3.json'
          }).as('POST:search/keyword/count?*');

          cy.get('.search-banner--input input').as('input');
          cy.get('@input').type('cat{enter}');
          cy.wait('@POST:search/keyword?*');
          cy.wait('@POST:search/keyword/count?*');
        });

        beforeEach(() => {
          cy.intercept('POST', '/api/search/keyword?*', {
            fixture: 'mocks/swimlane/search/keyword/post-3.json'
          }).as('POST:search/keyword?*');
        });

        it('shows result counts', () => {
          cy.get('.search-left > .results-meta > .results-meta--label').should('contain', 'Records');
          cy.get('.search-left > .results-meta > .results-meta--count').should('contain', '5 results');
          cy.get('.search-sidebar--selection-list > .results-meta > .results-meta--label').should(
            'contain',
            'Selected Records'
          );
          cy.get('.search-sidebar--selection-list > .results-meta > .results-meta--count').should(
            'contain',
            '0 selected'
          );
        });

        it('shows record results', () => {
          cy.get('.search-results .app-results').first().as('first-item');
          cy.get('@first-item').find('.record-heading').should('contain', 'CA-7');
          cy.get('@first-item').find('.record-values').as('values');
          cy.get('@values').should('contain', 'Record Id');
          cy.get('@values').should('contain', 'aV4WbUU5g2OfN3Onc');
          cy.get('@values').should('contain', 'Text');
          cy.get('@values').should('contain', 'Curiosity Killed The Cat');
        });

        it('shows tooltip when hovering over record name', () => {
          cy.get('.search-results .app-results .record-label').first().trigger('mouseenter');
          cy.get('.sw-popover-text').should('be.visible');
          cy.get('.sw-popover-text')
            .should('contain', 'Created')
            .should('contain', 'Updated')
            .should('contain', 'ago')
            .should('contain', 'admin');
          cy.get('.search-results .app-results .record-label').first().trigger('mouseleave');
        });

        it('selects records', () => {
          cy.get('.record-selector').first().click();
          cy.get('.selected-item').first().should('contain', 'CA-7');
          cy.get('.selected-item').first().should('contain', 'Matching "cat"');
          cy.get('.record-selector').eq(1).click();
          cy.get('.selected-item').eq(1).should('contain', 'CA-11');
          cy.get('.selected-item').eq(1).should('contain', 'Matching "cat"');
        });

        it('changing search and selecting records', () => {
          cy.setupStubbedSwimlane();
          cy.intercept('POST', '/api/search/keyword/count?*', {
            fixture: 'mocks/swimlane/search/keyword/count/post-5.json'
          }).as('POST:search/keyword/count?*');
          cy.intercept('POST', '/api/search/keyword?*', {
            fixture: 'mocks/swimlane/search/keyword/post-5.json'
          }).as('POST:search/keyword?*');

          cy.get('.search-banner--input input').as('input');
          cy.get('@input').should('not.have.attr', 'disabled');
          cy.get('@input').focus();
          cy.get('@input').type('{backspace}{backspace}{backspace}bag{enter}');

          cy.wait('@POST:search/keyword/count?*');
          cy.wait('@POST:search/keyword?*');

          cy.get('.record-selector').eq(0).click();
          cy.get('.selected-item', { timeout: 5000 }).eq(2).should('contain', 'CA-10');
          cy.get('.selected-item').eq(2).should('contain', 'Matching "bag"');
        });

        it('applies records', () => {
          cy.setupStubbedSwimlane();
          cy.get('.search-sidebar--selection-list--actions > .btn').click();
          cy.get('.reference-lookup-modal').should('not.exist');

          cy.get('@CUT').within(() => {
            cy.get('.datatable-body-row').should('have.length', 5);
            cy.get('.datatable-body-row')
              .first()
              .should('contain.text', 'REF-2')
              .should('contain.text', 'Hello')
              .should('contain.text', '42');
            cy.get('.datatable-body-row')
              .eq(1)
              .should('contain.text', 'REF-1')
              .should('contain.text', 'Goodbye')
              .should('contain.text', '86');
            cy.get('.datatable-body-row')
              .eq(2)
              .should('contain.text', 'REF-3')
              .should('contain.text', 'Curiosity Killed The Cat');
            cy.get('.datatable-body-row')
              .eq(3)
              .should('contain.text', 'REF-4')
              .should('contain.text', 'Cat got your tongue?');
            cy.get('.datatable-body-row')
              .eq(4)
              .should('contain.text', 'REF-7')
              .should('contain.text', 'Let the cat out of the bag');
          });
        });

        it('can remove items', () => {
          cy.get('@CUT').within(() => {
            cy.get('.datatable-body-row').should('have.length', 5);
            cy.get('.datatable-body-row').last().find('.reference-field__grid__row_controls__delete').click();
            cy.get('.datatable-body-row').last().find('.reference-field__grid__row_controls__delete').click();
            cy.get('.datatable-body-row').last().find('.reference-field__grid__row_controls__delete').click();
            cy.get('.datatable-body-row').should('have.length', 2);
          });
        });
      });
    });

    describe('opens record on tag click', { tags: ['SPT-13587'] }, () => {
      before(() => {
        cy.setupStubbedSwimlane();
        cy.get('#a9fx9').as('CUT');
        cy.get('@CUT').find('.reference-field__tag').first().click();
        cy.wait('@GET:app/*/record/*');
        cy.waitForNetworkIdle(1000);
      });

      it('open new record drawer', { tags: ['SPT-13587'] }, () => {
        cy.get('.ngx-drawer-content > app-record')
          .should('exist')
          .within(() => {
            cy.get('.ngx-toolbar-title-col').should('contain.text', 'TW-5');
          });
      });

      it('saves new record and updates grid', () => {
        cy.setupStubbedSwimlane();

        cy.get('.ngx-drawer-content > app-record')
          .should('exist')
          .within(() => {
            cy.get('.ngx-input').first().ngxFill('10');
            cy.get('.ngx-input').last().ngxFill('Hello');
            cy.get('.record-state__toolbar__controls').contains('button', 'Save').first().click(); // leaves drawer open
          });

        cy.wait('@PUT:app/*/record');

        // Watch for reference field updates but can't check values, since unchanged in the mock
        // TODO: mock changed response with new record
        cy.wait('@POST:app/aRIlkHzEA3Lou9JvS/record/reference_fields_record/references');
        cy.wait('@POST:app/aRIlkHzEA3Lou9JvS/record/reference_fields_record/references');
        cy.wait('@POST:app/aRIlkHzEA3Lou9JvS/record/reference_fields_record/references');
      });

      it('can delete record from drawer', () => {
        cy.setupStubbedSwimlane();

        cy.get('.ngx-drawer-content > app-record').within(() => {
          cy.get('.ngx-dropdown-toggle > button').click();
          cy.get('.vertical-list').contains('button', 'Delete').click();
        });

        cy.get('.ngx-dialog.ngx-alert-dialog.confirm').contains('button', 'Ok').click();
        cy.wait('@DELETE:app/*/record/*');

        // Watch for reference field updates but can't check values, since unchanged in the mock
        // TODO: mock changed response with deleted record
        cy.wait('@POST:app/aRIlkHzEA3Lou9JvS/record/reference_fields_record/references');
        cy.wait('@POST:app/aRIlkHzEA3Lou9JvS/record/reference_fields_record/references');
        cy.wait('@POST:app/aRIlkHzEA3Lou9JvS/record/reference_fields_record/references');
      });
    });
  });
});

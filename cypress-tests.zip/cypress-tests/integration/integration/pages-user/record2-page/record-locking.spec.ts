describe('Record Locking', () => {
  const appId = 'numeric_fields';
  const recordId = 'numeric_fields_record';

  const ADMIN_USER = {
    name: 'admin',
    displayName: 'admin',
    id: 'aO_RunwkwbYwkml6X'
  };

  const TEST_USER = {
    name: 'jtester',
    displayName: 'jtester',
    id: '5cd9d2a225cea00014bf1d79'
  };

  const THIRD_USER = {
    name: 'cypress-test-user',
    displayName: 'cypress-test-user',
    id: '5cd9d2a225cea00014bf1d7a'
  };

  describe('record locking as admin', () => {
    before(() => {
      cy.login();
      cy.setupStubbedSwimlane();
      cy.setMockFeatureFlag('RecordPage');
      cy.navigateSwimlane(`/record2/${appId}/${recordId}`);

      cy.waitForNetworkIdle(2000);
    });

    it('can lock and unlock via UI', () => {
      verifyNotReadonly();
      lockRecord(ADMIN_USER);
      verifyNotReadonly();
      unlockRecord(ADMIN_USER);
      verifyNotReadonly();
    });

    it('can be locked by another user via record hub', () => {
      verifyNotReadonly();
      lockViaRecordHub(TEST_USER);
      verifyReadonly();
      unlockViaRecordHub(TEST_USER);
      verifyNotReadonly();
    });

    it('can be locked by same user via record hub', () => {
      verifyNotReadonly();
      lockViaRecordHub(ADMIN_USER);
      verifyNotReadonly();
      unlockViaRecordHub(ADMIN_USER);
      verifyNotReadonly();
    });

    it('should allow admin to unlock records locked by another user', () => {
      verifyNotReadonly();
      lockViaRecordHub(THIRD_USER);
      verifyReadonly();
      unlockRecord(ADMIN_USER);
    });
  });

  describe('record locking as non admin', () => {
    before(() => {
      cy.login();
      cy.setupStubbedSwimlane();

      // Reset login to a limited user
      cy.intercept('GET', '/api/user/authorize', {
        fixture: 'mocks/swimlane/user/authorize/get-user.json'
      }).as('GET:user/authorize');
      cy.setMockFeatureFlag('RecordPage');
      cy.navigateSwimlane(`/record2/${appId}/${recordId}`, { forceReload: true });

      cy.waitForNetworkIdle(2000);
    });

    it('can lock and unlock via UI', () => {
      verifyNotReadonly();
      lockRecord(TEST_USER);
      verifyNotReadonly();
      unlockRecord(TEST_USER);
      verifyNotReadonly();
    });

    it('locked by another user via record hub', () => {
      verifyNotReadonly();
      lockViaRecordHub(THIRD_USER);
      verifyReadonly();
      unlockViaRecordHub(THIRD_USER);
      verifyNotReadonly();
    });

    it('can be locked by same user via record hub', () => {
      // Wait 1 second to avoid flooding the notification queue
      cy.wait(1000);

      verifyNotReadonly();
      lockViaRecordHub(TEST_USER);
      verifyNotReadonly();
      unlockViaRecordHub(TEST_USER);
      verifyNotReadonly();
    });

    it('should not allow non-admin to records locked by another user', () => {
      // Wait 1 second to avoid flooding the notification queue
      cy.wait(1000);

      verifyNotReadonly();
      lockViaRecordHub(ADMIN_USER);

      // Cannot unlock record
      cy.get('.record-state__toolbar').within(() => {
        cy.get('.ngx-dropdown-toggle > button').click();
        cy.get('.vertical-list').should('not.contain', 'Unlock Record');
      });
    });
  });

  // HELPER FUNCTIONS

  function verifyNotReadonly() {
    cy.get('.record-state__layout').should('not.have.class', 'record-state__layout--readonly');
    cy.get('.record-field').first().should('not.have.class', 'record-field--readonly');
  }

  function verifyReadonly() {
    cy.get('.record-state__layout').should('have.class', 'record-state__layout--readonly');
    cy.get('.record-field').should('have.class', 'record-field--readonly');
  }

  function lockRecord(lockingUser: any) {
    cy.intercept(`/api/app/${appId}/record/${recordId}/lock`, {
      lockingUser,
      lockedDate: new Date().toISOString()
    }).as('lock');

    // Lock record
    cy.get('.record-state__toolbar').within(() => {
      cy.get('.ngx-dropdown-toggle > button').click();
      cy.get('.vertical-list').contains('button', 'Lock Record').click();
    });
    cy.wait('@lock');

    // Notification is shown
    cy.get('.ngx-notification-container .notification-content')
      .should('exist')
      .last()
      .whileHovering($el => {
        cy.wrap($el).should('contain', 'Record locked successfully');
      });
    cy.ngxCloseNotifications();

    // Wait 1 second to avoid flooding the notification queue
    cy.wait(1000);

    // Lock with popup is shown
    cy.get('.record-state__toolbar__title .ngx-icon.ngx-lock')
      .should('exist')
      .whileHovering(() => {
        cy.root().closest('body').find('.ngx-tooltip-content').should('contain', `Locked by ${lockingUser.name}`);
      });
  }

  function lockViaRecordHub(lockingUser: any) {
    cy.hubPublish('recordLocked', {
      locked: true,
      lockingUser,
      lockedDate: new Date().toISOString()
    });
    cy.get('body').click();

    cy.get('.ngx-notification-container .notification-content')
      .should('exist')
      .last()
      .whileHovering($el => {
        cy.wrap($el).should('contain', `Record locked by ${lockingUser.name}`);
      });
    cy.ngxCloseNotifications();

    // Wait 1 second to avoid flooding the notification queue
    cy.wait(1000);
  }

  function unlockRecord(lockingUser: any) {
    cy.intercept(`/api/app/${appId}/record/${recordId}/unlock`, {
      lockingUser,
      lockedDate: new Date().toISOString()
    }).as('unlock');

    // Unlock record
    cy.get('.record-state__toolbar').within(() => {
      cy.get('.ngx-dropdown-toggle > button').click();
      cy.get('.vertical-list').contains('button', 'Unlock Record').click();
    });
    cy.wait('@unlock');

    // Notification is shown
    cy.get('.ngx-notification-container .notification-content')
      .should('exist')
      .last()
      .whileHovering($el => {
        cy.wrap($el).should('contain', 'Record unlocked successfully');
      });
    cy.ngxCloseNotifications();

    // Wait 1 second to avoid flooding the notification queue
    cy.wait(1000);

    // Lock is not shown
    cy.get('.record-state__toolbar__title .ngx-icon.ngx-lock').should('not.exist');
  }

  function unlockViaRecordHub(lockingUser: any) {
    cy.hubPublish('recordLocked', {
      locked: false,
      lockingUser,
      lockedDate: new Date().toISOString()
    });
    cy.get('body').click();

    // Notification is shown
    cy.get('.ngx-notification-container .notification-content')
      .should('exist')
      .last()
      .whileHovering($el => {
        cy.wrap($el).should('contain', 'Record unlocked');
      });
    cy.ngxCloseNotifications();

    // Wait 1 second to avoid flooding the notification queue
    cy.wait(1000);
  }
});

describe('Attachment Fields', () => {
  const appId = 'attachment_fields';
  const recordId = 'attachment_fields_record';

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('RecordPage');
    cy.navigateSwimlane(`/record2/${appId}/${recordId}`);
  });

  it('readonly hides dropzone and delete icons', () => {
    const label = 'Attachment Readonly';
    cy.getByLabel(label).as('attachmentField');
    cy.get('@attachmentField').prev('.attachment-field__dropzone').should('not.exist');
    cy.get('@attachmentField')
      .find('datatable-body-row')
      .each(row => {
        cy.wrap(row).find('.attachment-field__delete-btn').should('not.exist');
      });
  });

  it('help text', () => {
    it('below', () => {
      cy.getByLabel('Attachment Help Text Below').closest('.attachment-field').as('attachmentField');
      cy.get('@ugField').find('.record-field__help-text--below').should('contain', 'Help Text');
    });
    it('below', () => {
      cy.getByLabel('Attachment Help Text Above').closest('.attachment-field').as('attachmentField');
      cy.get('@ugField').find('.record-field__help-text--below').should('contain', 'Help Text');
    });
  });

  describe('basic attachment field', () => {
    beforeEach(() => {
      cy.getByLabel('Attachment Basic')
        .as('attachmentField')
        .closest('.attachment-field')
        .as('attachmentFieldContainer');
    });

    it('shows dropzone', () => {
      cy.get('@attachmentFieldContainer').find('.attachment-field__dropzone').should('exist');
    });

    it('shows attachment list', () => {
      cy.get('@attachmentField').find('datatable-body-row').should('have.length', 4);
    });

    it('shows preview icon for viewable file type', () => {
      cy.get('@attachmentField')
        .find('datatable-body-row')
        .last()
        .within(() => {
          cy.get('datatable-body-cell')
            .eq(0)
            .find('.attachment-field__preview-btn')
            .should('exist')
            .should('contain', 'png');
          cy.get('datatable-body-cell')
            .eq(1)
            .within(() => {
              cy.get('.attachment-field__download-btn').should('exist');
              cy.get('.attachment-field__delete-btn').should('exist');
            });
        });
    });

    it('hides preview icon for non-viewable file type', () => {
      cy.get('@attachmentField')
        .find('datatable-body-row')
        .first()
        .within(() => {
          cy.get('datatable-body-cell').eq(0).find('.attachment-field__filename').should('contain', 'ssp');
          cy.get('datatable-body-cell').eq(0).find('.attachment-field__preview-btn').should('not.exist');
          cy.get('datatable-body-cell')
            .eq(1)
            .within(() => {
              cy.get('.attachment-field__download-btn').should('exist');
              cy.get('.attachment-field__delete-btn').should('exist');
            });
        });
    });

    it('opens preview', () => {
      cy.get('@attachmentField')
        .find('datatable-body-row')
        .last()
        .within(() => {
          cy.get('.attachment-field__preview-btn').click();
        });

      cy.get('.preview-attachment-dialog').should('exist');
      cy.get('.preview-attachment-dialog').contains('button', 'Close').click();
      cy.get('.preview-attachment-dialog').should('not.exist');
    });

    it('can delete', () => {
      cy.get('@attachmentField').find('datatable-body-row').should('have.length', 4);
      cy.get('@attachmentField')
        .find('datatable-body-row')
        .first()
        .within(() => {
          cy.get('datatable-body-cell').eq(0).should('contain', 'ssp');
          cy.get('datatable-body-cell')
            .eq(1)
            .within(() => {
              cy.get('.attachment-field__delete-btn').click();
            });
        });

      cy.get('@attachmentField')
        .find('datatable-body-row')
        .last()
        .find('datatable-body-cell')
        .eq(0)
        .should('not.contain', 'ssp');
      cy.get('@attachmentField').find('datatable-body-row').should('have.length', 3);
    });
  });

  describe('upload', () => {
    beforeEach(() => {
      cy.getByLabel('Attachment Small')
        .as('attachmentField')
        .closest('.attachment-field')
        .as('attachmentFieldContainer');
    });

    it('shows no attachments message', () => {
      cy.get('@attachmentField').should('contain', 'No Attachments');
    });

    it('does not upload when file size exceeds max size', () => {
      cy.fixture('/attachments/227kb.png').then(fileContent => {
        cy.get('@attachmentFieldContainer').find('.attachment-field__dropzone .ngx-dropzone--input').attachFile({
          fileContent,
          fileName: '227kb.png',
          mimeType: 'text/plain',
          encoding: 'utf-8'
        });
      });
    });

    it('can upload', () => {
      cy.intercept('POST', '/api/attachment/attachment_fields/*', [
        {
          filename: 'common-task.json'
        }
      ]).as('POST:attachment');

      cy.fixture('/attachments/hello-world.xlsx').then(fileContent => {
        cy.get('@attachmentFieldContainer').find('.attachment-field__dropzone .ngx-dropzone--input').attachFile({
          fileContent,
          fileName: 'hello-world.xlsx',
          mimeType: 'text/plain',
          encoding: 'utf-8'
        });
      });

      cy.wait('@POST:attachment');
      cy.get('@attachmentField').find('datatable-body-row').should('have.length', 1);
    });
  });

  // TODO
  describe.skip('download', () => {
    // no-op
  });
});

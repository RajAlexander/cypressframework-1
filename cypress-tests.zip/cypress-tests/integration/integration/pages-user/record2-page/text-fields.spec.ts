describe('Text Fields', () => {
  const appId = 'text_fields';
  const recordId = 'text_fields_record';

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('RecordPage');
    cy.navigateSwimlane(`/record2/${appId}/${recordId}`);
  });

  describe('text fields using ngx-input', () => {
    describe('single line', () => {
      it('basic', () => {
        cy.getByLabel('Single-line').as('textField');
        cy.get('@textField').find('input').should('have.length', 1);
      });
      it('prefix and suffix', () => {
        cy.getByLabel('Single-line-prefix-suffix').as('textField');
        cy.get('@textField').within(() => {
          cy.get('input').should('have.length', 1);
          cy.get('ngx-input-prefix').should('contain', 'prefix');
          cy.get('ngx-input-suffix').should('contain', 'suffix');
        });
      });
      it('placeholder', () => {
        cy.getByLabel('Single-line-placeholder').as('textField');
        cy.get('@textField').within(() => {
          cy.get('input').should('have.length', 1);
          cy.get('input').should('have.attr', 'placeholder', 'placeholder text');
        });
      });
      it('required', () => {
        cy.getByLabel('Single-line-required').as('textField');
        cy.get('@textField').within(() => {
          cy.get('input').should('have.length', 1);
          cy.get('input').should('have.attr', 'required');
          cy.get('.ngx-input-label').should('contain', '*');
        });
        cy.get('@textField').ngxFill('hello');
        cy.get('@textField').clear().ngxFindNativeInput().blur();
        cy.get('@textField').find('.ngx-input-hint').should('contain', 'Error: Single-line-required is required.');
      });
      it('unique', () => {
        const fieldId = 'afez8';
        cy.intercept('POST', `/api/app/${appId}/record/${recordId}/unique/${fieldId}`, { unique: false }).as(
          'validateUniqueField'
        );
        cy.getByLabel('Single-line-unique').as('textField');
        cy.get('@textField').find('input').should('have.length', 1);
        cy.get('@textField').ngxFill('x');
        cy.get('@textField')
          .siblings('.record-field--unique__pending-message')
          .should('contain', 'Pending Validation...');
        cy.wait('@validateUniqueField');
        cy.get('@textField')
          .find('.ngx-input-hint')
          .should('contain', 'Error: Single-line-unique must be a unique value.');
      });
    });

    describe('multi line', () => {
      it('basic', () => {
        cy.getByLabel('Multi-line').as('textField');
        cy.get('@textField').find('textarea').should('have.length', 1);
      });
      it('prefix and suffix', () => {
        cy.getByLabel('Multi-line-prefix-suffix').as('textField');
        cy.get('@textField').within(() => {
          cy.get('textarea').should('have.length', 1);
          cy.get('ngx-input-prefix').should('contain', 'prefix');
          cy.get('ngx-input-suffix').should('contain', 'suffix');
        });
      });
    });

    it('ip', () => {
      cy.getByLabel('IP').as('textField');
      cy.get('@textField').ngxFill('h.');
      cy.get('@textField').find('.ngx-input-hint').should('contain', 'Error: This must be in IP address format');
      cy.get('@textField').clear();
      cy.get('@textField').ngxFill('0.0.0.0');
      cy.get('@textField').contains('Error: This must be in IP address format').should('not.exist');
    });

    it('email', () => {
      cy.getByLabel('Email').as('textField');
      cy.get('@textField').ngxFill('hello');
      cy.get('@textField').find('.ngx-input-hint').should('contain', 'Error: This must be in email address format.');
      cy.get('@textField').clear();
      cy.get('@textField').ngxFill('admin@swimlane.com');
      cy.get('@textField').contains('Error: This must be in email address format.').should('not.exist');
    });

    it('url', () => {
      cy.getByLabel('URL').as('textField');
      cy.get('@textField').ngxFill('hello');
      cy.get('@textField').find('.ngx-input-hint').should('contain', 'Error: This must be in URL format.');
      cy.get('@textField').clear();
      cy.get('@textField').ngxFill('https://swimlane.com');
      cy.get('@textField').contains('Error: This must be in URL format.').should('not.exist');
    });

    it('telephone', () => {
      cy.getByLabel('Telephone').as('textField');
      cy.get('@textField').ngxFill('hello');
      cy.get('@textField').find('.ngx-input-hint').should('contain', 'Error: This must be in telephone number format.');
      cy.get('@textField').clear();
      cy.get('@textField').ngxFill('333 333 3333');
      cy.get('@textField').contains('Error: This must be in telephone number format.').should('not.exist');
    });
  });

  describe('RTE', () => {
    it('basic', () => {
      cy.getByLabel('RTE').as('textField');
      cy.get('@textField').should('have.length', 1);
    });

    it('prefix and suffix', () => {
      cy.getByLabel('RTE-prefix-suffix').as('textField');
      cy.get('@textField').within(() => {
        cy.root().should('have.length', 1);
        cy.root().siblings('.rte-prefix').should('contain', 'prefix');
        cy.root().siblings('.rte-suffix').should('contain', 'suffix');
      });
    });

    it('required', () => {
      // ensure dirty state is set
      cy.getByLabel('Single-line').ngxFill('hello');

      cy.getByLabel('RTE-required').as('textField');
      // TODO: interact with the tinyMCE editor to trigger error state later
      cy.get('.record-state__toolbar').find('ngx-button').contains('Save').click();
      cy.wait(1000);

      cy.get('@textField').within(() => {
        cy.root()
          .closest('.record-field')
          .find('.record-field__error-message')
          .should('contain', 'Error: RTE-required is required.');
      });
    });
  });

  describe('JSON', () => {
    it('basic', () => {
      cy.getByLabel('JSON').as('textField');
      cy.get('@textField').within(() => {
        cy.root().should('have.length', 1);
        cy.root().find('i').should('contain', 'No data available');
      });
    });

    it('placholder', () => {
      cy.getByLabel('JSON-placeholder').as('textField');
      cy.get('@textField').within(() => {
        cy.root().should('have.length', 1);
        cy.root().find('i').should('contain', 'placeholder text');
      });
    });

    it('has data', () => {
      cy.getByLabel('JSON-data').as('textField');
      cy.get('@textField').within(() => {
        cy.get('ngx-tree').should('have.length', 2);
        cy.get('ngx-tree').find('code').last().should('contain', 'key').should('contain', 'value');
      });
    });
  });

  describe('readonly', () => {
    it('single line readonly', () => {
      cy.getByLabel('Single-line-readonly').as('textField');
      cy.get('@textField').should('contain', 'single line readonly text');
    });

    it('single line calculated', () => {
      cy.getByLabel('Single-line-calculated').as('textField');
      cy.get('@textField').should('contain', '37572');
    });

    it('multi line readonly', () => {
      cy.getByLabel('Multi-line-readonly').as('textField');
      cy.get('@textField').should('contain', 'multi line readonly text');
    });

    it('RTE readonly', () => {
      cy.getByLabel('RTE-readonly').as('textField');
      cy.get('@textField').should('contain', 'RTE readonly text');
    });

    it('RTE calculated', () => {
      cy.getByLabel('RTE-calculated').as('textField');
      cy.get('@textField').should('contain', '37572');
    });
  });

  describe('help text', () => {
    it('below', () => {
      cy.getByLabel('Single-line').as('textField');
      cy.get('@textField').parent().find('.record-field__help-text--below').should('contain', 'help text');
    });

    it('above', () => {
      cy.getByLabel('Multi-line').as('textField');
      cy.get('@textField').parent().find('.record-field__help-text--above').should('contain', 'help text');
    });
  });
});

describe('Integration Buttons', () => {
  const appId = 'int_buttons';
  const recordId = 'int_buttons_record';

  before(() => {
    cy.login();
  });

  describe('New Record', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.setMockFeatureFlag('RecordPage');
      cy.navigateSwimlane(`/record2/${appId}/`);
    });

    it('integration buttons are disabled', () => {
      cy.get('fieldset').within(() => {
        cy.get('ngx-button').first().should('have.class', 'disabled-button');
        cy.get('ngx-button').last().should('have.class', 'disabled-button');
      });
    });
  });

  describe('Existing Record', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.setMockFeatureFlag('RecordPage');
      cy.navigateSwimlane(`/record2/${appId}/${recordId}`);
    });

    beforeEach(() => {
      cy.get('fieldset').within(() => {
        cy.get('ngx-button').first().as('button1');
        cy.get('ngx-button').last().as('button2');
      });
    });

    it('should have buttons with correct classes and labels', () => {
      cy.get('@button1')
        .should('have.class', 'btn-primary-gradient')
        .and('have.class', 'active')
        .and('contain.text', 'Integration Button 1');

      // Flakey
      // .whileHovering(() => {
      //   cy.root().closest('body').find('ngx-tooltip-content').should('contain.text', 'Integration Button 1');
      // });

      cy.get('@button2')
        .should('have.class', 'btn-primary-gradient')
        .and('have.class', 'active')
        .and('contain.text', 'Integration Button 2');

      // Flakey
      // .whileHovering(() => {
      //   cy.root().closest('body').find('ngx-tooltip-content').should('contain.text', 'Integration Button 2');
      // });
    });

    it('should update state when clicked - failed', () => {
      const jobId = 'button1_failed';
      cy.intercept('/api/task/execute/record', jobId).as('execute-failed');

      cy.get('@button1').click();
      cy.get('@button1').should('have.class', 'in-progress');
      cy.get('@button2').should('have.class', 'active');

      cy.wait('@execute-failed');

      cy.hubPublish('taskUpdate', {
        jobId,
        taskName: 'Output Values',
        executioner: 'admin',
        status: 'failed',
        dateTime: new Date().toISOString(),
        output: '"Task complete"',
        fromWorkflow: false
      });

      cy.get('ngx-notification').should('contain.text', 'Output Values failed');

      cy.get('@button1').should('have.class', 'fail');
      cy.ngxCloseNotifications();

      cy.get('@button1', { timeout: 12000 }).should('have.class', 'active');
    });

    it('should update state when clicked - success', () => {
      const jobId = 'button2_success';
      cy.intercept('/api/task/execute/record', jobId).as('execute-success');

      cy.get('@button2').click();
      cy.get('@button2').should('have.class', 'in-progress');
      cy.get('@button1').should('have.class', 'active');

      cy.wait('@execute-success');

      cy.hubPublish('taskUpdate', {
        jobId,
        taskName: 'Output Values',
        executioner: 'admin',
        status: 'finished',
        dateTime: new Date().toISOString(),
        output: '"Task complete"',
        fromWorkflow: false
      });

      cy.get('ngx-notification').should('contain.text', 'Output Values finished');

      cy.get('@button2').should('have.class', 'success');
      cy.ngxCloseNotifications();

      cy.get('@button2', { timeout: 12000 }).should('have.class', 'active');
    });

    it('triggers save dialog when dirty and triggers task after save', () => {
      cy.setupStubbedSwimlane();

      const jobId = 'button2_success';
      cy.intercept('/api/task/execute/record', jobId).as('execute-success');

      cy.getByLabel('Text').ngxFill('test');

      cy.get('@button1').click();

      cy.get('ngx-alert-dialog').should('contain.text', 'Save Confirmation');
      cy.get('ngx-alert-dialog').contains('button', 'Ok').click();

      cy.wait(`@PUT:app/${appId}/record`);
      cy.wait('@execute-success');

      cy.get('@button1').should('have.class', 'in-progress');

      cy.hubPublish('taskUpdate', {
        jobId,
        taskName: 'Output Values',
        executioner: 'admin',
        status: 'finished',
        dateTime: new Date().toISOString(),
        output: '"Task complete"',
        fromWorkflow: false
      });

      cy.get('@button1').should('have.class', 'success');
      cy.ngxCloseNotifications();

      cy.get('@button1', { timeout: 12000 }).should('have.class', 'active');
    });
  });

  describe('Record History', () => {
    before(() => {
      cy.setupStubbedSwimlane();
      cy.setMockFeatureFlag('RecordPage');
      cy.navigateSwimlane(`/record2/${appId}/${recordId}/history`);
      cy.waitForNetworkIdle(1000);
    });

    it('integration buttons are disabled', () => {
      cy.get('fieldset').within(() => {
        cy.get('ngx-button').first().should('have.class', 'disabled-button');
        cy.get('ngx-button').last().should('have.class', 'disabled-button');
      });
    });
  });
});

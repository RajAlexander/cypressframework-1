describe('HTML Layout', () => {
  const appId = 'layout';
  const recordId = 'layout_record';

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('RecordPage');
    cy.navigateSwimlane(`/record2/${appId}/${recordId}`);
  });

  describe('displays html', () => {
    it('renders html', () => {
      cy.get('#623cb3b214feab4d1feee9b2').should('exist').should('contain.html', '<h1>Hello World</h1>');
    });

    it('fixes bad html', () => {
      cy.get('#xjck8YSsoD').should('exist').should('contain.html', '<h1>Hello\n  \nWorld</h1>');
    });

    it('sanitizes dangerous html', () => {
      cy.get('#pXie6DNTAP').should('exist').should('contain.html', 'Hello  World\n\n');
    });
  });
});

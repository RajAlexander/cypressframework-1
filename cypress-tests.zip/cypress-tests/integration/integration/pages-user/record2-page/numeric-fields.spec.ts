describe('Numeric Fields', () => {
  const appId = 'numeric_fields';
  const recordId = 'numeric_fields_record';

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('RecordPage');
    cy.navigateSwimlane(`/record2/${appId}/${recordId}`);
  });

  describe('numeric fields using ngx-input', () => {
    it('basic', () => {
      cy.getByLabel('Default Numeric Field').as('numericField');
      cy.get('@numericField').find('input').should('have.length', 1);
    });

    it('prefix and suffix', () => {
      cy.getByLabel('Numeric Prefix Suffix').as('numericField');
      cy.get('@numericField').within(() => {
        cy.get('input').should('have.length', 1);
        cy.get('ngx-input-prefix').should('contain', '$');
        cy.get('ngx-input-suffix').should('contain', 'USD');
      });
    });

    it('required', () => {
      cy.getByLabel('Required Numeric Field').as('numericField');
      cy.get('@numericField').within(() => {
        cy.get('input').should('have.length', 1);
        cy.get('input').should('have.attr', 'required');
        cy.get('.ngx-input-label').should('contain', '*');
      });
      cy.get('@numericField').clear().ngxFindNativeInput().blur();
      cy.get('@numericField').find('.ngx-input-hint').should('contain', 'Error: Required Numeric Field is required.');
    });

    it('unique', () => {
      const fieldId = 'awo5n';
      cy.intercept('POST', `/api/app/${appId}/record/${recordId}/unique/${fieldId}`, { unique: false }).as(
        'validateUniqueField'
      );
      cy.getByLabel('Unique Numeric Field').as('numericField');
      cy.get('@numericField').find('input').should('have.length', 1);
      cy.get('@numericField').ngxFill('1');
      cy.get('@numericField')
        .siblings('.record-field--unique__pending-message')
        .should('contain', 'Pending Validation...');
      cy.wait('@validateUniqueField');
      cy.get('@numericField')
        .find('.ngx-input-hint')
        .should('contain', 'Error: Unique Numeric Field must be a unique value.');
    });

    it('min', () => {
      cy.getByLabel('Numeric Field with Min').as('numericField');
      const min = '0';
      cy.get('@numericField').ngxFill(`${+min - 1}`);
      cy.get('@numericField')
        .find('.ngx-input-hint')
        .should('contain', `Error: Numeric Field with Min must be a minimum of ${min}.`);
      cy.get('@numericField').clear();
      cy.get('@numericField').ngxFill(min);
      cy.get('@numericField')
        .contains(`Error: Numeric Field with Min must be a minimum of ${min}.`)
        .should('not.exist');
    });

    it('max', () => {
      cy.getByLabel('Numeric Field with Max').as('numericField');
      const max = '100';
      cy.get('@numericField').ngxFill(`${+max + 1}`);
      cy.get('@numericField')
        .find('.ngx-input-hint')
        .should('contain', `Error: Numeric Field with Max must be a maximum of ${max}.`);
      cy.get('@numericField').clear();
      cy.get('@numericField').ngxFill(max);
      cy.get('@numericField')
        .contains(`Error: Numeric Field with Max must be a maximum of ${max}.`)
        .should('not.exist');
    });

    it('min and max', () => {
      cy.getByLabel('Numeric Field with Min and Max').as('numericField');
      const min = '-50';
      const max = '50';
      cy.get('@numericField').ngxFill(`${+min - 1}`);
      cy.get('@numericField')
        .find('.ngx-input-hint')
        .should('contain', `Error: Numeric Field with Min and Max must be a minimum of ${min}.`);
      cy.get('@numericField').clear();
      cy.get('@numericField').ngxFill(min);
      cy.get('@numericField')
        .contains(`Error: Numeric Field with Min and Max must be a maximum of ${min}.`)
        .should('not.exist');
      cy.get('@numericField').clear();
      cy.get('@numericField').ngxFill(`${+max + 1}`);
      cy.get('@numericField')
        .find('.ngx-input-hint')
        .should('contain', `Error: Numeric Field with Min and Max must be a maximum of ${max}.`);
      cy.get('@numericField').clear();
      cy.get('@numericField').ngxFill(max);
      cy.get('@numericField')
        .contains(`Error: Numeric Field with Min and Max must be a maximum of ${max}.`)
        .should('not.exist');
    });
  });

  describe('readonly', () => {
    it('readonly', () => {
      cy.getByLabel('Numeric Readonly').as('numericField');
      cy.get('@numericField').should('contain', 100);
    });

    it('calculated', () => {
      cy.getByLabel('Calculated Numeric Field').as('numericField');
      cy.get('@numericField').should('contain', 2);
    });
  });

  describe('help text', () => {
    it('below', () => {
      cy.getByLabel('Numeric Field with Help Text Below').closest('.numeric-field').as('numericField');
      cy.get('@numericField').find('.record-field__help-text--below').should('contain', 'Help Text');
    });

    it('above', () => {
      cy.getByLabel('Numeric Field with Help Text Above').closest('.numeric-field').as('numericField');
      cy.get('@numericField').find('.record-field__help-text--above').should('contain', 'Help Text');
    });
  });
});

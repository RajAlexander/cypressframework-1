describe('History Fields', () => {
  const appId = 'history_fields';
  const recordId = 'history_fields_record';

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();

    cy.intercept('GET', `/api/history/${appId}?type=Applications&revisionNumber=*`, {
      fixture: 'mocks/swimlane/app/history_fields/history/2/get.json'
    }).as('GET:revision');

    cy.setMockFeatureFlag('RecordPage');
    cy.navigateSwimlane(`/record2/${appId}/${recordId}`);

    cy.wait(`@GET:app/${appId}/record/${recordId}/history`);
    cy.wait(`@GET:revision`);
  });

  it('help text', () => {
    it('below', () => {
      cy.getByLabel('History-2').closest('.history-field').as('historyField');
      cy.get('@ugField').find('.record-field__help-text--below').should('contain', 'Help Text');
    });
    it('below', () => {
      cy.getByLabel('History-1').closest('.history-field').as('historyField');
      cy.get('@ugField').find('.record-field__help-text--below').should('contain', 'Help Text');
    });
  });

  describe('history field shows revision list', () => {
    beforeEach(() => {
      cy.getByLabel('History 1').as('CUT');
    });

    it('shows 2 revisions', () => {
      cy.get('@CUT').within(() => {
        cy.get('.datatable-body-row').should('have.length', 2);
        cy.get('.datatable-body-row')
          .eq(1)
          .within(() => {
            cy.get('datatable-body-cell').eq(0).as('revisionCell').should('contain', '2');
            cy.get('datatable-body-cell').eq(3).as('changeCell').should('contain', 'Text');
            cy.get('@changeCell').should('contain', 'Numeric');
            cy.get('datatable-body-cell').eq(4).as('commentsCell').should('contain', 'Comments');
          });
      });
    });

    it('opens revision record in a drawer', () => {
      cy.setupStubbedSwimlane();
      cy.get('@CUT').within(() => {
        cy.get('.datatable-body-row')
          .eq(1)
          .within(() => {
            cy.get('datatable-body-cell').eq(0).as('revisionCell').should('contain', '2');
            cy.get('@revisionCell').find('.history--field__table__open-revision').click();
          });
      });

      cy.wait(`@GET:app/${appId}/record/${recordId}/history/2`);
      cy.wait(`@GET:app/${appId}/history/2`);
      cy.wait(`@GET:app/${appId}/record/${recordId}/history`);

      cy.get('.ngx-drawer-content > app-record')
        .should('exist')
        .within(() => {
          cy.get('.ngx-toolbar-title-col').should('contain.text', 'HF-1').should('contain', 'Revision 2');
        });
    });
  });

  describe('Revision page', () => {
    before(() => {
      cy.login();
      cy.setupStubbedSwimlane();

      cy.intercept('GET', `/api/history/${appId}?type=Applications&revisionNumber=*`, {
        fixture: 'mocks/swimlane/app/history_fields/history/2/get.json'
      }).as('GET:revision');

      cy.setMockFeatureFlag('RecordPage');
      cy.navigateSwimlane(`/record2/${appId}/${recordId}/history/2`, { forceReload: true });
      cy.wait(`@GET:app/${appId}/history/2`);
      cy.wait(`@GET:app/${appId}/record/${recordId}/history/2`);
      cy.wait(`@GET:app/${appId}/record/${recordId}/history`);
      cy.wait(`@GET:revision`);
    });

    it('shows revision number in header', () => {
      cy.get('.record-state__toolbar').should('exist');
      cy.get('.record-state__toolbar .record-state__toolbar__title')
        .should('exist')
        .should('contain', 'HF-1')
        .should('contain', 'Revision 2');
    });

    it('hides save button', () => {
      cy.get('.record-state__toolbar__controls .btn-primary').should('not.exist');
    });
  });
});

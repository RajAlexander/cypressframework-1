describe('Calculated Fields', () => {
  const appId = 'calc_fields';
  const recordId = 'calc_fields_record';

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('RecordPage');
    cy.navigateSwimlane(`/record2/${appId}/${recordId}`);
  });

  describe('calculated fields', () => {
    beforeEach(() => {
      cy.get('.record-state__layout').should('exist');

      cy.getByLabel('Input Text Field').as('text-input');
      cy.getByLabel('Output Text Field').as('text-output');

      cy.getByLabel('Input Numeric Field').as('numeric-input');
      cy.getByLabel('Output Numeric Field').as('numeric-output');

      cy.getByLabel('Input Date Field').as('date-input');

      // TODO: output doesn't exist yet
      // cy.getByLabel('Output Date Field').as('date-output');
    });

    it('text', () => {
      cy.get('@text-output').closest('.record-field').should('have.class', 'record-field--readonly');
      cy.get('@text-output')
        .prev('.record-field__field-label')
        .find('i')
        .should('exist')
        .should('have.class', 'ngx-formula');
      cy.get('@text-output').ngxGetValue().invoke('trim').should('equal', '');

      cy.intercept('/api/app/calc_fields/record/calc_fields_record/calc', {
        values: {
          ajx37: 'Hello World'
        }
      }).as('calc');

      cy.get('@text-input').ngxFill('Hello');
      cy.wait('@calc');
      cy.get('@text-output').ngxGetValue().invoke('trim').should('equal', 'Hello World');
    });

    it('numeric', () => {
      cy.get('@numeric-output').closest('.record-field').should('have.class', 'record-field--readonly');
      cy.get('@numeric-output')
        .prev('.record-field__field-label')
        .find('i')
        .should('exist')
        .should('have.class', 'ngx-formula');
      cy.get('@numeric-output').ngxGetValue().invoke('trim').should('equal', '');

      cy.intercept('/api/app/calc_fields/record/calc_fields_record/calc', {
        values: {
          arpbc: 4200
        }
      }).as('calc');

      cy.get('@numeric-input').ngxFill('42');
      cy.wait('@calc');
      cy.get('@numeric-output').ngxGetValue().invoke('trim').should('equal', '4200');
    });

    it('date', () => {
      cy.intercept('/api/app/calc_fields/record/calc_fields_record/calc', {
        values: {
          a7riv: '2020-01-04T07:00:00.000Z'
        }
      }).as('calc');

      cy.get('@date-input').ngxFill('1/1/2020');
      cy.wait('@calc');

      cy.getByLabel('Output Date Field').as('date-output');
      cy.get('@date-output').closest('.record-field').should('have.class', 'record-field--readonly');
      cy.get('@date-output')
        .parent()
        .find('.record-field__field-label')
        .find('i')
        .should('exist')
        .should('have.class', 'ngx-formula');
      cy.get('@date-output').should('contain.text', 'Jan 4, 2020');
    });
  });
});

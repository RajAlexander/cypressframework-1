describe('Widget Layout', () => {
  const appId = 'widget_layout';
  const recordId = 'widget_layout_record';

  const v1WidgetId = '624603b2038055140716cbca';
  const v2WidgetId = '624603b2038055140716cbcb';

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('RecordPage');
    cy.navigateSwimlane(`/record2/${appId}/${recordId}`);
    cy.waitForNetworkIdle(2000);
  });

  describe('displays widget', () => {
    it('renders v1 widget', () => {
      cy.get(`widget-element#${v1WidgetId}`).as('widget').should('exist');

      cy.get('@widget').within(() => {
        cy.get('[widget-type="record"]', { timeout: 30000 }).as('widgetContent').should('exist');
        cy.get('@widgetContent')
          .shadow()
          .find('.frame')
          .within(() => {
            cy.get('pre').as('recordDisplay').should('exist');
            cy.get('@recordDisplay')
              .invoke('text')
              .then(text => {
                const record = JSON.parse(text);
                expect(record.id).to.equal(recordId);
                expect(record.text).to.equal('hello');
              });
          });
      });
    });

    it('renders v2 widget', () => {
      cy.get(`widget-element#${v2WidgetId}`).as('widget').should('exist');

      cy.get('@widget').within(() => {
        cy.get('[widget-type="record"]', { timeout: 30000 }).as('widgetContent').should('exist');
        cy.get('@widgetContent')
          .shadow()
          .find('.frame')
          .within(() => {
            cy.get('pre').as('recordDisplay').should('exist');
            cy.get('@recordDisplay')
              .invoke('text')
              .then(text => {
                const record = JSON.parse(text);
                expect(record.id).to.equal(recordId);
                expect(record.text).to.equal('hello');
              });
          });
      });
    });

    it('renders help text above', () => {
      cy.get(`widget-element#${v1WidgetId}`)
        .closest('.record-layout__widget')
        .should('exist')
        .within(() => {
          cy.get('.widget__help-text--above').should('contain.text', 'This is help text above the widget');
        });
    });

    it('renders help text below', () => {
      cy.get(`widget-element#${v2WidgetId}`)
        .as('widget')
        .closest('.record-layout__widget')
        .within(() => {
          cy.get('.widget__help-text--below').should('contain.text', 'This is help text below the widget');
        });
    });
  });

  describe('widgets trigger events', () => {
    beforeEach(() => {
      cy.get('widget-element#624603b2038055140716cbcc [widget-type="record"]').should('exist').as('trigger-widget');
    });

    it('updates values', () => {
      cy.get('@trigger-widget')
        .should('exist')
        .shadow()
        .find('.frame')
        .within(() => {
          cy.contains('button', 'Update Value').click();
        });

      cy.getByLabel('Text').ngxFindNativeInput().should('have.value', 'helloX');
      
      cy.get(`widget-element#${v1WidgetId} [widget-type="record"]`)
        .shadow()
        .find('.frame')
        .within(() => {
          cy.get('pre').should('contain.text', '"text": "helloX"');
        });

      cy.get(`widget-element#${v2WidgetId} [widget-type="record"]`)
        .shadow()
        .find('.frame')
        .within(() => {
          cy.get('pre').should('contain.text', '"text": "helloX"');
        });
    });

    it('trigger integrations', () => {
      cy.intercept('POST', '**//api/task/execute/record', '').as('trigger');

      cy.get('@trigger-widget')
        .should('exist')
        .shadow()
        .find('.frame')
        .within(() => {
          cy.contains('button', 'Trigger Integration').click();
        });

      cy.wait('@trigger');
    });

    it('adds comments', () => {
      cy.intercept('POST', `**//api/app/${appId}/record/${recordId}/ae1li/comment`, '').as('comment');

      cy.get('@trigger-widget')
        .should('exist')
        .shadow()
        .find('.frame')
        .within(() => {
          cy.contains('button', 'Add Comment').click();
        });

      cy.wait('@comment');
    });

    it('triggers save', () => {
      cy.intercept('PUT', '**//api/app/widget_layout/record', {
        fixture: 'mocks/swimlane/app/widget_layout/record/widget_layout_record/get.json'
      }).as('save');

      cy.get('@trigger-widget')
        .should('exist')
        .shadow()
        .find('.frame')
        .within(() => {
          cy.contains('button', 'Trigger Save').click();
        });

      cy.wait('@save');
    });
  });

  describe('read-only', () => {
    before(() => {
      cy.getByLabel('Text').ngxFill('hello');

      cy.hubPublish('recordLocked', {
        locked: true,
        lockingUser: {
          name: 'jtester',
          displayName: 'jtester',
          id: '5cd9d2a225cea00014bf1d79'
        },
        lockedDate: new Date().toISOString()
      });
      cy.get('body').click();
    });

    beforeEach(() => {
      cy.get('widget-element#624603b2038055140716cbcc [widget-type="record"]').should('exist').as('trigger-widget');
      cy.window().then(win => cy.spy(win.console, 'error'));
    });

    it(`doesn't update values`, () => {
      cy.get('@trigger-widget')
        .should('exist')
        .shadow()
        .find('.frame')
        .within(() => {
          cy.contains('button', 'Update Value').click();
        });

      cy.window().then((win) => {
        expect(win.console.error).to.have.calledOnceWith('Cannot update read-only record');
      });

      cy.getByLabel('Text').ngxGetValue().should('equal', ' hello ');

      cy.get(`widget-element#${v1WidgetId} [widget-type="record"]`)
        .shadow()
        .find('.frame')
        .within(() => {
          cy.get('pre').should('contain.text', '"text": "hello"');
        });

      cy.get(`widget-element#${v2WidgetId} [widget-type="record"]`)
        .shadow()
        .find('.frame')
        .within(() => {
          cy.get('pre').should('contain.text', '"text": "hello"');
        });
    });

    it(`doesn't trigger integrations`, () => {
      cy.get('@trigger-widget')
        .should('exist')
        .shadow()
        .find('.frame')
        .within(() => {
          cy.contains('button', 'Trigger Integration').click();
        });

      cy.window().then(win => {
        expect(win.console.error).to.have.calledOnceWith('Cannot trigger task from read-only record');
      });
    });

    it(`doesn't add comments`, () => {
      cy.get('@trigger-widget')
        .should('exist')
        .shadow()
        .find('.frame')
        .within(() => {
          cy.contains('button', 'Add Comment').click();
        });

      cy.window().then(win => {
        expect(win.console.error).to.have.calledOnceWith('Cannot update read-only record');
      });
    });

    it(`doesn't triggers save`, () => {
      cy.get('@trigger-widget')
        .should('exist')
        .shadow()
        .find('.frame')
        .within(() => {
          cy.contains('button', 'Trigger Save').click();
        });

      cy.window().then(win => {
        expect(win.console.error).to.have.calledOnceWith('Cannot trigger save from read-only record');
      });
    });
  });
});

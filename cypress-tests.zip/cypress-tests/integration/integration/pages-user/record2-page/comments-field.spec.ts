describe('Comment Fields', () => {
  const getIframeDocument = selector => {
    return cy.get(selector).find('iframe').its('0.contentDocument').should('exist');
  };

  const getEditor = selector => {
    return getIframeDocument(selector).its('body').should('not.be.undefined').then(cy.wrap);
  };

  const appId = 'comments_fields';
  const recordId = 'comments_fields_record';

  describe('New Record', () => {
    before(() => {
      cy.login();

      cy.setupStubbedSwimlane();
      cy.setMockFeatureFlag('RecordPage');
      cy.navigateSwimlane(`/record2/${appId}/`);
    });

    it('shows content header', () => {
      cy.get('.record-state__toolbar').should('exist');
      cy.get('.record-state__toolbar .record-state__toolbar__title').should('exist').should('contain', 'New Record');
    });

    describe('Comment Field', () => {
      describe('Comments', () => {
        beforeEach(() => {
          cy.getByLabel('Comments Basic').as('rte');
          cy.get('@rte').parent().as('rteContainer');
          cy.get('@rte').parentsUntil('.comments-field__comments-list').as('commentsList');
          cy.get('@rte').parentsUntil('.record-field__field-label').as('commentsLabel');
        });

        it('has label', () => {
          cy.get('@commentsLabel').should('contain', 'Comments Basic');
        });

        it('has rich text editor', () => {
          cy.get('@rte').should('have.length', 1);
        });

        it('setup comments', () => {
          cy.setupStubbedSwimlane();
          cy.get('@rteContainer')
            .scrollIntoView()
            .within(() => {
              cy.getRTE().focus().type('Hello');
              cy.get('.btn-primary').click();

              cy.getRTE().focus().type('Hello ').type('{meta}B').type('World');
              cy.get('.btn-primary').click();

              cy.getRTE().focus().type('1{enter}2{enter}3{enter}4{enter}5{enter}6');
              cy.get('.btn-primary').click();
            });
        });

        it('shows comment count', () => {
          cy.get('@commentsList').find('.comments-field__comments-list--count').should('contain', 'Comments 3');
        });

        it('shows comment text', () => {
          cy.get('.comment--body').should('have.length', 3);
          cy.get('.comment--body').eq(0).should('to.contain', 'Hello');
          cy.get('.comment--body')
            .eq(1)
            .invoke('text')
            .should('match', /Hello.+World/);

          // The HTML in comments doesn't seem to render properly when running the tests
          // from the current cypress/included:4.3.0 docker image
          // uncomment after https://github.com/cypress-io/cypress-docker-images/pull/290 gets merged
          // cy.get('.comment--body').eq(1).find('strong').should('have.length', 1);
          // cy.get('.comment--body').eq(1).find('strong').should('to.contain', 'World');

          cy.get('.comment--body')
            .eq(2)
            .find('.comment--body--rich')
            .should('have.html', '<p>1</p>\n<p>2</p>\n<p>3</p>\n<p>4</p>\n<p>5</p>\n<p>6</p>');
        });

        it('shows help lines', () => {
          cy.get('.comment--media-body .help-block').should('have.length', 3);
          cy.get('.comment--media-body .help-block').should('contain', 'Created:');
        });

        it('shows avatars', () => {
          cy.get('@rteContainer').scrollIntoView();
          cy.get('.avatar').should('have.length', 3);
          cy.get('.avatar').should('contain', 'AD');
        });
      });

      describe('Record', () => {
        it('saves', () => {
          cy.setupStubbedSwimlane();
          cy.get('.record-state__toolbar__controls .btn-primary').as('saveButton');

          cy.get('@saveButton').click();
          cy.wait(`@POST:app/*/record`);
          cy.wait(`@GET:app/*/record/*`);
        });
      });
    });

    describe('help text', () => {
      it('below', () => {
        cy.getByLabel('Comments Help Text Below').as('rte');
        cy.get('@rte').parentsUntil('.record-field__help-text--below').should('contain', 'Help Text');
      });

      it('above', () => {
        cy.getByLabel('Comments Help Text Above').as('rte');
        cy.get('@rte').parentsUntil('.record-field__help-text--above').should('contain', 'Help Text');
      });
    });
  });

  describe('Existing Record', () => {
    before(() => {
      cy.login();
      cy.setupStubbedSwimlane();
      cy.setMockFeatureFlag('RecordPage');

      cy.navigateSwimlane(`/record2/${appId}/${recordId}`);
    });

    beforeEach(() => {
      cy.setupStubbedSwimlane();
    });

    it('shows content header', () => {
      cy.get('.record-state__toolbar .record-state__toolbar__title').should('contain', 'CF-35');
    });

    describe('Comment Field', () => {
      describe('Comments', () => {
        beforeEach(() => {
          cy.getByLabel('Comments Basic').as('rte');
          cy.get('@rte').parent().as('rteContainer');
          cy.get('@rte').parentsUntil('.comments-field__comments-list').as('commentsList');
          cy.get('@rte').parentsUntil('.record-field__field-label').as('commentsLabel');
        });

        it('has label', () => {
          cy.get('@commentsLabel').should('contain', 'Comments Basic');
        });

        it('has rich text editor', () => {
          cy.get('@rte').should('have.length', 1);
        });

        describe('Comments', () => {
          it('shows comment count', () => {
            cy.get('@commentsList').find('.comments-field__comments-list--count').should('contain', 'Comments 2');
          });

          it('shows comment text', () => {
            cy.get('.comment--body').should('have.length', 2);
            cy.get('.comment--body').eq(0).should('to.contain', 'comment 1');
            cy.get('.comment--body').eq(1).should('to.contain', 'comment 2');
          });

          it('shows help lines', () => {
            cy.get('.comment--media-body .help-block').should('have.length', 2);
            cy.get('.comment--media-body .help-block').should('contain', 'Created:');
          });

          it('shows avatars', () => {
            cy.get('@rteContainer').scrollIntoView();
            cy.get('.avatar').should('have.length', 2);
            cy.get('.avatar').should('contain', 'AD');
          });
        });
      });

      describe('Posting New Comment', () => {
        before(() => {
          cy.setupStubbedSwimlane();
          cy.getByLabel('Comments Basic').as('rte');
          cy.get('@rte').parent().as('rteContainer');
          cy.get('@rteContainer').scrollIntoView();
          getEditor('@rte').focus().type('This will get saved when posting');
        });

        it('saves when posting', () => {
          cy.get('@rteContainer').find('.btn-primary').click();
          cy.wait(`@POST:app/*/record/*/*/comment`);
        });
      });
    });
  });
});

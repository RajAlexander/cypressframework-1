describe('Co-edit', () => {
  const applicationId = 'multi-fields';
  const recordId = 'multi-fields_record';

  const MOCK_COEDITOR = {
    id: 'a35z27IBkF1YYkQeq',
    name: 'joetester'
  };

  const MOCK_COEDITOR_2 = {
    id: 'a35z27IBkF1YYkQer',
    name: 'ttester'
  };

  function triggerEdit(fieldId: string, value: string, user = MOCK_COEDITOR) {
    cy.hubPublish('coeditUpdated', {
      userId: user,
      messageType: 'editing',
      recordId,
      applicationId,
      fieldId,
      value
    });
    cy.wait(300); // co-edit messages are debounced by 150 ms
    cy.get('body').click(); // Need to force change detection (unknown issue)
  }

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('RecordPage');
    cy.navigateSwimlane(`/record2/${applicationId}/${recordId}`);
    cy.waitForNetworkIdle(2000);
  });

  describe('co-editors', () => {
    it('no co-editors on load', () => {
      cy.get('.record-state__toolbar__record-editors__editor').should('have.length', 0);
    });

    it('shows co-editors on enter', () => {
      cy.hubPublish('coeditUpdated', {
        userId: MOCK_COEDITOR,
        messageType: 'enter',
        recordId,
        applicationId
      });
      cy.get('body').click();

      cy.get('.record-state__toolbar__record-editors__editor').should('have.length', 1);
      cy.get('.record-state__toolbar__record-editors__editor').first().should('contain.text', 'JO');
    });

    it('updates fields on edit', () => {
      triggerEdit('ar4zo', `"Hello"`);
      cy.getByLabel('Single Line').ngxFindNativeInput().should('have.value', 'Hello');
    });

    it('shows multiple co-editors on enter', () => {
      cy.hubPublish('coeditUpdated', {
        userId: MOCK_COEDITOR_2,
        messageType: 'enter',
        recordId,
        applicationId
      });
      cy.get('body').click();

      cy.get('.record-state__toolbar__record-editors__editor').should('have.length', 2);
      cy.get('.record-state__toolbar__record-editors__editor').eq(1).should('contain.text', 'TT');

      cy.hubPublish('coeditUpdated', {
        userId: MOCK_COEDITOR_2,
        messageType: 'exit',
        recordId,
        applicationId
      });
      cy.get('body').click();

      cy.get('.record-state__toolbar__record-editors__editor').should('have.length', 1);
    });

    it('removes co-editors on exit', () => {
      cy.hubPublish('coeditUpdated', {
        userId: MOCK_COEDITOR,
        messageType: 'exit',
        recordId,
        applicationId
      });
      cy.get('body').click();

      cy.get('.record-state__toolbar__record-editors__editor').should('have.length', 0);
    });
  });

  describe('basic fields', () => {
    it('updates multi-line fields', () => {
      cy.getByLabel('Multi Line').ngxFindNativeInput().should('have.value', '');
      triggerEdit('ae6sz', `"Hello Multi-Line"`);
      cy.getByLabel('Multi Line').ngxFindNativeInput().should('have.value', 'Hello Multi-Line');
    });

    it('updates numeric', () => {
      cy.getByLabel('Numeric').ngxFindNativeInput().should('have.value', '');
      triggerEdit('ag2gt', `123`);
      cy.getByLabel('Numeric').ngxFindNativeInput().should('have.value', 123);

      // Rejects non-numeric values
      triggerEdit('ag2gt', `"WHAT"`);
      cy.getByLabel('Numeric').ngxFindNativeInput().should('have.value', '');
    });

    it('updates rich text fields', () => {
      triggerEdit('aeqv9', `"<p><strong>Hello HTML</strong></p>"`);
      cy.getByLabel('Rich Text').getRTE().should('have.html', '<p><strong>Hello HTML</strong></p>');
    });
  });

  describe('date fields', () => {
    it('updates date & time fields', () => {
      cy.getByLabel('Date & Time').ngxFindNativeInput().should('have.value', '');
      triggerEdit('axobr', `"2022-06-01T17:31:45.863Z"`);
      cy.getByLabel('Date & Time').ngxFindNativeInput().should('have.value', 'Jun 1, 2022 11:31 AM -06:00');
    });

    it('updates date fields', () => {
      cy.get('#a2yoh-input').ngxFindNativeInput().should('have.value', '');
      triggerEdit('a2yoh', `"2022-06-03T00:00:00.000Z"`);
      cy.get('#a2yoh-input').ngxFindNativeInput().should('have.value', 'Jun 3, 2022');
    });

    it('updates time fields', () => {
      cy.get('#a8aw7-input').ngxFindNativeInput().should('have.value', '');
      triggerEdit('a8aw7', `"1970-01-01T14:55:00.000Z"`);
      cy.get('#a8aw7-input').ngxFindNativeInput().should('have.value', '2:55 PM');
    });

    it('updates timespan fields', () => {
      cy.getByLabel('Timespan').ngxFindNativeInput().should('have.value', '');
      triggerEdit('apt93', `1814400000`);
      cy.wait(1000);
      cy.getByLabel('Timespan').ngxFindNativeInput().should('contain.value', '3w');
    });
  });

  describe('list fields', () => {
    it('updates text list', () => {
      triggerEdit(
        'azgkm',
        '[{"$type":"Core.Models.Record.ListItem`1[[System.String]], Core","value":"hello","id":"62bb3f58988a9efab6975482"},{"$type":"Core.Models.Record.ListItem`1[[System.String]], Core","value":"world","id":"62bb3f5aa211433cd6f3d482"}]'
      );
      cy.getByLabel('Text List').within(() => {
        cy.get('.ngx-select-input-option').should('have.length', 2);
        cy.get('.ngx-select-input-option').eq(0).should('contain.text', 'hello');
        cy.get('.ngx-select-input-option').eq(1).should('contain.text', 'world');
      });
    });

    it('updates numeric list', () => {
      triggerEdit(
        'ar4iy',
        '[{"$type":"Core.Models.Record.ListItem`1[[System.Double]], Core","id":"62bb6db635709a4dff09f4f6","value":"1"},{"$type":"Core.Models.Record.ListItem`1[[System.Double]], Core","id":"62bb6db750418cba722ae541","value":"2"},{"$type":"Core.Models.Record.ListItem`1[[System.Double]], Core","id":"62bb6db7a357e225ce164581","value":"3"}]'
      );
      cy.getByLabel('Numeric List').within(() => {
        cy.get('.ngx-select-input-option').should('have.length', 3);
        cy.get('.ngx-select-input-option').eq(0).should('contain.text', '1');
        cy.get('.ngx-select-input-option').eq(1).should('contain.text', '2');
      });
    });
  });

  describe('selection fields', () => {
    it('updates single select', () => {
      triggerEdit(
        'a9kn5',
        '{"$type":"Core.Models.Record.ValueSelection, Core","id":"62ba29ce00f0fa39a941c576","value":"A"}'
      );
      cy.getByLabel('Single-select').within(() => {
        cy.get('.ngx-select-input-option').should('have.length', 1);
        cy.get('.ngx-select-input-option').eq(0).should('contain.text', 'A');
      });
    });

    it('updates multi select', () => {
      triggerEdit(
        'a25tq',
        '[{"$type":"Core.Models.Record.ValueSelection, Core","id":"62ba29d12b93749dfada3ce6","value":"Two"}]'
      );
      cy.getByLabel('Multi-select').within(() => {
        cy.get('.ngx-select-input-option').should('have.length', 1);
        cy.get('.ngx-select-input-option').eq(0).should('contain.text', 'Two');
      });
    });

    it('updates radio buttons', () => {
      triggerEdit(
        'ajyea',
        '{"$type":"Core.Models.Record.ValueSelection, Core","id":"62ba29d59a50f73acec0a3b1","value":"III"}'
      );
      cy.getByLabel('Radio buttons').within(() => {
        cy.get('*[name="I"]').should('not.be.checked');
        cy.get('*[name="II"]').should('not.be.checked');
        cy.get('*[name="III"]').should('be.checked');
      });
    });

    it('updates check boxes', () => {
      triggerEdit(
        'a6fmk',
        '[{"$type":"Core.Models.Record.ValueSelection, Core","id":"62ba29d979ee449c4b035898","value":"X"},{"$type":"Core.Models.Record.ValueSelection, Core","id":"62ba29d83cdad4c88465354e","value":"Y"}]'
      );
      cy.getByLabel('Checkboxes').within(() => {
        cy.get('*[type="checkbox"]').eq(0).should('be.checked');
        cy.get('*[type="checkbox"]').eq(1).should('be.checked');
        cy.get('*[type="checkbox"]').eq(2).should('not.be.checked');
      });
    });
  });

  describe('user/group fields', () => {
    it('updates multi select', () => {
      cy.intercept('GET', '/api/user/a35z27IBkF1YYkQep', {
        id: 'a35z27IBkF1YYkQep',
        name: 'jtester',
        displayName: 'jtester'
      }).as('getUser1');
      cy.intercept('GET', '/api/groups/a35z27IBkF1YYkQep', { statusCode: 204 }).as('getGroup1');
      cy.intercept('GET', '/api/user/aUSMUlO3L88SqGt3X', { statusCode: 204 }).as('getUser2');
      cy.intercept('GET', '/api/groups/aUSMUlO3L88SqGt3X', { id: 'aUSMUlO3L88SqGt3X', name: 'Testers' }).as(
        'getGroup2'
      );
      triggerEdit(
        'a6ih1',
        '[{"$type":"Core.Models.Utilities.UserGroupSelection, Core","id":"a35z27IBkF1YYkQep","name":"jtester"},{"$type":"Core.Models.Utilities.UserGroupSelection, Core","id":"aUSMUlO3L88SqGt3X","name":"Testers"}]'
      );
      cy.wait(['@getUser1', '@getGroup1', '@getUser2', '@getGroup2']);
      cy.getByLabel('Multi User/Groups').within(() => {
        cy.get('.ngx-select-input-option').should('have.length', 2);
        cy.get('.ngx-select-input-option').eq(0).should('contain.text', 'jtester');
        cy.get('.ngx-select-input-option').eq(1).should('contain.text', 'Testers');
      });
    });

    it('updates single select', () => {
      cy.intercept('GET', '/api/user/a35z27IBkF1YYkQep', {
        id: 'a35z27IBkF1YYkQep',
        name: 'jtester',
        displayName: 'jtester'
      }).as('getUser');
      cy.intercept('GET', '/api/groups/a35z27IBkF1YYkQep', { statusCode: 204 }).as('getGroup');
      triggerEdit(
        'a7jaz',
        '{"$type":"Core.Models.Utilities.UserGroupSelection, Core","id":"a35z27IBkF1YYkQep","name":"jtester"}'
      );
      cy.wait(['@getUser', '@getGroup']);
      cy.getByLabel('Single User/Groups').within(() => {
        cy.get('.ngx-select-input-option').should('have.length', 1);
        cy.get('.ngx-select-input-option').eq(0).should('contain.text', 'jtester');
      });
    });
  });

  describe.skip('reference fields', () => {
    // TODO: need to mock all reference API calls
  });

  describe('attachment fields', () => {
    it('updates attachment field', () => {
      triggerEdit(
        'aks11',
        '[{"$type":"Core.Models.Record.Attachment, Core","fileId":"aMAmtkjhKH7CAaseX","filename":"readme.md","uploadDate":"2022-07-01T18:14:11.522Z"}]'
      );
      cy.get('.record-field.attachment-field').within(() => {
        cy.get('datatable-body-row').should('have.length', 1);
        cy.get('datatable-body-row').eq(0).should('contain.text', 'readme.md');
      });
    });
  });
});

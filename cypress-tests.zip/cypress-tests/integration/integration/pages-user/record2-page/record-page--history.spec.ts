describe('Record Page - History Record', () => {
  const appId = 'ad2xJUGes5TNRKG4M';
  const recordId = 'a3Kjp2HL5YFzEfYzJ';

  before(() => {
    cy.setupStubbedSwimlane();

    cy.login();
    cy.setMockFeatureFlag('RecordPage');
    cy.navigateSwimlane(`/record2/${appId}/${recordId}/history`);
    cy.waitForNetworkIdle(2000);
  });

  it('shows content header', () => {
    cy.get('.record-state__toolbar').should('exist');
    cy.dataCy('record_page__title').should('exist').should('contain', 'TW-5');
  });

  it('shows controls', () => {
    cy.get('.record-state__toolbar__controls').should('exist');
  });

  it('shows readonly values', () => {
    cy.get('label').contains('Text').closest('text-field').should('contain', 'Text Field Value');
  });

  it('disables all buttons', () => {
    cy.get('#6202e5a26e71da4702eec47d button').should('be.disabled');
    cy.get('#6202ff259084a331c1c43014 button').should('be.disabled');
  });
});

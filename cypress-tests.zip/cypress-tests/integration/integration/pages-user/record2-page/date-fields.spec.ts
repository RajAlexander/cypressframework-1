describe('Date Fields', () => {
  const appId = 'date_fields';
  const recordId = 'date_fields_record';

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('RecordPage');
    cy.navigateSwimlane(`/record2/${appId}/${recordId}`);
  });

  describe('date & time fields', () => {
    const defaultDate = 'Dec 1, 2021 5:57 AM -07:00';
    it('default date time field', () => {
      const label = 'Default Date & Time';
      cy.getByLabel(label).as('dateField');
      cy.get('@dateField').ngxGetValue().should('equal', defaultDate);
      cy.get('@dateField').find('.calendar-dialog-btn').click();
      cy.get('.ngx-date-time-dialog').as('dialog').should('exist');
      cy.get('@dialog').within(() => {
        cy.get('.selected-header').should('contain', 'Wed, Dec 1 2021').should('contain', '5:57 am');
        cy.get('ngx-calendar').should('exist');
        cy.get('.time-row').should('exist');
        cy.get('.ngx-dialog-footer button').contains('Apply').click();
      });
    });

    it('required', () => {
      const label = 'Date & Time Required';
      cy.getByLabel(label).as('dateField');
      cy.get('@dateField').within(() => {
        cy.get('input').should('have.attr', 'required');
        cy.get('.ngx-input-label').should('contain', '*');
      });
      cy.get('@dateField').clear();
      cy.get('@dateField').find('.ngx-input-hint').should('contain', `Error: ${label} is required.`);
    });

    it('invalid', () => {
      const label = 'Default Date & Time';
      cy.getByLabel(label).as('dateField');
      cy.get('@dateField').ngxFill('invalid date');
      cy.get('@dateField')
        .find('.ngx-input-hint')
        .should('contain', `Error: ${label} must be in valid date/time format.`);
    });
  });

  describe('date field', () => {
    it('default date field', () => {
      const label = 'Default Date Field';
      cy.getByLabel(label).as('dateField');
      cy.get('@dateField').find('.calendar-dialog-btn').click();
      cy.get('.ngx-date-time-dialog').as('dialog').should('exist');
      cy.get('@dialog').within(() => {
        cy.get('ngx-calendar').should('exist');
        cy.get('.time-row').should('not.exist');
        cy.get('.ngx-dialog-footer button').contains('Apply').click();
      });
    });

    it('date min mode - year', () => {
      const label = 'Date Min Mode';
      cy.getByLabel(label).as('dateField');
      cy.get('@dateField').find('.calendar-dialog-btn').click();
      cy.get('.ngx-date-time-dialog').as('dialog').should('exist');
      cy.get('@dialog').within(() => {
        cy.get('.selected-header').should('contain', 'Fri, Jan 1 2021');
        cy.get('ngx-calendar').should('exist');
        cy.get('.time-row').should('not.exist');
        cy.get('.ngx-dialog-footer button').contains('Apply').click();
      });
    });

    it('invalid', () => {
      const label = 'Default Date Field';
      cy.getByLabel(label).as('dateField');
      cy.get('@dateField').ngxFill('invalid date');
      cy.get('@dateField')
        .find('.ngx-input-hint')
        .should('contain', `Error: ${label} must be in valid date/time format.`);
    });
  });

  describe('timespan fields', () => {
    it('default timespan field', () => {
      const label = 'Timespan';
      cy.getByLabel(label).as('timespanField');
      cy.get('@timespanField').ngxGetValue().should('equal', '');
      cy.get('@timespanField').find('input').should('have.attr', 'placeholder', '(e.g. 3w 4d 12h)');
      cy.get('@timespanField').ngxFill('invalid format');
      cy.get('@timespanField').should('have.class', 'ng-invalid');
      cy.get('@timespanField').ngxFill('3w 4d 12h');
      cy.get('@timespanField').should('have.class', 'ng-valid');
    });

    it('required', () => {
      const label = 'Timespan Required';
      cy.getByLabel(label).as('timespanField');
      cy.get('@timespanField').within(() => {
        cy.get('input').should('have.attr', 'required');
        cy.get('.ngx-input-label').should('contain', '*');
      });
      cy.get('@timespanField').clear();
      cy.get('@timespanField').find('.ngx-input-hint').should('contain', `Error: ${label} is required.`);
    });

    it('invalid', () => {
      const label = 'Timespan';
      cy.getByLabel(label).as('dateField');
      cy.get('@dateField').ngxFill('invalid date');
      cy.get('@dateField').should('have.class', 'ng-invalid');
    });
  });

  describe('time fields', () => {
    it('default time field', () => {
      const label = 'Default Time Field';
      cy.getByLabel(label).as('timeField');
      cy.get('@timeField').find('.calendar-dialog-btn').click();
      cy.get('.ngx-date-time-dialog').as('dialog').should('exist');

      cy.get('@dialog').within(() => {
        cy.get('ngx-calendar').should('not.exist');
        cy.get('.time-row').should('exist');
        cy.get('.ngx-dialog-footer button').contains('Apply').click();
      });
    });

    it('specific time', () => {
      const label = 'Time Specific Field';
      cy.getByLabel(label).as('timeField');
      cy.get('@timeField').ngxGetValue().should('equal', '10:00 AM');
      cy.get('@timeField').find('.calendar-dialog-btn').click();
      cy.get('.ngx-date-time-dialog').as('dialog').should('exist');

      cy.get('@dialog').within(() => {
        cy.get('.selected-header').should('contain', '10:00 am');
        cy.get('ngx-calendar').should('not.exist');
        cy.get('.time-row').should('exist');
        cy.get('.ngx-dialog-footer button').contains('Apply').click();
      });
    });

    it('invalid', () => {
      const label = 'Default Time Field';
      cy.getByLabel(label).as('timeField');
      cy.get('@timeField').ngxFill('Fri, Dec 10, 2021 12:57 PM +00:00');
      cy.get('@timeField')
        .find('.ngx-input-hint')
        .should('contain', `Error: ${label} must be in valid date/time format.`);
    });
  });

  describe('readonly', () => {
    it('first created', () => {
      const label = 'First Created';
      cy.getByLabel(label).as('firstCreatedField');
      cy.get('@firstCreatedField').find('time').as('value').should('contain', 'Fri, Dec 10, 2021');
      cy.get('@value').ngxHover();
      cy.get('ngx-tooltip-content').should('exist');
      cy.get('.date-zone-display').first().should('contain', 'Fri, Dec 10, 2021 5:57 AM -07:00 (MST)');
      cy.get('.date-zone-display').eq(1).should('contain', 'Fri, Dec 10, 2021 12:57 PM +00:00 (UTC)');
      cy.get('@value').ngxUnhover();
      cy.get('ngx-tooltip-content').should('not.exist');
    });

    it('last updated', () => {
      const label = 'Last Updated';
      cy.getByLabel(label).as('lastUpdated');
      cy.get('@lastUpdated').find('time').as('value').should('contain', 'Sun, Dec 12, 2021');
      cy.get('@value').ngxHover();
      cy.get('ngx-tooltip-content').should('exist');
      cy.get('.date-zone-display').first().should('contain', 'Sun, Dec 12, 2021 9:36 PM -07:00 (MST)');
      cy.get('.date-zone-display').eq(1).should('contain', 'Mon, Dec 13, 2021 4:36 AM +00:00 (UTC)');
      cy.get('@value').ngxUnhover();
      cy.get('ngx-tooltip-content').should('not.exist');
    });

    it('timespan automatic diff first created', () => {
      const label = 'Timespan Automatic Diff';
      cy.getByLabel(label).as('timespanField');
      cy.get('@timespanField').should('contain', '2w 11h 52m 51s 434ms');
    });

    it('date & time calculated', () => {
      const label = 'Date & Time Calculated';
      cy.getByLabel(label).as('dateTimeCalculated');
      cy.get('@dateTimeCalculated').find('time').as('value').should('contain', 'Wed, Dec 1, 2021 5:57 AM -07:00 (MST)');
      cy.get('@value').ngxHover();
      cy.get('ngx-tooltip-content').should('exist');
      cy.get('.date-zone-display span').first().should('contain', 'Wed, Dec 1, 2021 12:57 PM +00:00 (UTC)');
      cy.get('.date-zone-display span').eq(1).should('contain', 'Wed, Dec 1, 2021 5:57 AM -07:00 (MST)');
      cy.get('@value').ngxUnhover();
      cy.get('ngx-tooltip-content').should('not.exist');
    });
  });

  describe('help text', () => {
    it('below', () => {
      cy.get('.ngx-input-label')
        .contains(/Date & Time Help Text Below/g)
        .closest('.date-field')
        .as('dateField');
      cy.get('@dateField').find('.record-field__help-text--below').should('contain', 'Help Text');
    });

    it('above', () => {
      cy.get('.ngx-input-label')
        .contains(/Date & Time Help Text Above/g)
        .closest('.date-field')
        .as('dateField');
      cy.get('@dateField').find('.record-field__help-text--above').should('contain', 'Help Text');
    });
  });
});

describe('Record Page - New Record Page', () => {
  const appId = 'ad2xJUGes5TNRKG4M';
  const recordId = 'a3Kjp2HL5YFzEfYzJ';
  const fieldId = '#azzzm';

  before(() => {
    cy.login();

    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('RecordPage');
    cy.navigateSwimlane(`/record2/${appId}/`);
    cy.waitForNetworkIdle(2000);
  });

  it('shows content header', () => {
    cy.get('.record-state__toolbar').should('exist');
    cy.get('.record-state__toolbar .record-state__toolbar__title').should('exist').should('contain', 'New Record');
  });

  it('shows controls', () => {
    cy.get('.record-state__toolbar__controls').should('exist');
    cy.get('.record-state__toolbar__controls .btn-primary')
      .should('contain', 'Save')
      .find('button')
      .should('have.attr', 'disabled');
  });

  it('disables all buttons', () => {
    cy.get('#6202e5a26e71da4702eec47d button').should('be.disabled');
    cy.get('#6202ff259084a331c1c43014 button').should('be.disabled');
  });

  it('shows message when application changes', () => {
    cy.hubPublish('updated', 'apps', {
      id: appId,
      modifiedByUser: {
        name: 'jtester'
      }
    });
    cy.get('.notification-content').whileHovering($el => {
      cy.wrap($el).should(
        'contain',
        'This application has been modified by jtester. Save your progress and refresh the page to avoid losing any work.'
      );
    });
    cy.ngxCloseNotifications();
  });

  it('enables save on change', () => {
    cy.get(fieldId).ngxFill('Hello');
    cy.get('.record-state__toolbar__controls .btn-primary')
      .should('contain', 'Save')
      .find('button')
      .should('not.have.attr', 'disabled');
  });

  it('block navigation when dirty and cancel', () => {
    cy.get(fieldId).ngxFill('Hello');
    cy.get('.nav-logo').click();
    cy.get('.ngx-dialog-content')
      .should('exist')
      .should('contain', 'You have unsaved changes')
      .contains('Cancel')
      .click();
  });

  it('saves and navigates on save click', () => {
    cy.setupStubbedSwimlane();

    cy.get(fieldId).ngxFill('Hello');
    cy.get('.record-state__toolbar__controls .btn-primary').should('contain', 'Save').click();

    cy.wait('@POST:app/*/record');
    cy.wait('@GET:app/*/record/*');
    cy.url().should('include', `/record2/${appId}/${recordId}`);
    // cy.go('back');
  });

  // ToDO: SPT-11163-Flaky test. Bring this back when work on new record page is re started again
  xit('block navigation when dirty and leave', () => {
    cy.setupStubbedSwimlane();

    cy.get(fieldId).ngxFill('Hello');
    cy.navigateSwimlane(`/record2/${appId}/${recordId}`);
    cy.get('.ngx-dialog-content')
      .should('exist')
      .should('contain', 'You have unsaved changes')
      .find('.btn')
      .contains('Leave')
      .click();
    cy.url().should('include', `/record2/${appId}/${recordId}`);
  });
});

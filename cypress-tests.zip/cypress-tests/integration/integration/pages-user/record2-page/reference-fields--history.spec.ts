describe('Reference Fields - Read Only', () => {
  const appId = 'reference_fields';
  const recordId = 'reference_fields_record';

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('RecordPage');
    cy.navigateSwimlane(`/record2/${appId}/${recordId}/history`, { forceReload: true });
    cy.wait('@GET:app/aRIlkHzEA3Lou9JvS');
    cy.wait('@POST:app/aRIlkHzEA3Lou9JvS/record/reference_fields_record/references');
    cy.wait('@POST:app/aRIlkHzEA3Lou9JvS/record/reference_fields_record/references');
    cy.wait('@POST:app/aRIlkHzEA3Lou9JvS/record/reference_fields_record/references');
  });

  describe('single select', () => {
    beforeEach(() => {
      cy.getByLabel('Single-select Reference').should('exist').as('CUT');
    });

    it('renders values', () => {
      cy.get('@CUT').should('contain', 'Hello');
      cy.get('@CUT').should('contain', 'REF-2');
    });
  });

  describe('multi select', () => {
    beforeEach(() => {
      cy.getByLabel('Multi-select Reference').should('exist').as('CUT');
    });

    it('renders values', () => {
      cy.get('@CUT').within(() => {
        cy.get('.reference-field__tag').should('have.length', 2);
        cy.get('.reference-field__tag').first().should('contain', '42').should('contain', 'REF-2');
        cy.get('.reference-field__tag').eq(1).should('contain', '86').should('contain', 'REF-1');
      });
    });
  });

  describe('grid', () => {
    beforeEach(() => {
      cy.get('#a9fx9').as('CUT');
    });

    it('renders values', () => {
      cy.get('@CUT').within(() => {
        cy.get('.reference-field__tag').should('have.length', 2);
        cy.get('.reference-field__tag').first().should('contain', 'REF-2');
        cy.get('.reference-field__tag').eq(1).should('contain', 'REF-1');
      });
    });
  });
});

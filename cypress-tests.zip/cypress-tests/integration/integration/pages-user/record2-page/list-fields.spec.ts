describe('List Fields', () => {
  const appId = 'list_fields';
  const recordId = 'list_fields_record';

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('RecordPage');
    cy.navigateSwimlane(`/record2/${appId}/${recordId}`);
  });

  describe('inputType: text', () => {
    it('required', () => {
      cy.getByLabel('Text List Required').as('listField');
      cy.get('@listField').within(() => {
        cy.get('label.ngx-select-label').should('contain', '*');
      });
      cy.get('@listField').clear();
      cy.get('@listField').find('.ngx-select-hint').should('contain', 'Error: Text List Required is required.');
    });

    it('min max items', () => {
      cy.getByLabel('Text List Min Max Items').as('listField');
      cy.get('@listField').find('input').type('a {enter}');
      cy.get('@listField').find('input').type('a {enter}');
      cy.get('@listField').find('input').type('a {enter}');
      cy.get('@listField').find('input').type('b {enter}');
      cy.get('@listField').find('input').type('c {enter}');
      cy.get('@listField')
        .find('.ngx-select-hint')
        .should('contain', 'Error: Text List Min Max Items must contain a maximum of 4 items.');
    });

    it('max characters', () => {
      cy.getByLabel('Text List Min Max Char Lengths').as('listField');
      const errorMessage =
        'Error: Each item in Text List Min Max Char Lengths must contain a maximum of 10 characters.';
      const invalidStr = 'a'.repeat(11);
      cy.get('@listField').clear();
      cy.get('@listField').find('input').type(`${invalidStr} {enter}`);
      cy.get('@listField').find('.ngx-select-hint').should('contain', errorMessage);
      cy.get('@listField').clear();
      cy.get('@listField').find('.ngx-select-hint').should('not.contain', errorMessage);
      const validStr = 'a'.repeat(10);
      cy.get('@listField').find('input').type(`${validStr} {enter}`);
      cy.get('@listField').find('.ngx-select-hint').should('not.contain', errorMessage);
    });

    it('min characters', () => {
      cy.getByLabel('Text List Min Max Char Lengths').as('listField');
      const errorMessage = 'Error: Each item in Text List Min Max Char Lengths must contain a minimum of 2 characters.';
      const invalidStr = 'a';
      cy.get('@listField').clear();
      cy.get('@listField').find('input').type(`${invalidStr} {enter}`);
      cy.get('@listField').find('.ngx-select-hint').should('contain', errorMessage);
      cy.get('@listField').clear();
      cy.get('@listField').find('.ngx-select-hint').should('not.contain', errorMessage);
      const validStr = 'a'.repeat(2);
      cy.get('@listField').find('input').type(`${validStr} {enter}`);
      cy.get('@listField').find('.ngx-select-hint').should('not.contain', errorMessage);
    });

    it('max words', () => {
      cy.getByLabel('Text List Min Max Word Lengths').as('listField');
      const errorMessage = 'Error: Each item in Text List Min Max Word Lengths must contain a maximum of 4 words.';
      const invalidStr = 'word '.repeat(5);
      cy.get('@listField').clear();
      cy.get('@listField').find('input').type(`${invalidStr} {enter}`);
      cy.get('@listField').find('.ngx-select-hint').should('contain', errorMessage);
      cy.get('@listField').clear();
      const validStr = 'word '.repeat(4);
      cy.get('@listField').find('input').type(`${validStr} {enter}`);
      cy.get('@listField').find('.ngx-select-hint').should('not.contain', errorMessage);
    });

    it('min words', () => {
      cy.getByLabel('Text List Min Max Word Lengths').as('listField');
      const errorMessage = 'Error: Each item in Text List Min Max Word Lengths must contain a minimum of 2 words.';
      const invalidStr = 'word';
      cy.get('@listField').clear();
      cy.get('@listField').find('input').type(`${invalidStr} {enter}`);
      cy.get('@listField').find('.ngx-select-hint').should('contain', errorMessage);
      cy.get('@listField').clear();
      const validStr = 'word '.repeat(2);
      cy.get('@listField').find('input').type(`${validStr} {enter}`);
      cy.get('@listField').find('.ngx-select-hint').should('not.contain', errorMessage);
    });
  });

  describe('inputType: number', () => {
    it('required', () => {
      cy.getByLabel('Numeric List Required').as('listField');
      cy.get('@listField').within(() => {
        cy.get('label.ngx-select-label').should('contain', '*');
      });
      cy.get('@listField').clear();
      cy.get('@listField').find('.ngx-select-hint').should('contain', 'Error: Numeric List Required is required.');
    });

    it('min max items', () => {
      cy.getByLabel('Numeric List Min Max Items').as('listField');
      cy.get('@listField').find('input').type('0 {enter}');
      cy.get('@listField').find('input').type('0 {enter}');
      cy.get('@listField').find('input').type('0 {enter}');
      cy.get('@listField').find('input').type('0 {enter}');
      cy.get('@listField').find('input').type('0 {enter}');
      cy.get('@listField')
        .find('.ngx-select-hint')
        .should('contain', 'Error: Numeric List Min Max Items must contain a maximum of 4 items.');
    });

    it('max range', () => {
      cy.getByLabel('Numeric List Min Max Range').as('listField');
      const errorMessage = 'Error: Each item in Numeric List Min Max Range must be a maximum of 10.';
      cy.get('@listField').clear();
      cy.get('@listField').find('input').type('11 {enter}');
      cy.get('@listField').find('.ngx-select-hint').should('contain', errorMessage);
      cy.get('@listField').clear();
      cy.get('@listField').find('input').type('10 {enter}');
      cy.get('@listField').find('.ngx-select-hint').should('not.contain', errorMessage);
    });

    it('min range', () => {
      cy.getByLabel('Numeric List Min Max Range').as('listField');
      const errorMessage = 'Error: Each item in Numeric List Min Max Range must be a minimum of 1.';
      cy.get('@listField').clear();
      cy.get('@listField').find('input').type('0 {enter}');
      cy.get('@listField').find('.ngx-select-hint').should('contain', errorMessage);
      cy.get('@listField').clear();
      cy.get('@listField').find('input').type('1 {enter}');
      cy.get('@listField').find('.ngx-select-hint').should('not.contain', errorMessage);
    });
  });

  describe('readonly', () => {
    it('empty', () => {
      cy.getByLabel('Text List Readonly').as('listField');
      cy.get('@listField').should('contain', 'No value(s) selected');
    });

    it('non empty', () => {
      cy.getByLabel('Numeric List Readonly').as('listField');
      cy.get('@listField').within(() => {
        cy.get('ul li').as('li').should('have.length', 4);
        [0, 1, 2, 3].forEach(val => {
          cy.get('li').eq(val).should('contain', val);
        });
      });
    });
  });

  describe('help text', () => {
    it('below', () => {
      cy.getByLabel('Numeric List Help Text').closest('.list-field').as('listField');
      cy.get('@listField').find('.record-field__help-text--below').should('contain', 'Help Text');
    });

    it('above', () => {
      cy.getByLabel('Text List Help Text').closest('.list-field').as('listField');
      cy.get('@listField').find('.record-field__help-text--above').should('contain', 'Help Text');
    });
  });
});

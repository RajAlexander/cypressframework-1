import recordData from '../../../fixtures/mocks/swimlane/app/multi-fields/record/multi-fields_record/get.json';
import faker from 'faker/locale/en';

describe('Co-edit', () => {
  const applicationId = recordData.applicationId;
  const recordId = recordData.id;

  const singleLineId = 'ar4zo';
  const multiLineId = 'ae6sz';

  const MOCK_USER = {
    id: 'a35z27IBkF1YYkQeq',
    name: 'joetester'
  };

  const CURRENT_USER = {
    id: 'aO_RunwkwbYwkml6X',
    name: 'admin'
  };

  function triggerUpdate(values: Record<string, unknown>, modifiedByUser = CURRENT_USER) {
    cy.hubPublish('updated', 'records', {
      ...recordData,
      modifiedByUser,
      values: {
        ...recordData.values,
        ...values
      }
    });
    cy.wait(300); // co-edit messages are debounced by 150 ms
    cy.get('body').click(); // Need to force change detection (unknown issue)
  }

  function verifyPopup() {
    cy.get('.notification-content')
      .last()
      .whileHovering($el => {
        // Sometimes message is received twice.... check this
        cy.wrap($el).should('contain', 'Record updated by joetester'); // TODO: verify desired text
      });
    cy.ngxCloseNotifications();
  }

  function checkDirtyState(isDirty: boolean) {
    cy.get('.record-state__toolbar__controls .btn-primary button').should(
      isDirty ? 'not.have.attr' : 'have.attr',
      'disabled'
    );
  }

  before(() => {
    cy.login();
    cy.setupStubbedSwimlane();
    cy.setMockFeatureFlag('RecordPage');
    cy.navigateSwimlane(`/record2/${applicationId}/${recordId}`);
    cy.waitForNetworkIdle(2000);
  });

  describe('record not dirty', () => {
    before(() => {
      cy.getByLabel('Single Line').ngxFill('');
      cy.getByLabel('Multi Line').ngxFill('');
      cy.wait(300);
    });

    it(`rejects changes that are not on this record`, () => {
      const serverSingleLineChange = faker.random.words();

      checkDirtyState(false);
      cy.hubPublish('updated', 'records', {
        ...recordData,
        id: 'something_else',
        modifiedByUser: MOCK_USER,
        values: {
          ...recordData.values,
          [singleLineId]: serverSingleLineChange
        }
      });
      cy.wait(300); // co-edit messages are debounced by 150 ms
      cy.get('body').click(); // Need to force change detection (unknown issue)

      cy.getByLabel('Single Line').ngxFindNativeInput().should('have.value', '');
      checkDirtyState(false);
    });

    it(`doesn't show notification on updates by current user`, () => {
      const serverSingleLineChange = faker.random.words();
      checkDirtyState(false);
      triggerUpdate({ [singleLineId]: serverSingleLineChange });
      cy.getByLabel('Single Line').ngxFindNativeInput().should('have.value', serverSingleLineChange);
      checkDirtyState(false);
    });

    it('updates without any changes', () => {
      checkDirtyState(false);
      triggerUpdate({}, MOCK_USER);
      verifyPopup();
      checkDirtyState(false);
    });

    it('updates by another user', () => {
      const serverMultiLineChange = faker.lorem.sentences();
      checkDirtyState(false);
      triggerUpdate({ [multiLineId]: serverMultiLineChange }, MOCK_USER);
      verifyPopup();
      cy.getByLabel('Multi Line').ngxFindNativeInput().should('have.value', serverMultiLineChange);
      checkDirtyState(false);
    });
  });

  describe('dirty, without conflicts', () => {
    const localSingleLineChange = faker.random.words();

    before(() => {
      cy.getByLabel('Single Line').ngxFill(localSingleLineChange);
      cy.getByLabel('Multi Line').ngxFill('');
      cy.wait(300);
    });

    it('updates without any change', () => {
      checkDirtyState(true);
      triggerUpdate({}, MOCK_USER);
      verifyPopup();
      cy.getByLabel('Single Line').ngxFindNativeInput().should('have.value', localSingleLineChange);
      cy.getByLabel('Multi Line').ngxFindNativeInput().should('have.value', '');
      checkDirtyState(true);
    });

    it('updates with non-conflicting change', () => {
      const serverMultiLineChange = faker.lorem.sentences();
      checkDirtyState(true);
      triggerUpdate({ [multiLineId]: serverMultiLineChange }, MOCK_USER);
      verifyPopup();
      cy.getByLabel('Single Line').ngxFindNativeInput().should('have.value', localSingleLineChange);
      cy.getByLabel('Multi Line').ngxFindNativeInput().should('have.value', serverMultiLineChange);
      checkDirtyState(true);
    });

    it('resets dirty state when update match current change', () => {
      checkDirtyState(true);
      triggerUpdate({ [singleLineId]: localSingleLineChange }, MOCK_USER);
      verifyPopup();
      cy.getByLabel('Single Line').ngxFindNativeInput().should('have.value', localSingleLineChange);
      cy.getByLabel('Multi Line').ngxFindNativeInput().should('have.value', '');
      checkDirtyState(false);
    });
  });

  describe('dirty, with only conflicts', () => {
    let localSingleLineChange = faker.random.words();

    beforeEach(() => {
      localSingleLineChange = faker.random.words();

      cy.getByLabel('Single Line').ngxFill('');
      cy.getByLabel('Multi Line').ngxFill(localSingleLineChange);
      cy.wait(300);
    });

    it('accepts server changes', () => {
      const serverMultiLineChange = faker.lorem.sentences();

      checkDirtyState(true);
      triggerUpdate({ [multiLineId]: serverMultiLineChange }, MOCK_USER);
      verifyPopup();
      cy.get('.ngx-dialog-content')
        .should('exist')
        .within(() => {
          cy.get('.conflict-content').should(
            'contain.text',
            'This record has conflicts on the server introduced by another user or process'
          );
          cy.get('tbody tr').should('have.length', 1);
          cy.get('tr > .current').should('contain.text', localSingleLineChange);
          cy.get('tr.ng-star-inserted > :nth-child(3)').should('contain.text', serverMultiLineChange); // TODO: add class!!
          cy.getByLabel('Use server values').click();
          cy.contains('button', 'Apply').click();
        });
      cy.getByLabel('Single Line').ngxFindNativeInput().should('have.value', '');
      cy.getByLabel('Multi Line').ngxFindNativeInput().should('have.value', serverMultiLineChange);
      checkDirtyState(false);
    });

    it('accepts users changes', () => {
      const serverSingleLineChange = faker.random.words();

      checkDirtyState(true);
      triggerUpdate({ [multiLineId]: serverSingleLineChange }, MOCK_USER);
      verifyPopup();
      cy.get('.ngx-dialog-content')
        .should('exist')
        .within(() => {
          cy.get('.conflict-content').should(
            'contain.text',
            'This record has conflicts on the server introduced by another user or process'
          );
          cy.get('tbody tr').should('have.length', 1);
          cy.get('tr > .current').should('contain.text', localSingleLineChange);
          cy.get('tr.ng-star-inserted > :nth-child(3)').should('contain.text', serverSingleLineChange); // TODO: add class!!
          cy.getByLabel('Use my values').click();
          cy.contains('button', 'Apply').click();
        });
      cy.getByLabel('Single Line').ngxFindNativeInput().should('have.value', '');
      cy.getByLabel('Multi Line').ngxFindNativeInput().should('have.value', localSingleLineChange);
      checkDirtyState(true);
    });

    // requires previous step
    it('accepts users changes without dialog', () => {
      const serverSingleLineChange = faker.random.words();
      checkDirtyState(true);
      triggerUpdate({ [multiLineId]: serverSingleLineChange }, MOCK_USER);
      verifyPopup();
      cy.getByLabel('Single Line').ngxFindNativeInput().should('have.value', '');
      cy.getByLabel('Multi Line').ngxFindNativeInput().should('have.value', localSingleLineChange);
      checkDirtyState(true);
    });

    it('resets keep local changes on save', () => {
      cy.intercept('PUT', `/api/app/${applicationId}/record`, recordData).as('putRecord');
      cy.get('.record-state__toolbar__controls .btn-primary').click();
      cy.wait('@putRecord');

      cy.getByLabel('Single Line').ngxFill('');
      cy.getByLabel('Multi Line').ngxFill(localSingleLineChange);
      cy.wait(300);

      const serverMultiLineChange = faker.random.words();
      checkDirtyState(true);
      triggerUpdate({ [multiLineId]: serverMultiLineChange }, MOCK_USER);
      verifyPopup();
      cy.get('.ngx-dialog-content')
        .should('exist')
        .within(() => {
          cy.get('.conflict-content').should(
            'contain.text',
            'This record has conflicts on the server introduced by another user or process'
          );
          cy.get('tbody tr').should('have.length', 1);
          cy.get('tr > .current').should('contain.text', localSingleLineChange);
          cy.get('tr.ng-star-inserted > :nth-child(3)').should('contain.text', serverMultiLineChange); // TODO: add class!!
          cy.getByLabel('Use server values').click();
          cy.contains('button', 'Apply').click();
        });
      cy.getByLabel('Single Line').ngxFindNativeInput().should('have.value', '');
      cy.getByLabel('Multi Line').ngxFindNativeInput().should('have.value', serverMultiLineChange);
      checkDirtyState(false);
    });
  });

  describe('dirty, with conflicts and non-conflicts', () => {
    let localSingleLineChange = faker.random.words();
    let localMultiLineChange = faker.lorem.sentences();

    beforeEach(() => {
      localSingleLineChange = faker.random.words();
      localMultiLineChange = faker.lorem.sentences();

      cy.getByLabel('Single Line').ngxFill(localSingleLineChange);
      cy.getByLabel('Multi Line').ngxFill(localMultiLineChange);
      cy.wait(600);
    });

    it('accepts server changes', () => {
      const serverSingleLineChange = faker.random.words();

      checkDirtyState(true);
      triggerUpdate({ [multiLineId]: serverSingleLineChange }, MOCK_USER);
      verifyPopup();
      cy.get('.ngx-dialog-content')
        .should('exist')
        .within(() => {
          cy.get('.conflict-content').should(
            'contain.text',
            'This record has conflicts on the server introduced by another user or process'
          );
          cy.get('tbody tr').should('have.length', 1);
          cy.get('tr > .current').should('contain.text', localMultiLineChange);
          cy.get('tr.ng-star-inserted > :nth-child(3)').should('contain.text', serverSingleLineChange); // TODO: add class!!
          cy.getByLabel('Use server values').click();
          cy.contains('button', 'Apply').click();
        });
      cy.getByLabel('Single Line').ngxFindNativeInput().should('have.value', localSingleLineChange);
      cy.getByLabel('Multi Line').ngxFindNativeInput().should('have.value', serverSingleLineChange);
      checkDirtyState(true);
    });

    it('accepts users changes', () => {
      const serverMultiLineChange = faker.lorem.sentences();

      checkDirtyState(true);
      triggerUpdate({ [multiLineId]: serverMultiLineChange }, MOCK_USER);
      verifyPopup();
      cy.get('.ngx-dialog-content')
        .should('exist')
        .within(() => {
          cy.get('.conflict-content').should(
            'contain.text',
            'This record has conflicts on the server introduced by another user or process'
          );
          cy.get('tbody tr').should('have.length', 1);
          cy.get('tr > .current').should('contain.text', localMultiLineChange);
          cy.get('tr.ng-star-inserted > :nth-child(3)').should('contain.text', serverMultiLineChange); // TODO: add class!!
          cy.getByLabel('Use my values').click();
          cy.contains('button', 'Apply').click();
        });
      cy.getByLabel('Single Line').ngxFindNativeInput().should('have.value', localSingleLineChange);
      cy.getByLabel('Multi Line').ngxFindNativeInput().should('have.value', localMultiLineChange);
      checkDirtyState(true);
    });

    // requires previous step
    it('accepts users changes without dialog', () => {
      const serverMultiLineChange = faker.lorem.sentences();

      checkDirtyState(true);
      triggerUpdate({ [multiLineId]: serverMultiLineChange }, MOCK_USER);
      verifyPopup();
      cy.getByLabel('Single Line').ngxFindNativeInput().should('have.value', localSingleLineChange);
      cy.getByLabel('Multi Line').ngxFindNativeInput().should('have.value', localMultiLineChange);
      checkDirtyState(true);
    });
  });

  // TODO: multiple conflicts
});

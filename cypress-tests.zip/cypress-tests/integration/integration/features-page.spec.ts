const MOCK_FEATURE_FLAGS = [
  {
    id: 'Turbine',
    name: 'Turbine',
    description: 'Turbine feature gate',
    system: false,
    disabled: false
  },
  {
    id: 'Feature_1',
    name: 'whatever',
    description: 'wahtever feature gate',
    system: false,
    disabled: false
  },
  {
    id: 'Feature_2',
    name: 'heya',
    description: 'heya feature gate',
    system: false,
    disabled: true
  },
  {
    id: 'Feature_3',
    name: 'duck',
    description: 'duck feature gate',
    system: false,
    disabled: true
  },
  {
    id: 'Feature_4',
    name: 'goose dependent on duck',
    description: 'goose feature gate',
    system: false,
    disabled: true
  },
  {
    id: 'Feature_5',
    name: 'fox',
    description: 'fox feature gate',
    system: false,
    disabled: true
  },
  {
    id: 'Feature_6',
    name: 'mongoose cant touch me',
    description: 'mongoose feature gate',
    system: false,
    disabled: false
  }
];

const MOCK_SYSTEM_FLAGS = [
  {
    id: 'System_Feature_1',
    name: 'system feature 1',
    description: 'this is system feature 1',
    system: true,
    disabled: false
  },
  {
    id: 'System_Feature_2',
    name: 'system feature 2',
    description: 'this is system feature 2',
    system: true,
    disabled: false
  }
];

describe('Features', () => {
  before(() => {
    cy.login();

    cy.setupStubbedSwimlane();
    cy.intercept('/api/settings/features', MOCK_FEATURE_FLAGS).as('GET:settings/features');
    cy.intercept('/api/settings/features/enabled', MOCK_SYSTEM_FLAGS).as('GET:settings/features/enabled');
    cy.navigateSwimlane('/settings/features');

    cy.wait('@GET:settings/features/enabled');
  });

  describe('Header', () => {
    it('header should have title, subtitle, and proper icon', () => {
      cy.get('.header').find('h1').should('contain', 'Feature Settings');

      cy.get('.header').find('small').should('contain', 'Configuration');

      cy.get('.header').find('.ngx-icon').should('have.class', 'ngx-star-filled');
    });
  });

  describe('Content - user available features', () => {
    it('Feature toggles initially render correctly.', () => {
      MOCK_FEATURE_FLAGS.forEach(feature => {
        cy.get(`#${feature.id}`)
          .should('exist')
          .should(feature.disabled ? 'not.be.checked' : 'be.checked');
        cy.get('.feature-title').should('contain', feature.name);
      });
    });

    describe('Toggling feature dialog', () => {
      before(() => {
        cy.setupStubbedSwimlane();
      });

      it('Toggling a feature brings up confirm dialog, press yes to toggle', () => {
        // the first rendered flag toggle will be the second in the flag array, as it is the first flag with hidden: false.
        cy.get('ngx-toggle').first().as('toggle');

        // toggle starts turned on
        cy.get('@toggle').find('input').should('be.checked');

        cy.get('@toggle').click();

        cy.get('.ngx-dialog-content').should('exist').find('.header-text').should('contain', 'Are you sure?');

        // get Feature_1 flag
        const gate = MOCK_FEATURE_FLAGS[1];
        gate.disabled = !gate.disabled;

        cy.intercept('POST', '/api/settings/features/*', gate).as('toggleFeature');
        cy.get('ngx-button').click();
        cy.wait('@toggleFeature');

        // success notification shows
        cy.get('ngx-notification')
          .should('have.class', 'ngx-notification-success')
          .find('.ngx-notification-title')
          .should('contain', 'Feature toggled successfully.');

        // toggle has been turned off
        cy.get('@toggle').find('input').should('not.be.checked');
      });

      it('Toggling a feature brings up confirm dialog, press X to cancel', () => {
        cy.get('ngx-toggle').eq(1).as('toggle');

        // toggle starts turned off
        cy.get('@toggle').find('input').should('not.be.checked');

        cy.get('@toggle').click();

        cy.get('.ngx-dialog-content').should('exist').find('.header-text').should('contain', 'Are you sure?');

        cy.get('button.close').click();

        // toggle remains off
        cy.get('@toggle').find('input').should('not.be.checked');
      });
    });
  });

  describe('Content - system features', () => {
    it('Shows System Flags', () => {
      cy.get('.features-content__system-flags').within(() => {
        cy.get('.feature-flag-container').should('have.length', 2);
        MOCK_SYSTEM_FLAGS.forEach(feature => {
          cy.get('.feature-title').should('contain', feature.name);
        });
      });
    });
  });
});
